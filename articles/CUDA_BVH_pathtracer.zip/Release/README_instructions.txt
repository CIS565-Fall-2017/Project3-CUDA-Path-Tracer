Basic CUDA path tracer with SAH Bounding Volume Hierarchy

- Based on CUDA ray tracing code from https://github.com/ttsiodras/renderer and CUDA path tracing code from
https://github.com/peterkutz/GPUPathTracer 

- More information at http://raytracey.blogspot.co.nz/2016/01/gpu-path-tracing-tutorial-3-take-your.html

- C++/CUDA code at https://github.com/straaljager/GPU-path-tracing-tutorial-3

- Nvidia GPU (Fermi, Kepler or Maxwell: GeForce 400 series and up) required



INSTRUCTIONS

- Download the "dragon_recon.tar.gz" package from the Stanford 3d scanning repository 
(direct link: http://graphics.stanford.edu/pub/3Dscanrep/dragon/dragon_recon.tar.gz)

- Unzip the package and copy "dragon_vrip.ply" (the high res model) in the folder "data"

- The code for .ply file reading and BVH building is single threaded in this executable, but BVH building only needs to
be performed once as the BVH is stored in a file

- Navigate with mouse and keyboard:

- Mouse left button: rotate around center of the scene
- Mouse right button: zoom
- W, A, S, D, R, F: go forward/backwards/left/right/up/down
- G, H: change aperture/lens size
- T, Y: change focal distance


Sam Lapere, 2016