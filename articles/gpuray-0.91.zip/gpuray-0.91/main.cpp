/*
 * main.cpp --
 *
 *      Main routine for the Brook version of Tim Purcell's raytracer (or at
 *      least, what started life as Tim Purcell's raytracer).
 */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <assert.h>

#include "main.h"
#include "log.h"
#include "getopt.h"
#include "tracer.h"
#include "timer.h"

#ifndef BATCH_ONLY
#include "viewer.h"
#endif

/*
 * Usage --
 *
 *      Print program usage information and exit.
 *
 * Returns:
 *      void.
 */

void
Usage(const char *progName)
{
   fprintf(stderr,
           "Usage: %s <options>\n"
           "  Options:\n"
           "  -?, --help\n"
           "            This message\n"
           "  -a, --accelerator\n"
           "            Name of acceleration structure to use (voxelgrid or bruteforce)\n"
           "            (default: voxelgrid)\n"
           "  --accelOpt key=value\n"
           "            Pass option to selected accelerator\n"
           "  -b, --buildOnly\n"
           "            Construct the accelerator and then exit\n"
           "  --brook\n"
           "            Use the brook GPU version of the code\n"
           "  --ctm\n"
           "            Use the CTM version of the code\n"
           "  --brookShade\n"
           "            Use the CPU for acceleration, but brook for shading\n"
           "  --buildOpt key=value\n"
           "            Pass option to accelerator builder\n"
           "  -c, --cpu\n"
           "            Use the CPU instead of the GPU\n"
           "  -d, --debug <filename>\n"
           "            Logs a whole lot of state to <filename>\n"
           "  -D, --d3d\n"
           "            Uses the power of DirectX\n"
           "  --dumpRays <filename>\n"
           "            Dumps generated rays to the specified file (big-endian)\n"
           "  -f, --fullscreen\n"
           "            Make d3d app go fullscreen\n"
           "  -h, --height\n"
           "            Height for the image produced (256)\n"
           "  -l, --lighting\n"
           "            Lighting model to use (simple | false | shadow | whitted | diffuse)\n"
           "            (default: simple)\n"
           "  -o, --imageFile\n"
           "            Filename for the image produced (out.ppm)\n"
           "  -p, --packet\n"
           "            Trace packets of rays at a time\n"
           "  -q, --quiet\n"
           "            Print very little\n"
           "  -s, --scene\n"
           "            Name of the scene to raytrace (cbox glassner terrain)\n"
           "            (default: cbox)\n"
           "  --size <N>\n"
           "            Render an NxN image\n"
           "  -t, --timing\n"
           "            Time the core kernels for the current accelerator\n"
           "  -v, --verbose\n"
           "            Print extra information while running\n"
           "  -w, --width\n"
           "            Width for the image produced (256)\n"
           "  -x, --windowWidth\n"
           "            Width for the display window\n"
           "  -y, --windowHeight\n"
           "            Width for the display window\n",

           progName);
   exit(1);
}

enum LongOnlyOptions
{
   BROOK_OPTION = 256,
   BROOK_SHADE_OPTION,
   DUMP_RAYS_OPTION,
   SIZE_OPTION,
   ACCEL_OPT_OPTION,
   SHADE_OPT_OPTION,
   BUILD_OPT_OPTION,
   CTM_OPTION ,
};

/* GetKeyValueInt --
 *
 *      Finds and returns the value of
 *      an integer key=value option with the
 *      specified key or, if none is found,
 *      return the provided default.
 *
 *      If the same key appears multiple times,
 *      only the last value will be used.
 *
 * Returns:
 *      The result of atoi on the found
 *      value string if found, the provided
 *      default otherwise.
 * 
 */

extern int
GetKeyValueInt(const char* key,
               const std::vector<KeyValuePair>& opts,
               int defaultValue)
{
   int index = opts.size();
   while( index-- )
   {
      if( strcmp( opts[index].key.c_str(), key ) == 0 )
         return atoi( opts[index].value.c_str() );
   }
   return defaultValue;

}
extern const char*
GetKeyValueString(const char* key,
               const std::vector<KeyValuePair>& opts,
               const char* defaultValue)
{
   int index = opts.size();
   while( index-- )
   {
      if( strcmp( opts[index].key.c_str(), key ) == 0 )
         return opts[index].value.c_str() ;
   }
   return defaultValue;

}


extern float
GetKeyValueFloat(const char* key,
               const std::vector<KeyValuePair>& opts,
               float defaultValue)
{
   int index = opts.size();
   while( index-- )
   {
      if( strcmp( opts[index].key.c_str(), key ) == 0 )
		  return (float)atof( opts[index].value.c_str() );
   }
   return defaultValue;
}

/* ParseKeyValueOpt --
 *
 *      Parses a key=value option and stores
 *      it into the argument vector.
 *
 * Returns:
 *      void.
 * 
 */

static void
ParseKeyValueOpt(const char* optionString,
                 std::vector<KeyValuePair>& options)
{
   const char* equalPos = strchr( optionString, '=' );
   if( equalPos == NULL ) {
      fprintf( stderr, "Invalid accelerator option '%s'", optionString );
      fflush( stderr );
      exit( 1 );
   }

   size_t keyCharacterCount = equalPos - optionString;
   const char* valueString = equalPos + 1;
   
   options.push_back( KeyValuePair(
      std::string( optionString, keyCharacterCount ),
      std::string( valueString ) ) );
}

/*
 * ParseOpts --
 *
 *      Process all the commandline options and set the various options
 *      accordingly.
 *
 * Returns:
 *      void.
 */

static void
ParseOpts(int *argc, char *argv[], Opts *opts)
{
   int opt;
   int opt_index;

   static struct option long_options[] = {
      {"help",         0, 0, '?'},
      {"accelerator",  1, 0, 'a'},
      {"accelOpt",     1, 0, ACCEL_OPT_OPTION},
      {"shadeOpt",     1, 0, SHADE_OPT_OPTION},
      {"brook",        0, 0, BROOK_OPTION},
      {"ctm",        0, 0,   CTM_OPTION},
      {"brookShade",   0, 0, BROOK_SHADE_OPTION},
      {"buildOnly",    0, 0, 'b'},
      {"buildOpt",     1, 0, BUILD_OPT_OPTION},
      {"cpu",          0, 0, 'c'},
      {"debug",        1, 0, 'd'},
      {"gdi",          0, 0, 'G'},
      {"d3d",          0, 0, 'D'},
      {"fullscreen",          0, 0, 'f'},
      {"dumpRays",     1, 0, DUMP_RAYS_OPTION},
      {"height",       1, 0, 'h'},
      {"lighting",     1, 0, 'l'},
      {"imageFile",    1, 0, 'o'},
      {"packet",       0, 0, 'p'},
      {"quiet",        0, 0, 'q'},
      {"rasterize",    0, 0, 'r'},
      {"scene",        1, 0, 's'},
      {"size",         1, 0, SIZE_OPTION},
      {"timing",       0, 0, 't'},
      {"verbose",      0, 0, 'v'},
      {"width",        1, 0, 'w'},
      {"windowWidth",  1, 0, 'x'},
      {"windowHeight", 1, 0, 'y'},
      {0, 0, 0, 0}
   };
   opts->progName = argv[0];
   opts->fullscreen=false;
   while ((opt = getopt_long(*argc, argv, "?a:bcd:Dfl:h:o:pqrs:tvw:x:y:",
                             long_options, &opt_index)) != EOF) {
      switch (opt) {
      case 'a': opts->accelName = optarg;            break;
      case ACCEL_OPT_OPTION:
                ParseKeyValueOpt(
                   optarg, opts->accelOpts );        break;

      case SHADE_OPT_OPTION:
                ParseKeyValueOpt(
                   optarg, opts->shadeOpts );        break;

      case 'b': opts->buildOnly = true;              break;
      case BROOK_SHADE_OPTION: opts->brookShade = true;  break;
      case BROOK_OPTION: opts->brook = true;         break;
      case CTM_OPTION: opts->ctm = true;         break;
      case BUILD_OPT_OPTION:
                ParseKeyValueOpt(
                   optarg, opts->buildOpts );        break;
      case 'c': /* Nothing, legacy */                break;
      case 'd': opts->logName = optarg;              break;
      case 'D': opts->d3d = true;                    break;
      case 'G': opts->gdi = true;                    break;
      case DUMP_RAYS_OPTION:
                opts->dumpRaysFile = optarg;         break;
      case 'f': opts->fullscreen = true; break;
      case 'h': opts->height = atoi(optarg);         break;
      case 'l': opts->shaderName = optarg;           break;
      case 'o': opts->imageFile = optarg;            break;
      case 'p': opts->packets = true;                break;
      case 'q': _quiet = true;                       break;
      case 'r': opts->rasterize = true;              break;
      case 's': opts->sceneName = optarg;            break;
      case SIZE_OPTION: opts->width = opts->height = atoi(optarg); break;
      case 't': opts->genTimings = true;             break;
      case 'v': opts->verbose = true;                break;
      case 'w': opts->width = atoi(optarg);          break;
      case 'x': opts->windowWidth = atoi(optarg);    break;
      case 'y': opts->windowHeight = atoi(optarg);   break;

      case '?':
      default: Usage(opts->progName);                break;
      }
   }
   argv += optind;
   *argc -= optind;
   if (*argc < 0) {
     Usage(opts->progName);
   }

   if (opts->logName != NULL) {
      Log_Open(opts->logName);
   }

   if (opts->windowWidth <= 0) {
      opts->windowWidth = opts->width;
   }
   if (opts->windowHeight <= 0) {
      opts->windowHeight = opts->height;
   }
   PRINTTIME(("Raytracing the '%s' scene using %s acceleration.\n",
              opts->sceneName, opts->accelName ? opts->accelName : "default"));
}

/*
 * RenderInteractive --
 *
 *     Run an interactive ray tracing session. Uses
 *     the specified options
 *
 * Returns:
 *     void.
 */

static void
RenderInteractive( const Opts& opts )
{
#ifndef BATCH_ONLY
  Viewer* viewer = new Viewer();
  if (viewer->Create(opts)) {
     viewer->MakeVisible(true);
     viewer->PumpMsgs(true);
     viewer->Destroy();
  } else {
     PRINT(("Unable to create a viewer!\n"));
  }
  delete viewer;
#else
  PRINT(("Interactive mode is not available.\n"));
  exit(1);
#endif
}

/*
 * main --
 *
 *      Entry point for the raytracer.  Raytraces the specified scene and
 *      writes out the resulting image.
 *
 * Returns:
 *      0 on success
 */

int
main(int argc, char **argv)
{
   Opts opts = {
      /* progName: */   NULL,

      /* sceneName: */  "cbox",
#ifndef BATCH_ONLY
      /* imageFile: */  NULL,
#else
      /* imageFile: */  "out.ppm",
#endif
      /* width: */      256,
      /* height: */     256,
      /* windowWidth: */  -1,
      /* windowHeight: */ -1,
      /* accelName: */  NULL,
      /* shaderName: */ NULL,
      /* logName: */    NULL,
      /* dumpRaysFile: */ NULL
   };
   Timer_Reset();

   ParseOpts(&argc, argv, &opts);

   if (opts.imageFile == NULL) {
     RenderInteractive( opts );
   } else {
      PRINT(("Writing image to %s.\n", opts.imageFile));
      ::RenderOffline( opts );
   }
   return 0;
}
