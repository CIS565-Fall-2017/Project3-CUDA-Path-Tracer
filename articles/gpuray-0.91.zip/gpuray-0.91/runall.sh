sh runone.sh cbox minNodeExtentRatio=10000000 3 $1 $2 $3 $4
sh runone.sh kitchen  minNodeExtentRatio=10000000 2 $1 $2 $3 $4
sh runone.sh robots minNodeExtentRatio=10000000 1 $1 $2 $3 $4
sh runone.sh conference nop=1 3 $1 $2 $3 $4
#sh runone.sh cbox nop=1 3 $1
#sh runone.sh kitchen nop=1 2 $1
#sh runone.sh robots nop=1 1 $1
