/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * cameraManager.cpp --
 *
 *      Class to hide details of moving a camera within a scene.
 */
#include "cameraManager.h"

#include "log.h"

/*
 * Some constants that control the rates at which the camera moves in
 * various directions.  I have no explanation for why these are distinct
 * from the per-scene movementScale unless they were here first.
 */

static const Vec2f kSceneRotationScale( 0.2f, 0.2f );
static const float kCameraPitchScale = 0.05f;
static const float kCameraYawScale = -0.05f;


void
SceneTransformation::Rotate(const quaternion& q)
{
   _rotation *= q;
}

Vec3f
SceneTransformation::transformPoint(const Vec3f& p) const
{
   Vec3f v( p.x - _center.x, p.y - _center.y, p.z - _center.z );
   v = transformVector( v );
   return Vec3f( v.x + _center.x, v.y + _center.y, v.z + _center.z );
}

Vec3f
SceneTransformation::transformVector(const Vec3f& v) const
{
   return _rotation.transformVector(v);
}


/*
 * CameraManager::CameraManager --
 *
 *      Constructor.  Given a scene to view and an image size
 *      initializes a manager for computing and updating
 *      camera positions into that scene.
 *
 * Results:
 *      None (other than construction)
 */

CameraManager::CameraManager(Scene* inScene, int inWidth, int inHeight)
{
   _scene = inScene;
   _width = inWidth;
   _height = inHeight;

   ResetScene();
}


/*
 * CameraManager::~CameraManager --
 *
 *      Destructor.
 *
 * Results:
 *      void.
 */

CameraManager::~CameraManager(void)
{
}

/*
 * CameraManager::ResetScene --
 *
 *      Sets the scene parameters back to the defaults.
 *
 * Results:
 *      void.
 */

void
CameraManager::ResetScene(void)
{
   _sceneTransformation.SetCenter( _scene->center() );
   _sceneTransformation.SetRotation( quaternion::identity() );

   _worldSpaceCameraFrame.position = _scene->lookFrom();

   Vec3f direction = normalize( _scene->lookAt() - _scene->lookFrom() );

   _defaultUp = normalize( _scene->up() );
   // pick a basis around the up vector
   int minAxis = 0;
   if( fabs( _defaultUp[1] ) < fabs( _defaultUp[minAxis] ) )
      minAxis = 1;
   if( fabs( _defaultUp[2] ) < fabs( _defaultUp[minAxis] ) )
      minAxis = 2;
   _defaultU = Vec3f(0.0f);
   _defaultU[minAxis] = 1.0f;
   _defaultV = normalize( cross( _defaultU, _defaultUp ) );
   _defaultU = normalize( cross( _defaultUp, _defaultV ) );

   _worldSpaceCameraFrame.yaw = atan2f( dot( direction, _defaultU ),
                                        dot( direction, _defaultV ) );
   _worldSpaceCameraFrame.pitch = -asinf( dot( direction, _defaultUp ) );
   _worldSpaceCameraFrame.roll = 0;

   CreateSceneSpaceCamera();
}


void
CameraManager::ResetScene(Vec3f center, Vec3f Target, Vec3f up)
{
//   _sceneTransformation.SetCenter( _scene->center() );
//   _sceneTransformation.SetRotation( quaternion::identity() );

   _worldSpaceCameraFrame.position = center;

   Vec3f direction = normalize( Target - center );

   _defaultUp = normalize( up );
   // pick a basis around the up vector
   int minAxis = 0;
   if( fabs( _defaultUp[1] ) < fabs( _defaultUp[minAxis] ) )
      minAxis = 1;
   if( fabs( _defaultUp[2] ) < fabs( _defaultUp[minAxis] ) )
      minAxis = 2;
   _defaultU = Vec3f(0.0f);
   _defaultU[minAxis] = 1.0f;
   _defaultV = normalize( cross( _defaultU, _defaultUp ) );
   _defaultU = normalize( cross( _defaultUp, _defaultV ) );

   _worldSpaceCameraFrame.yaw = atan2f( dot( direction, _defaultU ),
                                        dot( direction, _defaultV ) );
   _worldSpaceCameraFrame.pitch = -asinf( dot( direction, _defaultUp ) );
   _worldSpaceCameraFrame.roll = 0;

   CreateSceneSpaceCamera();
}


/*
 * CameraManager::PrintScene --
 *
 *      Prints the scene parameters.
 *
 * Results:
 *      void.
 */

void
CameraManager::PrintScene(void)
{
   Vec3f from = _worldSpaceCameraFrame.position;
   Vec3f up = _sceneSpaceCameraFrame.up;
   Vec3f direction = _sceneSpaceCameraFrame.direction;
   PRINT(("lookFrom:\tfloat3(%f, %f, %f)\n",
          from.x, from.y, from.z));
   PRINT(("up:\tfloat(%f, %f, %f)\n",
          up.x, up.y, up.z));
   PRINT(("direction:\tfloat(%f, %f, %f)\n",
          direction.x, direction.y, direction.z));
   PRINT(("fov:\t\t%f\n", _scene->fov()));
}


/*
 * CameraManager::MoveCamera --
 *
 *      Adjusts the camera by the given amount (scaled by a
 *      per-scene factor) and rebuilds the various
 *      dependent properties.
 *
 * Results:
 *      void.
 */

void
CameraManager::MoveCamera(float dx, float dy)
{
   CameraFrame frame;
   CreateCameraFrame( _worldSpaceCameraFrame, frame );

   Vec3f forward = frame.direction;
   Vec3f right = normalize( cross( forward, frame.up ) );

   Vec3f delta;

   delta.x = dx*right.x + dy*forward.x;
   delta.y = dx*right.y + dy*forward.y;
   delta.z = dx*right.z + dy*forward.z;

   _worldSpaceCameraFrame.position.x += delta.x * _scene->movementScale();
   _worldSpaceCameraFrame.position.y += delta.y * _scene->movementScale();
   _worldSpaceCameraFrame.position.z += delta.z * _scene->movementScale();

   CreateSceneSpaceCamera();
}

/*
 * CameraManager::RotateCamera --
 *
 *      Incrementally rotates the camera by
 *      the specified yaw and pitch amounts
 *      (scaled by a constant factor).
 *
 * Results:
 *      void.
 */

void
CameraManager::RotateCamera(float dx, float dy)
{
   _worldSpaceCameraFrame.pitch += kCameraPitchScale * dy;
   _worldSpaceCameraFrame.yaw += kCameraYawScale * dx;

   CreateSceneSpaceCamera();
}

/*
 * CameraManager::RotateScene --
 *
 *      Rotates the scene itself, relative to the user's
 *      current view, and recalculates the appropriate
 *      transformations.
 *
 * Results:
 *      void.
 */

void
CameraManager::RotateScene( float dx, float dy )
{
   quaternion _xRotation = quaternion::fromAxisAngle( Vec3f(0,1,0), dx * kSceneRotationScale.x );
   quaternion _yRotation = quaternion::fromAxisAngle( Vec3f(1,0,0), dy * kSceneRotationScale.x );

   _sceneTransformation.Rotate( _xRotation * _yRotation );

   CreateSceneSpaceCamera();
}

/*
 * CameraManager::CreateCameraFrame --
 *
 *      Creates a glLookAt-style camera representation
 *      from a typical first-person camera that specifies only
 *      position and pitch/yaw/roll.
 *
 * Results:
 *      void.
 */

void CameraManager::CreateCameraFrame( const FPSCameraFrame& inFPSCamera, CameraFrame& outFrame )
{
   Vec3f position = inFPSCamera.position;
   float pitchAngle = inFPSCamera.pitch;
   float yawAngle = inFPSCamera.yaw;

   quaternion yawRotation = quaternion::fromAxisAngle( Vec3f( 0, 1, 0 ), yawAngle );
   quaternion pitchRotation = quaternion::fromAxisAngle( Vec3f( 1, 0, 0 ), pitchAngle );

   quaternion rotation = yawRotation * pitchRotation;
   Vec3f direction = rotation.transformVector( Vec3f( 0, 0, 1 ) );

   outFrame.position = position;
   outFrame.direction = direction.x * _defaultU
                      + direction.y * _defaultUp
                      + direction.z * _defaultV;
   outFrame.up = _defaultUp;
}

/*
 * CameraManager::CreateCameraInfo --
 *
 *      Creates a raytracing-appropriate camera
 *      from a glLookAt-style on.
 *
 * Results:
 *      void.
 */

void
CameraManager::CreateCameraInfo( const CameraFrame& inCameraFrame, CameraInfo& outInfo )
{
   Vec3f position = inCameraFrame.position;
   Vec3f direction = inCameraFrame.direction;
   Vec3f up = inCameraFrame.up;

   CameraInfo info;

   info.from = position;
   info.w = normalize(direction);
   info.u = normalize(cross(up, info.w));
   info.v = normalize(cross(info.w, info.u));
   info.ty = tanf((M_PI/180.0f*_scene->fov()) / 2.0f);
   info.tx = info.ty * ((float) _width / _height);

   outInfo = info;
}

/*
 * CameraManager::CreateSceneSpaceCamera --
 *
 *      Updates the scene-relative camera information
 *      after a change in viewing parameters.
 *
 * Results:
 *      void.
 */

void
CameraManager::CreateSceneSpaceCamera()
{
   CameraFrame frame;

   CreateCameraFrame( _worldSpaceCameraFrame, frame );

   _sceneSpaceCameraFrame.position =
      _sceneTransformation.transformPoint( frame.position );
   _sceneSpaceCameraFrame.direction =
      _sceneTransformation.transformVector( frame.direction );
   _sceneSpaceCameraFrame.up =
      _sceneTransformation.transformVector( frame.up );

   CreateCameraInfo( _sceneSpaceCameraFrame, _sceneSpaceCameraInfo );
}
