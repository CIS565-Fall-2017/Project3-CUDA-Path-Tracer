/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * renderContext.h --
 *
 *      Interfaces for dealing with graphics APIs
 */

#ifndef __RENDERCONTEXT_H__
#define __RENDERCONTEXT_H__

#ifdef _WIN32
#include <windows.h>
#else
#include <X11/Xlib.h>
#include <GL/glx.h>
#endif

class IRenderSystem;
class IRenderContext;

/*
 * IRenderSystem --
 *
 *      Interface for rendering APIs. Allows for
 *      retrieval of the API name, as well as
 *      for the creation of rendering contexts
 *      given a platform window handle.
 *
 */

class IRenderSystem {
public:
   virtual const char* getRenderSystemID() = 0;
#ifdef _WIN32
   virtual IRenderContext* createRenderContext( HWND inWindowHandle ) = 0;
#else
   virtual IRenderContext* createRenderContext( Display *display,
                                                Window win, XVisualInfo *visInfo ) = 0;
#endif
};

/*
 * IRenderContext --
 *
 *      A wrapper around a render context (a specific
 *      graphic API interface to a window or other
 *      frame buffer).
 *
 */

class IRenderContext {
public:
   virtual IRenderSystem* getRenderSystem() = 0;
   virtual void* getContextHandle() = 0;

   virtual void resize( int inWidth, int inHeight ) = 0;
};

#endif
