/*
 * vec2f.h --
 *
 *      Basic type for 2D points/vectors
 */

#ifndef __COMMON_VEC2F_H__
#define __COMMON_VEC2F_H__

#include <math.h>

#include "commonOperations.h"

class Vec2f
{
public:
   Vec2f()
   {
   }

   explicit Vec2f( float inScalar )
      : x(inScalar), y(inScalar)
   {
   }

   Vec2f( float inX, float inY )
      : x(inX), y(inY)
   {
   }

   operator const float*() const
   {
      return &x;
   }

   operator float*()
   {
      return &x;
   }

   float x, y;
};

inline Vec2f operator+( Vec2f inLeft, Vec2f inRight )
{
   return Vec2f( inLeft.x + inRight.x, inLeft.y + inRight.y );
}

inline Vec2f operator-( Vec2f inLeft, Vec2f inRight )
{
   return Vec2f( inLeft.x - inRight.x, inLeft.y - inRight.y );
}

inline Vec2f operator*( Vec2f inLeft, Vec2f inRight )
{
   return Vec2f( inLeft.x * inRight.x, inLeft.y * inRight.y );
}

inline Vec2f operator*( Vec2f inLeft, float inRight )
{
   return Vec2f( inLeft.x * inRight, inLeft.y * inRight );
}

inline Vec2f operator*( float inLeft, Vec2f inRight )
{
   return Vec2f( inLeft * inRight.x, inLeft * inRight.y );
}

inline Vec2f operator/( Vec2f inLeft, Vec2f inRight )
{
   return Vec2f( inLeft.x / inRight.x, inLeft.y / inRight.y );
}

inline Vec2f operator/( Vec2f inLeft, float inRight )
{
   return inLeft * (1.0f / inRight);
}

inline Vec2f operator/( float inLeft, Vec2f inRight )
{
   return Vec2f( inLeft / inRight.x, inLeft / inRight.y );
}

inline Vec2f minimum( Vec2f inLeft, Vec2f inRight )
{
   return Vec2f( minimum( inLeft.x, inRight.x ), minimum( inLeft.y, inRight.y ) );
}

inline Vec2f maximum( Vec2f inLeft, Vec2f inRight )
{
   return Vec2f( maximum( inLeft.x, inRight.x ), maximum( inLeft.y, inRight.y ) );
}

inline Vec2f abs( Vec2f inValue )
{
   return Vec2f( abs( inValue.x ), abs( inValue.y ) );
}

inline float dot( Vec2f inLeft, Vec2f inRight ) {
   return inLeft.x * inRight.x + inLeft.y * inRight.y;
}

inline float length( Vec2f inValue ) {
   return sqrtf( dot( inValue, inValue ) );
}

inline Vec2f normalize( Vec2f inValue ) {
   return inValue / length( inValue );
}

#endif
