/*
 * boundingBox.h --
 *
 *      Basic type for axis-aligned bounding box
 */

#ifndef __COMMON_BOUNDINGBOX_H__
#define __COMMON_BOUNDINGBOX_H__

#include "vec3f.h"

#include <float.h>

class BoundingBox
{
public:
   BoundingBox()
      : minimum( FLT_MAX ),
      maximum( -FLT_MAX )
   {
   }

   explicit BoundingBox( const Vec3f& inValue )
      : minimum( inValue ), maximum( inValue )
   {
   }

   BoundingBox( const BoundingBox& inOther )
      : minimum( inOther.minimum ),
      maximum( inOther.maximum )
   {
   }

   BoundingBox( const Vec3f inMinimum, const Vec3f inMaximum )
      : minimum( inMinimum ),
      maximum( inMaximum )
   {
   }

   float getSurfaceArea() const
   {
      Vec3f extents = abs( maximum - minimum );
      return 2*( extents.x*extents.y + extents.y*extents.z + extents.z*extents.x );
   }

   BoundingBox expandedBy( Vec3f inDelta )
   {
      return BoundingBox( minimum - inDelta, maximum + inDelta );
   }

   BoundingBox expandedBy( float inDelta )
   {
      return expandedBy( Vec3f( inDelta ) );
   }

   Vec3f minimum;
   Vec3f maximum;
};

inline BoundingBox join( const BoundingBox& inLeft, const BoundingBox& inRight )
{
   BoundingBox result;
   result.minimum = minimum( inLeft.minimum, inRight.minimum );
   result.maximum = maximum( inLeft.maximum, inRight.maximum );
   return result;
}

inline BoundingBox join( const BoundingBox& inLeft, Vec3f inRight )
{
   BoundingBox result;
   result.minimum = minimum( inLeft.minimum, inRight );
   result.maximum = maximum( inLeft.maximum, inRight );
   return result;
}

inline BoundingBox intersect( const BoundingBox& inLeft, const BoundingBox& inRight )
{
   BoundingBox result;
   result.minimum = maximum( inLeft.minimum, inRight.minimum );
   result.maximum = minimum( inLeft.maximum, inRight.maximum );
   return result;
}

#endif
