
/*
 * commonOperations.h --
 *
 *      Basic operations on primitive types
 */

#ifndef __COMMON_COMMONOPERATIONS_H__
#define __COMMON_COMMONOPERATIONS_H__
#include <math.h>

#ifdef WINDOWS
#include <string.h>
#else
#include <strings.h>
#endif

template<typename T>
inline T minimum( T inLeft, T inRight )
{
   return inLeft < inRight ? inLeft : inRight;
}

template<typename T>
inline T maximum( T inLeft, T inRight )
{
   return inLeft > inRight ? inLeft : inRight;
}

template<typename T>
inline T abs( T inValue )
{
   return inValue < 0 ? -inValue : inValue;
}

inline int CompareNoCase( const char* left, const char* right )
{
#ifdef WINDOWS
  return stricmp( left, right );
#else
  return strcasecmp( left, right );
#endif
}

#endif
