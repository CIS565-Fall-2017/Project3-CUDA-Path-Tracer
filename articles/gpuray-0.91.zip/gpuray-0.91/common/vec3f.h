/*
 * vec3f.h --
 *
 *      Basic type for 3D points/vectors
 */

#ifndef __COMMON_VEC3F_H__
#define __COMMON_VEC3F_H__

#include <math.h>

#include "commonOperations.h"

class Vec3f
{
public:
   Vec3f()
   {
   }

   explicit Vec3f( float inScalar )
      : x(inScalar), y(inScalar), z(inScalar)
   {
   }

   Vec3f( float inX, float inY, float inZ )
      : x(inX), y(inY), z(inZ)
   {
   }

   operator const float*() const
   {
      return &x;
   }

   operator float*()
   {
      return &x;
   }

   Vec3f& operator+=( Vec3f inValue )
   {
      x += inValue.x;
      y += inValue.y;
      z += inValue.z;
      return *this;
   }

   Vec3f& operator-=( Vec3f inValue )
   {
      x -= inValue.x;
      y -= inValue.y;
      z -= inValue.z;
      return *this;
   }

   float x, y, z;
};

inline Vec3f operator+( Vec3f inLeft, Vec3f inRight )
{
   return Vec3f( inLeft.x + inRight.x, inLeft.y + inRight.y, inLeft.z + inRight.z );
}

inline Vec3f operator-( Vec3f inLeft, Vec3f inRight )
{
   return Vec3f( inLeft.x - inRight.x, inLeft.y - inRight.y, inLeft.z - inRight.z );
}

inline Vec3f operator*( Vec3f inLeft, Vec3f inRight )
{
   return Vec3f( inLeft.x * inRight.x, inLeft.y * inRight.y, inLeft.z * inRight.z );
}

inline Vec3f operator*( Vec3f inLeft, float inRight )
{
   return Vec3f( inLeft.x * inRight, inLeft.y * inRight, inLeft.z * inRight );
}

inline Vec3f operator*( float inLeft, Vec3f inRight )
{
   return Vec3f( inLeft * inRight.x, inLeft * inRight.y, inLeft * inRight.z );
}

inline Vec3f operator/( Vec3f inLeft, Vec3f inRight )
{
   return Vec3f( inLeft.x / inRight.x, inLeft.y / inRight.y, inLeft.z / inRight.z );
}

inline Vec3f operator/( Vec3f inLeft, float inRight )
{
   return inLeft * (1.0f / inRight);
}

inline Vec3f operator/( float inLeft, Vec3f inRight )
{
   return Vec3f( inLeft / inRight.x, inLeft / inRight.y, inLeft / inRight.z );
}

inline Vec3f minimum( Vec3f inLeft, Vec3f inRight )
{
   return Vec3f( minimum( inLeft.x, inRight.x ), minimum( inLeft.y, inRight.y ), minimum( inLeft.z, inRight.z ) );
}

inline Vec3f maximum( Vec3f inLeft, Vec3f inRight )
{
   return Vec3f( maximum( inLeft.x, inRight.x ), maximum( inLeft.y, inRight.y ), maximum( inLeft.z, inRight.z ) );
}

inline Vec3f abs( Vec3f inValue )
{
   return Vec3f( abs( inValue.x ), abs( inValue.y ), abs( inValue.z ) );
}

inline float dot( Vec3f inLeft, Vec3f inRight ) {
   return inLeft.x * inRight.x + inLeft.y * inRight.y + inLeft.z * inRight.z;
}

inline Vec3f cross( Vec3f inLeft, Vec3f inRight )
{
   return Vec3f(
      inLeft.y * inRight.z - inLeft.z * inRight.y,
      inLeft.z * inRight.x - inLeft.x * inRight.z,
      inLeft.x * inRight.y - inLeft.y * inRight.x );
}

inline float length( Vec3f inValue ) {
   return sqrtf( dot( inValue, inValue ) );
}

inline Vec3f normalize( Vec3f inValue ) {
   return inValue / length( inValue );
}

#endif
