/*
 * endian.h --
 *
 *      Functions to deal with endianess conversion.
 */

#ifndef COMMON_ENDIAN_H
#define COMMON_ENDIAN_H

#include "commonTypes.h"

#ifndef __BIG_ENDIAN__
#ifndef __LITTLE_ENDIAN__
// XXX: default to little-endian for now
#define __LITTLE_ENDIAN__
#endif
#endif

static inline uint16
swapEndianness( uint16 x )
{
   union { uint8 a[2]; uint16 x; } from, to;
   from.x = x;
   to.a[0] = from.a[1];
   to.a[1] = from.a[0];
   return to.x;
}

static inline sint16
swapEndianness( sint16 x )
{
  return (sint16) swapEndianness( (uint16) x );
}

static inline uint32
swapEndianness( uint32 x )
{
  union { uint8 a[4]; uint32 x; } from, to;
  from.x = x;
  to.a[0] = from.a[3];
  to.a[1] = from.a[2];
  to.a[2] = from.a[1];
  to.a[3] = from.a[0];
  return to.x;
}

static inline sint32
swapEndianness( sint32 x )
{
  return (sint32) swapEndianness( (uint32) x );
}

static inline float
swapEndianness( float x )
{
  union { float f; uint32 i; } converter;
  converter.f = x;
  converter.i = swapEndianness( converter.i );
  return converter.f;
}

static inline double
swapEndianness( double x )
{
   union { uint8 a[8]; double x; } from, to;
   from.x = x;
   to.a[0] = from.a[7];
   to.a[1] = from.a[6];
   to.a[2] = from.a[5];
   to.a[3] = from.a[4];
   to.a[4] = from.a[3];
   to.a[5] = from.a[2];
   to.a[6] = from.a[1];
   to.a[7] = from.a[0];
   return to.x;
}


template<typename T>
static inline T
fromLittleEndian( T x )
{
#ifdef __LITTLE_ENDIAN__
  return x;
#else
  return swapEndianness( x );
#endif
}

template<typename T>
static inline T
fromBigEndian( T x )
{
#ifdef __BIG_ENDIAN__
  return x;
#else
  return swapEndianness( x );
#endif
}

template<typename T>
static inline T
toLittleEndian( T x )
{
#ifdef __LITTLE_ENDIAN__
  return x;
#else
  return swapEndianness( x );
#endif
}

template<typename T>
static inline T
toBigEndian( T x )
{
#ifdef __BIG_ENDIAN__
  return x;
#else
  return swapEndianness( x );
#endif
}



#endif
