/*
 * integerTypes.h --
 *
 *      Basic type defines
 */

#ifndef __COMMON__INTEGERTYPES__
#define __COMMON__INTEGERTYPES__

typedef signed char     sint8;
typedef signed short    sint16;
typedef signed int      sint32;

typedef unsigned char   uint8;
typedef unsigned short  uint16;
typedef unsigned int    uint32;

#ifdef WINDOWS
typedef signed __int64     sint64;
typedef unsigned __int64   uint64;
#else
typedef signed long long   sint64;
typedef unsigned long long uint64;
#endif

#endif
