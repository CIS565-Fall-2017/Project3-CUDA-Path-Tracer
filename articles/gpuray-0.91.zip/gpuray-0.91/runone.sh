#!/bin/sh
rm -rf cache
echo bin/release/raytracer.exe --ctm -s $1 -a kdtree --size 1024  --accelOpt useRaster=0 --accelOpt fetch4=1 --accelOpt benchmark=5 --shadeOpt specCutoff=-.5 --shadeOpt bounces=10 --shadeOpt shadow=0 -q  -o $1.ppm --accelOpt isectCost=1.5 --accelOpt $2 $4 $5 $6 $7
AVAR=`bin/release/raytracer.exe --ctm -s $1 -a kdtree --size 1024  --accelOpt useRaster=0 --accelOpt fetch4=1  --accelOpt benchmark=5 --shadeOpt specCutoff=-.5 --shadeOpt bounces=10 --shadeOpt shadow=0 -q  -o $1.ppm --accelOpt isectCost=1.5 --accelOpt $2 $4 $5 $6 $7|grep \;|grep -v Cycle|grep -v Miss`
echo bin/release/raytracer.exe --ctm -s $1 -a kdtree --size 1024  --accelOpt useRaster=0 --accelOpt fetch4=1  --accelOpt benchmark=5 --shadeOpt specCutoff=-.5 --shadeOpt bounces=1 --shadeOpt shadow=$3 -q  -o $1.ppm $4 $5 $6 $7
CVAR=`bin/release/raytracer.exe --ctm -s $1 -a kdtree --size 1024  --accelOpt useRaster=0 --accelOpt fetch4=1  --accelOpt benchmark=5 --shadeOpt specCutoff=-.5 --shadeOpt bounces=1  --accelOpt isectCost=1.5 --shadeOpt shadow=$3 -q  -o $1.shadow.ppm  $4 $5 $6 $7|grep \;|grep -v Cycle|grep -v Miss`
echo "$1 Single minNodeExtent=$2 isectCost=1.5 $4 $5 $6 $7"
echo 'Primary;Shadow;Bounce1;Bounce2;Bounce3;Bounce4;Bounce5;Bounce6;Bounce7;Bounce8;Bounce9;Bounce10'
echo $CVAR
echo KILL
echo `echo $AVAR | cut -d \; -f 2-`
echo bin/release/raytracer.exe --ctm -s $1 -a kdtree --size 1024  --accelOpt useRaster=0 --accelOpt fetch4=1  --accelOpt benchmark=5 --shadeOpt specCutoff=-.5 --shadeOpt bounces=10 --shadeOpt shadow=0 -q -p  -o $1.ppm  $4 $5 $6 $7
B=`bin/release/raytracer.exe --ctm -s $1 -a kdtree --size 1024  --accelOpt useRaster=0 --accelOpt fetch4=1  --accelOpt benchmark=5 --shadeOpt specCutoff=-.5 --shadeOpt bounces=10  --accelOpt isectCost=1.5 --shadeOpt shadow=0 -q -p  -o $1.packet.ppm  $4 $5 $6 $7|grep \;|grep -v Cycle|grep -v Miss`
echo bin/release/raytracer.exe --ctm -s $1 -a kdtree --size 1024  --accelOpt useRaster=0 --accelOpt fetch4=1  --accelOpt benchmark=5 --shadeOpt specCutoff=-.5 --shadeOpt bounces=1 --shadeOpt shadow=$3 -q  -p -o blah.ppm $4 $5 $6 $7
D=`bin/release/raytracer.exe --ctm -s $1 -a kdtree --size 1024  --accelOpt useRaster=0 --accelOpt fetch4=1  --accelOpt benchmark=5 --shadeOpt specCutoff=-.5 --shadeOpt bounces=1  --accelOpt isectCost=1.5 --shadeOpt shadow=$3 -q  -p -o $1.packetshadow.ppm $4 $5 $6 $7|grep \;|grep -v Cycle|grep -v Miss`
echo "$1 Packet minNodeExtent=$2 isectCost=1.5 $4"
echo 'Primary;Shadow;Bounce1;Bounce2;Bounce3;Bounce4;Bounce5;Bounce6;Bounce7;Bounce8;Bounce9;Bounce10'
echo $D
echo KILL
echo `echo $B | cut -d \; -f 2-`
