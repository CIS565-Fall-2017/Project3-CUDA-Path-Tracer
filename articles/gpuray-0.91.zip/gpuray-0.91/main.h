/* *************************************************************************
 * Copyright (C) 2004 Jeremy Sugerman
 * All Rights Reserved
 ************************************************************************/

/*
 * main.h --
 *
 *      Core structs used in the ray tracer
 */

#ifndef __MAIN_H__
#define __MAIN_H__

#include <iostream>
#include <vector>

#include "common/commonTypes.h"

typedef struct FPSCameraFrame {
   Vec3f position;
   float pitch;
   float yaw;
   float roll;
} FPSCameraFrame;

typedef struct CameraFrame {
   Vec3f position;
   Vec3f direction;
   Vec3f up;
} CameraFrame;

typedef struct CameraInfo {
   Vec3f from;
   Vec3f u, v, w;
   float tx, ty;
   float fov;
} CameraInfo;

enum SceneType
{
   kSceneType_Vox,
   kSceneType_Triangles,
   kSceneType_Simple
};

typedef struct LightInfo {
   Vec3f position;
   float  distAtten;
   Vec3f diffIntensity;
} LightInfo;

typedef struct SceneParams {
   SceneType sceneType;
   char *fileName;

   Vec3f lookFrom, lookAt;
   Vec3f up;
   float fov;

   Vec3f center;
   float movementScale;
   float lightMovementScale;
   
  // support for multiple point lights
   std::vector<LightInfo> pointLights;	//an array of lights

} SceneParams;

typedef struct KeyValuePair {
   KeyValuePair() {
   }

   KeyValuePair(const std::string& k, const std::string& v)
      : key(k), value(v) {
   }

   std::string key;
   std::string value;
} KeyValuePair;

typedef struct Opts {
   char *progName;

   char *sceneName;     /* Precomputed scene grid / voxelization */
   char *imageFile;     /* Name of the output image */

   int width, height;   /* Dimensions of the output image */
   int windowWidth, windowHeight; /* Dimensions of the display window */

   char *accelName;     /* Acceleration structure to use */
   char *shaderName;    /* Shading type to use */

   char *logName;       /* Filename for writing debug info */

   char *dumpRaysFile;  /* Filename to write rays to */

   /*
    * Boolean options (always default to false)
    */

   bool verbose;
   bool d3d;
   bool gdi;
   bool genTimings;
   bool packets;
   bool rasterize;
   bool brook;
   bool brookShade;
   bool buildOnly;
   bool ctm;
   bool fullscreen;
   /*
    * Options to be passed on to the accelerator
    * and builder.
    */
   std::vector<KeyValuePair> accelOpts;
   std::vector<KeyValuePair> shadeOpts;
   std::vector<KeyValuePair> buildOpts;
} Opts;

enum OptionalAttrib { NORMAL, DIFFUSE, AMBIENT, SPECULAR };

extern void Usage(const char *progName);
extern int GetKeyValueInt(const char* key,
                          const std::vector<KeyValuePair>& opts,
                          int defaultValue);
extern const char* GetKeyValueString(const char* key,
				     const std::vector<KeyValuePair>& opts,
				     const char* defaultValue);

extern float GetKeyValueFloat(const char* key,
                          const std::vector<KeyValuePair>& opts,
                          float defaultValue);

#endif
