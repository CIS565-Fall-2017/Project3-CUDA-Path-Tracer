
/*
 * renderContextGDI.h --
 *
 *      Win32 GDI implementation of the IRenderSystem interface.
 */
#include "renderContextGDI.h"

#include <stdio.h>
#include <iostream>

const char* RenderSystemGDI::getRenderSystemID()
{
   return "gdi";
}

IRenderContext* RenderSystemGDI::createRenderContext( HWND inWindowHandle )
{
   return new RenderContextGDI( this, inWindowHandle );
}

RenderContextGDI::RenderContextGDI( RenderSystemGDI* inRenderSystem, HWND inWindowHandle )
{
   _renderSystem = inRenderSystem;

   if ((_hdc = GetDC(inWindowHandle)) == NULL) {
      throw -1;
   }

   _hwnd = inWindowHandle;
}

IRenderSystem* RenderContextGDI::getRenderSystem()
{
   return _renderSystem;
}

void* RenderContextGDI::getContextHandle()
{
   return (void *) _hdc;
}

void* RenderContextGDI::getWindowHandle()
{
   return (void *) _hwnd;
}

void RenderContextGDI::resize( int inWidth, int inHeight )
{
   bind();
}

void RenderContextGDI::bind()
{

}

void RenderContextGDI::swap()
{

}
