/*
 * renderContextGDI.h --
 *
 *      Win32 GDI implementation of the IRenderSystem interface.
 */

#ifndef __RENDERCONTEXTGDI_H__
#define __RENDERCONTEXTGDI_H__

#include "renderContext.h"

class RenderSystemGDI : public IRenderSystem
{
public:
   const char* getRenderSystemID();
   IRenderContext* createRenderContext( HWND inWindowHandle );
};

class RenderContextGDI : public IRenderContext
{
public:
   RenderContextGDI( RenderSystemGDI* inRenderSystem, HWND inWindowHandle );

   IRenderSystem* getRenderSystem();
   void* getContextHandle();
   void* getWindowHandle();

   void resize( int inWidth, int inHeight );

   void bind();
   void swap();

private:
   RenderSystemGDI* _renderSystem;

   HDC _hdc;
   HWND _hwnd;
};


#endif
