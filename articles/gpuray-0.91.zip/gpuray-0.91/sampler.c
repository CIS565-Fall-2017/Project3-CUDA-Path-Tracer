/*
 * sampler.c --
 *
 *      Implementation of various sampling schemes.  All take a 1D index and
 *      return a 2D (x, y) where x is less than the specified width.
 */

#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include "sampler.h"
#include <time.h>
#ifdef WINDOWS
#define inline  __inline
#endif

#define HILBERT_EDGE       16
#define HILBERT_SIZE       (HILBERT_EDGE * HILBERT_EDGE)

static struct { int x, y; } hilbert[HILBERT_SIZE] = {
   { 0, 0 }, { 0, 1 }, { 1, 1 }, { 1, 0 },
   { 2, 0 }, { 3, 0 }, { 3, 1 }, { 2, 1 },
   { 2, 2 }, { 3, 2 }, { 3, 3 }, { 2, 3 },
   { 1, 3 }, { 1, 2 }, { 0, 2 }, { 0, 3 },
   { 0, 4 }, { 1, 4 }, { 1, 5 }, { 0, 5 },
   { 0, 6 }, { 0, 7 }, { 1, 7 }, { 1, 6 },
   { 2, 6 }, { 2, 7 }, { 3, 7 }, { 3, 6 },
   { 3, 5 }, { 2, 5 }, { 2, 4 }, { 3, 4 },
   { 4, 4 }, { 5, 4 }, { 5, 5 }, { 4, 5 },
   { 4, 6 }, { 4, 7 }, { 5, 7 }, { 5, 6 },
   { 6, 6 }, { 6, 7 }, { 7, 7 }, { 7, 6 },
   { 7, 5 }, { 6, 5 }, { 6, 4 }, { 7, 4 },
   { 7, 3 }, { 7, 2 }, { 6, 2 }, { 6, 3 },
   { 5, 3 }, { 4, 3 }, { 4, 2 }, { 5, 2 },
   { 5, 1 }, { 4, 1 }, { 4, 0 }, { 5, 0 },
   { 6, 0 }, { 6, 1 }, { 7, 1 }, { 7, 0 },
   { 8, 0 }, { 9, 0 }, { 9, 1 }, { 8, 1 },
   { 8, 2 }, { 8, 3 }, { 9, 3 }, { 9, 2 },
   { 10, 2 }, { 10, 3 }, { 11, 3 }, { 11, 2 },
   { 11, 1 }, { 10, 1 }, { 10, 0 }, { 11, 0 },
   { 12, 0 }, { 12, 1 }, { 13, 1 }, { 13, 0 },
   { 14, 0 }, { 15, 0 }, { 15, 1 }, { 14, 1 },
   { 14, 2 }, { 15, 2 }, { 15, 3 }, { 14, 3 },
   { 13, 3 }, { 13, 2 }, { 12, 2 }, { 12, 3 },
   { 12, 4 }, { 12, 5 }, { 13, 5 }, { 13, 4 },
   { 14, 4 }, { 15, 4 }, { 15, 5 }, { 14, 5 },
   { 14, 6 }, { 15, 6 }, { 15, 7 }, { 14, 7 },
   { 13, 7 }, { 13, 6 }, { 12, 6 }, { 12, 7 },
   { 11, 7 }, { 10, 7 }, { 10, 6 }, { 11, 6 },
   { 11, 5 }, { 11, 4 }, { 10, 4 }, { 10, 5 },
   { 9, 5 }, { 9, 4 }, { 8, 4 }, { 8, 5 },
   { 8, 6 }, { 9, 6 }, { 9, 7 }, { 8, 7 },
   { 8, 8 }, { 9, 8 }, { 9, 9 }, { 8, 9 },
   { 8, 10 }, { 8, 11 }, { 9, 11 }, { 9, 10 },
   { 10, 10 }, { 10, 11 }, { 11, 11 }, { 11, 10 },
   { 11, 9 }, { 10, 9 }, { 10, 8 }, { 11, 8 },
   { 12, 8 }, { 12, 9 }, { 13, 9 }, { 13, 8 },
   { 14, 8 }, { 15, 8 }, { 15, 9 }, { 14, 9 },
   { 14, 10 }, { 15, 10 }, { 15, 11 }, { 14, 11 },
   { 13, 11 }, { 13, 10 }, { 12, 10 }, { 12, 11 },
   { 12, 12 }, { 12, 13 }, { 13, 13 }, { 13, 12 },
   { 14, 12 }, { 15, 12 }, { 15, 13 }, { 14, 13 },
   { 14, 14 }, { 15, 14 }, { 15, 15 }, { 14, 15 },
   { 13, 15 }, { 13, 14 }, { 12, 14 }, { 12, 15 },
   { 11, 15 }, { 10, 15 }, { 10, 14 }, { 11, 14 },
   { 11, 13 }, { 11, 12 }, { 10, 12 }, { 10, 13 },
   { 9, 13 }, { 9, 12 }, { 8, 12 }, { 8, 13 },
   { 8, 14 }, { 9, 14 }, { 9, 15 }, { 8, 15 },
   { 7, 15 }, { 7, 14 }, { 6, 14 }, { 6, 15 },
   { 5, 15 }, { 4, 15 }, { 4, 14 }, { 5, 14 },
   { 5, 13 }, { 4, 13 }, { 4, 12 }, { 5, 12 },
   { 6, 12 }, { 6, 13 }, { 7, 13 }, { 7, 12 },
   { 7, 11 }, { 6, 11 }, { 6, 10 }, { 7, 10 },
   { 7, 9 }, { 7, 8 }, { 6, 8 }, { 6, 9 },
   { 5, 9 }, { 5, 8 }, { 4, 8 }, { 4, 9 },
   { 4, 10 }, { 5, 10 }, { 5, 11 }, { 4, 11 },
   { 3, 11 }, { 2, 11 }, { 2, 10 }, { 3, 10 },
   { 3, 9 }, { 3, 8 }, { 2, 8 }, { 2, 9 },
   { 1, 9 }, { 1, 8 }, { 0, 8 }, { 0, 9 },
   { 0, 10 }, { 1, 10 }, { 1, 11 }, { 0, 11 },
   { 0, 12 }, { 0, 13 }, { 1, 13 }, { 1, 12 },
   { 2, 12 }, { 3, 12 }, { 3, 13 }, { 2, 13 },
   { 2, 14 }, { 3, 14 }, { 3, 15 }, { 2, 15 },
   { 1, 15 }, { 1, 14 }, { 0, 14 }, { 0, 15 },
};


/*
 * Sampler16x16Hilbert --
 *
 *      Samples a tiling of blocks where each block is filled in according
 *      to a 16x16 Hilbert curve.
 *
 * Results:
 *      void, *x and *y filled in.
 */

static inline void
Sampler16x16Hilbert(uint32 index, uint32 width, uint32 *x, uint32 *y)
{
   uint32 tileNum, tileX, tileY, offset;

   assert(width % HILBERT_EDGE == 0);
   tileNum = index / HILBERT_SIZE;

   tileX = (tileNum % ((width + HILBERT_EDGE - 1)/HILBERT_EDGE)) * HILBERT_EDGE;
   tileY = (tileNum / ((width + HILBERT_EDGE - 1)/HILBERT_EDGE)) * HILBERT_EDGE;
   offset = index - (tileX * HILBERT_EDGE + tileY * width);

   //printf("Index %d -> Tile (%d, %d), Offset %d\n", index, tileX, tileY, offset);

   if (offset >= HILBERT_SIZE) {
      printf("Index is %d at tile (%d, %d)\n", offset, tileX, tileY);
   }
   assert(offset < HILBERT_SIZE);
   *x = tileX + hilbert[offset].x;
   *y = tileY + hilbert[offset].y;
}


/*
 * Sampler2x2Block --
 *
 *      Samples a simple 2x2 block pattern.
 *
 * Results:
 *      void, *x and *y filled in.
 */

static inline void
Sampler2x2Block(uint32 index, uint32 width, uint32 *x, uint32 *y)
{
   uint32 tileNum, tileX, tileY, offset;

   tileNum = index / 4;

   tileX = (tileNum % ((width + 2 - 1)/2)) * 2;
   tileY = (tileNum / ((width + 2 - 1)/2)) * 2;
   offset = index - (tileX * 2 + tileY * width);

   *x = tileX + (offset & 0x1);
   *y = tileY + (offset>>1);
}


/*
 * Sampler_IndexTo2D --
 *
 *      2D sampler entry point.  Just wrap the various functions to provide
 *      a single entry point.
 *
 * Results:
 *      void, *x and *y filled in.
 */

void
Sampler_IndexTo2D(uint32 index, uint32 width, uint32 *x, uint32 *y)
{
   if (1) {
      Sampler16x16Hilbert(index, width, x, y);
   } else  if (1) {
     //srand(time(NULL));
     Sampler2x2Block(index, width, x, y);
     /*
     if (*x&2)
       *x&=~2;
     else
       *x|=2;
     if (*y&2)
       *y&=~2;
     else
       *y|=2;
       
     *x&=~1;
     *y&=~1;
     */
     //*x=((*x)/64*64)+*x%8;
     //*y=((*y)/64*64)+*y%8;
     //*x=rand()%1024;//((*x)/4*4)+*x%2;
     //*y=rand()%1024;//((*y)/4*4)+*y%2;

   }else {
     *x=index%width;
     *y=index/width;
   }
}


#ifdef TEST_SAMPLER
#define WIDTH   16
#define HEIGHT  32

int
main(void)
{
   uint32 ii;
   uint32 buffer[HEIGHT][WIDTH];

   for (ii = 0; ii < WIDTH * HEIGHT; ii++) {
      uint32 x, y;

      Sampler_IndexTo2D(ii, WIDTH, &x, &y);
      if (x >= WIDTH || y >= HEIGHT) {
         printf("Index %d -> Bogus coordinates (%d, %d)\n",
                ii, x, y);
      }
      assert(x < WIDTH && y < HEIGHT);
      buffer[y][x] = ii;
      printf("(%2d, %2d) ", x, y);

      if (ii % 8 == 7) printf("\n");
   }
   printf("\n");

   for (ii = 0; ii < WIDTH * HEIGHT; ii++) {
      uint32 x, y;

      Sampler_IndexTo2D(ii, WIDTH, &x, &y);
      printf("%3d ", buffer[y][x]);
      if (ii % 16 == 15) printf("\n");
   }
   printf("\n");
   return 0;
}
#endif
