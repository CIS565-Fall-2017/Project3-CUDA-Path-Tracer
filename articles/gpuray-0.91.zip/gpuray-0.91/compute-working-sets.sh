#!/bin/bash
#
# compute-working-sets.sh --
#
#	Simple shell script to generate a bunch of timing numbers.

scenes=${1:-cbox glassner bunny robots kitchen gally}
shaders=${2:-simple shadow whitted}
resolution=1024

computeWorkingSet=1

echo -n "Starting at "
date

if [ $computeWorkingSet -ne 0 ]; then
   echo "*** Computing Working Sets (Scalar) ***"
   for scene in $scenes; do
      for shader in $shaders; do
         echo "** ${scene} ${shader} **"
         ./bin/raytracer --cpu \
           -s $scene -l $shader --size $resolution \
           -o junk.ppm | grep -E "(kdtreeCPU\:Rays)|(kdtreeCPU\:PacketSize)|(kdtreeCPU\:Traversals)|(kdtreeCPU\:MaxTraversals)|(kdtreeCPU\:Intersections)|(kdtreeCPU\:MaxIntersections)|(rayType\:)";
	      echo -e ""
      done
   done
fi

echo -n "Done at "
date
