/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * viewer.c --
 *
 *      Simple viewer to create a window and display the generated images.
 */

#include <assert.h>
#ifdef _WIN32
#include <windows.h>
#endif

#include "viewer.h"
#include "log.h"
#include "tracer.h"
#include "fileIO/ppmImage.h"
#include "timer.h"
#include "cameraManager.h"

#include "renderContextGL.h"
#ifdef _WIN32
#include "renderContextDX.h"
#include "renderContextGDI.h"
#endif

#define VIEWER_WINCLASS  "VIEWER_WC"

static char viewerWinTitle[] = "GPURay XXX.XX fps";


#ifdef _WIN32
/*
 * ViewerWindowFn --
 *
 *      This is the callback that gets invoked for when any Viewer window
 *      receives a Windows message.  It pretty much just turns around and
 *      hands it to the viewer.  The only exception is the funny dance at
 *      creation time-- CreateWindow() tunnels a void * to here where we
 *      stash it in the window's properties so we can fish it out on all
 *      subsequent events.
 *
 * Returns:
 *      Whatever the message handler indicates.
 */

static LRESULT CALLBACK
ViewerWindowFn(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
   Viewer *viewer = NULL;

   /*
    * Window creation tunnels a void * of our choice to here, at which point
    * we stash it in the window's struct and fish it out later.
    */
   if (uMsg == WM_CREATE) {
      CREATESTRUCT *create = (CREATESTRUCT *) lParam;
      SetWindowLong(hWnd, GWL_USERDATA, (long) create->lpCreateParams);
      SetTimer(hWnd,1,10,NULL);
   }

   if ((viewer = (Viewer *) GetWindowLong(hWnd, GWL_USERDATA)) == NULL) {
      return DefWindowProc(hWnd, uMsg, wParam, lParam);
   }
   return viewer->HandleMsg(hWnd, uMsg, wParam, lParam);
}


/*
 * ViewerRegisterWindowClass --
 *
 *      All the windows we create are of our window class, which means they
 *      call our event and draw handlers.  This function sets up the window
 *      class properly.
 *
 * Returns:
 *      void.
 */

static void
ViewerRegisterWindowClass()
{
   WNDCLASSEX wndClass;

   static bool beenHere;

   if (beenHere) {
      return;
   }
   beenHere = true;

   memset(&wndClass, 0, sizeof wndClass);
   wndClass.cbSize = sizeof wndClass;
   wndClass.style = CS_OWNDC;
   wndClass.lpfnWndProc = ViewerWindowFn;
   wndClass.hInstance = GetModuleHandle(NULL);
   wndClass.lpszClassName = VIEWER_WINCLASS;
   wndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
   wndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);

   if (!RegisterClassEx(&wndClass)) {
      fprintf(stderr, "RegisterClassEx() failed: 0x%x\n", GetLastError());
   }
}
#endif


/*
 * Viewer::Destroy --
 *
 *      Tears down any window state
 *
 * Returns:
 *      void.
 */

void
Viewer::Destroy(void)
{
   if (_cameraManager != NULL) {
      delete _cameraManager;
      _cameraManager = NULL;
   }

   if (IsCreated()) {
#ifdef _WIN32
      DestroyWindow(_win);
      _win = NULL;
#else
      XDestroyWindow(_dpy, _win);
      XCloseDisplay(_dpy);
      _win = None;
#endif
      _visible = _created = false;
   }
}


/*
 * Viewer::InitializeWindowSystem --
 *
 *      All of the host and GL/DX/GDI specific initialization, window
 *      creation, etc.
 *
 * Returns:
 *      true if everything worked, else false.
 */

bool
Viewer::InitializeWindowSystem(const Opts& opts)
{
#ifdef _WIN32
   RECT windowRect;
   windowRect.left = 0;
   windowRect.top = 0;
   windowRect.right = opts.windowWidth;
   windowRect.bottom = opts.windowHeight;

   AdjustWindowRect( &windowRect, WS_OVERLAPPEDWINDOW, false );
   int windowWidth = windowRect.right - windowRect.left;
   int windowHeight = windowRect.bottom - windowRect.top;

   ViewerRegisterWindowClass();
   _win = CreateWindow(VIEWER_WINCLASS, "GPURay", opts.fullscreen?(WS_POPUP|WS_SYSMENU|WS_VISIBLE):WS_OVERLAPPEDWINDOW,
                       -1, -1, windowWidth, windowHeight, GetDesktopWindow(),
                       NULL, GetModuleHandle(NULL), this);

   if (_win == NULL) {
      return false;
   }

   if (opts.d3d) {
      _renderSystem = new RenderSystemDX9(opts.fullscreen?opts.width:0,opts.fullscreen?opts.height:0);
   } else if (opts.gdi) {
       _renderSystem = new RenderSystemGDI();
   } else {
    _renderSystem = new RenderSystemOGL();
   }

   _renderContext = _renderSystem->createRenderContext( _win );
   return true;

#else
   int attrib[] = { GLX_RGBA,
                    GLX_RED_SIZE, 1, GLX_GREEN_SIZE, 1, GLX_BLUE_SIZE, 1,
                    GLX_DOUBLEBUFFER,
                    GLX_DEPTH_SIZE, 1,
                    None };
   XVisualInfo *visualInfo;
   XSetWindowAttributes attr;
   unsigned long mask;
   Window root;


   if ((_dpy = XOpenDisplay(NULL)) == NULL) {
      PRINT(("Unabled to open display\n"));
      return false;
   }


   root = RootWindow(_dpy, DefaultScreen(_dpy));
   visualInfo = glXChooseVisual(_dpy, DefaultScreen(_dpy), attrib);

   attr.background_pixel = 0;
   attr.border_pixel = 0;
   attr.colormap = XCreateColormap(_dpy, root, visualInfo->visual, AllocNone);
   attr.event_mask = StructureNotifyMask | ExposureMask | KeyPressMask;
   mask = CWBackPixel | CWBorderPixel | CWColormap | CWEventMask;

   _win = XCreateWindow(_dpy, root, 0, 0, opts.windowWidth, opts.windowHeight,
                        0, visualInfo->depth, InputOutput, visualInfo->visual,
                        mask, &attr);
   XStoreName(_dpy, _win, "GPURay");

   _renderSystem = new RenderSystemOGL();
   _renderContext = _renderSystem->createRenderContext(_dpy, _win, visualInfo);

   XFree(visualInfo);
   return true;
#endif
}


/*
 * Viewer::Create --
 *
 *      Initializes the rendering system.
 *
 * Returns:
 *      true if everything worked, else false.
 */

bool
Viewer::Create(const Opts& opts)
{
   if (!InitializeWindowSystem(opts)) {
      return false;
   }

   /*
    * We're now all done with the window system calls to establish our
    * window, so it's safe to initialize the tracer.  Note that this will
    * intialize Brook and switch to the Brook context when using GPU based
    * tracing.
    */

   Scene* scene = new Scene( opts );
   _cameraManager = new CameraManager( scene, opts.width, opts.height );
   InitializeTracer( opts, scene, _cameraManager );
   if (_tracer == NULL) {
      PRINT(("Unable to create a tracer\n"));
      return false;
   }

   _created = true;
   _width = opts.width;
   _height = opts.height;
   _visible = false;
   _rebuild = true;
   _rotate = false;
   return true;
}

/*
 * Viewer::MakeVisible --
 *
 *      Shows or hides the viewing window.
 *
 * Returns:
 *      void.
 */

void
Viewer::MakeVisible(bool show)
{
   if (!IsCreated() || _visible == show) {
      return;
   }

   _visible = show;
#ifdef _WIN32
   ShowWindow(_win, _visible ? SW_SHOW : SW_HIDE);
#else
   _visible ? XMapWindow(_dpy, _win) : XUnmapWindow(_dpy, _win);
#endif

   if (_visible) {
      DrawDisplay();
   }

   /*
    * Drain any pending Windows messages so that the window finishes
    * appearing or disappearing.
    */

   PumpMsgs(false);
}


/*
 * Viewer::Resize --
 *
 *
 * Results:
 *      void.
 */

void
Viewer::Resize(int width, int height)
{
   _renderContext->resize(width, height);
   _tracer->Resize(width, height);
//TIM   ResizeContext(width,height);
   DrawDisplay();
}

/*
 * Viewer::PumpMsgs --
 *
 *      Causes the Viewer to spin fetching and dispatching window messages
 *      until it's signalled to stop.  When it runs out of messages, it
 *      either blocks or returns depending on what the caller requested.
 *
 * Returns:
 *      -1 on error, 0 if the window is destroyed, else 1.
 */

int
Viewer::PumpMsgs(bool block)
{
#ifdef _WIN32
   int result;
   MSG msg;

   if (block) {
      while ((result = GetMessage(&msg, NULL, 0, 0)) != 0) {
         if (result < 0) {
            fprintf(stderr, "Viewer: Error 0x%x pumping messages!\n",
                    GetLastError());
            return -1;
         }

         TranslateMessage(&msg);
         DispatchMessage(&msg);
      }
      return 0;
   } else {
      while (PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE)) {
         result = GetMessage(&msg, NULL, 0, 0);
         if (result < 0) {
            fprintf(stderr, "Viewer: Error 0x%x pumping messages!\n",
                    GetLastError());
            return -1;
         }
         if (result == 0) {
            return 0;
         }

         TranslateMessage(&msg);
         DispatchMessage(&msg);
      }
      return 1;
   }
#else
   if (block) {
      bool keepProcessing;

      do {
         XEvent event;

         XNextEvent(_dpy, &event);
         keepProcessing = HandleEvent(&event);
      } while (keepProcessing);
   } else {
      while (XPending(_dpy) > 0) {
         XEvent event;

         XNextEvent(_dpy, &event);
         HandleEvent(&event);
      }
   }
   return 1;
#endif
}


/*
 * Viewer::Animate --
 *
 *      Quickly hacked up support for flying the camera around.  It reads
 *      camera instructions from stdin.
 *
 * Results:
 *      void, but moves the camera and redraws.
 */

void
Viewer::Animate(void)
{
   float x,y,z,tx,ty,tz,ux,uy,uz;
   int gobble=3;

   for (int i=0; i<gobble; ++i) {
      if (0 >= scanf("%f %f %f %f %f %f %f %f %f",&x,&y,&z,&tx,&ty,&tz,&ux,&uy,&uz)) {
         _rotate = false;
         return;
      }
   }

   //printf ("Scanning cam %f %f %f\n", x,y,z);
   _cameraManager->ResetScene(Vec3f(x,y,z), Vec3f(tx,ty,tz), Vec3f(ux,uy,uz));
   ForceRedraw();
}


/*
 * Viewer::HandleKeyPress --
 *
 *      This function is invoked when the Viewer window receives a
 *      keystroke.
 *
 * Results:
 *      true to continue processing, false to stop.
 *      (various keystrokes have all sorts of side effects)
 */
extern bool morebounces;
extern bool lessbounces;
extern bool yespacketize;
extern bool nopacketize;
extern bool yesrasterize;
extern bool norasterize;
extern bool morespec;
extern bool lessspec;
extern bool morecutoff;
extern bool lesscutoff;
extern bool toggleshadow;
bool
Viewer::HandleKeyPress(char c)
{
   switch (c) {
   case 't': _rotate = !_rotate;                                        break;
   case 'r': _cameraManager->ResetScene(); ForceRedraw();               break;
//   case 'w': WriteImage("out.ppm");                                   break;
   case 'v': _cameraManager->PrintScene();                              break;

   /* Scene Rotation */
   case '7': _cameraManager->RotateScene(-1, 0 ); ForceRedraw();        break;
   case '8': _cameraManager->RotateScene( 1, 0 ); ForceRedraw();        break;
   case '9': _cameraManager->RotateScene( 0,-1 ); ForceRedraw();        break;
   case '0': _cameraManager->RotateScene( 0, 1 ); ForceRedraw();        break;

   /* Camera Translation */
   case 'w': _cameraManager->MoveCamera( 0, 1 ); ForceRedraw();         break;
   case 'a': _cameraManager->MoveCamera(-1, 0 ); ForceRedraw();         break;
   case 's': _cameraManager->MoveCamera( 0,-1 ); ForceRedraw();         break;
   case 'd': _cameraManager->MoveCamera( 1, 0 ); ForceRedraw();         break;

   /* Camera Rotation */
   case 'i': _cameraManager->RotateCamera( 0, .25 ); ForceRedraw();     break;
   case 'j': _cameraManager->RotateCamera(-.25, 0 ); ForceRedraw();     break;
   case 'k': _cameraManager->RotateCamera( 0,-.25 ); ForceRedraw();     break;
   case 'l': _cameraManager->RotateCamera( .25, 0 ); ForceRedraw();     break;

   case '=':
   case '+': morebounces=true; ForceRedraw();                           break;
   case '-': lessbounces=true; ForceRedraw();                           break;
   case '*': yesrasterize=true; ForceRedraw();                          break;
   case '/': norasterize=true; ForceRedraw();                           break;
   case 'o': nopacketize=true; ForceRedraw();                           break;
   case 'p': yespacketize=true; ForceRedraw();                          break;
   case '.': morespec=true; ForceRedraw();                              break;
   case ',': lessspec=true; ForceRedraw();                              break;
   case '[': morecutoff=true; ForceRedraw();                            break;
   case ']': lesscutoff=true; ForceRedraw();                            break;
   case 'm': toggleshadow=true; ForceRedraw();                          break;

   case 'Q':
   case 'q':
#ifdef _WIN32
      PostQuitMessage(0);
#endif
      return false;

   default:
      {
         ToggleOptionMap::iterator i = _toggleOptions.find( c );
         if (i != _toggleOptions.end()) {
            ToggleOption* option = (*i).second;
            assert( option );
            option->toggle();
            PRINT(("%s: %s\n", option->getDescription(),
                   option->isEnabled() ? "enabled" : "disabled"));
            ForceRedraw();
         }
      }
   }

   return true;
}


/*
 * Viewer::WriteImage --
 *
 *      Writes the current contents of the image to the specified file.
 *
 * Results:
 *      void, but a file is written to the filesystem.
 */

void
Viewer::WriteImage(char *fileName)
{
   assert( false );

   // TIM: XXX: HACK:
#if 0
   ppmImage image(_width, _height);

   if (_rebuild) {
      RebuildImage();
   }
   _pixels.write(image.Data());
   PRINT(("Writing image to %s.\n", fileName));
   image.Write(fileName);
#endif
}


#if _WIN32
/*
 * Viewer::HandleMsg --
 *
 *      Entry point for all windows messages received by a viewer.  Handles
 *      the messages about which the viewer cares and passes the rest down
 *      to the default handler.
 *
 * Returns:
 *      Whatever the message handler indicates.
 */

LRESULT
Viewer::HandleMsg(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
   if (!IsCreated()) {
      return DefWindowProc(hWnd, uMsg, wParam, lParam);
   }

   //PRINT(("Viewer: Received msg 0x%x\n", uMsg));

   switch (uMsg) {
   case WM_CLOSE:
   case WM_DESTROY: PostQuitMessage(0);                         return 0;
   case WM_CHAR:    HandleKeyPress((char) wParam);              return 0;
   case WM_TIMER:   if (_rotate) Animate();                     return 0;
   case WM_SIZE:    Resize(LOWORD(lParam), HIWORD(lParam));     return 0;

   case WM_PAINT: DrawDisplay(); /* Fall through so to validates... */
   default: return DefWindowProc(hWnd, uMsg, wParam, lParam);
   }
}
#else


/*
 * Viewer::HandleEvent --
 *
 * Results:
 *      true to continue processing events, false to stop
 */

bool
Viewer::HandleEvent(XEvent *event)
{
   switch(event->type) {
   case Expose: DrawDisplay();          return true;
   case DestroyNotify:                  return false;

   case KeyPress: {
      char key;

      XLookupString(&event->xkey, &key, sizeof key, NULL, NULL);
      return HandleKeyPress(key);
   }

   default: /* Ignore unknown events */ return true;
   }
}
#endif


/*
 * Viewer::InitializeTracer --
 *
 *      Initializes an appropriate ITracer to do the actual
 *      rendering, based on the user's options.
 *
 * Results:
 *      None, but sets _tracer
 */

void
Viewer::InitializeTracer( const Opts& inOptions, Scene* inScene, CameraManager* inCameraManager )
{
   Timer_Reset();

   _tracer = ::CreateTracer( inOptions, inScene, inCameraManager, getRenderContext() );
}


/*
 * Viewer::DrawDisplay --
 *
 *      Draws the contents of the Viewer window.  We just bind the 'pixels'
 *      stream as a texture and draw a rectangle.
 *
 * Results:
 *      void.
 */

void
Viewer::DrawDisplay(void)
{
   if (_rebuild) {
      float fps = RebuildImage();

      if (fps > 999.0f) fps = 999.99f;
      sprintf(viewerWinTitle, "GPURay %5.2f fps", fps);
#ifdef _WIN32
      SetWindowText(_win, viewerWinTitle);
#else
      XStoreName(_dpy, _win, viewerWinTitle);
      XFlush(_dpy);
#endif
   }

   _tracer->Display();
}


/*
 * Viewer::RebuildImage --
 *
 *      Calls into the tracer to rebuild the current frame.
 *
 * Results:
 *      The fps value returned by the tracer.
 */

float
Viewer::RebuildImage(void)
{
   assert(_rebuild);
   _rebuild = false;

   Timer_Reset();
   _tracer->TraceRays();
   float t = Timer_GetMS();
   PRINT(("TraceRays took %3.2f seconds total.\n", t / 1000.0f));
   return 1000.0f / t;
}
