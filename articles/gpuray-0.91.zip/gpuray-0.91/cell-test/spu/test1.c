#include <stdio.h>
#include <spu_intrinsics.h>
#include <cbe_mfc.h>
#include <limits.h>
#include <math.h>
#include <assert.h>

#include "../request.h"

//#define DEBUG_TRACE_DMAS
//#define DEBUG_TRACE_INTERSECTION

//#define ENABLE_NODE_CACHE
#define NODE_CACHE_LINE_SIZE 2
#define NODE_CACHE_LINE_COUNT 4096
//#define COLLECT_NODE_CACHE_STATS

//#define ENABLE_TRIANGLE_CACHE
#define TRIANGLE_CACHE_LINE_SIZE 4
#define TRIANGLE_CACHE_LINE_COUNT 256
//#define COLLECT_TRIANGLE_CACHE_STATS

#define TAG_GROUP_MEGA_PACKET 4

//#define COLLECT_TRACE_STATS

//#define ENABLE_PROFILER

#define ENABLE_PIPELINE

//#define LOOP_A_BUNCH 64

//#define ENABLE_LOG
#ifdef ENABLE_LOG
#  define LOG(__args) printf __args
#else
#  define LOG(__args) do {} while(0)
#endif

#ifdef COLLECT_TRACE_STATS
#define STATS_DEFINE( _name ) unsigned long long _name = 0;
#define STATS_INC( _name ) _name ++ ;
#define STATS_PRINT( _name ) printf( #_name ": %lld\n", _name );
#else
#define STATS_DEFINE(_name) /* empty */
#define STATS_INC(_name) /* empty */
#define STATS_PRINT(_name) /* empty */
#endif

STATS_DEFINE( gNodeCount );
STATS_DEFINE( gTriangleCount );
STATS_DEFINE( gBadPacketCount );
STATS_DEFINE( gMissSceneCount );
STATS_DEFINE( gStackEmptyCount );
STATS_DEFINE( gNormalCount );

#ifdef ENABLE_PROFILER
#define PROFILE_BEGIN(_name) unsigned int start_ ## _name = spu_readch( SPU_RdDec );
#define PROFILE_END(_name) _name += (start_ ## _name) - spu_readch( SPU_RdDec );
#else
#define PROFILE_BEGIN(_name) /* empty */
#define PROFILE_END(_name) /* empty */
#endif

#ifdef ENABLE_PROFILER
unsigned long long gTotalTime = 0;
unsigned long long gTotalTraverseTime = 0;
unsigned long long gTraverseSplitTime = 0;
unsigned long long gSplitGetNodeTime = 0;
unsigned long long gTotalIntersectTime = 0;
unsigned long long gTotalDmaGetTime = 0;
unsigned long long gTotalDmaSetTime = 0;
#endif

volatile RequestContext request __attribute__((aligned(128)));

#ifdef ENABLE_PIPELINE
static volatile qword kdtree[256] __attribute__((aligned(128)));
static volatile Triangle testtri[128] __attribute__((aligned(128)));
#endif

inline qword spu_cmov( qword left, qword right,
                       vector unsigned int mask )
{
  return (qword) spu_sel( (vector unsigned int) left,
                          (vector unsigned int) right,
                          mask );
  //  return (qword) spu_or(spu_andc( (vector unsigned int) left, mask ),
  //                        spu_and( (vector unsigned int) right, mask ));
}

inline vector float spu_min( vector float left, vector float right )
{
  return (vector float) spu_cmov( (qword) right,
                                  (qword) left,
                                  spu_cmpgt( right, left ) ); 
}

inline vector float spu_max( vector float left, vector float right )
{
  return (vector float) spu_cmov( (qword) left,
                                  (qword) right,
                                  spu_cmpgt( right, left ) ); 
}

inline vector unsigned int spu_not( vector unsigned int x )
{
  return spu_cmpeq( x, spu_splats( (unsigned int) 0 ) );
}

inline vector unsigned int spu_cmpge( vector float left, vector float right )
{
  return spu_not( spu_cmpgt( right, left ) );
}

void debugPrintIntVector( const char* inName, vector signed int inValue )
{
  LOG(( "%s: <%d %d %d %d>\n",
        inName,
        spu_extract( inValue, 0 ),
        spu_extract( inValue, 1 ),
        spu_extract( inValue, 2 ),
        spu_extract( inValue, 3 ) ));
}

void debugPrintUIntVector( const char* inName, vector unsigned int inValue )
{
  LOG(( "%s: <%d %d %d %d>\n",
        inName,
        spu_extract( inValue, 0 ),
        spu_extract( inValue, 1 ),
        spu_extract( inValue, 2 ),
        spu_extract( inValue, 3 ) ));
}

void debugPrintFloatVector( const char* inName, vector float inValue )
{
  LOG(( "%s: <%f %f %f %f>\n",
        inName,
        spu_extract( inValue, 0 ),
        spu_extract( inValue, 1 ),
        spu_extract( inValue, 2 ),
        spu_extract( inValue, 3 ) ));
}

void IssueDmaGetAsync( void* outBuffer,
                       unsigned long long inBuffer,
                       size_t inSize,
                       unsigned int inGroup )
{
  assert( (inBuffer & 0xF) == 0 );

  spu_mfcdma64( outBuffer,
                inBuffer >> 32,
                inBuffer & 0xFFFFFFFF,
                inSize,
                inGroup,
                MFC_GET_CMD );
}

void IssueDmaSetAsync( void* inBuffer,
                       unsigned long long outBuffer,
                       size_t inSize,
                       unsigned int inGroup )
{
  assert( (outBuffer & 0xF) == 0 );

  spu_mfcdma64( inBuffer,
                outBuffer >> 32,
                outBuffer & 0xFFFFFFFF,
                inSize,
                inGroup,
                MFC_PUT_CMD );
}

void IssueDmaWait( unsigned int inGroup )
{
  spu_writech(MFC_WrTagMask, 1 << inGroup );
  (void)spu_mfcstat(2);
}

void IssueDmaGetAndWait( void* outBuffer,
                         unsigned long long inBuffer,
                         size_t inSize )
{
#ifdef DEBUG_TRACE_DMAS
  printf( "DMA: %d bytes from global 0x%llx to local 0x%lx\n",
          inSize,
          inBuffer,
          outBuffer );
#endif

  assert( (inBuffer & 0xF) == 0 );

  PROFILE_BEGIN( gTotalDmaGetTime )

  spu_mfcdma64( outBuffer,
                inBuffer >> 32,
                inBuffer & 0xFFFFFFFF,
                inSize,
                0,
                MFC_GET_CMD ); // dma
  spu_writech(MFC_WrTagMask, 1 << 0 );
  (void)spu_mfcstat(2); // wait

  PROFILE_END( gTotalDmaGetTime )
}

void IssueDmaSetAndWait( void* inBuffer,
                         unsigned long long outBuffer,
                         size_t inSize )
{
#ifdef DEBUG_TRACE_DMAS
  printf( "DMA: %d bytes from local 0x%lx to global 0x%llx\n",
          inSize,
          inBuffer,
          outBuffer );
#endif

  assert( (outBuffer & 0xF) == 0 );

  PROFILE_BEGIN( gTotalDmaSetTime )

  spu_mfcdma64( inBuffer,
                outBuffer >> 32,
                outBuffer & 0xFFFFFFFF,
                inSize,
                0,
                MFC_PUT_CMD ); // dma
  spu_writech(MFC_WrTagMask, 1 << 0 );
  (void)spu_mfcstat(2); // wait

  PROFILE_END( gTotalDmaSetTime )
}

RayPacket GetRayPacketData( int inIndex )
{
#ifdef DEBUG_TRACE_DMAS
  printf( "RayDMA\n" );
#endif
  RayPacket rayPacket;

  unsigned long long rayPacketPointer =
    request.inputRayPacketsBase + inIndex * sizeof(rayPacket);

  IssueDmaGetAndWait( (void*) &rayPacket,
                      rayPacketPointer,
                      sizeof(rayPacket) );

  (void)spu_mfcstat(2); // wait

  return rayPacket;
}

#ifdef ENABLE_NODE_CACHE
qword gNodeCacheData[NODE_CACHE_LINE_COUNT][NODE_CACHE_LINE_SIZE];
unsigned int gNodeCacheTags[NODE_CACHE_LINE_COUNT];

void InitializeNodeCache()
{
  int i;
  for( i = 0; i < NODE_CACHE_LINE_COUNT; i++ )
    gNodeCacheTags[i] = 0xFFFFFFFF;
}

#ifdef COLLECT_NODE_CACHE_STATS
unsigned long gNodeCacheGetCount = 0;
unsigned long gNodeCacheMissCount = 0;
#endif
#endif

qword GetNodePairData( unsigned int inIndex )
{
#ifdef ENABLE_PIPELINE
  return kdtree[inIndex];
#elif defined(ENABLE_NODE_CACHE)
  unsigned int lineBase = inIndex / NODE_CACHE_LINE_SIZE;
  unsigned int lineOffset = inIndex % NODE_CACHE_LINE_SIZE;

  unsigned int lineIndex = lineBase % NODE_CACHE_LINE_COUNT;
  if( __builtin_expect(gNodeCacheTags[lineIndex] != lineBase, 0) )
  {

#ifdef COLLECT_NODE_CACHE_STATS
    gNodeCacheMissCount++;
#endif

    unsigned long long linePointer =
      request.inputNodesBase + lineBase * NODE_CACHE_LINE_SIZE * sizeof(qword);
    IssueDmaGetAndWait( (void*) gNodeCacheData[lineIndex],
                        linePointer,
                        NODE_CACHE_LINE_SIZE * sizeof(qword) );
    gNodeCacheTags[lineIndex] = lineBase;
  }

#ifdef COLLECT_NODE_CACHE_STATS
  gNodeCacheGetCount++;
#endif


  return gNodeCacheData[lineIndex][lineOffset];

#else

#ifdef DEBUG_TRACE_DMAS
  printf( "NodeDMA %d\n", inIndex );
#endif
  qword nodes;

  unsigned long long nodePointer =
    request.inputNodesBase + inIndex * 2 * sizeof(Node);

  IssueDmaGetAndWait( (void*) &nodes,
                      nodePointer,
                      2*sizeof(Node) );

  return nodes;
#endif
}

#ifdef ENABLE_TRIANGLE_CACHE
Triangle gTriangleCacheData[TRIANGLE_CACHE_LINE_COUNT]
                           [TRIANGLE_CACHE_LINE_SIZE];
int gTriangleCacheTags[TRIANGLE_CACHE_LINE_COUNT];

void InitializeTriangleCache()
{
  int i;
  for( i = 0; i < TRIANGLE_CACHE_LINE_COUNT; i++ )
    gTriangleCacheTags[i] = 0xFFFFFFFF;
}

#ifdef COLLECT_TRIANGLE_CACHE_STATS
unsigned long gTriangleCacheGetCount = 0;
unsigned long gTriangleCacheMissCount = 0;
#endif
#endif

Triangle GetTriangleData( int inIndex )
{
#if defined(ENABLE_PIPELINE)
  return testtri[inIndex];
#elif defined(ENABLE_TRIANGLE_CACHE)
  int lineBase = inIndex / TRIANGLE_CACHE_LINE_SIZE;
  int lineOffset = inIndex % TRIANGLE_CACHE_LINE_SIZE;

  int lineIndex = lineBase % TRIANGLE_CACHE_LINE_COUNT;
  if( gTriangleCacheTags[lineIndex] != lineBase )
  {
#ifdef COLLECT_TRIANGLE_CACHE_STATS
    gTriangleCacheMissCount++;
#endif

    unsigned long long linePointer =
      request.inputTrianglesBase
      + lineBase * TRIANGLE_CACHE_LINE_SIZE * sizeof(Triangle);
    IssueDmaGetAndWait( (void*) gTriangleCacheData[lineIndex],
                        linePointer,
                        TRIANGLE_CACHE_LINE_SIZE * sizeof(Triangle) );
    gTriangleCacheTags[lineIndex] = lineBase;
  }

#ifdef COLLECT_TRIANGLE_CACHE_STATS
  gTriangleCacheGetCount++;
#endif

  return gTriangleCacheData[lineIndex][lineOffset];

#else

#ifdef DEBUG_TRACE_DMAS
  printf( "TriangleDMA %d\n", inIndex );
#endif
  Triangle triangle;

  unsigned long long trianglePointer =
    request.inputTrianglesBase + inIndex * sizeof(Triangle);

  IssueDmaGetAndWait( (void*) &triangle,
                      trianglePointer,
                      sizeof(triangle) );

  return triangle;
#endif
}

void SetHitPacketData( int inIndex, HitPacket* inHitPacket )
{
#ifdef DEBUG_TRACE_DMAS
  printf( "HitDMA %d\n", inIndex );
#endif
  unsigned long long hitPointer =
    request.outputHitPacketsBase + inIndex * sizeof(HitPacket);

  IssueDmaSetAndWait( (void*) inHitPacket,
                      hitPointer,
                      sizeof(HitPacket) );
}

void InitializeHit( HitPacket* ioHitPacket )
{
  ioHitPacket->triangleIndex = spu_splats( -1 );
  ioHitPacket->u = spu_splats( 0.0f );
  ioHitPacket->v = spu_splats( 0.0f );
  ioHitPacket->time = spu_splats( 10000.0f );
}

void IntersectTriangle( int inTriangleIndex,
                        RayPacket* inRayPacket,
                        HitPacket* ioHitPacket )
{
  STATS_INC( gTriangleCount );

#ifdef DEBUG_TRACE_INTERSECTION
  printf( "IntersectTriangle(%d)\n", inTriangleIndex );
#endif

  Triangle triangle = GetTriangleData( inTriangleIndex );

  volatile vector float rayO[3];
  rayO[0] = inRayPacket->origin.packet[0];
  rayO[1] = inRayPacket->origin.packet[1];
  rayO[2] = inRayPacket->origin.packet[2];

  volatile vector float rayD[3];
  rayD[0] = inRayPacket->direction.packet[0];
  rayD[1] = inRayPacket->direction.packet[1];
  rayD[2] = inRayPacket->direction.packet[2];

#ifdef DEBUG_TRACE_INTERSECTION
  debugPrintFloatVector( "ray.origin.x", rayO[0] );
  debugPrintFloatVector( "ray.origin.y", rayO[1] );
  debugPrintFloatVector( "ray.origin.z", rayO[2] );

  debugPrintFloatVector( "ray.direction.x", rayD[0] );
  debugPrintFloatVector( "ray.direction.y", rayD[1] );
  debugPrintFloatVector( "ray.direction.z", rayD[2] );
#endif

  vector signed int triIdxBest = ioHitPacket->triangleIndex;
  vector float tBest = ioHitPacket->time;
  vector float uBest = ioHitPacket->u;
  vector float vBest = ioHitPacket->v;
  vector float zero = spu_splats( 0.0f );
  vector float one = spu_splats( 1.0f );

#ifdef DEBUG_TRACE_INTERSECTION
  debugPrintFloatVector( "tBest", tBest );
  debugPrintFloatVector( "uBest", uBest );
  debugPrintFloatVector( "vBest", vBest );
  debugPrintFloatVector( "zero", zero );
  debugPrintFloatVector( "one", one );
#endif

  vector unsigned int bestMask;
  vector unsigned int hitMask;

  vector float v0[3];
  vector float e1[3];
  vector float e2[3];
  vector float e2xe1[3];
  vector float txrayD[3];
  vector float tvec[3];
  vector float invDet;
  vector float tHit;
  vector float uu;
  vector float vv;

  vector unsigned char splatWord0 =
    (vector unsigned char)(0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3);
  vector unsigned char splatWord1 =
    (vector unsigned char)(4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7);
  vector unsigned char splatWord2 =
    (vector unsigned char)(8, 9,10,11, 8, 9,10,11, 8, 9,10,11, 8, 9,10,10);
  vector unsigned char splatWord3 =
    (vector unsigned char)(12,13,14,15,12,13,14,15,12,13,14,15,12,13,14,15);

  vector float tmp0 = triangle.a;
  vector float tmp1 = triangle.b;
  vector float tmp2 = triangle.c;

  v0[0] = spu_shuffle( tmp0, tmp0, splatWord0 );
  v0[1] = spu_shuffle( tmp1, tmp1, splatWord0 );
  v0[2] = spu_shuffle( tmp2, tmp2, splatWord0 );

  e1[0] = spu_shuffle( tmp0, tmp0, splatWord1 );
  e1[1] = spu_shuffle( tmp1, tmp1, splatWord1 );
  e1[2] = spu_shuffle( tmp2, tmp2, splatWord1 );

  e2[0] = spu_shuffle( tmp0, tmp0, splatWord2 );
  e2[1] = spu_shuffle( tmp1, tmp1, splatWord2 );
  e2[2] = spu_shuffle( tmp2, tmp2, splatWord2 );

  e2xe1[0] = spu_shuffle( tmp0, tmp0, splatWord3 );
  e2xe1[1] = spu_shuffle( tmp1, tmp1, splatWord3 );
  e2xe1[2] = spu_shuffle( tmp2, tmp2, splatWord3 );

#ifdef DEBUG_TRACE_INTERSECTION
  debugPrintFloatVector( "v0.x", v0[0] );
  debugPrintFloatVector( "v0.y", v0[1] );
  debugPrintFloatVector( "v0.z", v0[2] );

  debugPrintFloatVector( "e1.x", e1[0] );
  debugPrintFloatVector( "e1.y", e1[1] );
  debugPrintFloatVector( "e1.z", e1[2] );

  debugPrintFloatVector( "e2.x", e2[0] );
  debugPrintFloatVector( "e2.y", e2[1] );
  debugPrintFloatVector( "e2.z", e2[2] );

  debugPrintFloatVector( "e2xe1.x", e2xe1[0] );
  debugPrintFloatVector( "e2xe1.y", e2xe1[1] );
  debugPrintFloatVector( "e2xe1.z", e2xe1[2] );
#endif

#define SPU_DOT(a, b) \
  spu_add( spu_add( spu_mul( a[0], b[0] ), spu_mul( a[1], b[1] )), \
           spu_mul( a[2], b[2] ) )

  invDet = spu_re( SPU_DOT(rayD, e2xe1) );
  tvec[0] = spu_sub( v0[0], rayO[0] );
  tvec[1] = spu_sub( v0[1], rayO[1] );
  tvec[2] = spu_sub( v0[2], rayO[2] );
  tHit = spu_mul( SPU_DOT(tvec, e2xe1), invDet );

#ifdef DEBUG_TRACE_INTERSECTION
  debugPrintFloatVector( "invDet", invDet );
  debugPrintFloatVector( "tvec.x", tvec[0] );
  debugPrintFloatVector( "tvec.y", tvec[1] );
  debugPrintFloatVector( "tvec.z", tvec[2] );
  debugPrintFloatVector( "tHit", tHit );
#endif
  
  bestMask = spu_andc( spu_cmpgt(tBest, tHit),
                       spu_cmpgt(zero, tHit) );

  // all rays in packet missed triangle plane
  if( spu_extract( spu_orx(bestMask), 0 ) == 0 )
  {
    //    printf( "all failed plane test\n" );
    return;
  }

  txrayD[0] = spu_sub(spu_mul(tvec[1], rayD[2]),
                      spu_mul(tvec[2], rayD[1]));
  txrayD[1] = spu_sub(spu_mul(tvec[2], rayD[0]),
                      spu_mul(tvec[0], rayD[2]));
  txrayD[2] = spu_sub(spu_mul(tvec[0], rayD[1]),
                      spu_mul(tvec[1], rayD[0]));

  uu = spu_sub(zero, SPU_DOT(txrayD, e2));
  vv = SPU_DOT(txrayD, e1);
  uu = spu_mul(uu, invDet);
  vv = spu_mul(vv, invDet);

#ifdef DEBUG_TRACE_INTERSECTION
  debugPrintFloatVector( "txrayD.x", txrayD[0] );
  debugPrintFloatVector( "txrayD.y", txrayD[1] );
  debugPrintFloatVector( "txrayD.z", txrayD[2] );

  debugPrintFloatVector( "uu", uu );
  debugPrintFloatVector( "vv", vv );
#endif
  
  hitMask = spu_nor(spu_or(
                           spu_cmpgt(zero, uu),
                           spu_cmpgt(zero, vv)),
                    spu_cmpgt(spu_add(uu, vv), one));
  hitMask = spu_and(hitMask, bestMask);

  // all rays in packet missed triangle plane
  // or missed barycentric coordinate test
  if( spu_extract( spu_orx(hitMask), 0 ) == 0 )
  {
    //    printf( "all failed barycentric test\n" );
    return;
  }

  //  printf( "somebody hit triangle %d\n", inTriangleIndex );

  tBest = (vector float) spu_cmov((qword) tBest, (qword) tHit, hitMask);
  uBest = (vector float) spu_cmov((qword) uBest, (qword) uu, hitMask);
  vBest = (vector float) spu_cmov((qword) vBest, (qword) vv, hitMask);
  triIdxBest = (vector signed int) spu_cmov( (qword) triIdxBest,
                                             (qword) spu_splats(inTriangleIndex),
                                       hitMask);

  ioHitPacket->time = tBest;
  ioHitPacket->u = uBest;
  ioHitPacket->v = vBest;
  ioHitPacket->triangleIndex = triIdxBest;
}

void IntersectLeaf( int inFirstPrimitiveIndex,
                    int inPrimitiveCount,
                    RayPacket* inRayPacket,
                    HitPacket* ioHitPacket )
{
#if 0
  printf( "IntersectLeaf(first:%d,count:%d,...)\n",
          inFirstPrimitiveIndex,
          inPrimitiveCount );
#endif
  PROFILE_BEGIN( gTotalIntersectTime )

  int i;
  for( i = 0; i < inPrimitiveCount; i++ )
  {
    IntersectTriangle( inFirstPrimitiveIndex + i,
                       inRayPacket,
                       ioHitPacket );
  }
  PROFILE_END( gTotalIntersectTime )
}


void IntersectScene( volatile float* inBoundsMin, volatile float* inBoundsMax,
                     RayPacket* inRayPacket, HitPacket* ioHitPacket )
{
  int i;

  vector float rayO[3];
  rayO[0] = inRayPacket->origin.packet[0];
  rayO[1] = inRayPacket->origin.packet[1];
  rayO[2] = inRayPacket->origin.packet[2];

  vector float rayD[3];
  rayD[0] = inRayPacket->direction.packet[0];
  rayD[1] = inRayPacket->direction.packet[1];
  rayD[2] = inRayPacket->direction.packet[2];

  vector float invD[3];
  invD[0] = spu_re( rayD[0] );
  invD[1] = spu_re( rayD[1] );
  invD[2] = spu_re( rayD[2] );

  vector float zero = spu_splats( 0.0f );
  vector unsigned int intZero = spu_splats( (unsigned int) 0 );
  vector unsigned int leftward[3];
  vector unsigned int signMask;
  vector unsigned int bad;
  signMask = spu_cmpgt(zero, invD[0]);
  leftward[0] = spu_splats( spu_extract( spu_orx( signMask ), 0 ) );
  bad = spu_and( spu_orx( signMask ),
                 spu_orx( spu_cmpeq( signMask, intZero ) ) );
  signMask = spu_cmpgt(zero, invD[1]);
  leftward[1] = spu_splats( spu_extract( spu_orx( signMask ), 0 ) );
  bad = spu_or( bad,
                spu_and( spu_orx( signMask ),
                         spu_orx( spu_cmpeq( signMask, intZero ) ) ) );
  signMask = spu_cmpgt(zero, invD[2]);
  leftward[2] = spu_splats( spu_extract( spu_orx( signMask ), 0 ) );
  bad = spu_or( bad,
                spu_and( spu_orx( signMask ),
                         spu_orx( spu_cmpeq( signMask, intZero ) ) ) );

  //debugPrintFloatVector( "direction.x", rayD[0] );
  //debugPrintFloatVector( "direction.y", rayD[1] );
  //debugPrintFloatVector( "direction.z", rayD[2] );

  //debugPrintUIntVector( "leftward.x", leftward[0] );
  //debugPrintUIntVector( "leftward.y", leftward[1] );
  //debugPrintUIntVector( "leftward.z", leftward[2] );

  if( spu_extract( bad, 0 ) != 0 )
  {
    STATS_INC( gBadPacketCount );
    return;
  }

  vector float tNear[3];
  vector float tFar[3];

  for( i = 0; i < 3; i++ )
  {
    vector float tmp1;
    vector float tmp2;

    tmp1 = spu_mul( spu_sub( spu_splats( inBoundsMin[i] ),
                             rayO[i] ),
                    invD[i] );
    tmp2 = spu_mul( spu_sub( spu_splats( inBoundsMax[i] ),
                             rayO[i] ),
                    invD[i] );

    tNear[i] = spu_min( tmp1, tmp2 );
    tFar[i] = spu_max( tmp1, tmp2 );
  }

  vector float tMin = spu_splats( 0.0f );
  tMin = spu_max(spu_max( tNear[0], tNear[1]),
                              spu_max( tNear[2], tMin ));
  vector float tMax = ioHitPacket->time;
  tMax = spu_min(spu_min( tFar[0], tFar[1]),
                              spu_min( tFar[2], tMax ));

  // fudge tmax, because Jeremy does too
  tMax = spu_mul(tMax, spu_splats(1.5f));

  //debugPrintFloatVector( "tMin", tMin );
  //debugPrintFloatVector( "tMax", tMax );

  vector unsigned int liveMask;
  vector unsigned int activeMask;

  liveMask = activeMask = spu_cmpge( tMax, tMin );
  if( spu_extract( spu_orx( liveMask ), 0 ) == 0 )
  {
    STATS_INC( gMissSceneCount );
    return;
  }

  int stackIndex = 0;
#define STACK_SIZE 32
  qword nodePairStack[STACK_SIZE];
  vector float tMinStack[STACK_SIZE];
  vector float tMaxStack[STACK_SIZE];

  qword nodePair = GetNodePairData( 0 );

  while( 1 )
  {
    PROFILE_BEGIN( gTraverseSplitTime )

    while( 1 )
    {
      //printf( "visiting node %d\n", nodeIndex );
      STATS_INC( gNodeCount );

      unsigned int leftIndex_splitAxis = spu_extract(
        (vector unsigned int) nodePair, 0 );

      unsigned int splitAxis = leftIndex_splitAxis & 0x3;

      if( __builtin_expect( splitAxis == 0x3, 0 ) )
        break;

      float splitValue = spu_extract(
        (vector float) nodePair, 1 );
      
      // process internal node
      unsigned int left = (unsigned int) leftIndex_splitAxis >> 3;

      //LOG(( "split axis=%d left=%d value=%f\n",
      //      splitAxis, left, splitValue ));

      //      PROFILE_BEGIN( gSplitGetNodeTime )
      nodePair = GetNodePairData( left );
      //      PROFILE_END( gSplitGetNodeTime )

      vector float tSplit = spu_mul(spu_sub(spu_splats(splitValue),
                                            rayO[splitAxis]),
                                    invD[splitAxis]);
      vector unsigned int wantFar = spu_andc(activeMask,
                                            spu_cmpgt(tSplit, tMax));
      vector unsigned int wantNear = spu_andc(activeMask,
                                             spu_cmpgt(tMin, tSplit));

      qword near = spu_rlqwbyte( nodePair,
         spu_extract( spu_and(spu_splats(8U), leftward[splitAxis]), 0 ));
      qword far = spu_rlqwbyte( nodePair,
         spu_extract( spu_andc(spu_splats(8U), leftward[splitAxis]), 0 ));

      unsigned int anyNear = spu_extract( spu_orx( wantNear ), 0 );
      unsigned int anyFar = spu_extract( spu_orx( wantFar ), 0 );

      //LOG(("anyNear=%d anyFar=%d\n", anyNear, anyFar));

      vector unsigned int mask = spu_splats( anyNear );
      nodePair = (qword) spu_sel( (vector unsigned int)far,
                                  (vector unsigned int)near,
                                  mask );

      //if( __builtin_expect( !(anyNear ^ anyFar), 0 ) )
      if( __builtin_expect( anyNear & anyFar, 0 ) )
      {
        //LOG(("push\n"));

        // do that stack thing... :)
        nodePairStack[stackIndex] = far;
        tMinStack[stackIndex] = spu_max(tSplit, tMin);
        tMaxStack[stackIndex] = tMax;
        stackIndex++;

        nodePair = near;
        tMax = spu_min(tSplit, tMax);
        activeMask = spu_cmpge(tMax, tMin);
      }
    }

    PROFILE_END( gTraverseSplitTime )

    // process leaf node
    //printf( "leaf\n" );
    unsigned int primitiveCount = spu_extract(
      (vector unsigned int) nodePair, 0 ) >> 2;
    unsigned int firstPrimitiveIndex = spu_extract(
      (vector unsigned int) nodePair, 1 );

    //LOG(( "leaf %d %d\n", firstPrimitiveIndex, primitiveCount ));

    IntersectLeaf( firstPrimitiveIndex, primitiveCount,
                   inRayPacket, ioHitPacket );

    liveMask = spu_cmpgt( ioHitPacket->time,
                          spu_max( tMax, tMin ) );

    if( spu_extract( spu_orx( liveMask ), 0 ) == 0 )
    {
      STATS_INC( gNormalCount );
      return;
    }

    do
    {
      if( stackIndex == 0 )
      {
        STATS_INC( gStackEmptyCount );
        return;
      }

      stackIndex--;
      nodePair = nodePairStack[stackIndex];
      tMin = tMinStack[stackIndex];
      tMax = tMaxStack[stackIndex];
      tMax = (vector float) spu_and( liveMask,
                                     (vector unsigned int) (qword) tMax );
      activeMask = spu_cmpge(tMax, tMin);

      //printf( "popped %d\n", nodeIndex );

    } while( spu_extract( spu_orx( activeMask ), 0 ) == 0 );
  }
}

static void
ProcessMegaPacket( RayPacket* inRays,
                   HitPacket* outHits,
                   unsigned int inCount )
{
  unsigned int j;
  for( j = 0; j < inCount; j++ )
  {
    LOG(("packet %d\n", j));
    
    RayPacket rayPacket = inRays[j];
    HitPacket hitPacket;
    
    InitializeHit( &hitPacket );
    PROFILE_BEGIN( gTotalTraverseTime )
    IntersectScene( request.bboxMin, request.bboxMax,
                    &rayPacket, &hitPacket );
    PROFILE_END( gTotalTraverseTime )

    //debugPrintIntVector( "hit:", hitPacket.triangleIndex );

    outHits[j] = hitPacket;
  }
}

int main(
  unsigned long long inThreadID,
  unsigned long long inContextPointer )
{
  LOG(("main\n"));

#ifdef ENABLE_PROFILER
  spu_writech( SPU_WrDec, 0xFFFFFFFF );
#endif

  PROFILE_BEGIN( gTotalTime )

  spu_writech(MFC_WrTagMask, -1);

  IssueDmaGetAndWait( (void*) &request,
                      inContextPointer,
                      sizeof(request) );

#ifdef ENABLE_PIPELINE
  IssueDmaGetAndWait( (void*) kdtree,
                      request.inputNodesBase,
                      request.inputNodeCount * sizeof(Node) );
  IssueDmaGetAndWait( (void*) testtri,
                      request.inputTrianglesBase,
                      request.inputTriangleCount * sizeof(Triangle) );
#endif

  spu_writech( SPU_WrOutMbox, MESSAGE_SPU_READY );

  while( 1 )
  {
    
#ifdef ENABLE_NODE_CACHE
  InitializeNodeCache();
#endif
#ifdef ENABLE_TRIANGLE_CACHE
  InitializeTriangleCache();
#endif

  unsigned int m = spu_readch( SPU_RdInMbox );

  if( m == MESSAGE_TERMINATE_THREAD )
    break;


  // allocate space for double-buffers
  // of messages, input ray packets,
  // and output hit packets
  unsigned int message[2];
  RayPacket megaPacketBuffer[2][MEGA_PACKET_SIZE];
  HitPacket megaHitBuffer[2][MEGA_PACKET_SIZE];

  // which buffer are we on?
  int bufferIndex = 0;

  // read our first message, and if its "terminate"
  // then do so
  message[bufferIndex] = m;
  if( message[bufferIndex] == MESSAGE_END_FRAME )
    continue;
  
  // all other messages are indices of "mega packets",
  // that is big blocks of ray data that we load
  // as a unit.

  // start an async DMA for the first mega packet
  // we issue DMA on tag groups TAG_GROUP_MEGA_PACKET + {0,1}
  // based on which of the two buffers we are using
  IssueDmaGetAsync( (void*) megaPacketBuffer[bufferIndex],
                    request.inputRayPacketsBase
                      + message[bufferIndex]
                        * MEGA_PACKET_SIZE * sizeof(RayPacket),
                    MEGA_PACKET_SIZE * sizeof(RayPacket),
                    TAG_GROUP_MEGA_PACKET + bufferIndex );

  while( 1 )
  {
    // in the steady state we read the message
    // telling us what to load for the next iteration
    int nextBufferIndex = bufferIndex ^ 1;
    message[nextBufferIndex] = spu_readch( SPU_RdInMbox );
    if( message[nextBufferIndex] == MESSAGE_END_FRAME )
      break;

    // issue the DMA for the next iteration
    IssueDmaGetAsync( (void*) megaPacketBuffer[nextBufferIndex],
                      request.inputRayPacketsBase
                        + message[nextBufferIndex]
                          * MEGA_PACKET_SIZE * sizeof(RayPacket),
                      MEGA_PACKET_SIZE * sizeof(RayPacket),
                      TAG_GROUP_MEGA_PACKET + nextBufferIndex );

    // wait for this iterations input data (DMA
    // started last iteration), as well as the output
    // data buffer (DMA started two iterations ago).
    IssueDmaWait( TAG_GROUP_MEGA_PACKET + bufferIndex );

    // trace the ray data for this iteration
    ProcessMegaPacket( megaPacketBuffer[bufferIndex],
                       megaHitBuffer[bufferIndex],
                       MEGA_PACKET_SIZE );

    // start the output DMA
    IssueDmaSetAsync( (void*) megaHitBuffer[bufferIndex],
                      request.outputHitPacketsBase
                        + message[bufferIndex]
                          * MEGA_PACKET_SIZE * sizeof(HitPacket),
                      MEGA_PACKET_SIZE * sizeof(HitPacket),
                      TAG_GROUP_MEGA_PACKET + bufferIndex );

    // swap buffers
    bufferIndex = nextBufferIndex;
  }

  // wait for any outstanding DMAs
  IssueDmaWait( TAG_GROUP_MEGA_PACKET + bufferIndex );

  // process the last pending mega packet
  ProcessMegaPacket( megaPacketBuffer[bufferIndex],
                     megaHitBuffer[bufferIndex],
                     MEGA_PACKET_SIZE );

  // write out the last data synchronously
  IssueDmaSetAndWait( (void*) megaHitBuffer[bufferIndex],
                      request.outputHitPacketsBase
                        + message[bufferIndex]
                          * MEGA_PACKET_SIZE * sizeof(HitPacket),
                      MEGA_PACKET_SIZE * sizeof(HitPacket) );

  }

  spu_writech( SPU_WrOutMbox, MESSAGE_SPU_DONE );

#ifdef ENABLE_NODE_CACHE
#ifdef COLLECT_NODE_CACHE_STATS
  printf( "node cache %d misses from %d fetches\n",
          gNodeCacheMissCount,
          gNodeCacheGetCount );
#endif
#endif

#ifdef ENABLE_TRIANGLE_CACHE
#ifdef COLLECT_TRIANGLE_CACHE_STATS
  printf( "triangle cache %d misses from %d fetches\n",
          gTriangleCacheMissCount,
          gTriangleCacheGetCount );
#endif
#endif

  PROFILE_END( gTotalTime )

#ifdef ENABLE_PROFILER
  printf( "total: %lld DMAGet: %lld DMASet: %lld Isect: %lld Trav: %lld Split: %lld SplitNode: %lld\n",
          gTotalTime,
          gTotalDmaGetTime,
          gTotalDmaSetTime,
          gTotalIntersectTime,
          gTotalTraverseTime,
          gTraverseSplitTime,
          gSplitGetNodeTime );
#endif

  STATS_PRINT( gNodeCount );
  STATS_PRINT( gTriangleCount );
  STATS_PRINT( gBadPacketCount );
  STATS_PRINT( gMissSceneCount );
  STATS_PRINT( gStackEmptyCount );
  STATS_PRINT( gNormalCount );

  LOG(("done with main\n"));

  return 0;
}
