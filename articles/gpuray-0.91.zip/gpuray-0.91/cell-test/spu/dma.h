// Copyright (C) 2006 Tim Foley

/*
 * dma.h --
 *      Functions for issuing and waiting for DMAs.
 */

#ifndef __SPU_DMA_H__
#define __SPU_DMA_H__

#include "log.h"
#include "profiler.h"

// profile counters for synchronous
// DMA transfers
PROFILE_DEFINE( gTotalDmaGetTime )
PROFILE_DEFINE( gTotalDmaSetTime )

/*
 * IssueDmaGetAsync --
 *      Start a DMA into the local-store
 *      address outBuffer, from the global
 *      address inBuffer for inSize bytes,
 *      and assign the transfer to group
 *      inGroup.
 *
 * Returns:
 *      void.
 */

static void
IssueDmaGetAsync( void* outBuffer,
                  unsigned long long inBuffer,
                  size_t inSize,
                  unsigned int inGroup )
{
   assert( (inBuffer & 0xF) == 0 );

   spu_mfcdma64( outBuffer,
                 inBuffer >> 32,
                 inBuffer & 0xFFFFFFFF,
                 inSize,
                 inGroup,
                 MFC_GET_CMD );
}

/*
 * IssueDmaSetAsync --
 *      Start a DMA from the local-store
 *      address inBuffer, to the global
 *      address outBuffer for inSize bytes,
 *      and assign the transfer to group
 *      inGroup.
 *
 * Returns:
 *      void.
 */

static void
IssueDmaSetAsync( void* inBuffer,
                  unsigned long long outBuffer,
                  size_t inSize,
                  unsigned int inGroup )
{
   assert( (outBuffer & 0xF) == 0 );

   spu_mfcdma64( inBuffer,
                 outBuffer >> 32,
                 outBuffer & 0xFFFFFFFF,
                 inSize,
                 inGroup,
                 MFC_PUT_CMD );
}

/*
 * IssueDmaWait --
 *      Wait for all previously-issued
 *      DMAs in group inGroup to complete.
 *
 * Returns:
 *      void.
 */

static inline void
IssueDmaWait( unsigned int inGroup )
{
   spu_writech(MFC_WrTagMask, 1 << inGroup );
   (void)spu_mfcstat(2);
}

/*
 * IssueDmaGetAndWait --
 *      Start a DMA into the local-store
 *      address outBuffer, from the global
 *      address inBuffer for inSize bytes,
 *      and waits for it to complete.
 *      Also waits for any pending
 *      DMAs in group 0.
 *
 * Returns:
 *      void.
 */

static void
IssueDmaGetAndWait( void* outBuffer,
                    unsigned long long inBuffer,
                    size_t inSize )
{
   PROFILE_BEGIN( gTotalDmaGetTime )

   IssueDmaGetAsync( outBuffer,
                    inBuffer,
                    inSize,
                    0 );
   IssueDmaWait( 0 );

   PROFILE_END( gTotalDmaGetTime )
}

/*
 * IssueDmaSetAndWait --
 *      Start a DMA from the local-store
 *      address inBuffer, to the global
 *      address outBuffer for inSize bytes,
 *      and waits for it to complete.
 *      Also waits for any pending
 *      DMAs in group 0.
 *
 * Returns:
 *      void.
 */

static void
IssueDmaSetAndWait( void* inBuffer,
                    unsigned long long outBuffer,
                    size_t inSize )
{
   PROFILE_BEGIN( gTotalDmaSetTime )

   IssueDmaSetAsync( inBuffer,
                      outBuffer,
                      inSize,
                      0 );
   IssueDmaWait( 0 );

   PROFILE_END( gTotalDmaSetTime )
}

#endif
