#include <stdio.h>
#include <spu_intrinsics.h>
#include <cbe_mfc.h>
#include <limits.h>
#include <math.h>
#if 0
#include <assert.h>
#else
#define assert(_foo) do {} while(0)
#endif
#include "../request.h"
#include "simdIntrinsics.h"

//#define DEBUG_TRACE_DMAS
//#define ENABLE_PROFILER
//#define ENABLE_LOG
//#define ENABLE_STATS

#include "profiler.h"
#include "log.h"
#include "stats.h"
#include "dma.h"

#define ENABLE_NODE_CACHE
//#define ENABLE_LRU
#define NODE_CACHE_LINE_QWORD_COUNT 8
#define NODE_CACHE_LINE_SIZE (NODE_CACHE_LINE_QWORD_COUNT * sizeof(qword))
#define NODE_CACHE_ASSOCIATIVITY 4
#define NODE_CACHE_SET_COUNT (2048 / NODE_CACHE_LINE_QWORD_COUNT)
#define NODE_CACHE_LINE_COUNT (NODE_CACHE_SET_COUNT * NODE_CACHE_ASSOCIATIVITY)
//#define COLLECT_NODE_CACHE_STATS

#define ENABLE_TRIANGLE_CACHE
#define TRIANGLE_CACHE_LINE_SIZE 4
#define TRIANGLE_CACHE_LINE_COUNT 256
//#define COLLECT_TRIANGLE_CACHE_STATS

#define TAG_GROUP_MEGA_PACKET 4
#define TAG_GROUP_NODE_CACHE 3

STATS_DEFINE( gNodeCount )
STATS_DEFINE( gTriangleCount )
STATS_DEFINE( gBadPacketCount )
STATS_DEFINE( gMissSceneCount )
STATS_DEFINE( gStackEmptyCount )
STATS_DEFINE( gNormalCount )

PROFILE_DEFINE( gTotalTime )
PROFILE_DEFINE( gTotalTraverseTime )
PROFILE_DEFINE( gTraverseSplitTime )
PROFILE_DEFINE( gSplitGetNodeTime )
PROFILE_DEFINE( gTotalIntersectTime )

volatile RequestContext request __attribute__((aligned(128)));

#ifdef ENABLE_NODE_CACHE
qword gNodeCacheData[NODE_CACHE_LINE_COUNT*NODE_CACHE_LINE_QWORD_COUNT] __attribute__((aligned(128)));
vector unsigned int gNodeCacheTags[NODE_CACHE_SET_COUNT*2] __attribute((aligned(16)));

void InitializeNodeCache()
{
  vector unsigned int offsets = (vector unsigned int)(
    0,
    NODE_CACHE_LINE_SIZE,
    2*NODE_CACHE_LINE_SIZE,
    3*NODE_CACHE_LINE_SIZE);
  offsets = spu_add( offsets, spu_splats( (unsigned int) gNodeCacheData ) );

  int i;
  for( i = 0; i < NODE_CACHE_SET_COUNT; i++ )
  {
    gNodeCacheTags[2*i] = spu_splats( 0xFFFFFFFF );
    gNodeCacheTags[2*i+1] = offsets;

    offsets = spu_add( offsets, (vector unsigned int)spu_splats( NODE_CACHE_LINE_SIZE*4 ) );
  }
}

#ifdef COLLECT_NODE_CACHE_STATS
unsigned long gNodeCacheGetCount = 0;
unsigned long gNodeCacheMissCount = 0;
#ifdef ENABLE_LRU
unsigned long gNodeCacheHitElement[4] = {0, 0, 0, 0};
#endif 
#endif
#endif

inline qword GetNodePairData( unsigned int inOffset )
{
#ifdef ENABLE_NODE_CACHE

#ifdef COLLECT_NODE_CACHE_STATS
  gNodeCacheGetCount++;
#endif

  // NOTE: inOffset is already multiplied by sizeof(qword)
  // so it is the byte offset of the data we want

#define NODE_LINE_OFFSET_MASK (NODE_CACHE_LINE_SIZE-1)
  unsigned int lineOffset = inOffset & NODE_LINE_OFFSET_MASK;

#define NODE_LINE_TAG_MASK (~NODE_LINE_OFFSET_MASK)
  unsigned int lineBase = inOffset & NODE_LINE_TAG_MASK;

#define NODE_SET_MASK ((NODE_CACHE_SET_COUNT-1) * NODE_CACHE_LINE_SIZE)
#define NODE_SET_FACTOR (NODE_CACHE_LINE_SIZE / (2*sizeof(qword)))
  unsigned int setOffset = (inOffset & NODE_SET_MASK) / NODE_SET_FACTOR;

  vector unsigned int* tagEntry = (vector unsigned int*)
    (((unsigned int) gNodeCacheTags) + setOffset);

  vector unsigned int tags = tagEntry[0];
  vector unsigned int dataPointers = tagEntry[1];

  vector unsigned int compareTags = spu_cmpeq( tags, spu_splats( lineBase ) );
  unsigned int anyHit = spu_extract( spu_orx( compareTags ), 0 );

  if( __builtin_expect(anyHit != 0, 1) )
  {
    unsigned int dataPointer = spu_extract( spu_orx( spu_and( dataPointers,
       compareTags ) ), 0 );

#ifdef ENABLE_LRU
    /* 
     * This part is updating the replacement priority order.
     * Now, most recently used is element 3.
     * Least recently used is element 0.
     * The lefter it is placed, the higher.
     * Hit element should be placed as element 3.
     * And others should be realigned accordingly.
     */
    if(spu_extract(compareTags, 3))
    {
#ifdef COLLECT_NODE_CACHE_STATS
      gNodeCacheHitElement[3]++;
#endif
      // Element 3 was hit. So there is no change.
      return *((qword*) (dataPointer+lineOffset));
    }
    else if(spu_extract(compareTags, 2))
    {
#ifdef COLLECT_NODE_CACHE_STATS
      gNodeCacheHitElement[2]++;
#endif
      // Element 2 was hit. So, element 3 was switched positions with element 2.
#if 0
      tags = spu_insert(spu_extract(tags, 3), tags, 2);
      tagEntry[0] = spu_insert(lineBase, tags, 3);
      dataPointers = spu_insert(spu_extract(dataPointers, 3), dataPointers, 2);
      tagEntry[1] = spu_insert(dataPointer, dataPointers, 3);
#else
      vector unsigned char pattern = (vector unsigned char)(0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
                                                            0x0C, 0x0D, 0x0E, 0x0F, 0x08, 0x09, 0x0A, 0x0B); 
      tagEntry[0] = spu_shuffle(tags, tags, pattern);
      tagEntry[1] = spu_shuffle(dataPointers, dataPointers, pattern);
#endif
    }
    else if(spu_extract(compareTags, 1))
    {
#ifdef COLLECT_NODE_CACHE_STATS
      gNodeCacheHitElement[1]++;
#endif
      // Element 1 was hit. So, the vector was rotated to the left by 4 bytes.
      // Then element 0 was switched positions with element 3.
      // As a result, element 1 was placed as element 3 and others were moved accordingly.
#if 0
      tags = spu_rlqwbyte(tags, 4);
      tags = spu_insert(spu_extract(tags, 3), tags, 0);
      tagEntry[0] = spu_insert(lineBase, tags, 3);
      dataPointers = spu_rlqwbyte(dataPointers, 4);
      dataPointers = spu_insert(spu_extract(dataPointers, 3), dataPointers, 0);
      tagEntry[1] = spu_insert(dataPointer, dataPointers, 3);
#else
      vector unsigned char pattern = (vector unsigned char)(0x00, 0x01, 0x02, 0x03, 0x08, 0x09, 0x0A, 0x0B, 
                                                            0x0C, 0x0D, 0x0E, 0x0F, 0x04, 0x05, 0x06, 0x07); 
      tagEntry[0] = spu_shuffle(tags, tags, pattern);
      tagEntry[1] = spu_shuffle(dataPointers, dataPointers, pattern);
#endif
    }
    else
    {
#ifdef COLLECT_NODE_CACHE_STATS
      gNodeCacheHitElement[0]++;
#endif
      // Element 0 was hit. So, the vector was just rotated to the left by 4 bytes.
      tagEntry[0] = spu_rlqwbyte(tags, 4);
      tagEntry[1] = spu_rlqwbyte(dataPointers, 4);
    }
#endif
    return *((qword*) (dataPointer+lineOffset));
  }

#ifdef COLLECT_NODE_CACHE_STATS
  gNodeCacheMissCount++;
#endif
  
  unsigned long long globalPointer =
    request.inputNodesBase + lineBase;

  unsigned int localPointer = spu_extract( dataPointers, 0 );
  
  IssueDmaGetAsync( (void*) localPointer,
                    globalPointer,
                    NODE_CACHE_LINE_SIZE,
                    TAG_GROUP_NODE_CACHE );
  
  tags = spu_insert( lineBase, tags, 0 );
  
  // rotate the tag entry so that we replace
  // a different element next time
  tags = spu_rlqwbyte( tags, 4 );
  dataPointers = spu_rlqwbyte( dataPointers, 4 );

  tagEntry[0] = tags;
  tagEntry[1] = dataPointers;

  IssueDmaWait( TAG_GROUP_NODE_CACHE );
  
  return *((qword*) (localPointer + lineOffset));

#else

#ifdef DEBUG_TRACE_DMAS
  printf( "NodeDMA %d\n", inIndex );
#endif
  Node nodes[2];

  int alignedIndex = inIndex & ~1;
  int offset = inIndex & 1;

  unsigned long long nodePointer =
    request.inputNodesBase + alignedIndex * sizeof(Node);

  IssueDmaGetAndWait( (void*) nodes,
                      nodePointer,
                      2*sizeof(Node) );

  return nodes[offset];
#endif
}

#ifdef ENABLE_TRIANGLE_CACHE
Triangle gTriangleCacheData[TRIANGLE_CACHE_LINE_COUNT]
                           [TRIANGLE_CACHE_LINE_SIZE];
int gTriangleCacheTags[TRIANGLE_CACHE_LINE_COUNT];

void InitializeTriangleCache()
{
  int i;
  for( i = 0; i < TRIANGLE_CACHE_LINE_COUNT; i++ )
    gTriangleCacheTags[i] = 0xFFFFFFFF;
}

#ifdef COLLECT_TRIANGLE_CACHE_STATS
unsigned long gTriangleCacheGetCount = 0;
unsigned long gTriangleCacheMissCount = 0;
#endif
#endif

Triangle GetTriangleData( int inIndex )
{
#ifdef ENABLE_TRIANGLE_CACHE
  int lineBase = inIndex / TRIANGLE_CACHE_LINE_SIZE;
  int lineOffset = inIndex % TRIANGLE_CACHE_LINE_SIZE;

  int lineIndex = lineBase % TRIANGLE_CACHE_LINE_COUNT;
  if( gTriangleCacheTags[lineIndex] != lineBase )
  {
#ifdef COLLECT_TRIANGLE_CACHE_STATS
    gTriangleCacheMissCount++;
#endif

    unsigned long long linePointer =
      request.inputTrianglesBase
      + lineBase * TRIANGLE_CACHE_LINE_SIZE * sizeof(Triangle);
    IssueDmaGetAndWait( (void*) gTriangleCacheData[lineIndex],
                        linePointer,
                        TRIANGLE_CACHE_LINE_SIZE * sizeof(Triangle) );
    gTriangleCacheTags[lineIndex] = lineBase;
  }

#ifdef COLLECT_TRIANGLE_CACHE_STATS
  gTriangleCacheGetCount++;
#endif

  return gTriangleCacheData[lineIndex][lineOffset];

#else

#ifdef DEBUG_TRACE_DMAS
  printf( "TriangleDMA %d\n", inIndex );
#endif
  Triangle triangle;

  unsigned long long trianglePointer =
    request.inputTrianglesBase + inIndex * sizeof(Triangle);

  IssueDmaGetAndWait( (void*) &triangle,
                      trianglePointer,
                      sizeof(triangle) );

  return triangle;
#endif
}

void InitializeHit( HitBundle* ioHitPacket )
{
  int i;
  for( i = 0; i < BUNDLES_PER_PACKET; i++ )
  {
    ioHitPacket[i].triangleIndex = spu_splats( -1 );
    ioHitPacket[i].u = spu_splats( 0.0f );
    ioHitPacket[i].v = spu_splats( 0.0f );
    ioHitPacket[i].time = spu_splats( 10000.0f );
  }
}

void IntersectTriangle( int inTriangleIndex,
                        vector unsigned int* activeMask,
                        RayBundle* inRayPacket,
                        HitBundle* ioHitPacket )
{
  STATS_INC( gTriangleCount );

#ifdef DEBUG_TRACE_INTERSECTION
  printf( "IntersectTriangle(%d)\n", inTriangleIndex );
#endif

  Triangle triangle = GetTriangleData( inTriangleIndex );

  vector float v0[3];
  vector float e1[3];
  vector float e2[3];
  vector float e2xe1[3];

  vector unsigned char splatWord0 =
    (vector unsigned char)(0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3);
  vector unsigned char splatWord1 =
    (vector unsigned char)(4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7);
  vector unsigned char splatWord2 =
    (vector unsigned char)(8, 9,10,11, 8, 9,10,11, 8, 9,10,11, 8, 9,10,10);
  vector unsigned char splatWord3 =
    (vector unsigned char)(12,13,14,15,12,13,14,15,12,13,14,15,12,13,14,15);

  vector float tmp0 = triangle.a;
  vector float tmp1 = triangle.b;
  vector float tmp2 = triangle.c;

  v0[0] = spu_shuffle( tmp0, tmp0, splatWord0 );
  v0[1] = spu_shuffle( tmp1, tmp1, splatWord0 );
  v0[2] = spu_shuffle( tmp2, tmp2, splatWord0 );

  e1[0] = spu_shuffle( tmp0, tmp0, splatWord1 );
  e1[1] = spu_shuffle( tmp1, tmp1, splatWord1 );
  e1[2] = spu_shuffle( tmp2, tmp2, splatWord1 );

  e2[0] = spu_shuffle( tmp0, tmp0, splatWord2 );
  e2[1] = spu_shuffle( tmp1, tmp1, splatWord2 );
  e2[2] = spu_shuffle( tmp2, tmp2, splatWord2 );

  e2xe1[0] = spu_shuffle( tmp0, tmp0, splatWord3 );
  e2xe1[1] = spu_shuffle( tmp1, tmp1, splatWord3 );
  e2xe1[2] = spu_shuffle( tmp2, tmp2, splatWord3 );

#define SPU_DOT(a, b) \
  spu_add( spu_add( spu_mul( a[0], b[0] ), spu_mul( a[1], b[1] )), \
           spu_mul( a[2], b[2] ) )

  volatile vector float rayO[BUNDLES_PER_PACKET][3];
  volatile vector float rayD[BUNDLES_PER_PACKET][3];
  vector signed int triIdxBest[BUNDLES_PER_PACKET];
  vector float tBest[BUNDLES_PER_PACKET];
  vector float uBest[BUNDLES_PER_PACKET];
  vector float vBest[BUNDLES_PER_PACKET];
  vector float zero = spu_splats( 0.0f );
  vector float one = spu_splats( 1.0f );

  vector unsigned int bestMask[BUNDLES_PER_PACKET];
  vector unsigned int hitMask[BUNDLES_PER_PACKET];

  vector float txrayD[BUNDLES_PER_PACKET][3];
  vector float tvec[BUNDLES_PER_PACKET][3];
  vector float invDet[BUNDLES_PER_PACKET];
  vector float tHit[BUNDLES_PER_PACKET];
  vector float uu[BUNDLES_PER_PACKET];
  vector float vv[BUNDLES_PER_PACKET];

  int j;
  for( j = 0; j < BUNDLES_PER_PACKET; j++ )
  {
    // all rays in packet vector missed triangle plane
    if( spu_extract( spu_orx(activeMask[j]), 0 ) == 0 )
    {
      //    printf( "all failed plane test\n" );
      continue;
    }

    rayO[j][0] = inRayPacket[j].origin.bundle[0];
    rayO[j][1] = inRayPacket[j].origin.bundle[1];
    rayO[j][2] = inRayPacket[j].origin.bundle[2];

    rayD[j][0] = inRayPacket[j].direction.bundle[0];
    rayD[j][1] = inRayPacket[j].direction.bundle[1];
    rayD[j][2] = inRayPacket[j].direction.bundle[2];

    triIdxBest[j] = ioHitPacket[j].triangleIndex;
    tBest[j] = ioHitPacket[j].time;
    uBest[j] = ioHitPacket[j].u;
    vBest[j] = ioHitPacket[j].v;

    invDet[j] = spu_re( SPU_DOT(rayD[j], e2xe1) );
    tvec[j][0] = spu_sub( v0[0], rayO[j][0] );
    tvec[j][1] = spu_sub( v0[1], rayO[j][1] );
    tvec[j][2] = spu_sub( v0[2], rayO[j][2] );
    tHit[j] = spu_mul( SPU_DOT(tvec[j], e2xe1), invDet[j] );

    bestMask[j] = spu_andc( spu_cmpgt(tBest[j], tHit[j]),
                            spu_cmpgt(zero, tHit[j]) );

    // all rays in packet vector missed triangle plane
    if( spu_extract( spu_orx(bestMask[j]), 0 ) == 0 )
    {
      //    printf( "all failed plane test\n" );
      continue;
    }

    txrayD[j][0] = spu_sub(spu_mul(tvec[j][1], rayD[j][2]),
                           spu_mul(tvec[j][2], rayD[j][1]));
    txrayD[j][1] = spu_sub(spu_mul(tvec[j][2], rayD[j][0]),
                           spu_mul(tvec[j][0], rayD[j][2]));
    txrayD[j][2] = spu_sub(spu_mul(tvec[j][0], rayD[j][1]),
                           spu_mul(tvec[j][1], rayD[j][0]));

    uu[j] = spu_sub(zero, SPU_DOT(txrayD[j], e2));
    vv[j] = SPU_DOT(txrayD[j], e1);
    uu[j] = spu_mul(uu[j], invDet[j]);
    vv[j] = spu_mul(vv[j], invDet[j]);

    hitMask[j] = spu_nor(spu_or(spu_cmpgt(zero, uu[j]),
                                spu_cmpgt(zero, vv[j])),
                         spu_cmpgt(spu_add(uu[j], vv[j]), one));
    hitMask[j] = spu_and(hitMask[j], bestMask[j]);

    // all rays in packet vector missed triangle plane
    // or missed barycentric coordinate test
    if( spu_extract( spu_orx(hitMask[j]), 0 ) == 0 )
    {
      //    printf( "all failed barycentric test\n" );
      continue;
    }

    //  printf( "somebody hit triangle %d\n", inTriangleIndex );

    tBest[j] = (vector float) spu_cmov((qword) tBest[j], (qword) tHit[j], hitMask[j]);
    uBest[j] = (vector float) spu_cmov((qword) uBest[j], (qword) uu[j], hitMask[j]);
    vBest[j] = (vector float) spu_cmov((qword) vBest[j], (qword) vv[j], hitMask[j]);
    triIdxBest[j] = (vector signed int) spu_cmov( (qword) triIdxBest[j],
                                                  (qword) spu_splats(inTriangleIndex),
                                                  hitMask[j]);

    ioHitPacket[j].time = tBest[j];
    ioHitPacket[j].u = uBest[j];
    ioHitPacket[j].v = vBest[j];
    ioHitPacket[j].triangleIndex = triIdxBest[j];
  }
}

static void
IntersectLeaf( int inFirstPrimitiveIndex,
               int inPrimitiveCount,
               vector unsigned int* activeMask,
               RayBundle* inRayPacket,
               HitBundle* ioHitPacket )
{
  PROFILE_BEGIN( gTotalIntersectTime )

  int i;
  for( i = 0; i < inPrimitiveCount; i++ )
  {
    IntersectTriangle( inFirstPrimitiveIndex + i,
                       activeMask,
                       inRayPacket,
                       ioHitPacket );
  }
  PROFILE_END( gTotalIntersectTime )
}


static void
IntersectScene( volatile float* inBoundsMin,
                volatile float* inBoundsMax,
                RayBundle* inRayPacket,
                HitBundle* ioHitPacket )
{
  int i, j;

  vector float rayO[BUNDLES_PER_PACKET][3];
  vector float rayD[BUNDLES_PER_PACKET][3];
  vector float invD[BUNDLES_PER_PACKET][3];

  vector float zero = spu_splats( 0.0f );
  vector unsigned int intZero = spu_splats( (unsigned int) 0 );

  vector unsigned int leftward[3] = { (vector unsigned int)( 0, 0, 0, 0 ),
                                      (vector unsigned int)( 0, 0, 0, 0 ),
                                      (vector unsigned int)( 0, 0, 0, 0 ) };
  vector unsigned int signMask;
  vector unsigned int bad = (vector unsigned int)( 0, 0, 0, 0 );

  for( j = 0; j < BUNDLES_PER_PACKET; j++ )
  {
    rayO[j][0] = inRayPacket[j].origin.bundle[0];
    rayO[j][1] = inRayPacket[j].origin.bundle[1];
    rayO[j][2] = inRayPacket[j].origin.bundle[2];

    rayD[j][0] = inRayPacket[j].direction.bundle[0];
    rayD[j][1] = inRayPacket[j].direction.bundle[1];
    rayD[j][2] = inRayPacket[j].direction.bundle[2];

    invD[j][0] = spu_re( rayD[j][0] );
    invD[j][1] = spu_re( rayD[j][1] );
    invD[j][2] = spu_re( rayD[j][2] );

    signMask = spu_cmpgt(zero, invD[j][0]);
    leftward[0] = spu_or( leftward[0], 
                          spu_splats( spu_extract( spu_orx( signMask ), 0 ) ) );
    bad = spu_or( bad,
                  spu_and( spu_orx( signMask ),
                           spu_orx( spu_cmpeq( signMask, intZero ) ) ) );
    signMask = spu_cmpgt(zero, invD[j][1]);
    leftward[1] = spu_or( leftward[1], 
                          spu_splats( spu_extract( spu_orx( signMask ), 0 ) ) );
    bad = spu_or( bad,
                  spu_and( spu_orx( signMask ),
                           spu_orx( spu_cmpeq( signMask, intZero ) ) ) );
    signMask = spu_cmpgt(zero, invD[j][2]);
    leftward[2] = spu_or( leftward[2], 
                          spu_splats( spu_extract( spu_orx( signMask ), 0 ) ) );
    bad = spu_or( bad,
                  spu_and( spu_orx( signMask ),
                           spu_orx( spu_cmpeq( signMask, intZero ) ) ) );

  }

  if( spu_extract( bad, 0 ) != 0 )
  {
    STATS_INC( gBadPacketCount );
    return;
  }

  vector float tNear[BUNDLES_PER_PACKET][3];
  vector float tFar[BUNDLES_PER_PACKET][3];
  vector float tMin[BUNDLES_PER_PACKET];
  vector float tMax[BUNDLES_PER_PACKET];
  vector unsigned int liveMask[BUNDLES_PER_PACKET];
  vector unsigned int activeMask[BUNDLES_PER_PACKET];
  unsigned int hitScene = 0;

#define LOOP_UNROLLING

  for( j = 0; j < BUNDLES_PER_PACKET; j++ )
  {
#ifdef LOOP_UNROLLING
      vector float tmp1[3];
      vector float tmp2[3];

      tmp1[0] = spu_mul( spu_sub( spu_splats( inBoundsMin[0] ),
                                  rayO[j][0] ),
                         invD[j][0] );
      tmp1[1] = spu_mul( spu_sub( spu_splats( inBoundsMin[1] ),
                                  rayO[j][1] ),
                         invD[j][1] );
      tmp1[2] = spu_mul( spu_sub( spu_splats( inBoundsMin[2] ),
                                  rayO[j][2] ),
                         invD[j][2] );
      tmp2[0] = spu_mul( spu_sub( spu_splats( inBoundsMax[0] ),
                                  rayO[j][0] ),
                         invD[j][0] );
      tmp2[1] = spu_mul( spu_sub( spu_splats( inBoundsMax[1] ),
                                  rayO[j][1] ),
                         invD[j][1] );
      tmp2[2] = spu_mul( spu_sub( spu_splats( inBoundsMax[2] ),
                                  rayO[j][2] ),
                         invD[j][2] );

      tNear[j][0] = spu_min( tmp1[0], tmp2[0] );
      tNear[j][1] = spu_min( tmp1[1], tmp2[1] );
      tNear[j][2] = spu_min( tmp1[2], tmp2[2] );
      tFar[j][0] = spu_max( tmp1[0], tmp2[0] );
      tFar[j][1] = spu_max( tmp1[1], tmp2[1] );
      tFar[j][2] = spu_max( tmp1[2], tmp2[2] );
#else
    for( i = 0; i < 3; i++ )
    {
      vector float tmp1;
      vector float tmp2;

      tmp1 = spu_mul( spu_sub( spu_splats( inBoundsMin[i] ),
                               rayO[j][i] ),
                      invD[j][i] );
      tmp2 = spu_mul( spu_sub( spu_splats( inBoundsMax[i] ),
                               rayO[j][i] ),
                      invD[j][i] );

      tNear[j][i] = spu_min( tmp1, tmp2 );
      tFar[j][i] = spu_max( tmp1, tmp2 );

      //debugPrintFloatVector( "tNear", tNear[j][i] );
      //debugPrintFloatVector( "tFar", tFar[j][i] );
    }
#endif

    tMin[j] = spu_splats( 0.0f );
    tMin[j] = spu_max(spu_max( tNear[j][0], tNear[j][1]),
                      spu_max( tNear[j][2], tMin[j] ));
    tMax[j] = ioHitPacket[j].time;
    tMax[j] = spu_min(spu_min( tFar[j][0], tFar[j][1]),
                      spu_min( tFar[j][2], tMax[j] ));

    // fudge tmax, because Jeremy does too
    tMax[j] = spu_mul(tMax[j], spu_splats(1.5f));

    //debugPrintFloatVector( "tMin", tMin[j] );
    //debugPrintFloatVector( "tMax", tMax[j] );

    liveMask[j] = activeMask[j] = spu_cmpge( tMax[j], tMin[j] );
    hitScene |=  spu_extract( spu_orx( liveMask[j] ), 0 );
  }

  if( hitScene == 0 )
  {
    STATS_INC( gMissSceneCount );
    return;
  }

  int stackIndex = 0;
#define STACK_SIZE 32
  qword nodePairStack[STACK_SIZE];
  vector float tMinStack[BUNDLES_PER_PACKET][STACK_SIZE];
  vector float tMaxStack[BUNDLES_PER_PACKET][STACK_SIZE];

  vector float tSplit[BUNDLES_PER_PACKET];
  vector unsigned int wantNear[BUNDLES_PER_PACKET];
  vector unsigned int wantFar[BUNDLES_PER_PACKET];

  qword nodePair = GetNodePairData( 0 );

  while( 1 )
  {
    PROFILE_BEGIN( gTraverseSplitTime )

    while( 1 )
    {
      //printf( "visiting node %d\n", nodeIndex );
      STATS_INC( gNodeCount );

      unsigned int leftIndex_splitAxis = spu_extract(
        (vector unsigned int) nodePair, 0 );

      unsigned int splitAxis = leftIndex_splitAxis & 0x3;

      if( __builtin_expect( splitAxis == 0x3, 0 ) )
        break;

      float splitValue = spu_extract(
        (vector float) nodePair, 1 );
      
      // process internal node
      unsigned int left = (unsigned int) leftIndex_splitAxis;

      //LOG(( "split axis=%d left=%d value=%f\n",
      //    splitAxis, left, splitValue ));

      //      PROFILE_BEGIN( gSplitGetNodeTime )
      nodePair = GetNodePairData( left << 1 );
      //      PROFILE_END( gSplitGetNodeTime )

      qword near = spu_rlqwbyte( nodePair,
         spu_extract( spu_and(spu_splats(8U), leftward[splitAxis]), 0 ));
      qword far = spu_rlqwbyte( nodePair,
         spu_extract( spu_andc(spu_splats(8U), leftward[splitAxis]), 0 ));

      unsigned int anyNear = 0;
      unsigned int anyFar = 0;

      for( j = 0; j < BUNDLES_PER_PACKET; j++ )
      {
        tSplit[j] = spu_mul(spu_sub(spu_splats(splitValue),
                                    rayO[j][splitAxis]),
                            invD[j][splitAxis]);
        wantFar[j] = spu_andc(activeMask[j],
                              spu_cmpgt(tSplit[j], tMax[j]));
        wantNear[j] = spu_andc(activeMask[j],
                               spu_cmpgt(tMin[j], tSplit[j]));

        anyNear |= spu_extract( spu_orx( wantNear[j] ), 0 );
        anyFar |= spu_extract( spu_orx( wantFar[j] ), 0 );
      }

      //LOG(("anyNear=%d anyFar=%d\n", anyNear, anyFar));

      vector unsigned int mask = spu_splats( anyNear );
      nodePair = (qword) spu_sel( (vector unsigned int)far,
                                  (vector unsigned int)near,
                                  mask );

      //if( __builtin_expect( !(anyNear ^ anyFar), 0 ) )
      if( __builtin_expect( anyNear & anyFar, 0 ) )
      {
        //LOG(("push\n"));

        // do that stack thing... :)
        for( j = 0; j < BUNDLES_PER_PACKET; j++ )
        {
          tMinStack[j][stackIndex] = spu_max(tSplit[j], tMin[j]);
          tMaxStack[j][stackIndex] = tMax[j];
          tMax[j] = spu_min(tSplit[j], tMax[j]);
          activeMask[j] = spu_cmpge(tMax[j], tMin[j]);
        }
        nodePairStack[stackIndex] = far;
        stackIndex++;
        nodePair = near;
      }
    }

    PROFILE_END( gTraverseSplitTime )

    // process leaf node
    //printf( "leaf\n" );
    unsigned int primitiveCount = spu_extract(
      (vector unsigned int) nodePair, 0 ) >> 2;
    unsigned int firstPrimitiveIndex = spu_extract(
      (vector unsigned int) nodePair, 1 );

    //LOG(( "leaf %d %d\n", firstPrimitiveIndex, primitiveCount ));

    IntersectLeaf( firstPrimitiveIndex, primitiveCount,
                   activeMask, inRayPacket, ioHitPacket );

    unsigned int normal = 0;

    for( j = 0; j < BUNDLES_PER_PACKET; j++ )
    {
      liveMask[j] = spu_cmpgt( ioHitPacket[j].time,
                               spu_max( tMax[j], tMin[j] ) );
      normal |= spu_extract( spu_orx( liveMask[j] ), 0 );
    }

    if( normal == 0 )
    {
      STATS_INC( gNormalCount );
      return;
    }

    int active = 0;

    do
    {
      if( stackIndex == 0 )
      {
        STATS_INC( gStackEmptyCount );
        return;
      }

      stackIndex--;
      nodePair = nodePairStack[stackIndex];

      for( j = 0; j < BUNDLES_PER_PACKET; j++ )
      { 
        tMin[j] = tMinStack[j][stackIndex];
        tMax[j] = tMaxStack[j][stackIndex];
        tMax[j] = (vector float) spu_and( liveMask[j],
                                          (vector unsigned int) (qword) tMax[j] );
        activeMask[j] = spu_cmpge(tMax[j], tMin[j]);
        active |= spu_extract( spu_orx( activeMask[j] ), 0 );
      }
      //printf( "popped %d\n", nodeIndex );

    } while( active == 0 );
  }
}

/*
 * ProcessMegaPacket --
 *
 *      Process a buffer of rays
 *      to produce hits.
 *
 * Returns:
 *      void.
 */

static void
ProcessMegaPacket( RayBundle* inRays,
                   HitBundle* outHits,
                   unsigned int inRayBundleCount )
{
  RayBundle* rays = inRays;
  HitBundle* hits = outHits;

  assert( inRayBundleCount % BUNDLES_PER_PACKET == 0 );

  unsigned int packetsRemaining = inRayBundleCount / BUNDLES_PER_PACKET;
  while( packetsRemaining-- )
  {
    InitializeHit( hits );
    PROFILE_BEGIN( gTotalTraverseTime );
    IntersectScene( request.bboxMin,
                    request.bboxMax,
                    rays,
                    hits );
    PROFILE_END( gTotalTraverseTime );

    rays += BUNDLES_PER_PACKET;
    hits += BUNDLES_PER_PACKET;
  }
}

/*
 * ProcessFrame --
 *
 *      Receive data for a single frame
 *      from the PPE until MESSAGE_END_FRAME
 *      is received.
 *      'inMessage' is the first message to
 *      be processed for this frame.
 *
 * Returns:
 *      void.
 */

static void
ProcessFrame( unsigned int inMessage )
{
  // allocate space for double-buffers
  // of messages, input ray packets,
  // and output hit packets
  unsigned int message[2];
  unsigned int messageIndex = 0;
  
  RayBundle rayBuffer[2][BUNDLES_PER_TRANSFER_BLOCK];
  HitBundle hitBuffer[2][BUNDLES_PER_TRANSFER_BLOCK];
  unsigned int bufferIndex = 0;

  // read our first message, and if its "end frame"
  // then do so
  message[messageIndex] = inMessage;
  if( message[messageIndex] == MESSAGE_END_FRAME )
    return;

  unsigned int bufferDestinationOffset = 0;
  unsigned int ii = 0;


  // this is the first iteration of the loop
  // where we set things up for the steady-state
  // cast.

  unsigned int nextBufferIndex = bufferIndex;
  unsigned int nextBufferSourceOffset =
    message[messageIndex] * RAY_MESSAGE_BLOCK_SIZE
    + ii * RAY_TRANSFER_BLOCK_SIZE;
  unsigned int nextBufferDestinationOffset = 
    message[messageIndex] * HIT_MESSAGE_BLOCK_SIZE
    + ii * HIT_TRANSFER_BLOCK_SIZE;
  
  IssueDmaGetAsync( (void*) rayBuffer[nextBufferIndex],
                    request.inputRayPacketsBase + nextBufferSourceOffset,
                    RAY_TRANSFER_BLOCK_SIZE,
                    TAG_GROUP_MEGA_PACKET + nextBufferIndex );
      
  bufferIndex = nextBufferIndex;
  bufferDestinationOffset = nextBufferDestinationOffset;
  ii++;

  // this is the steady-state loop
  // where we always a previous block
  // to wait for, a current one to
  // process, and a next one to start
  // pulling in...

  while( 1 )
  {
    for( ; ii < TRANSFER_BLOCKS_PER_MESSAGE_BLOCK; ii++ )
    {
      unsigned int nextBufferIndex = bufferIndex ^ 1;
      unsigned int nextBufferSourceOffset =
        message[messageIndex] * RAY_MESSAGE_BLOCK_SIZE
        + ii * RAY_TRANSFER_BLOCK_SIZE;
      unsigned int nextBufferDestinationOffset = 
        message[messageIndex] * HIT_MESSAGE_BLOCK_SIZE
        + ii * HIT_TRANSFER_BLOCK_SIZE;

      IssueDmaGetAsync( (void*) rayBuffer[nextBufferIndex],
                        request.inputRayPacketsBase + nextBufferSourceOffset,
                        RAY_TRANSFER_BLOCK_SIZE,
                        TAG_GROUP_MEGA_PACKET + nextBufferIndex );
    
      IssueDmaWait( TAG_GROUP_MEGA_PACKET + bufferIndex );

      ProcessMegaPacket( rayBuffer[bufferIndex],
                         hitBuffer[bufferIndex],
                         BUNDLES_PER_TRANSFER_BLOCK );

      IssueDmaSetAsync( (void*) hitBuffer[bufferIndex],
                        request.outputHitPacketsBase
                          + bufferDestinationOffset,
                        HIT_TRANSFER_BLOCK_SIZE,
                        TAG_GROUP_MEGA_PACKET + bufferIndex );
      
      bufferIndex = nextBufferIndex;
      bufferDestinationOffset = nextBufferDestinationOffset;
    }

    unsigned int nextMessageIndex = messageIndex ^ 1;
    message[nextMessageIndex] = spu_readch( SPU_RdInMbox );
    if( message[nextMessageIndex] == MESSAGE_END_FRAME )
      break;

    messageIndex = nextMessageIndex;
    ii = 0;
  }

  // finish any remaining transfer block
  IssueDmaWait( TAG_GROUP_MEGA_PACKET + bufferIndex );
  
  ProcessMegaPacket( rayBuffer[bufferIndex],
                     hitBuffer[bufferIndex],
                     BUNDLES_PER_TRANSFER_BLOCK );

  IssueDmaSetAndWait( (void*) hitBuffer[bufferIndex],
                      request.outputHitPacketsBase
                        + bufferDestinationOffset,
                      HIT_TRANSFER_BLOCK_SIZE );
}

/*
 * ProcessFrames --
 *
 *      Respond to frames sent from the PPE
 *      until MESSAGE_TERMINATE_THREAD is
 *      received.
 *
 * Returns:
 *      void.
 */
static void
ProcessFrames()
{
  while( 1 )
  {
    // re-initialize the node
    // and triangle caches between
    // frames to simulate a case
    // where scene data changes per-frame
#ifdef ENABLE_NODE_CACHE
    InitializeNodeCache();
#endif
#ifdef ENABLE_TRIANGLE_CACHE
    InitializeTriangleCache();
#endif

    // read the next request from the PPE
    // and terminate if it is the 'terminate thread'
    // request
    unsigned int message = spu_readch( SPU_RdInMbox );
    if( message == MESSAGE_TERMINATE_THREAD )
      break;

    // otherwise this is the first message for
    // a frame's worth of data, so process  the frame
    ProcessFrame( message );
  }
}

/*
 * PrintCollectedResults --
 *
 *      Write all relevant data collected
 *      to standard output for the user.
 *
 * Returns:
 *      void.
 */

static void
PrintCollectedResults()
{
#ifdef ENABLE_NODE_CACHE
#ifdef COLLECT_NODE_CACHE_STATS
  printf( "node cache %ld misses from %ld fetches\n",
          gNodeCacheMissCount,
          gNodeCacheGetCount );
#ifdef ENABLE_LRU
  printf( "element3 %ld (%ld\%) element2 %ld (%ld\%) element1 %ld (%ld\%) element0 %ld (%ld\%)\n",
          gNodeCacheHitElement[3], 100 * gNodeCacheHitElement[3] / (gNodeCacheGetCount - gNodeCacheMissCount),
          gNodeCacheHitElement[2], 100 * gNodeCacheHitElement[2] / (gNodeCacheGetCount - gNodeCacheMissCount),
          gNodeCacheHitElement[1], 100 * gNodeCacheHitElement[1] / (gNodeCacheGetCount - gNodeCacheMissCount),
          gNodeCacheHitElement[0], 100 * gNodeCacheHitElement[0] / (gNodeCacheGetCount - gNodeCacheMissCount) );
#endif
#endif
#endif

#ifdef ENABLE_TRIANGLE_CACHE
#ifdef COLLECT_TRIANGLE_CACHE_STATS
  printf( "triangle cache %d misses from %d fetches\n",
          gTriangleCacheMissCount,
          gTriangleCacheGetCount );
#endif
#endif

  PROFILE_END( gTotalTime )

#ifdef ENABLE_PROFILER
  printf( "total: %lld DMAGet: %lld DMASet: %lld Isect: %lld Trav: %lld Split: %lld SplitNode: %lld\n",
          gTotalTime,
          gTotalDmaGetTime,
          gTotalDmaSetTime,
          gTotalIntersectTime,
          gTotalTraverseTime,
          gTraverseSplitTime,
          gSplitGetNodeTime );
#endif

  STATS_PRINT( gNodeCount );
  STATS_PRINT( gTriangleCount );
  STATS_PRINT( gBadPacketCount );
  STATS_PRINT( gMissSceneCount );
  STATS_PRINT( gStackEmptyCount );
  STATS_PRINT( gNormalCount );
}

int main(
  unsigned long long inThreadID,
  unsigned long long inContextPointer )
{
  // initialize profiler
  PROFILE_INITIALIZE()
  PROFILE_BEGIN( gTotalTime )

  // read in frame-independent data
  IssueDmaGetAndWait( (void*) &request,
                      inContextPointer,
                      sizeof(request) );

  // let the PPE know we are ready
  spu_writech( SPU_WrOutMbox, MESSAGE_SPU_READY );

  // main loop - process one or more frames
  ProcessFrames();

  // let the PPE know we are dpme
  spu_writech( SPU_WrOutMbox, MESSAGE_SPU_DONE );

  // if we are collecting any stats
  // print them out before exit
  PrintCollectedResults();

  return 0;
}
