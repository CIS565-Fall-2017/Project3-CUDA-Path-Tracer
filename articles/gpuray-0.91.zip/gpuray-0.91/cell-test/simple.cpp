// simple.cpp

#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <sys/time.h>
#include <assert.h>
#include <string.h>

extern "C" {
#include <libspe.h>
}

#include "request.h"
#include "scene.h"

extern spe_program_handle_t simple_spu;

int main( int argc, char** argv )
{
  const char* sceneName = "cbox";

  if( argc > 1 )
    sceneName = argv[1];

  spe_program_handle_t* programHandle = &simple_spu;
  if( argc > 2 )
  {
    const char* programName = argv[2];
    if( strcmp( programName, "simple" ) == 0 )
      programHandle = &simple_spu;
    else
    {
      fprintf( stderr, "uknown program name %s\n", programName );
      exit( 1 );
    }
  }

  // control for how many times to re-submit the same frame
  // (when testing throughput rather than end-to-end latency)
  int repeatFrameSubmitCount = 1;

  if( argc > 3 )
    repeatFrameSubmitCount = atoi( argv[3] );

  int threadCount = 8;

  if( argc > 4 )
    threadCount = atoi( argv[4] );

  char rayFileName[1024];
  char triangleFileName[1024];
  char kdtreeFileName[1024];

  sprintf( rayFileName, "%s.rays", sceneName );
  sprintf( triangleFileName, "%s.triangles", sceneName );
  sprintf( kdtreeFileName, "%s.kdtree", sceneName );

  // number of SPE threads to launch
  // can range from 1-16 for our dual-processor
  // blades, but will scale best in the 1-8 range
  static const int kMaximumThreadCount = 16;
  speid_t speThreadIDs[kMaximumThreadCount];

  if( threadCount <= 0 )
    threadCount = 1;
  if( threadCount > kMaximumThreadCount )
    threadCount = kMaximumThreadCount;


  // allocate a buffer to hold static information
  // for the various processing threads...
  // XXX: we allocate kThreadCount of these,
  // although they currently all contain identical data
  RequestContext* requests;
  posix_memalign( (void**) &requests, 16,
                  threadCount * sizeof(RequestContext) );

  // load all of the data from input files

  RayBundle* rayBundles;
  int rayBundleCount;
  int imageWidth;
  int imageHeight;

  loadRayBundles( rayFileName,
                  &rayBundles,
                  &rayBundleCount,
                  &imageWidth,
                  &imageHeight );

  Triangle* rawTriangles;
  int rawTriangleCount;

  loadTriangles( triangleFileName,
                 &rawTriangles,
                 &rawTriangleCount );

  float bboxMin[3];
  float bboxMax[3];

  Node* nodes;
  int nodeCount;

  int* indices;
  int indexCount;

  Triangle* triangles;
  int triangleCount;  

  loadKdTree( kdtreeFileName,
              rawTriangles,
              rawTriangleCount,
              bboxMin,
              bboxMax,
              &nodes,
              &nodeCount,
              &indices,
              &indexCount,
              &triangles,
              &triangleCount );

  HitBundle* hitBundles;
  int hitBundleCount = rayBundleCount;

  posix_memalign( (void**) &hitBundles, 16,
                  hitBundleCount * sizeof(HitBundle) );

  unsigned int rayCount = imageWidth * imageHeight;
  printf( "%s scene with %d nodes %d indices (%d triangles) and %d rays\n",
          sceneName,
          nodeCount,
          indexCount,
          rawTriangleCount,
          rayCount );

  // launch all the threads

  for( int i = 0; i < threadCount; i++ )
  {
    requests[i].inputRayPacketsBase = (unsigned long) rayBundles;
    requests[i].outputHitPacketsBase = (unsigned long) hitBundles;
    requests[i].inputRayPacketCount = 0; // XXX: unused
    requests[i].inputNodesBase = (unsigned long) nodes;
    requests[i].inputTrianglesBase = (unsigned long) triangles;
    requests[i].inputNodeCount = nodeCount;
    requests[i].inputTriangleCount = triangleCount;

    for( int j = 0; j < 3; j++ )
    {
      requests[i].bboxMin[j] = bboxMin[j];
      requests[i].bboxMax[j] = bboxMax[j];
    }

    speThreadIDs[i] = spe_create_thread( 0,
                                         programHandle,
                                         (void*) (requests + i),
                                         NULL,
                                         (unsigned long) -1, 0 );
    
    if( speThreadIDs[i] == 0 )
    {
      fprintf( stderr, "Failed to create SPE thread\n" );
      exit(1);
    }
  }
  
  for( int i = 0; i < threadCount; i++ )
  {
    while( spe_stat_out_mbox( speThreadIDs[i] ) == 0 )
      ;
    unsigned int message = spe_read_out_mbox( speThreadIDs[i] );
    assert( message == MESSAGE_SPU_READY );
  }
  // the threads are started and ready to serve
  // as ray-tracing "servers". We start timing
  // now, as we launch the job

  timeval startTime;
  gettimeofday( &startTime, NULL );

  static unsigned int kMegaPacketSize = BUNDLES_PER_MESSAGE_BLOCK;


  // submit this one frame of data multiple times,
  // so that we can measure throughput rather than
  // the end-to-end time of a single frame...
  for( int jj = 0; jj < repeatFrameSubmitCount; jj++ )
  {

    int blockCount = rayBundleCount / kMegaPacketSize;
    int blockIndex = 0;

    while( true )
    {
      if( blockCount == 0 )
        break;

      for( int i = 0; i < threadCount; i++ )
      {
        // check number of free slots in threads
        // input queue
        if( spe_stat_in_mbox( speThreadIDs[i] ) != 0 )
        {
          // if there is an available slot,
          // fill it
          spe_write_in_mbox( speThreadIDs[i], blockIndex );
          blockIndex++;
          blockCount--;
          if( blockCount == 0 )
            break;
        }
      }
    }
    
    // inform all the SPEs of end-of-frame
    // in case they want to invalidate cache or anything
    for( int i = 0; i < threadCount; i++ )
    {
      // wait until an open slot is available in the mailbox
      while( spe_stat_in_mbox( speThreadIDs[i] ) == 0 )
        ;
      spe_write_in_mbox( speThreadIDs[i], MESSAGE_END_FRAME );
    }
  }

  // we must now inform each thread that we are done
  // distributing data, so that they can shut down
  // XXX: we need a way to insert a "fence" into
  // each threads mailbox queue after each frame
  // worth of data. When it processes all data before
  // this fence, the SPE would put an even into
  // the PPU's mailbox to inform it that it is safe
  // to display the frame

  for( int i = 0; i < threadCount; i++ )
  {
    // wait until an open slot is available in the mailbox
    while( spe_stat_in_mbox( speThreadIDs[i] ) == 0 )
      ;
    spe_write_in_mbox( speThreadIDs[i], MESSAGE_TERMINATE_THREAD );
  }

  for( int i = 0; i < threadCount; i++ )
  {
    while( spe_stat_out_mbox( speThreadIDs[i] ) == 0 )
      ;
    unsigned int message = spe_read_out_mbox( speThreadIDs[i] );
    assert( message == MESSAGE_SPU_DONE );
  }

  // we are now guaranteed to have all the frame's
  // hits back in PPE memory, so we can stop our timer

  timeval stopTime;
  gettimeofday( &stopTime, NULL );

  // XXX: we should really just wait for some kind
  // of signal from the SPEs that they are done with
  // this frame, but for now we wait for thread
  // completion

  for( int i = 0; i < threadCount; i++ )
  {
    int status;
    spe_wait( speThreadIDs[i], &status, 0 );
  }


  long elapsedSeconds = stopTime.tv_sec - startTime.tv_sec;
  long elapsedMicroseconds = stopTime.tv_usec - startTime.tv_usec;

  elapsedMicroseconds = elapsedSeconds*1000000 + elapsedMicroseconds;


  printf( "start %d:%d end %d:%d elapsed %d\n",
          startTime.tv_sec,
          startTime.tv_usec,
          stopTime.tv_sec,
          stopTime.tv_usec,
          elapsedMicroseconds );

  long totalRayCount = rayCount * repeatFrameSubmitCount;

  printf( "total of %d rays\n", totalRayCount );

  printf( "%fMrays/s\n",
          ((double) totalRayCount / (double) elapsedMicroseconds) );

  // debug code to dump hits
#if 0
  //for( int i = 0; i < hitPacketCount; i++ )
  int i = 32;
  {
    for( int j = 0; j < PACKET_SIZE; j++ )
    {
      int indexIndex = hitPackets[i].array.triangleIndex[j];
      int index = indexIndex >= 0 ? indices[indexIndex] : -1;

      printf( "ray[%d][%d] = tri %d time %f uv %f %f\n",
              i, j,
              index,
              hitPackets[i].array.time[j],
              hitPackets[i].array.u[j],
              hitPackets[i].array.v[j] );
    }
  }
#endif

  // write out a poorly-shaded image to allow us
  // to visually check correctness...

  FILE* outputImageFile = fopen( "result.ppm", "wb" );
  if( outputImageFile == NULL )
  {
    fprintf( stderr, "couldn't open output image\n" );
    exit(-1);
  }

  fprintf( outputImageFile, "P6\n" );
  fprintf( outputImageFile, "%d %d\n", imageWidth, imageHeight );
  fprintf( outputImageFile, "255\n" );
  for( int y = 0; y < imageHeight; y++ )
  {
    for( int x = 0; x < imageWidth; x++ )
    {
      int swizzled = swizzleIndex( y*imageWidth + x, imageWidth );
      int i = swizzled / BUNDLE_SIZE;
      int j = swizzled % BUNDLE_SIZE;

      int indexIndex = hitBundles[i].array.triangleIndex[j];
      int index = indexIndex >= 0 ? indices[indexIndex] : -1;

      float data[3] = { 0, 0, 0 };
      if( index != -1 )
      {
        data[0] = hitBundles[i].array.u[j];
        data[1] = hitBundles[i].array.v[j];
        data[2] = 1 - (data[0] + data[1]);
      }

      for( int k = 0; k < 3; k++ )
        fputc( (char)(unsigned char)( data[k]*255.0f), outputImageFile );
    }
  }
  fclose( outputImageFile );

  return 0;
}
