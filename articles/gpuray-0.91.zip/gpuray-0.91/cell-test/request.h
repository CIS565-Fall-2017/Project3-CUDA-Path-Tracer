/* request.h */

#ifndef REQUEST_H
#define REQUEST_H

#ifdef __cplusplus
extern "C" {
#endif

// number of elements in a SIMD bundle
#define BUNDLE_SIZE 4

// number of SIMD bundles in a packet
#define BUNDLES_PER_PACKET 4

// number of bundles per group
// we DMA in
#define BUNDLES_PER_TRANSFER_BLOCK 128
#define RAY_TRANSFER_BLOCK_SIZE \
  (BUNDLES_PER_TRANSFER_BLOCK * sizeof(RayBundle))
#define HIT_TRANSFER_BLOCK_SIZE \
  (BUNDLES_PER_TRANSFER_BLOCK * sizeof(HitBundle))

#define BUNDLES_PER_MESSAGE_BLOCK 1024
#define RAY_MESSAGE_BLOCK_SIZE \
  (BUNDLES_PER_MESSAGE_BLOCK * sizeof(RayBundle))
#define HIT_MESSAGE_BLOCK_SIZE \
  (BUNDLES_PER_MESSAGE_BLOCK * sizeof(HitBundle))
#define TRANSFER_BLOCKS_PER_MESSAGE_BLOCK \
  (BUNDLES_PER_MESSAGE_BLOCK / BUNDLES_PER_TRANSFER_BLOCK)

#define MESSAGE_END_FRAME        0xFFFFFFFE
#define MESSAGE_TERMINATE_THREAD 0xFFFFFFFF
#define MESSAGE_SPU_READY        0x00000001
#define MESSAGE_SPU_DONE         0x00000002

typedef struct RequestContext_t
{
  unsigned long long inputRayPacketsBase;
  unsigned long long inputNodesBase;
  unsigned long long inputTrianglesBase;
  unsigned long long outputHitPacketsBase;

  float bboxMin[3];
  float bboxMax[3];
  int inputRayPacketCount;
  int inputNodeCount;

  int inputTriangleCount;
  int padding[3];
} RequestContext;

typedef union Float3Bundle_t
{
  struct
  {
    vector float bundle[3];
  };
  struct
  {
    float array[3][4];
  };
} Float3Bundle;

typedef struct RayBundle_t
{
  Float3Bundle origin;
  Float3Bundle direction;
} RayBundle;

typedef union HitBundle_t
{
  struct
  {
    vector signed int triangleIndex;
    vector float u;
    vector float v;
    vector float time;
  };
  struct
  {
    int triangleIndex[BUNDLE_SIZE];
    float u[BUNDLE_SIZE];
    float v[BUNDLE_SIZE];
    float time[BUNDLE_SIZE];
  } array;
} HitBundle;

typedef union Node_t
{
  struct
  {
    unsigned int leftChildIndex;
    float splitValue;
  } split;
  
  struct
  {
    unsigned int primitiveCount;
    unsigned int firstPrimitiveIndex;
  } leaf;  
} Node;

typedef union Triangle_t
{
  // we pad it out to 3 float4s
  // so that it will be 16-byte
  // aligned

  struct
  {
    vector float a;
    vector float b;
    vector float c;
  };
  float array[3][4];
} Triangle;

#ifdef __cplusplus
}
#endif

#endif
