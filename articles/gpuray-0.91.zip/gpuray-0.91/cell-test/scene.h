// scene.h
#ifndef SCENE_H
#define SCENE_H

#include "request.h"

unsigned int swizzleIndex( unsigned int inIndex, int inWidth );
unsigned int unswizzleIndex( unsigned int inIndex, int inWidth );

void loadRayBundles( const char* inFileName,
                     RayBundle** outRayBundles,
                     int* outRayBundleCount,
                     int* outWidth,
                     int* outHeight );

void loadTriangles( const char* inFileName,
                    Triangle** outTriangles,
                    int* outTriangleCount );

void loadKdTree( const char* inFileName,
                 Triangle* inTriangles,
                 int inTriangleCount,
                 float* outBoundsMin,
                 float* outBoundsMax,
                 Node** outNodes,
                 int* outNodeCount,
                 int** outIndices,
                 int* outIndexCount,
                 Triangle** outTriangles,
                 int* outTriangleCount );

#endif
