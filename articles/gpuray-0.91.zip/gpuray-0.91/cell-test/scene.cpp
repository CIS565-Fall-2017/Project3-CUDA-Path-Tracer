// scene.cpp
#include "scene.h"

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

unsigned int swizzleIndex( unsigned int inIndex, int inWidth )
{
  unsigned int rayIndexX = inIndex % inWidth;
  unsigned int rayIndexY = inIndex / inWidth;
  
  unsigned int swizzledRayIndex = 0;
  for( int bit = 0; bit < 32; bit++ )
  {
    unsigned int mask = 1 << bit;
    if( rayIndexX & mask )
      swizzledRayIndex |= 1 << (bit*2);
    if( rayIndexY & mask )
      swizzledRayIndex |= 1 << (bit*2 + 1);
  }

  return swizzledRayIndex;
}

unsigned int unswizzleIndex( unsigned int inIndex )
{
}

void loadRayBundles( const char* inFileName,
                     RayBundle** outRayBundles,
                     int* outRayBundleCount,
                     int* outWidth,
                     int* outHeight )
{
  FILE* file = fopen( inFileName, "r" );

  int width;
  fread( &width, sizeof(width), 1, file );

  int height;
  fread( &height, sizeof(height), 1, file );

  int rayCount = width * height;

  assert( rayCount % BUNDLE_SIZE == 0 );
  int rayBundleCount = rayCount / BUNDLE_SIZE;

  RayBundle* rayBundles = NULL;
  posix_memalign( (void**) &rayBundles, 16,
                  rayBundleCount * sizeof(RayBundle) );
  assert( rayBundles != NULL );

  for( int i = 0; i < rayBundleCount; i++ )
  {
    for( int j = 0; j < BUNDLE_SIZE; j ++ )
    {
      unsigned int linearRayIndex = i*BUNDLE_SIZE + j;
      
      unsigned int swizzledRayIndex = swizzleIndex( linearRayIndex, width );

      unsigned int bundleIndex = swizzledRayIndex / BUNDLE_SIZE;
      unsigned int bundleOffset = swizzledRayIndex % BUNDLE_SIZE;

      float origin[3];
      float direction[3];

      fread( &origin[0], sizeof(float), 3, file );
      fread( &direction[0], sizeof(float), 3, file );

      for( int k = 0; k < 3; k++ )
      {
        rayBundles[bundleIndex].origin.array[k][bundleOffset] = origin[k];
        rayBundles[bundleIndex].direction.array[k][bundleOffset] = direction[k];
      }
    }
  }
  fclose( file );

  *outRayBundles = rayBundles;
  *outRayBundleCount = rayBundleCount;
  *outWidth = width;
  *outHeight = height;
}

void loadTriangles( const char* inFileName,
                    Triangle** outTriangles,
                    int* outTriangleCount )
{
  FILE* file = fopen( inFileName, "r" );

  int triangleCount;
  fread( &triangleCount, sizeof(triangleCount), 1, file );

  Triangle* triangles;
  posix_memalign( (void**) &triangles, 16,
                  triangleCount * sizeof(Triangle) );

  for( int i = 0; i < triangleCount; i++ )
  {
    float v0[3];
    float v1[3];
    float v2[3];

    fread( &v0[0], sizeof(float), 3, file );
    fread( &v1[0], sizeof(float), 3, file );
    fread( &v2[0], sizeof(float), 3, file );

    float e1[3];
    float e2[3];
    float e2xe1[3];

    for( int j = 0; j < 3; j++ )
    {
      e1[j] = v1[j] - v0[j];
      e2[j] = v2[j] - v0[j];
    }

    for( int j = 0; j < 3; j++ )
    {
      int jp1 = (j+1) % 3;
      int jp2 = (j+2) % 3;
      e2xe1[j] = e2[jp1]*e1[jp2] - e2[jp2]*e1[jp1];
    }

    for( int j = 0; j < 3; j++ )
    {
      triangles[i].array[j][0] = v0[j];
      triangles[i].array[j][1] = e1[j];
      triangles[i].array[j][2] = e2[j];
      triangles[i].array[j][3] = e2xe1[j];
    }
  }

  fclose( file );

  *outTriangles = triangles;
  *outTriangleCount = triangleCount;
}

void loadKdTree( const char* inFileName,
                 Triangle* inTriangles,
                 int inTriangleCount,
                 float* outBoundsMin,
                 float* outBoundsMax,
                 Node** outNodes,
                 int* outNodeCount,
                 int** outIndices,
                 int* outIndexCount,
                 Triangle** outTriangles,
                 int* outTriangleCount )
{
  FILE* file = fopen( inFileName, "r" );

  fread( outBoundsMin, sizeof(float), 3, file );
  fread( outBoundsMax, sizeof(float), 3, file );


  int nodeCount;
  fread( &nodeCount, sizeof(nodeCount), 1, file );

  int alignedNodeCount = nodeCount + (nodeCount & 1);

  Node* nodes;
  posix_memalign( (void**) &nodes,16,
                  alignedNodeCount * sizeof(Node) );

  for( int i = 0; i < nodeCount; i++ )
  {
    Node node;
    fread( &node, sizeof(node), 1, file );
    nodes[i] = node;
  }

  int indexCount;
  fread( &indexCount, sizeof(indexCount), 1, file );

  int* indices;
  posix_memalign( (void**) &indices, 16,
                  indexCount * sizeof(int) );

  for( int i = 0; i < indexCount; i++ )
  {
    int index;
    fread( &index, sizeof(index), 1, file );

    assert( index < inTriangleCount );

    indices[i] = index;
  }

  Triangle* indexedTriangles;
  posix_memalign( (void**) &indexedTriangles, 16,
                  indexCount * sizeof(Triangle) );

  for( int i = 0; i < indexCount; i++ )
  {
    indexedTriangles[i] = inTriangles[indices[i]];
  }

  // read the indices and generate triangles...

  *outNodes = nodes;
  *outNodeCount = nodeCount;
  *outIndices = indices;
  *outIndexCount = indexCount;
  *outTriangles = indexedTriangles;
  *outTriangleCount = indexCount;
}
