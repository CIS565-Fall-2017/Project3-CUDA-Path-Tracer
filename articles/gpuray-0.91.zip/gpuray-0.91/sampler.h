/* *************************************************************************
 * Copyright (C) 2006 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * sampler.h --
 *
 *      Takes a scalar value and samples it according to some distribution.
 */

#ifndef __SAMPLER_H__
#define __SAMPLER_H__

#include "common/integerTypes.h"

#ifdef __cplusplus
extern "C" {
#endif

extern void Sampler_IndexTo2D(uint32 index, uint32 width, uint32 *x, uint32 *y);

#ifdef __cplusplus
}
#endif
#endif
