/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * cameraManager.h --
 *
 *      Class to hide details of moving a camera within a scene.
 */

#ifndef __CAMERAMANAGER_H__
#define __CAMERAMANAGER_H__

#include "main.h"
#include "scene.h"
#include "quaternion.h"

class SceneTransformation
{
public:
   Vec3f GetCenter() { return _center; }
   void SetCenter(const Vec3f& c) {
      _center = c;
   }

   quaternion GetRotation() { return _rotation; }
   void SetRotation(const quaternion& r) {
      _rotation = r;
   }

   void Rotate(const quaternion& q);

   Vec3f transformPoint(const Vec3f& p) const;
   Vec3f transformVector(const Vec3f& v) const;

private:
   Vec3f _center;
   quaternion _rotation;
};

class CameraManager {
public:
   CameraManager(Scene* inScene, int inWidth, int inHeight);
   ~CameraManager(void);

   SceneTransformation getSceneTransformation() const { return _sceneTransformation; }
   CameraFrame getSceneSpaceCameraFrame() const { return _sceneSpaceCameraFrame; }
   CameraInfo getSceneSpaceCameraInfo() const { return _sceneSpaceCameraInfo; }

   void MoveCamera(float dx, float dy);
   void RotateCamera(float dx, float dy);
   void RotateScene( float dx, float dy );
   void ResetScene(void);
    void ResetScene(Vec3f center, Vec3f Target, Vec3f up);
   void PrintScene(void);

protected:
   void CreateCameraFrame( const FPSCameraFrame& inFPSCamera, CameraFrame& outFrame );
   void CreateCameraInfo( const CameraFrame& inCameraFrame, CameraInfo& outInfo );
   void CreateSceneSpaceCamera();

   int _width, _height;

   Scene* _scene;
   SceneTransformation _sceneTransformation;

   Vec3f _defaultUp, _defaultU, _defaultV;
   FPSCameraFrame _worldSpaceCameraFrame;
   CameraFrame _sceneSpaceCameraFrame;
   CameraInfo _sceneSpaceCameraInfo;
};

#endif
