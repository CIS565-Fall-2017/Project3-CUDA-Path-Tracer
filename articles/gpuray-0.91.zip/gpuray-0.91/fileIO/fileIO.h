#ifndef FILEIO_H
#define FILEIO_H

#include <stdio.h>
#include "../common/commonTypes.h"

#include "types.h"
#include "hmatrix3.h"
#include "bitvector.h"

typedef struct Grid {
   Tuple3i      dim;
   Vec3f       min;
   Vec3f       max;
   Vec3f       vsize;

   int          nTris;

   int          trilistSize;
   int          *trilistOffset;
   int          *trilist;

   BitVector    *bitmap;
} Grid;

void ReadVoxFile(char *fname, bool verbose, Grid& grid,
		 Point3* &v0, Point3* &v1, Point3* &v2,
		 Normal3* &n0, Normal3* &n1, Normal3* &n2,
		 Spectra* &c0, Spectra* &c1, Spectra* &c2);

void WriteVoxFile(char *fname, int *ntris, int modelno,
		  const Tuple3i &grid_dim, const Vec3f &grid_min,
		  const Vec3f &grid_max, const Vec3f &grid_vsize,
		  BitVector* bv, int ****voxels,
		  Point3 **v0, Point3 **v1, Point3 **v2,
		  Normal3 **n0, Normal3 **n1, Normal3 **n2,
		  Spectra **c0, Spectra **c1, Spectra **c2);

void ReadPlyFile(char *filename, int &numtris, HMatrix3 xform,
		 Point3* &v0, Point3* &v1, Point3* &v2,
		 Normal3* &n0, Normal3* &n1, Normal3* &n2,
		 Spectra* &c0, Spectra* &c1, Spectra* &c2);

void ReadTrianglesFile( const char* inFileName, Grid& outGrid,
   Point3*& outV0, Point3*& outV1, Point3*& outV2,
   Normal3*& outN0, Normal3*& outN1, Normal3*& outN2,
   Spectra*& outC0, Spectra*& outC1, Spectra*& outC2 );

#endif /* FILEIO_H */
