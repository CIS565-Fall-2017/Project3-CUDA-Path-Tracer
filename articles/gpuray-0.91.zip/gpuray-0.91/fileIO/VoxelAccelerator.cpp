// VoxelAccelerator.cpp

#include "VoxelAccelerator.h"

#include "fileIO.h"
#include "types.h"
#include "bitvector.h"

#include <vector>
#include <assert.h>
#include <fstream>


class VoxelAccelerator :
  public IVoxelAccelerator
{
public:
  VoxelAccelerator( const uint32 inGridDimensions[3] )
  {
    uint32 cellCount = 1;
    for( uint32 i = 0; i < 3; i++ )
    {
      _gridDimensions[i] = inGridDimensions[i];
      cellCount *= _gridDimensions[i];
    }

    _cellTriangleIndices.resize( cellCount );
  }

  virtual ~VoxelAccelerator() {}

  BoundingBox getBoundingBox() const {
    return _boundingBox;
  }

  void setBoundingBox( const BoundingBox& inBoundingBox ) {
    _boundingBox = inBoundingBox;
  }

  BoundingBox getCellBoundingBox( uint32 inCellIndex[3] ) const
  {
    Vec3f index( (float)inCellIndex[0], (float)inCellIndex[1], (float)inCellIndex[2] );

    Vec3f bboxDim = _boundingBox.maximum - _boundingBox.minimum;
    Vec3f gridDim = Vec3f( (float)_gridDimensions[0], (float)_gridDimensions[1], (float)_gridDimensions[2] );

    BoundingBox result;
    result.minimum = _boundingBox.minimum + bboxDim * ( index / gridDim );
    result.maximum = _boundingBox.minimum + bboxDim * ( (index + Vec3f(1)) / gridDim );

    return result;
  }

  uint32 getCellTriangleCount( uint32 inCellIndex[3] ) const
  {
    uint32 cellIndex = getLinearCellIndex( inCellIndex );
    return _cellTriangleIndices[cellIndex].size();
  }

  uint32 getIndexedCellTriangleIndex( uint32 inCellIndex[3], uint32 inIndex ) const
  {
    uint32 cellIndex = getLinearCellIndex( inCellIndex );
    return _cellTriangleIndices[cellIndex][inIndex];
  }

  Vec3f getCellVertex( uint32 inCellIndex[3], uint32 inCorner ) const
  {
    BoundingBox bbox = getCellBoundingBox( inCellIndex );

    Vec3f result;
    result.x = (inCorner & 1) ? bbox.maximum.x : bbox.minimum.x;
    result.y = (inCorner & 2) ? bbox.maximum.y : bbox.minimum.y;
    result.z = (inCorner & 4) ? bbox.maximum.z : bbox.minimum.z;
    return result;
  }

  BoundingBox getTriangleBoundingBox( const Vec3f* inCornerPositions ) const
  {
    BoundingBox result( inCornerPositions[0] );
    result = join( result, inCornerPositions[1] );
    result = join( result, inCornerPositions[2] );
    return result;
  }

  void getCellIndexRange( const BoundingBox& inBoundingBox, uint32 outMin[3], uint32 outMax[3] ) const
  {
    Vec3f dimensions = _boundingBox.maximum - _boundingBox.minimum;
    Vec3f minRatio = (inBoundingBox.minimum - _boundingBox.minimum) / dimensions;
    Vec3f maxRatio = (inBoundingBox.maximum - _boundingBox.minimum) / dimensions;

    for( uint32 i = 0; i < 3; i++ )
    {
      outMin[i] = (uint32) (minRatio[i] * _gridDimensions[i]);
      outMax[i] = (uint32) (maxRatio[i] * _gridDimensions[i] + 0.5f);
    
      if( outMin[i] < 0 ) outMin[i] = 0;
      if( outMax[i] < 0 ) outMax[i] = 0;
      if( outMin[i] >= _gridDimensions[i] ) outMin[i] = _gridDimensions[i] - 1;
      if( outMax[i] >= _gridDimensions[i] ) outMax[i] = _gridDimensions[i] - 1;
    }
  }

  class ClassifyResult
  {
  public:
    ClassifyResult() {}
    ClassifyResult( float inValue )
      : minimum(inValue), maximum(inValue)
    {
    }

    void expand( const ClassifyResult& inOther )
    {
       minimum = ::minimum( minimum, inOther.minimum );
       maximum = ::maximum( maximum, inOther.maximum );
    }

    bool intersects( const ClassifyResult& inOther )
    {
      if( minimum > inOther.maximum ) return false;
      if( maximum < inOther.minimum ) return false;
      return true;
    }

  private:
    float minimum;
    float maximum;
  };

  ClassifyResult classify( const Vec3f& inPoint, const Vec3f& inFrom, const Vec3f& inTo ) const
  {
    Vec3f origin = inFrom;
    Vec3f dir = normalize( inTo - inFrom );

    Vec3f p = inPoint - origin;
    float result = dot( p, dir );

    return ClassifyResult( result );
  }

  bool isSeparatingAxis( Vec3f inFrom, Vec3f inTo, uint32 inCellIndex[3], const Vec3f* inTriangleCorners ) const
  {
    ClassifyResult cellResult;
    cellResult = classify( getCellVertex(inCellIndex,0), inFrom, inTo );

    for( uint32 i = 1; i < 8; i++ )
    {
      Vec3f cellVertex = getCellVertex( inCellIndex, i );
      
      ClassifyResult r = classify( cellVertex, inFrom, inTo );
      cellResult.expand( r );
    }

    ClassifyResult triResult;
    triResult = classify( inTriangleCorners[0], inFrom, inTo );
    triResult.expand( classify( inTriangleCorners[1], inFrom, inTo ) );
    triResult.expand( classify( inTriangleCorners[2], inFrom, inTo ) );

    return !( cellResult.intersects( triResult ) );
  }

  bool addTriangleToCell( uint32 inCellIndex[3], uint32 inTriangleIndex, const Vec3f* inCornerPositions )
  {
    Vec3f cellCenter = _boundingBox.minimum + 
      (Vec3f( (float)inCellIndex[0], (float)inCellIndex[1], (float)inCellIndex[2] ) + Vec3f(0.5f)) * (_boundingBox.maximum - _boundingBox.minimum) / Vec3f( (float)_gridDimensions[0], (float)_gridDimensions[1], (float)_gridDimensions[2] );

    Vec3f boxAxes[] = { Vec3f(1,0,0), Vec3f(0,1,0), Vec3f(0,0,1) };

    for( uint32 i = 0; i < 3; i++ )
    {
      if( isSeparatingAxis( cellCenter, cellCenter + boxAxes[i], inCellIndex, inCornerPositions ) )
        return false;
    }


    Vec3f triAxes[3];
    triAxes[0] = inCornerPositions[1] - inCornerPositions[0];
    triAxes[1] = inCornerPositions[2] - inCornerPositions[1];
    triAxes[2] = inCornerPositions[0] - inCornerPositions[2];

    Vec3f normalDirection = cross( triAxes[0], triAxes[1] );
    if( dot(normalDirection, normalDirection) > 0.0f )
    {
      Vec3f normal = normalize( normalDirection );

      if( isSeparatingAxis( cellCenter, cellCenter + normal, inCellIndex, inCornerPositions ) )
        return false;
    }
    

    for( uint32 i = 0; i < 3; i++ )
    {
      for( uint32 j = 0; j < 3; j++ )
      {
        Vec3f axis = cross( boxAxes[i], triAxes[j] );

        if( dot( axis, axis ) <= 0.01 )
          continue;

        if( isSeparatingAxis( cellCenter, cellCenter + axis, inCellIndex, inCornerPositions ) )
          return false;
      }
    }
    
    uint32 cellIndex = getLinearCellIndex( inCellIndex );
    _cellTriangleIndices[cellIndex].push_back( inTriangleIndex );
	return true;
  }

  void addTriangle( const FullTriangle& inTriangle )
  {
    uint32 triangleIndex = _triangles.size();
    _triangles.push_back( inTriangle );

    Vec3f cornerPositions[3];
    for( uint32 v = 0; v < 3; v++ )
      cornerPositions[v] = inTriangle.vertices[v].position;

    addTriangle( triangleIndex, cornerPositions );

  }

  void addTriangle( uint32 inTriangleIndex, const Vec3f* inCornerPositions )
  {
    BoundingBox triangleBoundingBox = getTriangleBoundingBox( inCornerPositions );
    uint32 minCell[3], maxCell[3];
    getCellIndexRange( triangleBoundingBox, minCell, maxCell );

	uint32 count = 0;

    uint32 cellIndex[3];
    for( cellIndex[0] = minCell[0]; cellIndex[0] <= maxCell[0]; cellIndex[0]++ )
    {
      for( cellIndex[1] = minCell[1]; cellIndex[1] <= maxCell[1]; cellIndex[1]++ )
      {
        for( cellIndex[2] = minCell[2]; cellIndex[2] <= maxCell[2]; cellIndex[2]++ )
        {
          if( addTriangleToCell( cellIndex, inTriangleIndex, inCornerPositions ) )
			  count++;
        }
      }
    }

	assert( count != 0 );
  }

  void getGridDimensions(uint32 gridDim[3]) const {
    gridDim[0] = _gridDimensions[0];
    gridDim[1] = _gridDimensions[1];
    gridDim[2] = _gridDimensions[2];
  }


  void getMinMaxNumTris(uint32& minTris, uint32& maxTris) const {
    minTris = _statsMinNumTris;
    maxTris = _statsMaxNumTris;
  }


  int getContainingCellIndex(const Vec3f& point) const {
    
    BoundingBox bbox = getBoundingBox();

    Vec3f dims((float)_gridDimensions[0], (float)_gridDimensions[1], (float)_gridDimensions[2]);
    Vec3f indicies = (point - bbox.minimum) / ((bbox.maximum - bbox.minimum) / dims);

    uint32 cellIndex[3];
    cellIndex[0] = (uint32)indicies.x;
    cellIndex[1] = (uint32)indicies.y;
    cellIndex[2] = (uint32)indicies.z;

    if (cellIndex[0] >= _gridDimensions[0] ||
        cellIndex[1] >= _gridDimensions[1]) {
      return -1;
    } 

    // <kayvonf> HACK:
    // rays might get generated outside the bounding box.
    // project onto voxel grid
    uint32 dim2Index;

    if (cellIndex[2] >= _gridDimensions[2]) {
      if (indicies.z < 0.0f)
        dim2Index = 0;
      else
        dim2Index = _gridDimensions[2]-1;
    }
    else
      dim2Index = cellIndex[2];

    return (int)(cellIndex[0] + (_gridDimensions[0] * cellIndex[1]) +
                                (_gridDimensions[0] * _gridDimensions[1] * dim2Index));

  }

  virtual uint32 getTriangleCount() const {
    return _triangles.size();
  }

  virtual FullTriangle getIndexedTriangle( uint32 inIndex ) const {
    return _triangles[ inIndex ];
  }

  void printStatistics() {
    

    uint32 minCellIndex[3] = { 0 };
    uint32 maxCellIndex[3] = { 0 };

    uint32 sum = 0;
    uint32 minCellSize = 0xFFFFFFFF;
    uint32 maxCellSize = 0;

    uint32 cellIndex[3];


    for (uint32 i=0; i<_gridDimensions[0]; i++)
      for (uint32 j=0; j<_gridDimensions[1]; j++)
        for (uint32 k=0; k<_gridDimensions[2]; k++) {
    
          cellIndex[0] = i; cellIndex[1] = j; cellIndex[2] = k;
          uint32 cellSize = getCellTriangleCount(cellIndex);

          sum += cellSize;

          if (cellSize < minCellSize) {
            minCellSize = cellSize;
            minCellIndex[0] = cellIndex[0];
            minCellIndex[1] = cellIndex[1];
            minCellIndex[2] = cellIndex[2];
          }
          if (cellSize > maxCellSize) {
            maxCellSize = cellSize;
            maxCellIndex[0] = cellIndex[0];
            maxCellIndex[1] = cellIndex[1];
            maxCellIndex[2] = cellIndex[2];
          }

        }

   _statsMinNumTris = minCellSize;
   _statsMaxNumTris = maxCellSize;

//   float idealTriPerCell = (float)_mesh->getTriangleCount() / _cellTriangleIndices.size();
   float avgTriPerCell = (float)sum / _cellTriangleIndices.size();

   printf("tri list size: %d\n", sum);
//   printf("Ideal num tri per cell: %f\n", idealTriPerCell);
   printf("Avg num tri per cell:   %f\n", avgTriPerCell);
   printf("max num tri = %d in cell [%d,%d,%d]\n", maxCellSize, maxCellIndex[0], maxCellIndex[1], maxCellIndex[2]);
   printf("min num tri = %d in cell [%d,%d,%d]\n", minCellSize, minCellIndex[0], minCellIndex[1], minCellIndex[2]);

  }

private:
  uint32 getLinearCellIndex( uint32 inCellIndex[3] ) const
  {
    uint32 result = 0;
    uint32 stride = 1;

    for( uint32 i = 0; i < 3; i++ )
    {
      result += stride * inCellIndex[i];
      stride *= _gridDimensions[i];
    }
    return result;
  }



  typedef std::vector< FullTriangle > TriangleList;
  typedef std::vector< uint32 > IndexList;
  typedef std::vector< IndexList > CellIndexList;

  TriangleList _triangles;
  CellIndexList _cellTriangleIndices;

  uint32 _gridDimensions[3];
  BoundingBox _boundingBox;

  uint32 _statsMinNumTris;
  uint32 _statsMaxNumTris;
};

IVoxelAccelerator* createVoxelAccelerator(
  const FullTriangle* inTriangles, uint32 inTriangleCount, const uint32 inGridDimensions[3] )
{
  VoxelAccelerator* result = new VoxelAccelerator( inGridDimensions );

  uint32 triangleCount = inTriangleCount;

  BoundingBox boundingBox;

  for( uint32 t = 0; t < triangleCount; t++ )
  {
    for( uint32 v = 0; v < 3; v++ )
    {
      FullVertex vertex = inTriangles[t].vertices[v];

      Vec3f position = vertex.position;

      if( t == 0 && v == 0 )
      {
        boundingBox = BoundingBox( position );
      }
      else
      {
        boundingBox = join( boundingBox, position );
      }
    }
  }

  Vec3f dimensions = boundingBox.maximum - boundingBox.minimum;
  boundingBox = boundingBox.expandedBy( dimensions * 0.01f );

  result->setBoundingBox( boundingBox );

  for( uint32 t = 0; t < triangleCount; t++ )
    result->addTriangle( inTriangles[t] );

  return result;
}


void saveVoxelAccelerator(IVoxelAccelerator* accelerator, const char* inOutputFileName) {
  uint32 gridDimensions[3];

  accelerator->getGridDimensions(gridDimensions);

  uint32 triangleCount = accelerator->getTriangleCount();
  int triangleCountInt = (int) triangleCount;
  int modelCount = 1;

  BoundingBox bbox = accelerator->getBoundingBox();
  Vec3f bboxMin = bbox.minimum;
  Vec3f bboxMax = bbox.maximum;
  Vec3f gridSize( (float)gridDimensions[0], (float)gridDimensions[1], (float)gridDimensions[2] );
  Vec3f voxelSize = (bboxMax - bboxMin) / gridSize;

  Tuple3i gridDimTuple( (int)gridDimensions[0], (int)gridDimensions[1], (int)gridDimensions[2] );
  Vec3f gridMinTuple( bboxMin.x, bboxMin.y, bboxMin.z );
  Vec3f gridMaxTuple( bboxMax.x, bboxMax.y, bboxMax.z );
  Vec3f gridVSizeTuple( voxelSize.x, voxelSize.y, voxelSize.z );

  BitVector bv( gridDimTuple, 4 );
  int**** voxels;

  typedef int*** intPPP;
  typedef int** intPP;
  typedef int* intP;

  std::ofstream dump( "vox_dump.txt" );

  int histogram[8] = { 0, 0, 0, 0, 0, 0, 0, 0 };
  uint32 maxTriCount = 0;
  double sumTriCount = 0;
  double voxelCount = gridDimensions[0] * gridDimensions[1] * gridDimensions[2];

  voxels = new intPPP[ gridDimensions[0] ];
  for( uint32 x = 0; x < gridDimensions[0]; x++ )
  {
    voxels[x] = new intPP[ gridDimensions[1] ];

    for( uint32 y = 0; y < gridDimensions[1]; y++ )
    {
      voxels[x][y] = new intP[ gridDimensions[2] ];

      for( uint32 z = 0; z < gridDimensions[2]; z++ )
      {
        uint32 cellIndex[3] = { x, y, z };

        uint32 cellTriangleCount = accelerator->getCellTriangleCount( cellIndex );

		sumTriCount += (double) cellTriangleCount;
		if( cellTriangleCount > maxTriCount )
			maxTriCount = cellTriangleCount;

//		dump << "voxel[" << x << "," << y << "," << z << "] has " << (int)cellTriangleCount << " triangles" << std::endl;

		if( cellTriangleCount == 0 )
			histogram[0]++;
		else if( cellTriangleCount < 10 )
			histogram[1]++;
		else if( cellTriangleCount < 100 )
			histogram[2]++;
		else if( cellTriangleCount < 1000 )
			histogram[3]++;
		else if( cellTriangleCount < 10000 )
			histogram[4]++;
		else if( cellTriangleCount < 100000 )
			histogram[5]++;
		else if( cellTriangleCount < 1000000 )
			histogram[6]++;
		else if( cellTriangleCount < 10000000 )
			histogram[7]++;


        if( cellTriangleCount > 0 )
          bv.Set( (int)x, (int)y, (int)z );

        voxels[x][y][z] = new int[ cellTriangleCount + 1];
        voxels[x][y][z][0] = (int) cellTriangleCount;

        for( uint32 t = 0; t < cellTriangleCount; t++ )
        {
          voxels[x][y][z][t+1] = (int) accelerator->getIndexedCellTriangleIndex( cellIndex, t );
        }

      }
    }
  }

  dump << "max tri count: " << (int) maxTriCount << std::endl;
  dump << "ave tri count: " << (sumTriCount / voxelCount) << std::endl;

  int histoValue = 1;
  for( int i = 0; i < 8; i++ )
  {
	  dump << "histogram[ triangleCount < " << histoValue << "] = " << histogram[i] << std::endl;
	  histoValue *= 10;
  }

  dump.close();

  Point3* pos[3];
  Normal3* nrm[3];
  Spectra* col[3];

  for( uint32 i = 0; i < 3; i++ )
  {
    pos[i] = new Point3[ triangleCount ];
    nrm[i] = new Normal3[ triangleCount ];
    col[i] = new Spectra[ triangleCount ];
  }

  for( uint32 t = 0; t < triangleCount; t++ )
  {
    FullTriangle triangle = accelerator->getIndexedTriangle( t );
    for( uint32 v = 0; v < 3; v++ )
    {
      FullVertex vertex = triangle.vertices[v];

      pos[v][t] = vertex.position;
      nrm[v][t] = vertex.normal;
      col[v][t] = vertex.color;
    }
  }

  WriteVoxFile( (char*) inOutputFileName, &triangleCountInt, modelCount,
    gridDimTuple, gridMinTuple, gridMaxTuple, gridVSizeTuple,
    &bv, voxels,
    &pos[0], &pos[1], &pos[2],
    &nrm[0], &nrm[1], &nrm[2],
    &col[0], &col[1], &col[2] );
}
