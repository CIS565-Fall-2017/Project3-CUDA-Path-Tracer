/* $Id: ppmImage.cpp,v 1.7 2006/08/16 22:48:48 danielrh Exp $ */

#include "ppmImage.h"
#include <stdio.h>

ppmImage::ppmImage( int img_width, int img_height ){
  width = img_width;
  height = img_height;
  int size = width*height*4;
  data = new float[size];
  byteData=false;
  for(int i=0; i<size; i++)
    data[i] = 0.0f;
}
void ppmImage::setByteData(bool bytedata) {
    this->byteData=bytedata;
}
void ppmImage::AddSample( int x, int y, const Spectra& color, const Spectra& weight ){
  Spectra contrib = color*weight;
  int index = (y*width+x)*4;
  data[index+0] += contrib.x;
  data[index+1] += contrib.y;
  data[index+2] += contrib.z;
  data[index+3] += 1.0f;
}

static inline char
GetPixelValue( float x )
{
   if( x <= 0.0f )
      return 0;
#ifdef WINDOWS
   if ( !_finite( x ) )
#else
   if( isnan( x ) || isinf( x ) )
#endif
      return (char) 128;
   int value = (int)(x * 255.0f);
   if( value > 255 )
      value = 255;
   return (char) value;
}

void ppmImage::Write( char *fname ){
  FILE *fp = fopen( fname, "wb" );
  if (!fp)
    fprintf(stderr, "Couldn't open PPM file for writing\n");
  else{
    fprintf(fp, "P6\n");
    fprintf(fp, "%d %d\n", width, height );
    fprintf(fp, "255\n" );
    if (byteData) {
	for (int j=0;j<=height-1;++j) {
        for(int i=0; i<width; i++){
          for(int c=0; c<=2; c++){
            fputc( ((char*)data)[(j*width+i)*4+c], fp );//write upside down bgr data cus that's what most things like these days (thanks, .bmp )
          }
        }
      }
    
    }else {
    for(int i=0; i<width*height*4; i+=4){
       for(int c=0; c<3; c++)
          fputc( GetPixelValue(data[i+c]), fp );
    }
    }
    fclose(fp);
  }
}
