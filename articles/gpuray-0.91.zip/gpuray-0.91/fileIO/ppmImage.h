/* $Id: ppmImage.h,v 1.2 2006/07/20 00:13:37 danielrh Exp $ */

#ifndef PPMIMAGE_H
#define PPMIMAGE_H

#include "types.h"

class ppmImage {
public:
  ppmImage( int img_width, int img_height );
  ~ppmImage() { delete [] data; }
  int Width() const { return width; }
  int Height() const { return height; }
  void AddSample( int x, int y, const Spectra& color, const Spectra& weight );
  void Write( char *fname );
  float *Data() { return data; }
  void Clear() { for(int i=0; i<width*height*4; i++) data[i] = 0.0f; }
  void setByteData(bool bytedata);
private:
  bool byteData;
  int width;
  int height;
  float *data;
};

#endif /* PPMIMAGE_H */
