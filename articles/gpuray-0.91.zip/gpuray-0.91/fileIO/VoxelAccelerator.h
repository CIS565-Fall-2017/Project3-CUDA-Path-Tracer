// VoxelAccelerator.h
#ifndef VOXEL_ACCELERATOR_H
#define VOXEL_ACCELERATOR_H

#include "types.h"
#include "../common/commonTypes.h"

class IVoxelAccelerator
{
public:
  virtual BoundingBox getBoundingBox() const = 0;
  virtual BoundingBox getCellBoundingBox( uint32 inCellIndex[3] ) const = 0;

  virtual uint32 getCellTriangleCount( uint32 inCellIndex[3] ) const = 0;
  virtual uint32 getIndexedCellTriangleIndex( uint32 inCellIndex[3], uint32 inIndex ) const = 0;
  virtual void   getGridDimensions(uint32 gridDim[3] ) const = 0;
  virtual void   getMinMaxNumTris(uint32& minTris, uint32& maxTris) const = 0;
  virtual int    getContainingCellIndex(const Vec3f& point) const = 0;

  virtual uint32 getTriangleCount() const = 0;
  virtual FullTriangle getIndexedTriangle( uint32 inIndex ) const = 0;
  

  virtual void   printStatistics() = 0;
  
};

IVoxelAccelerator* createVoxelAccelerator(
  const FullTriangle* inTriangles, uint32 inTriangleCount, const uint32 inGridDimensions[3] );
void saveVoxelAccelerator( IVoxelAccelerator* accelerator, const char* inOutputFileName );

#endif
