#ifndef __TYPES_H__
#define __TYPES_H__

#include <math.h>

#include "../common/commonTypes.h"

class Tuple3i;

typedef unsigned char       u8;
typedef signed char         s8;

typedef unsigned short      u16;
typedef signed short        s16;

typedef unsigned int        u32;
typedef signed int          s32;

#ifdef WIN32
#define M_PI  3.14159265358979323846f

typedef unsigned __int64 u64;
typedef signed __int64   s64;
#else
typedef unsigned long long u64;
typedef signed long long s64;
#endif

typedef Vec3f Point3;
typedef Vec3f Vector3;
typedef Vec3f Normal3;
typedef Vec3f Spectra;

class Tuple3i {
public:
  Tuple3i() : x(0), y(0), z(0) {}
  Tuple3i( int _x, int _y, int _z ) : x(_x), y(_y), z(_z) {}
  Tuple3i( const Tuple3i &t ) { x=t.x; y=t.y; z=t.z; }

  ~Tuple3i() {}

  Tuple3i operator+( const Tuple3i &t ) const   { return Tuple3i( x+t.x, y+t.y, z+t.z ); }
  int &operator[]( int i )                      { if (i==0) return x;
                                                  else if (i==1) return y;
                                                  else return z; }

  bool operator==( const Tuple3i& other ) const {
    return x == other.x && y == other.y && z == other.z;
  }

  int X() const                               { return x; }
  int Y() const                               { return y; }
  int Z() const                               { return z; }
  int R() const                               { return x; }
  int G() const                               { return y; }
  int B() const                               { return z; }

  int x, y, z;
};

// TIM: added structures shared by many pieces of import/export code

struct FullVertex
{
  Point3 position;
  Normal3 normal;
  Spectra color;

  bool operator==( const FullVertex& other ) const {
    return position == other.position && normal == other.normal && color == other.color;
  }
};

struct FullTriangle
{
  FullVertex vertices[3];
};


#endif /* __TYPES_H__ */
