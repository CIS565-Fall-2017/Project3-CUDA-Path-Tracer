/*
 * sceneparser.h --
 *
 *      Utility to parse scene parameters from an XML file
 */

#ifndef __SCENEPARSER_H__
#define __SCENEPARSER_H__

#include "main.h"

void parseScene( const std::string& inFileName, SceneParams& outScene );

#endif
