This work is reported about in the paper Interactive k-D Tree GPU Raytracing presented at i3d 2007 by Daniel Horn, Jeremy Sugerman, Mike Houston and Pat Hanrahan. 
The paper is available at http://graphics.stanford.edu/papers/i3dkdtree/

-----------------------------
Getting it building.
Step 1: unzip this package to a folder of your choice, lets say c:\gpuray
Step 2: install cygwin and the included perl distribution
Step 3: install visual studio 8 (if building the cell, install CELL SDK)
Step 4 start bash and go to  cd /cygdrive/c (or whatever path you unzipped gpuray in)
Step 5: cvs -d:pserver:anonymous@brook.cvs.sourceforge.net:/cvsroot/brook co brook
Step 6: verify brook and gpuray are in the same directory (in this case c:\gpuray and c:\brook )
Step 7: cd brook
        make release
Step 8a: (builds both DX and CTM)
        cd ..
        cd gpuray
        sh qmake.sh release 
Step 8b: (builds only DX)
        cd ..
        cd gpuray
        make DXSDK_DIR="c:\\Program Files\Microsoft DirectX SDK" release


Running With DirectX
start with a small scene:
bin/release/raytracer.exe -s cbox -a kdtree-brook --ctm --d3d
now lets move to a shadowed scene
cat robot_cam.txt|bin/release/raytracer.exe -s robots -a kdtree-brook --ctm --d3d --shadeOpt shadow=1 -p --size 1024 --shadeOpt bounces=1

You can run kitchen or conference by replacing -s robots with -s kitchen or -s conference: however note that the texture that worked for robots may look ugly there, so you may wish to replace scenes/texture.ppm and scenes/texturespec.ppm with a white ppm or delete them altogether

keys to move through the scene are 
w,a,s,d, arrow keys

to switch to reflections hit m
to add bounces use + (- subtracts)
to turn off rasterization mode use / and to reenable use *
to flythrough hit the t key

Other keys are included in viewer.cpp

Running With CTM
Right now CTM raytracing has only been tested with an R500 series ATI card
cat robot_cam.txt|bin/release/raytracer.exe -s robots -a kdtree --ctm --gdi --shadeOpt shadow=1 -p --size 1024 --shadeOpt bounces=1 --accelOpt useRaster=0

if you have 2 GPU's and wish to utilize both, then you can enable ALL 4 screens in display properties then do
cat robot_cam.txt|bin/release/raytracer.exe -s robots -a kdtree --ctm --gdi --shadeOpt shadow=1 -p --size 1024 --shadeOpt bounces=1 --accelOpt useRaster=0 --accelOpt xfire=2

(this has been tested with up to 3...but it probably works with more)
you can attempt to get it working on an R600 by deleting ctm/raytracer.r5xx (which is coded in the native assembly)

CTM makes full use of a 3 deep short-stack because the pixel shader code uses more than 32 registers for temporaries whereas the r5xx ISA allows us to utilize exactly 32 registers.  So on DirectX you only get the benefit of a 1-deep short stack... a directX 10 port that makes use of the extra registers that DX exposes before the driver tears at the code would be quite useful.

------------------------------
Abstract:

Over the past few years, the powerful computation rates and high memory bandwidth of GPUs have attracted efforts to run raytracing on GPUs. Our work extends Foley et al.'s GPU k-D tree research. We port their kd-restart algorithm from multi-pass, using CPU load balancing, to single pass, using current GPUs' branching and looping abilities. We introduce three optimizations: a packetized formulation, a technique for restarting partially down the tree instead of at the root, and a small, fixed-size stack that is checked before resorting to restart. Our optimized implementation achieves 15 - 18 million primary rays per second and 16 - 27 million shadow rays per second on our test scenes.
 

Our system also takes advantage of GPUs' strengths at rasterization and shading to offer a mode where rasterization replaces eye ray scene intersection, and primary hits and local shading are produced with standard Direct3D code. For 1024x1024 renderings of our scenes with shadows and Phong shading, we achieve 12-18 frames per second. Finally, we investigate the efficiency of our implementation relative to the computational resources of our GPUs and also compare it against conventional CPUs and the Cell processor, which both have been shown to raytrace well. 