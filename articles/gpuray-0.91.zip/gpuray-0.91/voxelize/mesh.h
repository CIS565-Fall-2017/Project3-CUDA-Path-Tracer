/*
 * mesh.h --
 *
 *      Mesh object used to import/export triangles.
 */

#ifndef __MESH_H__
#define __MESH_H__

#include <vector>

#include "main.h"
#include "../fileIO/fileIO.h"

class Mesh
{
public:
  Mesh( const Opts& inOptions );

  void importMesh( const char* filename );
  void exportMesh( const char* filename );

  void scale( float scaleX, float scaleY, float scaleZ );

private:
  const Opts& _options;
  std::vector<FullTriangle> _triangles;
};

#endif
