/*
 * vox.cpp --
 *
 *      Implementation of .vox import/export.
 */
#include "vox.h"

#include "../fileIO/VoxelAccelerator.h"

void readVoxFile(const char* filename, std::vector<FullTriangle>& triangles)
{
  Grid grid;
  Point3* p[3];
  Normal3* n[3];
  Spectra* c[3];

  // TIM: I'm not sure if the non-constness of that argument is intended...
  ReadVoxFile( (char*) filename, false, grid,
    p[0], p[1], p[2], n[0], n[1], n[2], c[0], c[1], c[2] );

  int triangleCount = grid.nTris;
  for( int t = 0; t < triangleCount; t++ )
  {
    FullTriangle triangle;

    for( int v = 0; v < 3; v++ )
    {
      FullVertex vertex;
      vertex.position = p[v][t];
      vertex.normal = n[v][t];
      vertex.color = c[v][t];

      triangle.vertices[v] = vertex;
    }

    triangles.push_back( triangle );
  }
}

void writeVoxFile(const char* filename,
                  const FullTriangle* triangles, uint32 triangleCount,
                  int voxelsX, int voxelsY, int voxelsZ )
{
  uint32 gridDimensions[3] = { (uint32) voxelsX, (uint32) voxelsY, (uint32) voxelsZ };
  IVoxelAccelerator* accelerator = createVoxelAccelerator( triangles, triangleCount, gridDimensions );
  saveVoxelAccelerator( accelerator, filename );
  delete accelerator;
}
