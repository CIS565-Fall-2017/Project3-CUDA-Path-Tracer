/*
 * main.cpp --
 *
 *      Main entry point for voxelizer.
 */

#ifdef _WIN32
#include "getopt.h"
#else
#include <getopt.h>
#endif

#include "main.h"
#include "mesh.h"

/*
 * Usage --
 *
 *      Print program usage information and exit.
 *
 * Returns:
 *      void.
 */

void
Usage(const char *progName)
{
   fprintf(stderr,
           "Usage: %s <options> [input] [output]\n"
           "  Options:\n"
           "  -?, --help\n"
           "            This message\n"
           "  -i, --input\n"
           "            Input file name\n"
           "  -I, --inputList\n"
           "            File with list of input file names\n"
           "  -o, --output\n"
           "            Output file name\n"
           "  -v, --verbose\n"
           "            Print extra information while running\n"
           "  -x, --voxelsX\n"
           "            Number of voxels along x axis (8)\n"
           "  -y, --voxelsY\n"
           "            Number of voxels along x axis (8)\n"
           "  -z, --voxelsZ\n"
           "            Number of voxels along x axis (8)\n",
           progName);
   exit(1);
}

/*
 * ParseInputFileList --
 *
 *      Process a file that contains multiple input file
 *      names.
 *
 * Returns:
 *      void.
 */

static void
ParseInputFileList(const char* fileName, Opts *opts)
{
   FILE* file = fopen( fileName, "r" );
   if( file == NULL )
   {
      fprintf(stderr,"Could not open input file '%s'\n", fileName);
      exit(1);
   }

   char buffer[1024];
   while( true )
   {
      char* result = fgets( buffer, sizeof(buffer), file );
      if( result == NULL )
         break;
      buffer[sizeof(buffer)-1] = 0;
      if( buffer[strlen(buffer)-1] == '\n' )
         buffer[strlen(buffer)-1] = 0;

      opts->inputFiles.push_back( strdup( buffer ) );
   }
   
   fclose( file );
}

/*
 * ParseOpts --
 *
 *      Process all the commandline options and set the various options
 *      accordingly.
 *
 * Returns:
 *      void.
 */

static void
ParseOpts(int *argc, char *argv[], Opts *opts)
{
   int opt;
   int opt_index;

   static struct option long_options[] = {
      {"help",         0, 0, '?'},
      {"input",        0, 0, 'i'},
      {"inputList",    0, 0, 'I'},
      {"output",       0, 0, 'o'},
      {"verbose",      0, 0, 'v'},
      {"voxelsX",      0, 0, 'x'},
      {"voxelsY",      0, 0, 'y'},
      {"voxelsZ",      0, 0, 'z'},
      {0, 0, 0, 0}
   };


   opts->progName = argv[0];
   while ((opt = getopt_long(*argc, argv, "?i:I:o:vx:y:z:",
                             long_options, &opt_index)) != EOF) {
      switch (opt) {
      case 'i': opts->inputFiles.push_back(optarg);  break;
      case 'I': ParseInputFileList(optarg, opts);    break;
      case 'o': opts->outputFile = optarg;           break;
      case 'v': opts->verbose = true;                break;
      case 'x': opts->voxelsX = atoi(optarg);        break;
      case 'y': opts->voxelsY = atoi(optarg);        break;
      case 'z': opts->voxelsZ = atoi(optarg);        break;

      case '?':
      default: Usage(opts->progName);                break;
      }
   }

   argv += optind;
   *argc -= optind;
   if (*argc < 0) {
     Usage(opts->progName);
   }

   int argumentsForOutputFile = opts->outputFile ? 0 : 1;

   while( *argc > argumentsForOutputFile )
   {
      opts->inputFiles.push_back( argv[0] );
      argv++;
      *argc--;      
   }

   if( opts->inputFiles.size() == 0 )
   {
      fprintf(stderr,"No input file specified\n");
      Usage(opts->progName);
   }

   if (opts->outputFile == NULL)
   {
     if (*argc == 0) {
       fprintf(stderr,"No output file specified\n");
       Usage(opts->progName);
     }
     opts->outputFile = argv[0];
     argv++;
     *argc--;
   }
}


/*
 * main --
 *
 *      Entry point for the voxelizer.
 *
 * Returns:
 *      0 on success
 */

int
main(int argc, char **argv)
{
   Opts opts = {
      /* progName: */   NULL,

      /* outputFile: */  NULL,

      /* voxelsX: */     8,
      /* voxelsY: */     8,
      /* voxelsZ: */     8
   };

   ParseOpts(&argc, argv, &opts);

   Mesh mesh( opts );
   size_t inputFileCount = opts.inputFiles.size();
   for( size_t ii = 0; ii < inputFileCount; ii++ )
      mesh.importMesh( opts.inputFiles[ii] );
   mesh.exportMesh( opts.outputFile );

   return 0;
}
