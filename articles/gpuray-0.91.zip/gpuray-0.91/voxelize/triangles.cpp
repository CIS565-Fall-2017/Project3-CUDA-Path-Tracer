/*
 * triangles.cpp --
 *
 *      Implementation of .triangles import/export.
 */
#include "triangles.h"

#include "../fileIO/fileIO.h"

void readTrianglesFile( const char* filename, std::vector<FullTriangle>& triangles )
{
  Grid grid;
  Point3* p[3];
  Normal3* n[3];
  Spectra* c[3];

  ReadTrianglesFile( filename, grid,
    p[0], p[1], p[2], n[0], n[1], n[2], c[0], c[1], c[2] );

  int triangleCount = grid.nTris;
  for( int t = 0; t < triangleCount; t++ )
  {
    FullTriangle triangle;

    for( int v = 0; v < 3; v++ )
    {
      FullVertex vertex;
      vertex.position = p[v][t];
      vertex.normal = n[v][t];
      vertex.color = c[v][t];

      triangle.vertices[v] = vertex;
    }

    triangles.push_back( triangle );
  }
}

void writeTrianglesFile( const char* filename, const FullTriangle* triangles, uint32 triangleCount )
{
  FILE* file = fopen( filename, "wb" );

  int count = (int) triangleCount;
  fwrite( &count, 1, sizeof(count), file );

  fwrite( triangles, triangleCount, sizeof(FullTriangle), file );

  fclose( file );
}
