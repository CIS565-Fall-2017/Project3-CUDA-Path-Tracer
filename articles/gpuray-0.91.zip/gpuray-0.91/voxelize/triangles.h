/*
 * triangles.h --
 *
 *      Routines for import/export of .triangles files.
 */

#ifndef __TRIANGLES_H__
#define __TRIANGLES_H__

#include <vector>

#include "mesh.h"

void readTrianglesFile( const char* filename, std::vector<FullTriangle>& triangles );
void writeTrianglesFile( const char* filename, const FullTriangle* triangles, uint32 triangleCount );

#endif
