/*
 * ply.h --
 *
 *      Routines for import/export of .ply files.
 */

#ifndef __PLY_H__
#define __PLY_H__

#include <vector>

#include "mesh.h"

void readPlyFile( const char* filename, std::vector<FullTriangle>& triangles );

#endif
