/*
 * ply.cpp --
 *
 *      Implementation of .triangles import/export.
 */
#include "ply.h"

#include "../fileIO/fileIO.h"

void readPlyFile( const char* filename, std::vector<FullTriangle>& triangles )
{
   int triangleCount;
   HMatrix3 transform;
   Point3 *v0, *v1, *v2;
   Normal3 *n0, *n1, *n2;
   Spectra *c0, *c1, *c2;
   
   transform.setIdentity();
   
   ReadPlyFile( (char*) filename,
                triangleCount,
                transform,
                v0, v1, v2,
                n0, n1, n2,
                c0, c1, c2 );

   Point3  *v[3] = { v0, v1, v2 };
   Normal3 *n[3] = { n0, n1, n2 };
   Spectra *c[3] = { c0, c1, c2 };
   
   for( int ii = 0; ii < triangleCount; ii++ )
   {
      FullTriangle triangle;

      for( int jj = 0; jj < 3; jj++ )
      {
         triangle.vertices[jj].position = v[jj][ii];
         triangle.vertices[jj].normal = n[jj][ii];
         triangle.vertices[jj].color = c[jj][ii];
      }
      
      triangles.push_back( triangle );
   }

   for( int ii = 0; ii < 3; ii++ )
   {
      free( v[ii] );
      free( n[ii] );
      free( c[ii] );
   }
}

