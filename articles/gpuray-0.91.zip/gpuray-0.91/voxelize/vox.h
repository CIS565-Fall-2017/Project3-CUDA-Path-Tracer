/*
 * vox.h --
 *
 *      Routines for import/export of .vox files.
 */

#ifndef __VOX_H__
#define __VOX_H__

#include <vector>

#include "mesh.h"

void readVoxFile(const char* filename, std::vector<FullTriangle>& triangles);
void writeVoxFile(const char* filename,
                  const FullTriangle* triangles, uint32 triangleCount,
                  int voxelsX, int voxelsY, int voxelsZ );

#endif
