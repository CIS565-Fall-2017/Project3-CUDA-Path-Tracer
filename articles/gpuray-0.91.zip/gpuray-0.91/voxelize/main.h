/*
 * main.h --
 *
 *      Global structures used by voxelizer
 */

#ifndef __MAIN_H__
#define __MAIN_H__

#include <vector>

typedef struct Opts {
   char *progName;

   const char* outputFile;  /* output file name */

   int voxelsX;             /* number of voxels along x axis */
   int voxelsY;             /* number of voxels along y axis */
   int voxelsZ;             /* number of voxels along z axis */

   /*
    * Boolean options (always default to false)
    */

   bool verbose;

   /*
    * Complex options.
    */

   std::vector<const char*> inputFiles; /* input file names */
} Opts;

extern void Usage(const char *progName);
#endif
