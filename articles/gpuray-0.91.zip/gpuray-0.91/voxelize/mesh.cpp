/*
 * mesh.cpp --
 *
 *      Implementation of mesh import/export.
 */
#include "mesh.h"

#include <string>
#include <ctype.h>
#include <algorithm>

#include "triangles.h"
#include "vox.h"
#include "ply.h"

static std::string getExtension( const char* filename )
{
  std::string f = filename;

  // find substring after the '.' character
  std::string::size_type i = f.find_last_of('.',std::string::npos);
  if( i == std::string::npos )
    return "";
  std::string extension = f.substr( i+1 );

  // convert to lower case
  std::transform( extension.begin(), extension.end(),
    extension.begin(), tolower );

  return extension;
}

Mesh::Mesh( const Opts& inOptions )
  : _options(inOptions)
{
}

void Mesh::importMesh( const char* filename )
{
  std::string extension = getExtension( filename );
  std::vector<FullTriangle> importedTriangles;

  if( extension == "triangles" )
  {
    readTrianglesFile( filename, importedTriangles );
  }
  else if( extension == "vox" )
  {
    readVoxFile( filename, importedTriangles );
  }
  else if( extension == "ply" )
  {
     readPlyFile( filename, importedTriangles );
  }
  else
  {
    fprintf(stderr,"Unknown input file extension '%s'\n", extension.c_str());
    exit(1);
  }

  _triangles.insert(
        _triangles.end(),
        importedTriangles.begin(),
        importedTriangles.end() );
}

void Mesh::exportMesh( const char* filename )
{
  std::string extension = getExtension( filename );

  if( extension == "triangles" )
  {
    writeTrianglesFile( filename, &_triangles[0], _triangles.size() );
  }
  else if( extension == "vox" )
  {
    writeVoxFile( filename,
      &_triangles[0], _triangles.size(),
      _options.voxelsX, _options.voxelsY, _options.voxelsZ ); 
  }
  else
  {
    fprintf(stderr,"Unknown output file extension '%s'\n", extension.c_str());
    exit(1);
  }
}

void Mesh::scale( float scaleX, float scaleY, float scaleZ )
{
   unsigned int i, j;

   for (i = 0; i < _triangles.size(); i++) {
      for (j = 0; j < 3; j++) {
         _triangles[i].vertices[j].position.x *= scaleX;
         _triangles[i].vertices[j].position.y *= scaleY;
         _triangles[i].vertices[j].position.z *= scaleZ;
      }
   }
}
