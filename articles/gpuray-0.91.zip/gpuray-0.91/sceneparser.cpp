/* *************************************************************************
* Copyright (C) 2005 Tim Foley, Jeremy Sugerman
* All Rights Reserved
* *************************************************************************/

/*
 * sceneparser.cpp --
 *
 *      Utility to parse scene parameters from an XML file
 */

#include "sceneparser.h"

#include <string>

#include "external/tinyxml/tinyxml.h"

float getFloatAttribute( TiXmlElement* inElement, const char* inName, float* inDefault = NULL )
{
   double attributeValue = 0.0f;
   const char* attribute = inElement->Attribute( inName, &attributeValue );
   TiXmlElement* element = inElement->FirstChildElement( inName );
   if( attribute && element )
   {
      fprintf( stderr, "duplicate specifications for %s", inName );
      exit(1);
   }
   if( !attribute && !element )
   {
      if( inDefault == NULL )
      {
         fprintf( stderr, "no specification for %s", inName );
         exit(1);
      }
      else
         return *inDefault;
   }

   if( attribute != NULL )
   {
      return (float) attributeValue;
   }
   else
   {
      // TIM: more error checking would be justified here
      return (float) atof( element->GetText() );
   }
}

float getFloatAttribute( TiXmlElement* inElement, const char* inName, float inDefault )
{
   return getFloatAttribute( inElement, inName, &inDefault );
}

Vec3f getFloat3Attribute( TiXmlElement* inElement, const char* inName, Vec3f* inDefault = NULL )
{
   Vec3f result;

   const char* attribute = inElement->Attribute( inName );
   TiXmlElement* element = inElement->FirstChildElement( inName );
   if( attribute && element )
   {
      fprintf( stderr, "duplicate specifications for %s", inName );
      exit(1);
   }
   if( !attribute && !element )
   {
      if( !inDefault )
      {
         fprintf( stderr, "no specification for %s", inName );
         exit(1);
      }
      else
         return *inDefault;
   }

   const char* text = attribute;
   if( element != NULL )
      text = element->GetText();

   if( text != NULL )
   {
      sscanf(text, "%f %f %f", &result.x, &result.y, &result.z);
   }
   else
   {
      result.x = getFloatAttribute( element, "x" );
      result.x = getFloatAttribute( element, "y" );
      result.x = getFloatAttribute( element, "z" );
   }
   return result;
}

Vec3f getFloat3Attribute( TiXmlElement* inElement, const char* inName, Vec3f inDefault )
{
   return getFloat3Attribute( inElement, inName, &inDefault );
}

void parseScene( const std::string& inFileName, SceneParams& outScene )
{
   TiXmlDocument document;
   if( !document.LoadFile( inFileName.c_str() ) )
   {
      fprintf( stderr, "couldn't open or parse scene file '%s'",
               inFileName.c_str() );
      exit( 1 );
   }

   TiXmlElement* root = document.RootElement();
   int version = 0;
   root->Attribute( "version", &version );

   if( version != 0 )
   {
      fprintf( stderr, "version should be 0" );
      exit( 1 );
   }

   TiXmlElement* geometry = root->FirstChildElement( "geometry" );
   if( geometry == NULL )
   {
      fprintf( stderr, "no geometry found" );
      exit( 1 );
   }

   const char* geometryType = geometry->Attribute( "type" );
   if( CompareNoCase( geometryType, "triangles" ) == 0 )
      outScene.sceneType = kSceneType_Triangles;
   else if( CompareNoCase( geometryType, "vox" ) == 0 )
      outScene.sceneType = kSceneType_Vox;
   else if( CompareNoCase( geometryType, "ss" ) == 0 ){
      outScene.sceneType = kSceneType_Simple;
   } else {
      fprintf( stderr, "unknown geometry type '%s'", geometryType );
      exit( 1 );
   }

   const char* geometrySource = geometry->Attribute( "src" );
   if( geometrySource == 0 )
   {
      fprintf( stderr, "geometry source unspecified" );
      exit( 1 );
   }
   /*
    * This strdup is required because the 'fileName' member
    * is declared as a char*. It might be possible to change
    * it to a const char * and avoid this...
    */
   outScene.fileName = strdup( geometrySource );

   TiXmlElement* camera = root->FirstChildElement("camera");
   if( camera == NULL )
   {
      fprintf( stderr, "no camera found" );
      exit( 1 );
   }

   outScene.lookFrom = getFloat3Attribute( camera, "lookFrom" );
   outScene.lookAt = getFloat3Attribute( camera, "lookAt" );
   outScene.up = getFloat3Attribute( camera, "up" );
   outScene.fov = getFloatAttribute( camera, "fov" );

   TiXmlElement* interaction = root->FirstChildElement("interaction");
   if( interaction != NULL )
   {
      outScene.center = getFloat3Attribute( interaction, "center", Vec3f(0) );
      outScene.movementScale = getFloatAttribute( interaction, "movementScale", 1.0f );
      outScene.lightMovementScale = getFloatAttribute( interaction, "lightMovementScale", 1.0f );
   }

   TiXmlElement* allLights = root->FirstChildElement("lights");
   if (allLights == NULL){
      fprintf( stderr, "must specify at least 1 light" );
      exit(1);
   }

   TiXmlElement* light = allLights->FirstChildElement( "light" );
   if (light == NULL){
      fprintf( stderr, "must specify at least 1 light" );
      exit(1);
   }

   LightInfo newInfo;
   while (light != NULL) {
      newInfo.position =  getFloat3Attribute( light, "position" );
      newInfo.distAtten = getFloatAttribute( light, "attenuation" );
      newInfo.diffIntensity = getFloat3Attribute( light, "diffuseColor" );
      
      outScene.pointLights.push_back (newInfo);
      light = light->NextSiblingElement( "light" );
   }
}
