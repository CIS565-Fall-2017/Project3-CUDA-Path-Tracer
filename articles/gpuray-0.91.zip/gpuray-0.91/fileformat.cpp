#include <iostream>

#include "main.h"
#include "fileformat.h"
#include "common/endian.h"

static inline int
ReadIntFromFile( FILE* inFile )
{
   int result;
   fread( &result, sizeof(result), 1, inFile );
   return fromLittleEndian( result );
}

static inline float
ReadFloatFromFile( FILE* inFile )
{
   float result;
   fread( &result, sizeof(result), 1, inFile );
   return fromLittleEndian( result );
}

static inline void
ReadFloatArrayFromFile( FILE* inFile, float* outValues, int inCount )
{
   int count = inCount;
   float* value = outValues;
   while( count-- )
      *value++ = ReadFloatFromFile( inFile );
}

static inline void
ReadVector3FromFile( FILE* inFile, F3* outVector )
{
   outVector->x = ReadFloatFromFile( inFile );
   outVector->y = ReadFloatFromFile( inFile );
   outVector->z = ReadFloatFromFile( inFile );
}

static inline void
ReadVector3ArrayFromFile( FILE* inFile, F3* outVectors, int inCount )
{
   int count = inCount;
   F3* vector = outVectors;
   while( count-- )
      ReadVector3FromFile( inFile, vector++ );
}

// READ IN FILE
void ReadSceneFile( char *fname, bool verbose,
                  NewScene *scene)
{
   FILE *fp = fopen (fname, "rb");
   if (!fp ) {
      fprintf(stderr, "Couldn't open %s for reading\n", fname);
      exit(-1);
   }

   // first read the number of batches
   scene->batchCount = ReadIntFromFile( fp );
   Batch* newBatch = new Batch[scene->batchCount];
   scene->batches = newBatch;

   for (int ii=0; ii<scene->batchCount; ii++) {
      // read in a batch -- see what kinds of attribs will be available
      int numAttribs = ReadIntFromFile( fp );

      // read in num vertices
      newBatch[ii].vertexCount = ReadIntFromFile( fp );
      int vCount = newBatch[ii].vertexCount;

      // block read all vertices
      newBatch[ii].vertices = new F3[vCount];
      ReadVector3ArrayFromFile( fp, &newBatch[ii].vertices[0], vCount );

      // NULL out all attribs
      newBatch[ii].normals = NULL;
      newBatch[ii].diffuseColors = NULL;
      newBatch[ii].ambientColors = NULL;
      newBatch[ii].specularColors = NULL;
      newBatch[ii].specularExp = NULL;

      for (int jj=0; jj<numAttribs; jj++) {
         // read in all the extra attribs
         OptionalAttrib attrib = (OptionalAttrib) ReadIntFromFile( fp );

         switch (attrib) {
            case (NORMAL):
               newBatch[ii].normals = new F3[vCount];
               ReadVector3ArrayFromFile(
                  fp, &newBatch[ii].normals[0], vCount );
               break;
            case (DIFFUSE):
               newBatch[ii].diffuseColors = new F3[vCount];
               ReadVector3ArrayFromFile(
                  fp, &newBatch[ii].diffuseColors[0], vCount );
               break;
            case (AMBIENT):
               newBatch[ii].ambientColors = new F3[vCount];
               ReadVector3ArrayFromFile(
                  fp, &newBatch[ii].ambientColors[0], vCount );
               break;
            case (SPECULAR):
               newBatch[ii].specularColors = new F3[vCount];
               newBatch[ii].specularExp = new float[vCount];
               ReadVector3ArrayFromFile(
                  fp, &newBatch[ii].specularColors[0], vCount );
               ReadFloatArrayFromFile(
                  fp, &newBatch[ii].specularExp[0], vCount );
               break;
         }
      }

      newBatch[ii].triangleCount = vCount/3;
   }
   fclose(fp);
}

#define WRITE_TEST 0
void WriteOutScene ( char *fname, bool verbose,
                  NewScene *scene)
{
   FILE *fp = fopen (fname, "wb");  // check flag
   if (!fp ) {
      fprintf(stderr, "Couldn't open %s for writing\n", fname);
      exit(-1);
   }

   FILE *fpTest;
   if (WRITE_TEST) {
      fpTest = fopen ("TEST", "wt");  // check flag
      if (!fpTest ) {
         fprintf(stderr, "Couldn't open %s for writing\n", fname);
         exit(-1);
      }
   }

   Batch *newBatch = scene->batches;

   // first write the number of batches
   fwrite(&scene->batchCount, sizeof(int), 1, fp);
   int numBatches = scene->batchCount;

   if (WRITE_TEST)
      fprintf(fpTest, "%d\n", numBatches);

   for (int i=0; i<numBatches; i++) {
      //write out numAttribs
      int numAttribs = 0;
      if (newBatch[i].diffuseColors) numAttribs++;
      if (newBatch[i].ambientColors) numAttribs++;
      if (newBatch[i].normals) numAttribs++;
      if (newBatch[i].specularColors) numAttribs++;

      fwrite (&numAttribs, sizeof(int), 1, fp);

      if (WRITE_TEST)
         fprintf(fpTest, "%d\n", numAttribs);

      // write out numVerts
      fwrite(&newBatch[i].vertexCount, sizeof(int), 1, fp);
      int vCount = newBatch[i].vertexCount;

      if (WRITE_TEST)
         fprintf(fpTest, "%d\n", vCount);

      // write out verts
      fwrite(newBatch[i].vertices, sizeof(F3), vCount, fp);

      if (WRITE_TEST) {
         for (int j=0; j<vCount; j++) {
            printf("%f %f %f\n", newBatch[i].vertices[j].x,  newBatch[i].vertices[j].y,  newBatch[i].vertices[j].z);
         }
      }

      // write out all attribs
      int attrib;
      if (newBatch[i].normals) {
         attrib = NORMAL;
         fwrite(&attrib, sizeof(int), 1, fp);
         fwrite(newBatch[i].normals, sizeof(F3), vCount, fp);
      }
      if (newBatch[i].diffuseColors) {
         attrib = DIFFUSE;
         fwrite(&attrib, sizeof(int), 1, fp);
         fwrite(newBatch[i].diffuseColors, sizeof(F3), vCount, fp);
      }
      if (newBatch[i].ambientColors) {
         attrib = AMBIENT;
         fwrite(&attrib, sizeof(int), 1, fp);
         fwrite(newBatch[i].ambientColors, sizeof(F3), vCount, fp);
      }
      if (newBatch[i].specularColors) {
         attrib = SPECULAR;
         fwrite(&attrib, sizeof(int), 1, fp);
         fwrite(newBatch[i].specularColors, sizeof(F3), vCount, fp);
         fwrite(newBatch[i].specularExp, sizeof(float), vCount, fp);
      }

      // finally write out triangle indeces
      fwrite(&newBatch[i].triangleCount, sizeof(int), 1, fp);
      int triCount = newBatch[i].triangleCount;

      fwrite(newBatch[i].triangleIndeces, sizeof(int), triCount*3, fp);
   }
   if (WRITE_TEST)
      fclose(fpTest);
   fclose(fp);
}

