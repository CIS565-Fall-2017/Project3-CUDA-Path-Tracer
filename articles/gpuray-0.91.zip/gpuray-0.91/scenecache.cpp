/* *************************************************************************
 * Copyright (C) 2006 Tim Foley
 * All Rights Reserved
 * *************************************************************************/

/*
 * scencachee.cpp --
 *
 *      A simple cache for created k-d trees, so that
 *      we don't have to suffer from long build times.
 *      This hopefully will be a short-lived module.
 */

#include "scenecache.h"

#include <assert.h>
#include <string>
#if !defined(_WIN32) || defined(__CYGWIN__)
#include <sys/stat.h>
#else
#include <direct.h>
#endif

#include "log.h"
#include "common/endian.h"
#include "builder/trianglePrimitives.h"

/*
 * BuildKDTree --
 *
 *      Creates a tree for the scene given,
 *      using the specified options.
 *
 * Returns:
 *      The created tree.
 */

static KDTree*
BuildKDTree( const Opts& cmdLineOpts, const Scene* inScene,
             const KDTreeBuildOptions& inOptions)
{
  PRINT(("Building kd-tree from %d triangles.\n", inScene->nTris()));
  return KDTree_Create( cmdLineOpts, *inScene, inOptions );
}

/*
 * ReadKDTree --
 *
 *      Loads a k-d tree accelerator from disk.
 *
 * Returns:
 *      The loaded tree.
 */

static KDTree*
ReadKDTree( const Opts& cmdLineOpts, FILE* inFile )
{
   // number of nodes
   uint32 nodeCount;
   fread( &nodeCount, sizeof(nodeCount), 1, inFile );
   nodeCount = fromLittleEndian( nodeCount );

   // number of indices
   uint32 indexCount;
   fread( &indexCount, sizeof(indexCount), 1, inFile );
   indexCount = fromLittleEndian( indexCount );

   // bounding box
   BoundingBox bounds;
   fread( &bounds, sizeof(bounds), 1, inFile );
   for( uint32 ii = 0; ii < 3; ii++ )
   {
      bounds.minimum[ii] = fromLittleEndian( bounds.minimum[ii] );
      bounds.maximum[ii] = fromLittleEndian( bounds.maximum[ii] );
   }

   // nodes
   assert( sizeof(KDTreeNode) == 2*sizeof(uint32) );

   std::vector<KDTreeNode> nodes;
   nodes.resize( nodeCount );
   uint32* currentWord = (uint32*) &nodes[0];
   for( uint32 ii = 0; ii < nodeCount; ii++ )
   {
      uint32 word0;
      uint32 word1;
      fread( &word0, sizeof(word0), 1, inFile );
      fread( &word1, sizeof(word1), 1, inFile );
      word0 = fromLittleEndian( word0 );
      word1 = fromLittleEndian( word1 );
      *currentWord++ = word0;
      *currentWord++ = word1;
   }

   // indices
   std::vector<int> indices;
   indices.resize( indexCount );
   for( uint32 ii = 0; ii < indexCount; ii++ )
   {
      uint32 index;
      fread( &index, sizeof(index), 1, inFile );
      index = fromLittleEndian( index );
      indices[ii] = (int) index;
   }

   return KDTree_Create( cmdLineOpts, bounds, nodes, indices );
}

/*
 * WriteKDTree --
 *
 *      Saves a k-d tree accelerator to disk.
 *
 * Returns:
 *      void
 *
 */

static void
WriteKDTree( KDTree* inTree, FILE* inFile )
{
   uint32 swapped;

   // number of nodes
   uint32 nodeCount = inTree->getNodeCount();
   swapped = toLittleEndian( nodeCount );
   fwrite( &swapped, sizeof(swapped), 1, inFile );

   // number of indices
   uint32 indexCount = inTree->getPrimitiveIndexCount();
   swapped = toLittleEndian( indexCount );
   fwrite( &swapped, sizeof(swapped), 1, inFile );

   // bounding box
   BoundingBox bounds = inTree->getBounds();
   for( uint32 ii = 0; ii < 3; ii++ )
   {
      bounds.minimum[ii] = toLittleEndian( bounds.minimum[ii] );
      bounds.maximum[ii] = toLittleEndian( bounds.maximum[ii] );
   }
   fwrite( &bounds, sizeof(bounds), 1, inFile );

   // nodes
   assert( sizeof(KDTreeNode) == 2*sizeof(uint32) );

   const KDTreeNode* nodes = inTree->getNodes();
   uint32* currentWord = (uint32*) nodes;
   for( uint32 ii = 0; ii < nodeCount; ii++ )
   {
      uint32 word0 = *currentWord++;
      uint32 word1 = *currentWord++;
      word0 = toLittleEndian( word0 );
      word1 = toLittleEndian( word1 );
      fwrite( &word0, sizeof(word0), 1, inFile );
      fwrite( &word1, sizeof(word1), 1, inFile );
   }

   // indices
   const int* indices = inTree->getPrimitiveIndices();
   for( uint32 ii = 0; ii < indexCount; ii++ )
   {
      uint32 index = indices[ii];
      index = toLittleEndian( index );
      fwrite( &index, sizeof(index), 1, inFile );
   }
}

/*
 * BuildKDTreeCached --
 *
 *      Returns a previously-created k-d tree
 *      from the cache or, if none exists,
 *      creates a tree with the specified options
 *      and inserts it into the cache.
 *
 * Returns:
 *      The created tree.
 */

KDTree*
BuildKDTreeCached( const Opts& cmdLineOpts, const Scene* inScene,
                   const KDTreeBuildOptions& inOptions )
{
   KDTree* result;

   static const char* cacheDirectory = "cache/";
   std::string cachedFileName = std::string("cache/")
      + inScene->sceneName() + ".cached.kdtree";

   FILE* cachedFile = fopen( cachedFileName.c_str(), "rb" );
   if( cachedFile != NULL )
   {
      result = ReadKDTree( cmdLineOpts, cachedFile );
      fclose( cachedFile );
   }
   else
   {
      result = BuildKDTree( cmdLineOpts, inScene, inOptions );

#if !defined(_WIN32) || defined(__CYGWIN__)
      mkdir( cacheDirectory, 0xFFFFFFFF );
#else
      _mkdir( cacheDirectory );
#endif
      cachedFile = fopen( cachedFileName.c_str(), "wb" );
      if( cachedFile == NULL )
      {
         fprintf( stderr, "Could not open file '%s' for cached k-d tree.\n",
               cachedFileName.c_str() );
         exit( 1 );
      }
      WriteKDTree( result, cachedFile );
      fclose( cachedFile );
   }

   return result;
}

