#!/bin/bash
#
# run-timings.sh --
#
#	Simple shell script to generate a bunch of timing numbers.

scenes=${1:-cbox glassner bunny robots kitchen}
resolution=1024
iterations=3
timeBuild=1
timeScalar=1
timePacket=1

echo -n "Starting at "
date
if [ $timeBuild -ne 0 ]; then
   echo "*** Timing kd-tree building ***"
   for scene in $scenes; do
      for ((i=0; i < $iterations; i++)) ; do
	 ./bin/raytracer --quiet --cpu -s $scene --size $resolution --buildOnly;
	 echo -e ""
      done
   done
fi

if [ $timeScalar -ne 0 ]; then
   echo -e "\n*** Timing kd-tree scalar intersection ***"
   for scene in $scenes; do
      for ((i=0; i < $iterations; i++)) ; do
	 ./bin/raytracer --quiet --cpu -s $scene --size $resolution -o junk.ppm;
	 echo -e ""
      done
   done
fi

if [ $timePacket -ne 0 ]; then
   echo -e "\n*** Timing kd-tree packet intersection ***"
   for scene in $scenes; do
      for ((i=0; i < $iterations; i++)) ; do
	 ./bin/raytracer --quiet --cpu -s $scene --size $resolution --packet -o junk.ppm;
	 echo -e ""
      done
   done
fi
echo -n "Done at "
date
