/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * f3.h --
 *
 *      (Very) Simple vector typedef to use instead of more complicated
 *      Brook float3, or other people's Point, Spectra, Normal, whatever.
 *
 *      Note: After experimenting a bunch with the compiler, operator
 *      overloading produced worse code, even with aggressive inlining and
 *      optimization, than the #defines.  Hence they stay.
 *
 */

#ifndef __F3_H__
#define __F3_H__

#define BLOCK_SIZE      2
#define BUNDLE_SIZE  (BLOCK_SIZE * BLOCK_SIZE)


/*
 * Some macros for basic operations on f3's.  There are lots of other
 * ways to implement these using the might of C++, but I prefer the
 * explicitness of the macros.  It also makes it extra convenient to replace
 * them with inline assembly later if I so choose. --Jeremy.
 */

#define F3_ADD(c, a, b)   /* c = a + b */               \
{                                                       \
   (c).v[0] = (a).v[0] + (b).v[0];                      \
   (c).v[1] = (a).v[1] + (b).v[1];                      \
   (c).v[2] = (a).v[2] + (b).v[2];                      \
}
#define F3_SUB(c, a, b)   /* c = a - b */               \
{                                                       \
   (c).v[0] = (a).v[0] - (b).v[0];                      \
   (c).v[1] = (a).v[1] - (b).v[1];                      \
   (c).v[2] = (a).v[2] - (b).v[2];                      \
}
#define F3_MUL(c, a, b)   /* c = a * b */               \
{                                                       \
   (c).v[0] = (a).v[0] * (b).v[0];                      \
   (c).v[1] = (a).v[1] * (b).v[1];                      \
   (c).v[2] = (a).v[2] * (b).v[2];                      \
}
#define F3_CROSS(c, a, b) /* c = a x b */               \
{                                                       \
   (c).v[0] = (a).v[1] * (b).v[2] - (a).v[2] * (b).v[1];\
   (c).v[1] = (a).v[2] * (b).v[0] - (a).v[0] * (b).v[2];\
   (c).v[2] = (a).v[0] * (b).v[1] - (a).v[1] * (b).v[0];\
}
#define F3_INV(a, b)   /* a = 1 / b */                  \
{                                                       \
   (a).v[0] = (1.0f) / (b).v[0];                        \
   (a).v[1] = (1.0f) / (b).v[1];                        \
   (a).v[2] = (1.0f) / (b).v[2];                        \
}
#define F3_SCALE(a, b)   /* a = a * b */                \
{                                                       \
   (a).v[0] = (b) * (a).v[0];                           \
   (a).v[1] = (b) * (a).v[1];                           \
   (a).v[2] = (b) * (a).v[2];                           \
}
#define F3_DOT(a, b) /* returns a dot b */      \
   ((a).v[0] * (b).v[0] + (a).v[1] * (b).v[1] + (a).v[2] * (b).v[2])


#define F3_FROM_FLOAT3(a, b) \
   { (a).v[0] = (b).x; (a).v[1] = (b).y; (a).v[2] = (b).z; }
#define FLOAT3_FROM_F3(a, b) \
   { (a).x = (b).v[0]; (a).y = (b).v[1]; (a).z = (b).v[2]; }

typedef union F3 {
   float v[3];
   struct {
      float x, y, z;
   };
} F3;

typedef union F3Packet {
   float v[3 * BUNDLE_SIZE];
   struct {
      float x0, x1, x2, x3;
      float y0, y1, y2, y3;
      float z0, z1, z2, z3;
   };
} F3Packet;

#endif
