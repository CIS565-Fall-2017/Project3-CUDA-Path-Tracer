/* *************************************************************************
 * Copyright (C) 2006 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * raster.h --
 *
 *      Class for rasterizing primary hits
 */

#ifndef __RASTER_H__
#define __RASTER_H__

#include "main.h"
#include "scene.h"
#include "tracer.h"

class RenderContextOGL;

class SceneTransformation;

class Raster {
public:
   Raster(const Opts& opts, const Scene& scene, RenderContextOGL* renderContext);
   ~Raster(void);

   float Rasterize(const Scene& scene, const int width, const int height,
                   const SceneTransformation& sceneTransform,
                   const CameraFrame& sceneSpaceCamera);

protected:
   RenderContextOGL* _renderContext;
};

/*
 * TracerRaster::TracerRaster --
 *
 *      A thin wrapper around the Raster class
 *      to allow it to serve as a ITracer
 *      instance.
 *
 */

class TracerRaster : public ITracer {
public:
   TracerRaster(
      const Opts& inOptions, Scene* inScene, CameraManager* inCameraManager,
      RenderContextOGL* inRenderContext );

   void Resize( int inWidth, int inHeight ) {
      _width = inWidth; _height = inHeight;
   }
   void TraceRays();
   void Display();

private:
   Scene *_scene;
   CameraManager *_cameraManager;

   Raster *_raster;

   int _width, _height;
};


#endif
