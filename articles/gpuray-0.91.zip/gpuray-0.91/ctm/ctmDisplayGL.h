/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * ctmDisplayGL.h --
 *
 *      XXX
 */

#ifndef __CTM_CTMDISPLAYGL_H__
#define __CTM_CTMDISPLAYGL_H__

#include <windows.h>
#include <GL/gl.h>

#include "ctmDisplay.h"
#include "../renderContextGL.h"
#include "../nv-glext.h"

class PixelDisplayerCtmOgl : public IPixelDisplayerCTM
{
public:
   PixelDisplayerCtmOgl( RenderContextOGL* inRenderContext );

   void Display( int inWidth, int inHeight, const PixelCTM* inPixels );

private:
   RenderContextOGL* _renderContext;

   unsigned int _fpID;
   unsigned int _textureID;

   PFNGLGENPROGRAMSARBPROC glGenProgramsARB;
   PFNGLPROGRAMSTRINGARBPROC glProgramStringARB;
   PFNGLBINDPROGRAMARBPROC glBindProgramARB;
   PFNGLDELETEPROGRAMSARBPROC glDeleteProgramsARB;
   PFNGLISPROGRAMARBPROC glIsProgramARB;
   PFNGLACTIVETEXTUREARBPROC glActiveTextureARB;
};

#endif
