/*
 * ctmAccelerator.h --
 *
 *      Abstract class for wrapping CTM-hosted acceleration structures.
 */

#ifndef __CTM_ACCELERATOR_H__
#define __CTM_ACCELERATOR_H__

#include "ctmTypes.h"

class AcceleratorCTM
{
public:
   virtual void intersect(const RayCTM rays[],
                          uint32 numRays, HitCTM hits[]) = 0;
   virtual void intersectP(const RayCTM rays[],
                           uint32 numRays, HitCTM hits[]) = 0;
   virtual void intersectPacket(const RayCTM rays[],
                                uint32 numRays, HitCTM hits[]) = 0;
   virtual void intersectPacketP(const RayCTM rays[],
                                 uint32 numRays, HitCTM hits[]) = 0;

   virtual uint32 getBatchGranularity() = 0;
};

#endif
