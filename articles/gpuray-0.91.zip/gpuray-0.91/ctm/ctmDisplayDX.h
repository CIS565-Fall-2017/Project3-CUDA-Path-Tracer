
/*
 * ctmDisplayGDI.h --
 *
 *      XXX
 */

#ifndef __CTM_CTMDISPLAYDX_H__
#define __CTM_CTMDISPLAYDX_H__

#include "ctmDisplay.h"
#include "../brook/brookDisplayDX.h"
class PixelDisplayerCtmDX : public IPixelDisplayerCTM,PixelDisplayerBrookDX9
{
public:
    PixelDisplayerCtmDX( RenderContextDX9* inRenderContext, BrookContext*inBrookContext );

   void Display( int inWidth, int inHeight, const PixelCTM* inPixels );
};
#endif
