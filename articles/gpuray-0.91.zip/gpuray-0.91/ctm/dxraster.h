#include "../renderContextDX.h"
#include "ctmTypes.h"
namespace brook{
    class stream;
}

class Iraster{
public:
    virtual void draw(int w, int h, const RayCTM rays[],ctmstream stream, float fov)=0;
};
class rasterDX:public Iraster{
    int count;
    RenderContextDX9 * _renderContext;
    IDirect3DVertexBuffer9* _vertexBuffer;
    IDirect3DVertexDeclaration9* _vertexDecl;
    IDirect3DVertexShader9* _vertexShader;
    IDirect3DPixelShader9* _pixelShader;
    LPDIRECT3DSURFACE9 _depthStencilSurface;
public:
    void draw(int w, int h, const RayCTM rays[],ctmstream stream, float fov);
    rasterDX(int count, const F3*v0,const F3*v1,const F3*v2, F3 offset, RenderContextDX9 * ctx);
};
