/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * ctmDisplay.h --
 *
 *      Helper classes for displaying pixels traced on the CTM.
 */

#ifndef __CTM_CTMDISPLAY_H__
#define __CTM_CTMDISPLAY_H__

#include "../common/commonTypes.h"
#include "ctmTracer.h"

class ppmImage;

/*
 * IPixelDisplayerCTM --
 *
 *      Interface for components that can take an array
 *      of pixels and display it to the user (or otherwise
 *      consume the pixel data).
 *
 */

class IPixelDisplayerCTM
{
public:
   virtual void Display( int inWidth, int inHeight, const PixelCTM* inPixels ) = 0;
};

/*
 * WriteImagePixelDisplayerCTM --
 *
 *      An implementation of IPixelDisplayerCTM that
 *      writes the result pixels out to a memory-resident
 *      image.
 *
 */

class WriteImagePixelDisplayerCTM : public IPixelDisplayerCTM
{
public:
   WriteImagePixelDisplayerCTM(
      ppmImage* inOutputImage );

   void Display( int inWidth, int inHeight, const PixelCTM* inPixels );

private:
   ppmImage* _outputImage;
};
#endif
