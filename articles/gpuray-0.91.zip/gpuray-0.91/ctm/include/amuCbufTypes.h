//
//  Copyright (c) 2006, ATI Technologies Inc.
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions
//  are met:
//
//  Redistributions of source code must retain the above copyright
//  notice, this list of conditions and the following disclaimer.
//
//  Redistributions in binary form must reproduce the above copyright
//  notice, this list of conditions and the following disclaimer in the
//  documentation and/or other materials provided with the distribution.
//
//  Neither the name of ATI Technologies Inc., nor the names of its
//  affiliates, subsidiaries or contributors may be used to endorse or
//  promote products derived from this software without specific prior
//  written permission.
//
//  THIS SOFTWARE IS PROVIDED BY ATI TECHNOLOGIES INC., ITS AFFILIATES,
//  SUBSIDIARIES AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
//  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
//  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
//  IN NO EVENT SHALL ATI TECHNOLOGIES INC., ITS AFFILIATES, SUBSIDIARIES
//  OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
//  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
//  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
//  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
//  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
//  SUCH DAMAGE.
//
//  Under no circumstances will the license grant above be construed as
//  granting, by implication, estoppel or otherwise, a license to any
//  technology belonging to ATI Technologies Inc. other than a copyright
//  license to this software.  For greater certainty this license does not
//  convey any rights, by implication, estoppel or otherwise, under or to
//  any patents or pending applications belonging to ATI Technologies Inc.
//  All rights not expressly granted herein are expressly reserved by ATI
//  Technologies Inc.
//

#ifndef _AMU_CBUF_TYPES_H_
#define _AMU_CBUF_TYPES_H_

///
///  @file  amuCbufTypes.h
///  @brief Types for the ATI CTM Command Buffer Utility Libraries
///  @warning The standard math library header <math.h> must be included after this file.
///

////////////////////////////////////////////////////////////////////////////////
//
//  native data types
//

//
///  32-bit unsigned integer
//
typedef unsigned int AMUcbufUint32;

////////////////////////////////////////////////////////////////////////////////
//
//  command opcodes
//

//
///  command opcodes
//
typedef enum _AMUcbufOpcode {
    AMU_CBUF_OP_INITPERFCOUNTERS   = 0xC0010200,
    AMU_CBUF_OP_STARTPERFCOUNTERS  = 0xC0000300,
    AMU_CBUF_OP_STOPPERFCOUNTERS   = 0xC0000400,
    AMU_CBUF_OP_READPERFCOUNTERS   = 0xC0010500,
    AMU_CBUF_OP_SETCONDVAL         = 0xC0000600,
    AMU_CBUF_OP_SETDOMAIN          = 0xC0030700,
    AMU_CBUF_OP_STARTPROGRAM       = 0xC0000800,
    AMU_CBUF_OP_WAITFORIDLE        = 0xC0000900,
    AMU_CBUF_OP_SETINSTFMT         = 0xC0010A00,
    AMU_CBUF_OP_SETINPFMT          = 0xC0030B00,
    AMU_CBUF_OP_SETOUTFMT          = 0xC0030C00,
    AMU_CBUF_OP_SETCONDOUTFMT      = 0xC0020D00,
    AMU_CBUF_OP_SETCONSTFFMT       = 0xC0010E00,
    AMU_CBUF_OP_SETCONSTIFMT       = 0xC0010F00,
    AMU_CBUF_OP_SETCONSTBFMT       = 0xC0011000,
    AMU_CBUF_OP_INVINSTCACHE       = 0xC0001100,
    AMU_CBUF_OP_INVCONSTFCACHE     = 0xC0001200,
    AMU_CBUF_OP_INVCONSTICACHE     = 0xC0001300,
    AMU_CBUF_OP_INVCONSTBCACHE     = 0xC0001400,
    AMU_CBUF_OP_INVCONDOUTCACHE    = 0xC0001500,
    AMU_CBUF_OP_INVINPCACHE        = 0xC0001600,
    AMU_CBUF_OP_FLUSHOUTCACHE      = 0xC0001700,
    AMU_CBUF_OP_FLUSHCONDOUTCACHE  = 0xC0001800,
    AMU_CBUF_OP_SETOUTMASK         = 0xC0001900,
    AMU_CBUF_OP_SETCONDOUTMASK     = 0xC0001A00,
    AMU_CBUF_OP_SETCONDTEST        = 0xC0001B00,
    AMU_CBUF_OP_SETCONDLOC         = 0xC0001C00,
    AMU_CBUF_OP_SETPARAMS          = 0xC0001D00,
    AMU_CBUF_OP_SETOFFSETFMT       = 0xC0021E00,
} AMUcbufOpcode;

////////////////////////////////////////////////////////////////////////////////
//
//  field data types and possible values
//

//
///  data formats for use in the format command parameter
//
typedef enum _AMUcbufFldFormat {
    AMU_CBUF_FLD_FORMAT_UINT16_1  = 0x0,
    AMU_CBUF_FLD_FORMAT_UINT8_4   = 0x1,
    AMU_CBUF_FLD_FORMAT_FLOAT32_1 = 0x2,
    AMU_CBUF_FLD_FORMAT_FLOAT32_2 = 0x3,
    AMU_CBUF_FLD_FORMAT_FLOAT32_4 = 0x4,
    AMU_CBUF_FLD_FORMAT_UINT16_2  = 0x5,
    AMU_CBUF_FLD_FORMAT_UINT16_4  = 0x6,
    AMU_CBUF_FLD_FORMAT_UINT8_1   = 0x7,
    AMU_CBUF_FLD_FORMAT_UINT8_2   = 0x8,
    AMU_CBUF_FLD_FORMAT_INT8_1    = 0x9,
    AMU_CBUF_FLD_FORMAT_INT8_2    = 0xa,
    AMU_CBUF_FLD_FORMAT_INT8_4    = 0xb,
    AMU_CBUF_FLD_FORMAT_INT16_1   = 0xc,
    AMU_CBUF_FLD_FORMAT_INT16_2   = 0xd,
    AMU_CBUF_FLD_FORMAT_INT16_4   = 0xe,
    AMU_CBUF_FLD_FORMAT_FLOAT16_1 = 0xf,
    AMU_CBUF_FLD_FORMAT_FLOAT16_2 = 0x10,
    AMU_CBUF_FLD_FORMAT_FLOAT16_4 = 0x11,
} AMUcbufFldFormat;

//
///  tiling formats for use in the format command parameter
//
typedef enum _AMUcbufFldTiling {
    AMU_CBUF_FLD_TILING_LINEAR = 0x0,
    AMU_CBUF_FLD_TILING_TILED0 = 0x1,
    AMU_CBUF_FLD_TILING_TILED1 = 0x2,
    AMU_CBUF_FLD_TILING_TILED2 = 0x3,
    AMU_CBUF_FLD_TILING_TILED3 = 0x4,
    AMU_CBUF_FLD_TILING_TILED4 = 0x5,
    AMU_CBUF_FLD_TILING_TILED5 = 0x6,
    AMU_CBUF_FLD_TILING_TILED6 = 0x7,
} AMUcbufFldTiling;

//
///  output indices for use in the output command parameter
//
typedef enum _AMUcbufFldOutput {
    AMU_CBUF_FLD_OUTPUT_0 = 0x0,
    AMU_CBUF_FLD_OUTPUT_1 = 0x1,
    AMU_CBUF_FLD_OUTPUT_2 = 0x2,
    AMU_CBUF_FLD_OUTPUT_3 = 0x3,
} AMUcbufFldOutput;

//
///  input indices for use in the input command parameter
//
typedef enum _AMUcbufFldInput {
    AMU_CBUF_FLD_INPUT_0 = 0x0,
    AMU_CBUF_FLD_INPUT_1 = 0x1,
    AMU_CBUF_FLD_INPUT_2 = 0x2,
    AMU_CBUF_FLD_INPUT_3 = 0x3,
    AMU_CBUF_FLD_INPUT_4 = 0x4,
    AMU_CBUF_FLD_INPUT_5 = 0x5,
    AMU_CBUF_FLD_INPUT_6 = 0x6,
    AMU_CBUF_FLD_INPUT_7 = 0x7,
    AMU_CBUF_FLD_INPUT_8 = 0x8,
    AMU_CBUF_FLD_INPUT_9 = 0x9,
    AMU_CBUF_FLD_INPUT_A = 0xA,
    AMU_CBUF_FLD_INPUT_B = 0xB,
    AMU_CBUF_FLD_INPUT_C = 0xC,
    AMU_CBUF_FLD_INPUT_D = 0xD,
    AMU_CBUF_FLD_INPUT_E = 0xE,
    AMU_CBUF_FLD_INPUT_F = 0xF,
} AMUcbufFldInput;

//
///  writemask values for use in the out mask and cond out mask parameters
//
typedef enum _AMUcbufFldWritemask {
    AMU_CBUF_FLD_WRITEMASK_0 = 0x0,
    AMU_CBUF_FLD_WRITEMASK_1 = 0x1,
} AMUcbufFldWritemask;

//
///  test values for use in the cond test parameter
//
typedef enum _AMUcbufFldCondTest {
    AMU_CBUF_FLD_COND_TEST_NEVER    = 0x0,
    AMU_CBUF_FLD_COND_TEST_LESS     = 0x1,
    AMU_CBUF_FLD_COND_TEST_LEQUAL   = 0x2,
    AMU_CBUF_FLD_COND_TEST_EQUAL    = 0x3,
    AMU_CBUF_FLD_COND_TEST_GEQUAL   = 0x4,
    AMU_CBUF_FLD_COND_TEST_GREATER  = 0x5,
    AMU_CBUF_FLD_COND_TEST_NOTEQUAL = 0x6,
    AMU_CBUF_FLD_COND_TEST_ALWAYS   = 0x7,
} AMUcbufFldCondTest;

//
///  location values for use in the cond loc parameter
//
typedef enum _AMUcbufFldCondLoc {
    AMU_CBUF_FLD_CONDLOC_NONE = 0x0,
    AMU_CBUF_FLD_CONDLOC_DPP  = 0x1,
    AMU_CBUF_FLD_CONDLOC_PE   = 0x3,
} AMUcbufFldCondLoc;

////////////////////////////////////////////////////////////////////////////////
//
//  parameter types
//

//
///  format command parameter
//
typedef union _AMUcbufPrmFormat {
    struct {
        AMUcbufUint32 RESERVED0 : 1;
        AMUcbufUint32     PITCH : 12;
        AMUcbufUint32 RESERVED1 : 3;
        AMUcbufUint32    TILING : 8;
        AMUcbufUint32    FORMAT : 8;
    } bits;
    AMUcbufUint32 u32;
} AMUcbufPrmFormat;

//
///  offset format command parameter
//
typedef union _AMUcbufPrmOffsetFormat {
    struct {
        AMUcbufUint32     COUNT : 16;
        AMUcbufUint32    TILING : 8;
        AMUcbufUint32    FORMAT : 8;
    } bits;
    AMUcbufUint32 u32;
} AMUcbufPrmOffsetFormat;

//
///  base address command parameter
//
typedef union _AMUcbufPrmAddress {
    struct {
        AMUcbufUint32 RESERVED : 11;
        AMUcbufUint32     ADDR : 21;
    } bits;
    AMUcbufUint32 u32;
} AMUcbufPrmAddress;

//
///  height command parameter
//
typedef union _AMUcbufPrmHeight {
    struct {
        AMUcbufUint32   HEIGHT : 13;
        AMUcbufUint32 RESERVED : 19;
    } bits;
    AMUcbufUint32 u32;
} AMUcbufPrmHeight;

//
///  offset id command parameter
//
typedef union _AMUcbufPrmOffsetId {
    struct {
        AMUcbufUint32       ID : 4;
        AMUcbufUint32 RESERVED : 28;
    } bits;
    AMUcbufUint32 u32;
} AMUcbufPrmOffsetId;

//
///  input command parameter
//
typedef union _AMUcbufPrmInput {
    struct {
        AMUcbufUint32    INPUT : 4;
        AMUcbufUint32 RESERVED : 28;
    } bits;
    AMUcbufUint32 u32;
} AMUcbufPrmInput;

//
///  output command parameter
//
typedef union _AMUcbufPrmOutput {
    struct {
        AMUcbufUint32   OUTPUT : 2;
        AMUcbufUint32 RESERVED : 30;
    } bits;
    AMUcbufUint32 u32;
} AMUcbufPrmOutput;

//
///  domain command parameter
//
typedef union _AMUcbufPrmDomain {
    struct {
        AMUcbufUint32   DOMAIN : 12;
        AMUcbufUint32 RESERVED : 20;
    } bits;
    AMUcbufUint32 u32;
} AMUcbufPrmDomain;

//
///  conditional value command parameter
//
typedef union _AMUcbufPrmCondVal {
    struct {
        AMUcbufUint32 CONDVAL : 32;
    } bits;
    AMUcbufUint32 u32;
} AMUcbufPrmCondVal;

//
///  out mask command parameter
//
typedef union _AMUcbufPrmOutMask {
    struct {
        AMUcbufUint32       C0 : 1;
        AMUcbufUint32       C1 : 1;
        AMUcbufUint32       C2 : 1;
        AMUcbufUint32       C3 : 1;
        AMUcbufUint32 RESERVED : 28;
    } bits;
    AMUcbufUint32 u32;
} AMUcbufPrmOutMask;

//
///  cond out mask command parameter
//
typedef union _AMUcbufPrmCondOutMask {
    struct {
        AMUcbufUint32        W : 1;
        AMUcbufUint32 RESERVED : 31;
    } bits;
    AMUcbufUint32 u32;
} AMUcbufPrmCondOutMask;

//
///  cond test command parameter
//
typedef union _AMUcbufPrmCondTest {
    struct {
        AMUcbufUint32     TEST : 3;
        AMUcbufUint32 RESERVED : 29;
    } bits;
    AMUcbufUint32 u32;
} AMUcbufPrmCondTest;

//
///  cond loc command parameter
//
typedef union _AMUcbufPrmCondLoc {
    struct {
        AMUcbufUint32      LOC : 2;
        AMUcbufUint32 RESERVED : 30;
    } bits;
    AMUcbufUint32 u32;
} AMUcbufPrmCondLoc;

////////////////////////////////////////////////////////////////////////////////
//
//  command types
//

//
///  init perf counters command
//
typedef struct _AMUcbufCmdInitPerfCounters {
  AMUcbufUint32 cmd;
  AMUcbufUint32 val;
  AMUcbufUint32 reserved;
} AMUcbufCmdInitPerfCounters;

//
///  start perf counters command
//
typedef struct _AMUcbufCmdStartPerfCounters {
  AMUcbufUint32 cmd;
  AMUcbufUint32 reserved;
} AMUcbufCmdStartPerfCounters;

//
///  stop perf counters command
//
typedef struct _AMUcbufCmdStopPerfCounters {
  AMUcbufUint32 cmd;
  AMUcbufUint32 reserved;
} AMUcbufCmdStopPerfCounters;

//
///  read perf counters command
//
typedef struct _AMUcbufCmdReadPerfCounters {
  AMUcbufUint32 cmd;
  AMUcbufPrmAddress addr;
  AMUcbufUint32 reserved;
} AMUcbufCmdReadPerfCounters;

//
///  set conditional value command
//
typedef struct _AMUcbufCmdSetCondVal {
    AMUcbufOpcode     op;
    AMUcbufPrmCondVal val;
} AMUcbufCmdSetCondVal;

//
///  set domain command
//
typedef struct _AMUcbufCmdSetDomain {
    AMUcbufOpcode    op;
    AMUcbufPrmDomain i0;
    AMUcbufPrmDomain j0;
    AMUcbufPrmDomain i1;
    AMUcbufPrmDomain j1;
} AMUcbufCmdSetDomain;

//
///  start program command
//
typedef struct _AMUcbufCmdStartProgram {
    AMUcbufOpcode op;
    AMUcbufUint32 reserved;
} AMUcbufCmdStartProgram;

//
///  wait for idle command
//
typedef struct _AMUcbufCmdWaitForIdle {
    AMUcbufOpcode op;
    AMUcbufUint32 reserved;
} AMUcbufCmdWaitForIdle;

//
///  set offset format command
//
typedef struct _AMUcbufCmdSetOffsetFmt {
    AMUcbufOpcode          op;
    AMUcbufPrmOffsetId     id;
    AMUcbufPrmAddress      addr;
    AMUcbufPrmOffsetFormat fmt;
} AMUcbufCmdSetOffsetFmt;

//
///  set instruction format command
//
typedef struct _AMUcbufCmdSetInstFmt {
    AMUcbufOpcode     op;
    AMUcbufPrmAddress addr;
    AMUcbufPrmFormat  fmt;
} AMUcbufCmdSetInstFmt;

//
///  set input format command
//
typedef struct _AMUcbufCmdSetInpFmt {
    AMUcbufOpcode     op;
    AMUcbufPrmInput   inp;
    AMUcbufPrmAddress addr;
    AMUcbufPrmFormat  fmt;
    AMUcbufPrmHeight  height;
} AMUcbufCmdSetInpFmt;

//
///  set output format command
//
typedef struct _AMUcbufCmdSetOutFmt {
    AMUcbufOpcode     op;
    AMUcbufPrmOutput  out;
    AMUcbufPrmAddress addr;
    AMUcbufPrmFormat  fmt;
    AMUcbufPrmHeight  height;
} AMUcbufCmdSetOutFmt;

//
///  set conditional output format command
//
typedef struct _AMUcbufCmdSetCondOutFmt {
    AMUcbufOpcode     op;
    AMUcbufPrmAddress addr;
    AMUcbufPrmFormat  fmt;
    AMUcbufPrmHeight  height;
} AMUcbufCmdSetCondOutFmt;

//
///  set floating point constant format command
//
typedef struct _AMUcbufCmdSetConstfFmt {
    AMUcbufOpcode     op;
    AMUcbufPrmAddress addr;
    AMUcbufPrmFormat  fmt;
} AMUcbufCmdSetConstfFmt;

//
///  set integer constant format command
//
typedef struct _AMUcbufCmdSetConstiFmt {
    AMUcbufOpcode     op;
    AMUcbufPrmAddress addr;
    AMUcbufPrmFormat  fmt;
} AMUcbufCmdSetConstiFmt;

//
///  set boolean constant format command
//
typedef struct _AMUcbufCmdSetConstbFmt {
    AMUcbufOpcode     op;
    AMUcbufPrmAddress addr;
    AMUcbufPrmFormat  fmt;
} AMUcbufCmdSetConstbFmt;

//
///  invalidate instruction cache command
//
typedef struct _AMUcbufCmdInvInstCache {
    AMUcbufOpcode op;
    AMUcbufUint32 reserved;
} AMUcbufCmdInvInstCache;

//
///  invalidate floating point constant cache command
//
typedef struct _AMUcbufCmdInvConstfCache {
    AMUcbufOpcode op;
    AMUcbufUint32 reserved;
} AMUcbufCmdInvConstfCache;

//
///  invalidate integer constant cache command
//
typedef struct _AMUcbufCmdInvConstiCache {
    AMUcbufOpcode op;
    AMUcbufUint32 reserved;
} AMUcbufCmdInvConstiCache;

//
///  invalidate boolean constant cache command
//
typedef struct _AMUcbufCmdInvConstbCache {
    AMUcbufOpcode op;
    AMUcbufUint32 reserved;
} AMUcbufCmdInvConstbCache;

//
///  invalidate conditional output cache command
//
typedef struct _AMUcbufCmdInvCondOutCache {
    AMUcbufOpcode op;
    AMUcbufUint32 reserved;
} AMUcbufCmdInvCondOutCache;

//
///  invalidate input cache command
//
typedef struct _AMUcbufCmdInvInpCache {
    AMUcbufOpcode op;
    AMUcbufUint32 reserved;
} AMUcbufCmdInvInpCache;

//
///  flush output cache command
//
typedef struct _AMUcbufCmdFlushOutCache {
    AMUcbufOpcode op;
    AMUcbufUint32 reserved;
} AMUcbufCmdFlushOutCache;

//
///  flush conditional output cache command
//
typedef struct _AMUcbufCmdFlushCondOutCache {
    AMUcbufOpcode op;
    AMUcbufUint32 reserved;
} AMUcbufCmdFlushCondOutCache;

//
///  set output mask command
//
typedef struct _AMUcbufCmdSetOutMask {
    AMUcbufOpcode     op;
    AMUcbufPrmOutMask mask;
} AMUcbufCmdSetOutMask;

//
///  set conditional output mask command
//
typedef struct _AMUcbufCmdSetCondOutMask {
    AMUcbufOpcode         op;
    AMUcbufPrmCondOutMask mask;
} AMUcbufCmdSetCondOutMask;

//
///  set conditional test command
//
typedef struct _AMUcbufCmdSetCondTest {
    AMUcbufOpcode      op;
    AMUcbufPrmCondTest test;
} AMUcbufCmdSetCondTest;

//
///  set conditional location command
//
typedef struct _AMUcbufCmdSetCondLoc {
    AMUcbufOpcode     op;
    AMUcbufPrmCondLoc loc;
} AMUcbufCmdSetCondLoc;

typedef struct _AMUcbufCmdSetParams {
    AMUcbufOpcode     op;
    AMUcbufPrmAddress addr;
} AMUcbufCmdSetParams;

#endif // _AMU_CBUF_TYPES_H_
