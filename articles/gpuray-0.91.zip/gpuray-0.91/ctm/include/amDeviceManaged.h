//
//  Copyright (c) 2006, ATI Technologies Inc.
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions
//  are met:
//
//  Redistributions of source code must retain the above copyright
//  notice, this list of conditions and the following disclaimer.
//
//  Redistributions in binary form must reproduce the above copyright
//  notice, this list of conditions and the following disclaimer in the
//  documentation and/or other materials provided with the distribution.
//
//  Neither the name of ATI Technologies Inc., nor the names of its
//  affiliates, subsidiaries or contributors may be used to endorse or
//  promote products derived from this software without specific prior
//  written permission.
//
//  THIS SOFTWARE IS PROVIDED BY ATI TECHNOLOGIES INC., ITS AFFILIATES,
//  SUBSIDIARIES AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
//  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
//  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
//  IN NO EVENT SHALL ATI TECHNOLOGIES INC., ITS AFFILIATES, SUBSIDIARIES
//  OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
//  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
//  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
//  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
//  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
//  SUCH DAMAGE.
//
//  Under no circumstances will the license grant above be construed as
//  granting, by implication, estoppel or otherwise, a license to any
//  technology belonging to ATI Technologies Inc. other than a copyright
//  license to this software.  For greater certainty this license does not
//  convey any rights, by implication, estoppel or otherwise, under or to
//  any patents or pending applications belonging to ATI Technologies Inc.
//  All rights not expressly granted herein are expressly reserved by ATI
//  Technologies Inc.
//

#ifndef _AM_DEVICE_MANAGED_H_
#define _AM_DEVICE_MANAGED_H_

///
///  @file  amDeviceManaged.h
///  @brief Interfaces Exported by the ATI CTM Library
///

#ifdef __cplusplus
extern "C" {
#endif

typedef char         AMchar8;   ///< 8-bit ANSI character data type
typedef unsigned int AMuint32;  ///< 32-bit unsigned integer data type


//
/// device information returned upon initialization
//
typedef struct AMmanagedDeviceInfoRec {
    AMuint32 platformVersion; ///< Version of the software platform that is managing this device
    AMuint32 deviceID;        ///< Uniquely identifies the GPU device based on card type
    AMuint32 baseAddressGPU;  ///< GPU-relative address of the base of the GPU memory arena
    AMuint32 arenaSizeGPU;    ///< Total size in bytes of the GPU memory arena
    AMuint32 baseAddressGPUb; ///< GPU-relative address of the base of the secondary GPU memory arena
    AMuint32 arenaSizeGPUb;   ///< Total size in bytes of the secondary GPU memory arena
    AMuint32 baseAddressSYS;  ///< GPU-relative address of the base of the SYS memory arena
    AMuint32 arenaSizeSYS;    ///< Total size in bytes of the SYS memory arena
    void*    baseAddressCPU;  ///< CPU-relative address of the base of the SYS memory arena
    AMuint32 baseAddressSYSc; ///< GPU-relative address of the base of the cached SYS memory arena
    AMuint32 arenaSizeSYSc;   ///< Total size in bytes of the cached SYS memory arena
    void*    baseAddressCPUc; ///< CPU-relative address of the base of the cached SYS memory arena
} AMmanagedDeviceInfo;


//
/// opaque handle to a managed device
//
typedef struct AMmanagedDeviceRec {}* AMmanagedDevice;


///
///  @fn amOpenManagedConnection(const AMchar8* dev, AMmanagedDeviceInfo* info)
///
///  @brief Instantiate a managed device.
///
///  This function must be used to create a managed device instantiation.
///  All CTM functions take a handle to a managed device created here.
///  If a valid device is identified, the corresponding device ID will
///  be set in the info struct prior to opening the connection.  Valid
///  device names to connect to include /dev/pcie## where ## is between
///  00 - 03.  The allocation size of the memory pools can be limited
///  to a specified amount by setting the arenaSize* fields in the info
///  struct being passed in.  If any of the arenaSize* fields are set to
///  zero, the corresponding pool will be allocated with the maximum
///  available size.
///
///  @param dev  (in)   Name of device to open a connection to
///  @param info (out)  Information structure populated by this function.
///
///  @return Returns an opaque managed device handle, or NULL upon failure.
///
///  @sa amCloseManagedConnection
///
extern AMmanagedDevice amOpenManagedConnection(const AMchar8* dev, AMmanagedDeviceInfo* info);

///
///  @fn amCloseManagedConnection(AMmanagedDevice dev)
///
///  @brief Close a managed device.
///
///  This function shuts down an instantiation of a managed device,
///  freeing all associated resources. The handle is undefined after
///  the function call.
///
///  @param dev  (in)  Handle to the managed device
///
///  @return No return value.
///
///  @sa amOpenManagedConnection
///
extern void amCloseManagedConnection(AMmanagedDevice dev);

///
///  @fn amSubmitCommandBuffer(AMmanagedDevice dev, AMuint32 addr, AMuint32 size)
///
///  @brief Submit a command buffer to a managed device.
///
///  This function submits a command buffer to a managed device.  The
///  command buffer location (as a GPU address) and size are passed
///  in.  It returns a unique 32-bit unsigned integer identifying this
///  command buffer submission request.  This return value can be used
///  to query whether the command buffer has been consumed.
///
///  @param dev  (in)  Handle to the managed device
///  @param addr (in)  32-bit unsigned integer specifying GPU address of command buffer
///  @param size (in)  size of the command buffer in units of 32-bit unsigned integers
///
///  @return Returns a unique 32-bit unsigned integer identifying this command buffer
///          submission request, or zero if the submission has failed.
///
///  @sa amOpenManagedConnection, amCommandBufferConsumed
///
extern AMuint32 amSubmitCommandBuffer(AMmanagedDevice dev, AMuint32 addr, AMuint32 size);

///
///  @fn amCommandBufferConsumed(AMmanagedDevice dev, AMuint32 buf)
///
///  @brief Submit a command buffer to a managed device.
///
///  This function submits a command buffer to a managed device.  The
///  command buffer location (as a GPU address) and size are passed
///  in.  It returns a unique 32-bit unsigned integer identifying this
///  command buffer submission request.  This return value can be used
///  to query whether the command buffer has been consumed.
///
///  @param dev  (in)  Handle to the managed device
///  @param buf  (in)  command buffer identifier that was returned by amSubmitCommandBuffer
///
///  @return Returns 1 if command buffer has been consumed; otherwise returns 0.
///
///  @sa amOpenManagedConnection, amCommandBufferConsumed
///
extern AMuint32 amCommandBufferConsumed(AMmanagedDevice dev, AMuint32 buf);

#ifdef __cplusplus
}
#endif

#endif // _AM_DEVICE_MANAGED_H_


