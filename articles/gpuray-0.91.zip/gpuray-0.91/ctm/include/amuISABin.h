//
//  Copyright (c) 2006, ATI Technologies Inc.
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions
//  are met:
//
//  Redistributions of source code must retain the above copyright
//  notice, this list of conditions and the following disclaimer.
//
//  Redistributions in binary form must reproduce the above copyright
//  notice, this list of conditions and the following disclaimer in the
//  documentation and/or other materials provided with the distribution.
//
//  Neither the name of ATI Technologies Inc., nor the names of its
//  affiliates, subsidiaries or contributors may be used to endorse or
//  promote products derived from this software without specific prior
//  written permission.
//
//  THIS SOFTWARE IS PROVIDED BY ATI TECHNOLOGIES INC., ITS AFFILIATES,
//  SUBSIDIARIES AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
//  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
//  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
//  IN NO EVENT SHALL ATI TECHNOLOGIES INC., ITS AFFILIATES, SUBSIDIARIES
//  OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
//  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
//  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
//  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
//  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
//  SUCH DAMAGE.
//
//  Under no circumstances will the license grant above be construed as
//  granting, by implication, estoppel or otherwise, a license to any
//  technology belonging to ATI Technologies Inc. other than a copyright
//  license to this software.  For greater certainty this license does not
//  convey any rights, by implication, estoppel or otherwise, under or to
//  any patents or pending applications belonging to ATI Technologies Inc.
//  All rights not expressly granted herein are expressly reserved by ATI
//  Technologies Inc.
//

#ifndef _AMU_ISA_BIN_H_
#define _AMU_ISA_BIN_H_

//
//  data types shared by all of the instructions
//
typedef enum _AMUisaFldBool {
    AMU_ISA_FLD_FALSE                  = 0x0,
    AMU_ISA_FLD_TRUE                   = 0x1,
} AMUisaFldBool;

typedef enum _AMUisaFldInstType {
    AMU_ISA_FLD_INST_TYPE_ALU          = 0x0,
    AMU_ISA_FLD_INST_TYPE_OUT          = 0x1,
    AMU_ISA_FLD_INST_TYPE_FLW          = 0x2,
    AMU_ISA_FLD_INST_TYPE_INP          = 0x3,
} AMUisaFldInstType;

typedef enum _AMUisaFldPredSel {
    AMU_ISA_FLD_PRED_SEL_NONE          = 0x0,
    AMU_ISA_FLD_PRED_SEL_EACH          = 0x1,
    AMU_ISA_FLD_PRED_SEL_C0            = 0x2,
    AMU_ISA_FLD_PRED_SEL_C1            = 0x3,
    AMU_ISA_FLD_PRED_SEL_C2            = 0x4,
    AMU_ISA_FLD_PRED_SEL_C3            = 0x5,
} AMUisaFldPredSel;

//
//  data types for input instructions
//
typedef enum _AMUisaFldInpBool {
    AMU_ISA_FLD_INP_FALSE              = 0x0,
    AMU_ISA_FLD_INP_TRUE               = 0x1,
} AMUisaFldInpBool;

typedef enum _AMUisaFldInpOp {
    AMU_ISA_FLD_INP_OP_NOP             = 0x0,
    AMU_ISA_FLD_INP_OP_LOOKUP          = 0x1,
    AMU_ISA_FLD_INP_OP_KILL_LT_0       = 0x2,
    AMU_ISA_FLD_INP_OP_LOOKUP_PROJ     = 0x3,
    AMU_ISA_FLD_INP_OP_LOOKUP_LODBIAS  = 0x4,
    AMU_ISA_FLD_INP_OP_LOOKUP_LOD      = 0x5,
    AMU_ISA_FLD_INP_OP_LOOKUP_DXDY     = 0x6,
    AMU_ISA_FLD_INP_OP_LOOKUP_UNCACHED = 0x7,
} AMUisaFldInpOp;

typedef enum _AMUisaFldInpSmp {
    AMU_ISA_FLD_INP_SMP_S0             = 0x0,
    AMU_ISA_FLD_INP_SMP_S1             = 0x1,
    AMU_ISA_FLD_INP_SMP_S2             = 0x2,
    AMU_ISA_FLD_INP_SMP_S3             = 0x3,
    AMU_ISA_FLD_INP_SMP_S4             = 0x4,
    AMU_ISA_FLD_INP_SMP_S5             = 0x5,
    AMU_ISA_FLD_INP_SMP_S6             = 0x6,
    AMU_ISA_FLD_INP_SMP_S7             = 0x7,
    AMU_ISA_FLD_INP_SMP_S8             = 0x8,
    AMU_ISA_FLD_INP_SMP_S9             = 0x9,
    AMU_ISA_FLD_INP_SMP_S10            = 0xa,
    AMU_ISA_FLD_INP_SMP_S11            = 0xb,
    AMU_ISA_FLD_INP_SMP_S12            = 0xc,
    AMU_ISA_FLD_INP_SMP_S13            = 0xd,
    AMU_ISA_FLD_INP_SMP_S14            = 0xe,
    AMU_ISA_FLD_INP_SMP_S15            = 0xf,
} AMUisaFldInpSmp;

typedef enum _AMUisaFldInpSwiz {
    AMU_ISA_FLD_INP_SWIZZLE_C0         = 0x0,
    AMU_ISA_FLD_INP_SWIZZLE_C1         = 0x1,
    AMU_ISA_FLD_INP_SWIZZLE_C2         = 0x2,
    AMU_ISA_FLD_INP_SWIZZLE_C3         = 0x3,
} AMUisaFldInpSwiz;

typedef union _AMU_ISA_INP_DWORD_0 {
    struct {
        unsigned int             TYPE : 2;
        unsigned int     INP_SEM_WAIT : 1;
        unsigned int     VEC_PRED_SEL : 3;
        unsigned int     VEC_PRED_INV : 1;
        unsigned int   WRITE_INACTIVE : 1;
        unsigned int                  : 2;
        unsigned int         ALU_WAIT : 1;
        unsigned int        VEC_WMASK : 3;
        unsigned int        SCL_WMASK : 1;
        unsigned int                  : 7;
        unsigned int     SCL_PRED_INV : 1;
        unsigned int                  : 2;
        unsigned int     SCL_PRED_SEL : 3;
        unsigned int                  : 4;
    } bits;
    unsigned int u32;
} AMU_ISA_INP_DWORD_0;

typedef union _AMU_ISA_INP_DWORD_1 {
    struct {
        unsigned int                  : 16;
        unsigned int           INP_ID : 4;
        unsigned int                  : 2;
        unsigned int               OP : 3;
        unsigned int  INP_SEM_ACQUIRE : 1;
        unsigned int IGNORE_UNCOVERED : 1;
        unsigned int         UNSCALED : 1;
        unsigned int                  : 4;
    } bits;
    unsigned int u32;
} AMU_ISA_INP_DWORD_1;

typedef union _AMU_ISA_INP_DWORD_2 {
    struct {
        unsigned int         SRC_ADDR : 7;
        unsigned int     SRC_ADDR_REL : 1;
        unsigned int      SRC_SWIZ_C0 : 2;
        unsigned int      SRC_SWIZ_C1 : 2;
        unsigned int      SRC_SWIZ_C2 : 2;
        unsigned int      SRC_SWIZ_C3 : 2;
        unsigned int         DST_ADDR : 7;
        unsigned int     DST_ADDR_REL : 1;
        unsigned int      DST_SWIZ_C0 : 2;
        unsigned int      DST_SWIZ_C1 : 2;
        unsigned int      DST_SWIZ_C2 : 2;
        unsigned int      DST_SWIZ_C3 : 2;
    } bits;
    unsigned int u32;
} AMU_ISA_INP_DWORD_2;

typedef union _AMU_ISA_INP_DWORD_3 {
    struct {
        unsigned int          DX_ADDR : 7;
        unsigned int      DX_ADDR_REL : 1;
        unsigned int       DX_SWIZ_C0 : 2;
        unsigned int       DX_SWIZ_C1 : 2;
        unsigned int       DX_SWIZ_C2 : 2;
        unsigned int       DX_SWIZ_C3 : 2;
        unsigned int          DY_ADDR : 7;
        unsigned int      DY_ADDR_REL : 1;
        unsigned int       DY_SWIZ_C0 : 2;
        unsigned int       DY_SWIZ_C1 : 2;
        unsigned int       DY_SWIZ_C2 : 2;
        unsigned int       DY_SWIZ_C3 : 2;
    } bits;
    unsigned int u32;
} AMU_ISA_INP_DWORD_3;

typedef union _AMU_ISA_INP_DWORD_4 {
    struct {
        unsigned int         RESERVED : 32;
    } bits;
    unsigned int u32;
} AMU_ISA_INP_DWORD_4;

typedef union _AMU_ISA_INP_DWORD_5 {
    struct {
        unsigned int         RESERVED : 32;
    } bits;
    unsigned int u32;
} AMU_ISA_INP_DWORD_5;

typedef struct
{
    AMU_ISA_INP_DWORD_0 inp0;
    AMU_ISA_INP_DWORD_1 inp1;
    AMU_ISA_INP_DWORD_2 inp2;
    AMU_ISA_INP_DWORD_3 inp3;
    AMU_ISA_INP_DWORD_4 inp4;
    AMU_ISA_INP_DWORD_5 inp5;
} AMUisaInpBin;

//
//  data types for flow control instructions
//
typedef enum _AMUisaFldFlwBool {
    AMU_ISA_FLD_FLW_FALSE              = 0x0,
    AMU_ISA_FLD_FLW_TRUE               = 0x1,
} AMUisaFldFlwBool;

typedef enum _AMUisaFldFlwOp {
    AMU_ISA_FLD_FLW_OP_JUMP            = 0x0,
    AMU_ISA_FLD_FLW_OP_LOOP            = 0x1,
    AMU_ISA_FLD_FLW_OP_ENDLOOP         = 0x2,
    AMU_ISA_FLD_FLW_OP_REP             = 0x3,
    AMU_ISA_FLD_FLW_OP_ENDREP          = 0x4,
    AMU_ISA_FLD_FLW_OP_BREAKLOOP       = 0x5,
    AMU_ISA_FLD_FLW_OP_BREAKREP        = 0x6,
    AMU_ISA_FLD_FLW_OP_CONTINUE        = 0x7,
} AMUisaFldFlwOp;

typedef enum _AMUisaFldFlwAOp {
    AMU_ISA_FLD_FLW_A_OP_NONE          = 0x0,
    AMU_ISA_FLD_FLW_A_OP_POP           = 0x1,
    AMU_ISA_FLD_FLW_A_OP_PUSH          = 0x2,
} AMUisaFldFlwAOp;

typedef enum _AMUisaFldFlwBOp {
    AMU_ISA_FLD_FLW_B_OP_NONE          = 0x0,
    AMU_ISA_FLD_FLW_B_OP_DECR          = 0x1,
    AMU_ISA_FLD_FLW_B_OP_INCR          = 0x2,
} AMUisaFldFlwBOp;

typedef enum _AMUisaFldFlwSIMD {
    AMU_ISA_FLD_FLW_JUMP_ALL           = 0x0,
    AMU_ISA_FLD_FLW_JUMP_ANY           = 0x1,
} AMUisaFldFlwSIMD;

typedef unsigned int AMUisaFldPopCnt;
typedef unsigned int AMUisaFldJumpFunc;

typedef union _AMU_ISA_FLW_DWORD_0 {
    struct {
        unsigned int             TYPE : 2;
        unsigned int     INP_SEM_WAIT : 1;
        unsigned int         PRED_SEL : 3;
        unsigned int         PRED_INV : 1;
        unsigned int                  : 3;
        unsigned int         ALU_WAIT : 1;
        unsigned int                  : 21;
    } bits;
    unsigned int u32;
} AMU_ISA_FLW_DWORD_0;

typedef union _AMU_ISA_FLW_DWORD_1 {
    struct {
        unsigned int         RESERVED : 32;
    } bits;
    unsigned int u32;
} AMU_ISA_FLW_DWORD_1;

typedef union _AMU_ISA_FLW_DWORD_2 {
    struct {
        unsigned int               OP : 3;
        unsigned int                  : 1;
        unsigned int           B_ELSE : 1;
        unsigned int         JUMP_ANY : 1;
        unsigned int             A_OP : 2;
        unsigned int        JUMP_FUNC : 8;
        unsigned int        B_POP_CNT : 5;
        unsigned int                  : 3;
        unsigned int            B_OP0 : 2;
        unsigned int            B_OP1 : 2;
        unsigned int IGNORE_UNCOVERED : 1;
        unsigned int                  : 3;
    } bits;
    unsigned int u32;
} AMU_ISA_FLW_DWORD_2;

typedef union _AMU_ISA_FLW_DWORD_3 {
    struct {
        unsigned int        BOOL_ADDR : 5;
        unsigned int                  : 3;
        unsigned int         INT_ADDR : 5;
        unsigned int                  : 3;
        unsigned int        JUMP_ADDR : 9;
        unsigned int                  : 6;
        unsigned int      JUMP_GLOBAL : 1;
    } bits;
    unsigned int u32;
} AMU_ISA_FLW_DWORD_3;

typedef union _AMU_ISA_FLW_DWORD_4 {
    struct {
        unsigned int         RESERVED : 32;
    } bits;
    unsigned int u32;
} AMU_ISA_FLW_DWORD_4;

typedef union _AMU_ISA_FLW_DWORD_5 {
    struct {
        unsigned int         RESERVED : 32;
    } bits;
    unsigned int u32;
} AMU_ISA_FLW_DWORD_5;

typedef struct
{
    AMU_ISA_FLW_DWORD_0 flw0;
    AMU_ISA_FLW_DWORD_1 flw1;
    AMU_ISA_FLW_DWORD_2 flw2;
    AMU_ISA_FLW_DWORD_3 flw3;
    AMU_ISA_FLW_DWORD_4 flw4;
    AMU_ISA_FLW_DWORD_5 flw5;
} AMUisaFlwBin;

//
//  data types for alu and out instructions
//
typedef enum _AMUisaFldAluBool {
    AMU_ISA_FLD_ALU_FALSE                   = 0x0,
    AMU_ISA_FLD_ALU_TRUE                    = 0x1,
} AMUisaFldAluBool;

typedef enum _AMUisaFldAluResultOp {
    AMU_ISA_FLD_ALU_RESULT_OP_EQUAL         = 0x0,
    AMU_ISA_FLD_ALU_RESULT_OP_LESS          = 0x1,
    AMU_ISA_FLD_ALU_RESULT_OP_GREATER_EQUAL = 0x2,
    AMU_ISA_FLD_ALU_RESULT_OP_NOT_EQUAL     = 0x3,
} AMUisaFldAluResultOp;

typedef enum _AMUisaFldAluResultSel {
    AMU_ISA_FLD_ALU_RESULT_SEL_C0           = 0x0,
    AMU_ISA_FLD_ALU_RESULT_SEL_C3           = 0x1,
} AMUisaFldAluResultSel;

typedef enum _AMUisaFldAluVectorOp {
    AMU_ISA_FLD_ALU_VEC_OP_MAD              = 0x0,
    AMU_ISA_FLD_ALU_VEC_OP_DP3              = 0x1,
    AMU_ISA_FLD_ALU_VEC_OP_DP4              = 0x2,
    AMU_ISA_FLD_ALU_VEC_OP_D2A              = 0x3,
    AMU_ISA_FLD_ALU_VEC_OP_MIN              = 0x4,
    AMU_ISA_FLD_ALU_VEC_OP_MAX              = 0x5,
    AMU_ISA_FLD_ALU_VEC_OP_CND              = 0x7,
    AMU_ISA_FLD_ALU_VEC_OP_CMP              = 0x8,
    AMU_ISA_FLD_ALU_VEC_OP_FRC              = 0x9,
    AMU_ISA_FLD_ALU_VEC_OP_SOP              = 0xa,
    AMU_ISA_FLD_ALU_VEC_OP_MDH              = 0xb,
    AMU_ISA_FLD_ALU_VEC_OP_MDV              = 0xc,
} AMUisaFldAluVectorOp;

typedef enum _AMUisaFldAluScalarOp {
    AMU_ISA_FLD_ALU_SCL_OP_MAD              = 0x0,
    AMU_ISA_FLD_ALU_SCL_OP_VDP              = 0x1,
    AMU_ISA_FLD_ALU_SCL_OP_MIN              = 0x2,
    AMU_ISA_FLD_ALU_SCL_OP_MAX              = 0x3,
    AMU_ISA_FLD_ALU_SCL_OP_CND              = 0x5,
    AMU_ISA_FLD_ALU_SCL_OP_CMP              = 0x6,
    AMU_ISA_FLD_ALU_SCL_OP_FRC              = 0x7,
    AMU_ISA_FLD_ALU_SCL_OP_EX2              = 0x8,
    AMU_ISA_FLD_ALU_SCL_OP_LN2              = 0x9,
    AMU_ISA_FLD_ALU_SCL_OP_RCP              = 0xa,
    AMU_ISA_FLD_ALU_SCL_OP_RSQ              = 0xb,
    AMU_ISA_FLD_ALU_SCL_OP_SIN              = 0xc,
    AMU_ISA_FLD_ALU_SCL_OP_COS              = 0xd,
    AMU_ISA_FLD_ALU_SCL_OP_MDH              = 0xe,
    AMU_ISA_FLD_ALU_SCL_OP_MDV              = 0xf,
} AMUisaFldAluScalarOp;

typedef enum _AMUisaFldAluOmod {
    AMU_ISA_FLD_ALU_OMOD_U1                 = 0x0,
    AMU_ISA_FLD_ALU_OMOD_U2                 = 0x1,
    AMU_ISA_FLD_ALU_OMOD_U4                 = 0x2,
    AMU_ISA_FLD_ALU_OMOD_U8                 = 0x3,
    AMU_ISA_FLD_ALU_OMOD_D2                 = 0x4,
    AMU_ISA_FLD_ALU_OMOD_D4                 = 0x5,
    AMU_ISA_FLD_ALU_OMOD_D8                 = 0x6,
    AMU_ISA_FLD_ALU_OMOD_DISABLED           = 0x7,
} AMUisaFldAluOmod;

typedef enum _AMUisaFldAluRegType {
    AMU_ISA_FLD_ALU_REG_TYPE_REG            = 0x0,
    AMU_ISA_FLD_ALU_REG_TYPE_CONST          = 0x1,
    AMU_ISA_FLD_ALU_REG_TYPE_INLINE         = AMU_ISA_FLD_ALU_REG_TYPE_REG,
} AMUisaFldAluRegType;

typedef enum _AMUisaFldAluSrcSel {
    AMU_ISA_FLD_ALU_SRC_SEL_0               = 0x0,
    AMU_ISA_FLD_ALU_SRC_SEL_1               = 0x1,
    AMU_ISA_FLD_ALU_SRC_SEL_2               = 0x2,
    AMU_ISA_FLD_ALU_SRC_SEL_P               = 0x3,
} AMUisaFldAluSrcSel;

typedef enum _AMUisaFldAluSwizzle {
    AMU_ISA_FLD_ALU_SWIZZLE_C0              = 0x0,
    AMU_ISA_FLD_ALU_SWIZZLE_C1              = 0x1,
    AMU_ISA_FLD_ALU_SWIZZLE_C2              = 0x2,
    AMU_ISA_FLD_ALU_SWIZZLE_C3              = 0x3,
    AMU_ISA_FLD_ALU_SWIZZLE_0               = 0x4,
    AMU_ISA_FLD_ALU_SWIZZLE_0_5             = 0x5,
    AMU_ISA_FLD_ALU_SWIZZLE_1               = 0x6,
} AMUisaFldAluSwizzle;

typedef enum _AMUisaFldAluImod {
    AMU_ISA_FLD_ALU_IMOD_OFF                = 0x0,
    AMU_ISA_FLD_ALU_IMOD_NEG                = 0x1,
    AMU_ISA_FLD_ALU_IMOD_ABS                = 0x2,
    AMU_ISA_FLD_ALU_IMOD_NAB                = 0x3,
} AMUisaFldAluImod;

typedef enum _AMUisaFldAluSrcpOp {
    AMU_ISA_FLD_ALU_SRCP_OP_BIAS            = 0x0,
    AMU_ISA_FLD_ALU_SRCP_OP_SUB             = 0x1,
    AMU_ISA_FLD_ALU_SRCP_OP_ADD             = 0x2,
    AMU_ISA_FLD_ALU_SRCP_OP_INV             = 0x3,
} AMUisaFldAluSrcpOp;

typedef enum _AMUisaFldAluPredOp {
    AMU_ISA_FLD_ALU_PRED_OP_EQUAL           = 0x0,
    AMU_ISA_FLD_ALU_PRED_OP_LESS            = 0x1,
    AMU_ISA_FLD_ALU_PRED_OP_GREATER_EQUAL   = 0x2,
    AMU_ISA_FLD_ALU_PRED_OP_NOT_EQUAL       = 0x3,
} AMUisaFldAluPredOp;

typedef enum _AMUisaFldAluTarget {
    AMU_ISA_FLD_ALU_OUT_O0                  = 0x0,
    AMU_ISA_FLD_ALU_OUT_O1                  = 0x1,
    AMU_ISA_FLD_ALU_OUT_O2                  = 0x2,
    AMU_ISA_FLD_ALU_OUT_O3                  = 0x3,
    AMU_ISA_FLD_ALU_SCT_PER_QUAD_IDX                  = 0x0,
    AMU_ISA_FLD_ALU_SCT_PER_QUAD_IDX_INP_SEM_ACQUIRE  = 0x1,
    AMU_ISA_FLD_ALU_SCT_PER_PIXEL_IDX                 = 0x2,
    AMU_ISA_FLD_ALU_SCT_PER_PIXEL_IDX_INP_SEM_ACQUIRE = 0x3,
} AMUisaFldAluTarget;

typedef union _AMU_ISA_ALU_DWORD_0 {
    struct {
        unsigned int            TYPE : 2;
        unsigned int    INP_SEM_WAIT : 1;
        unsigned int    VEC_PRED_SEL : 3;
        unsigned int    VEC_PRED_INV : 1;
        unsigned int  WRITE_INACTIVE : 1;
        unsigned int            LAST : 1;
        unsigned int             NOP : 1;
        unsigned int                 : 1;
        unsigned int       VEC_WMASK : 3;
        unsigned int       SCL_WMASK : 1;
        unsigned int       VEC_OMASK : 3;
        unsigned int       SCL_OMASK : 1;
        unsigned int       VEC_CLAMP : 1;
        unsigned int       SCL_CLAMP : 1;
        unsigned int  ALU_RESULT_SEL : 1;
        unsigned int    SCL_PRED_INV : 1;
        unsigned int   ALU_RESULT_OP : 2;
        unsigned int    SCL_PRED_SEL : 3;
        unsigned int                 : 4;
    } bits;
    unsigned int u32;
} AMU_ISA_ALU_DWORD_0;

typedef union _AMU_ISA_ALU_DWORD_1 {
    struct {
        unsigned int       VEC_ADDR0 : 8;
        unsigned int VEC_ADDR0_CONST : 1;
        unsigned int   VEC_ADDR0_REL : 1;
        unsigned int       VEC_ADDR1 : 8;
        unsigned int VEC_ADDR1_CONST : 1;
        unsigned int   VEC_ADDR1_REL : 1;
        unsigned int       VEC_ADDR2 : 8;
        unsigned int VEC_ADDR2_CONST : 1;
        unsigned int   VEC_ADDR2_REL : 1;
        unsigned int     VEC_SRCP_OP : 2;
    } bits;
    unsigned int u32;
} AMU_ISA_ALU_DWORD_1;

typedef union _AMU_ISA_ALU_DWORD_2 {
    struct {
        unsigned int       SCL_ADDR0 : 8;
        unsigned int SCL_ADDR0_CONST : 1;
        unsigned int   SCL_ADDR0_REL : 1;
        unsigned int       SCL_ADDR1 : 8;
        unsigned int SCL_ADDR1_CONST : 1;
        unsigned int   SCL_ADDR1_REL : 1;
        unsigned int       SCL_ADDR2 : 8;
        unsigned int SCL_ADDR2_CONST : 1;
        unsigned int   SCL_ADDR2_REL : 1;
        unsigned int     SCL_SRCP_OP : 2;
    } bits;
    unsigned int u32;
} AMU_ISA_ALU_DWORD_2;

typedef union _AMU_ISA_ALU_DWORD_3 {
    struct {
        unsigned int       VEC_SEL_A : 2;
        unsigned int   VEC_SWIZ_C0_A : 3;
        unsigned int   VEC_SWIZ_C1_A : 3;
        unsigned int   VEC_SWIZ_C2_A : 3;
        unsigned int      VEC_IMOD_A : 2;
        unsigned int       VEC_SEL_B : 2;
        unsigned int   VEC_SWIZ_C0_B : 3;
        unsigned int   VEC_SWIZ_C1_B : 3;
        unsigned int   VEC_SWIZ_C2_B : 3;
        unsigned int      VEC_IMOD_B : 2;
        unsigned int        VEC_OMOD : 3;
        unsigned int      VEC_TARGET : 2;
        unsigned int       ALU_WMASK : 1;
    } bits;
    unsigned int u32;
} AMU_ISA_ALU_DWORD_3;

typedef union _AMU_ISA_ALU_DWORD_4 {
    struct {
        unsigned int          SCL_OP : 4;
        unsigned int       SCL_ADDRD : 7;
        unsigned int   SCL_ADDRD_REL : 1;
        unsigned int       SCL_SEL_A : 2;
        unsigned int      SCL_SWIZ_A : 3;
        unsigned int      SCL_IMOD_A : 2;
        unsigned int       SCL_SEL_B : 2;
        unsigned int      SCL_SWIZ_B : 3;
        unsigned int      SCL_IMOD_B : 2;
        unsigned int        SCL_OMOD : 3;
        unsigned int      SCL_TARGET : 2;
        unsigned int     SCL_OMASK_W : 1;
    } bits;
    unsigned int u32;
} AMU_ISA_ALU_DWORD_4;

typedef union _AMU_ISA_ALU_DWORD_5 {
    struct {
        unsigned int          VEC_OP : 4;
        unsigned int       VEC_ADDRD : 7;
        unsigned int   VEC_ADDRD_REL : 1;
        unsigned int       VEC_SEL_C : 2;
        unsigned int   VEC_SWIZ_C0_C : 3;
        unsigned int   VEC_SWIZ_C1_C : 3;
        unsigned int   VEC_SWIZ_C2_C : 3;
        unsigned int      VEC_IMOD_C : 2;
        unsigned int       SCL_SEL_C : 2;
        unsigned int      SCL_SWIZ_C : 3;
        unsigned int      SCL_IMOD_C : 2;
    } bits;
    unsigned int u32;
} AMU_ISA_ALU_DWORD_5;

typedef struct
{
    AMU_ISA_ALU_DWORD_0 alu0;
    AMU_ISA_ALU_DWORD_1 alu1;
    AMU_ISA_ALU_DWORD_2 alu2;
    AMU_ISA_ALU_DWORD_3 alu3;
    AMU_ISA_ALU_DWORD_4 alu4;
    AMU_ISA_ALU_DWORD_5 alu5;
} AMUisaAluBin;

typedef struct
{
    AMU_ISA_ALU_DWORD_0 out0;
    AMU_ISA_ALU_DWORD_1 out1;
    AMU_ISA_ALU_DWORD_2 out2;
    AMU_ISA_ALU_DWORD_3 out3;
    AMU_ISA_ALU_DWORD_4 out4;
    AMU_ISA_ALU_DWORD_5 out5;
} AMUisaOutBin;

//
//  data types for raw binary instructions
//
typedef union _AMU_ISA_RAW_DWORD_0 {
    struct {
        unsigned int     TYPE :  2;
        unsigned int RESERVED : 30;
    } bits;
    unsigned int u32;
} AMU_ISA_RAW_DWORD_0;

typedef union _AMU_ISA_RAW_DWORD_1 {
    struct {
        unsigned int RESERVED : 32;
    } bits;
    unsigned int u32;
} AMU_ISA_RAW_DWORD_1;

typedef union _AMU_ISA_RAW_DWORD_2 {
    struct {
        unsigned int RESERVED : 32;
    } bits;
    unsigned int u32;
} AMU_ISA_RAW_DWORD_2;

typedef union _AMU_ISA_RAW_DWORD_3 {
    struct {
        unsigned int RESERVED : 32;
    } bits;
    unsigned int u32;
} AMU_ISA_RAW_DWORD_3;

typedef union _AMU_ISA_RAW_DWORD_4 {
    struct {
        unsigned int RESERVED : 32;
    } bits;
    unsigned int u32;
} AMU_ISA_RAW_DWORD_4;

typedef union _AMU_ISA_RAW_DWORD_5 {
    struct {
        unsigned int RESERVED : 32;
    } bits;
    unsigned int u32;
} AMU_ISA_RAW_DWORD_5;

typedef struct
{
    AMU_ISA_RAW_DWORD_0 raw0;
    AMU_ISA_RAW_DWORD_1 raw1;
    AMU_ISA_RAW_DWORD_2 raw2;
    AMU_ISA_RAW_DWORD_3 raw3;
    AMU_ISA_RAW_DWORD_4 raw4;
    AMU_ISA_RAW_DWORD_5 raw5;
} AMUisaRawBin;

//
//  union of all possible instruction formats
//
typedef union
{
    AMUisaRawBin raw;
    AMUisaAluBin alu;
    AMUisaOutBin out;
    AMUisaInpBin inp;
    AMUisaFlwBin flw;
} AMUisaInstBin;

#endif // _AMU_ISA_BIN_H_
