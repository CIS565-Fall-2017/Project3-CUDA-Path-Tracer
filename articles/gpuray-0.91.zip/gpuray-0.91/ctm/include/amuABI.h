//
//  Copyright (c) 2006, ATI Technologies Inc.
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions
//  are met:
//
//  Redistributions of source code must retain the above copyright
//  notice, this list of conditions and the following disclaimer.
//
//  Redistributions in binary form must reproduce the above copyright
//  notice, this list of conditions and the following disclaimer in the
//  documentation and/or other materials provided with the distribution.
//
//  Neither the name of ATI Technologies Inc., nor the names of its
//  affiliates, subsidiaries or contributors may be used to endorse or
//  promote products derived from this software without specific prior
//  written permission.
//
//  THIS SOFTWARE IS PROVIDED BY ATI TECHNOLOGIES INC., ITS AFFILIATES,
//  SUBSIDIARIES AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
//  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
//  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
//  IN NO EVENT SHALL ATI TECHNOLOGIES INC., ITS AFFILIATES, SUBSIDIARIES
//  OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
//  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
//  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
//  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
//  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
//  SUCH DAMAGE.
//
//  Under no circumstances will the license grant above be construed as
//  granting, by implication, estoppel or otherwise, a license to any
//  technology belonging to ATI Technologies Inc. other than a copyright
//  license to this software.  For greater certainty this license does not
//  convey any rights, by implication, estoppel or otherwise, under or to
//  any patents or pending applications belonging to ATI Technologies Inc.
//  All rights not expressly granted herein are expressly reserved by ATI
//  Technologies Inc.
//

#ifndef _AMU_ABI_H_
#define _AMU_ABI_H_

///
///  @file  amuABI.h
///  @brief Interfaces Exported by ATI ABI Utility Library
///
#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

//
//  ELF Specific Definitions
//
#define ELFOSABI_ATI               98
#define EM_ATI_R5XX                122
#define EF_ATI_FRAGMENT            1

#define ELF_NOTE_ATI               "ATI DPP"
#define ELF_NOTE_ATI_PROGINFO      1
#define ELF_NOTE_ATI_INPUTS        2
#define ELF_NOTE_ATI_OUTPUTS       3
#define ELF_NOTE_ATI_CONDOUT       4
#define ELF_NOTE_ATI_FLOAT32CONSTS 5
#define ELF_NOTE_ATI_INT32CONSTS   6
#define ELF_NOTE_ATI_BOOL32CONSTS  7
#define ELF_NOTE_ATI_EARLYEXIT     8

#define ELF_STT_ATI_LOPROC         13
#define ELF_STB_ATI_LOCAL          0
#define ELF_STB_ATI_GLOBAL         1
#define ELF_ST_ATI_INFO(bind, type)   (((bind) << 4) + ((type) & 0xf))

#define ELF_SYM_ATI_FLOAT32        ELF_ST_ATI_INFO(ELF_STB_ATI_GLOBAL, (ELF_STT_ATI_LOPROC+0))
#define ELF_SYM_ATI_INT32          ELF_ST_ATI_INFO(ELF_STB_ATI_GLOBAL, (ELF_STT_ATI_LOPROC+1))
#define ELF_SYM_ATI_BOOL32         ELF_ST_ATI_INFO(ELF_STB_ATI_GLOBAL, (ELF_STT_ATI_LOPROC+2))
#define ELF_SYM_ATI_SAMPLER        ELF_ST_ATI_INFO(ELF_STB_ATI_GLOBAL, (ELF_STT_ATI_LOPROC+3))


//
///  ABI Fixed Sizes for Extract Interface
//
const unsigned int AMUabiMaxUserConsts = 256;        ///< maximum number of user constants
const unsigned int AMUabiMaxLiteralConsts = 256;     ///< maximum number of literal constants
const unsigned int AMUabiMaxSamplerNames = 16;       ///< maximum number of user samplers
const unsigned int AMUabiMaxFixedStringLength = 256; ///< maximum length of constant or sampler names

//
///  ABI Datatypes For Constants
//
enum AMUabiDataType {
    AMU_ABI_UNDEF,                  ///< undefined
    AMU_ABI_BOOL32,                 ///< 32bit boolean (stored as unsigned int)
    AMU_ABI_INT32,                  ///< 32bit integer
    AMU_ABI_FLOAT32,                ///< 32bit floating point
    AMU_ABI_SAMPLER,                ///< sampler
    AMU_ABI_MAXTYPES = 255          ///< number of datatypes
};

//
///  ABI Program Info
//
typedef struct AMUabiProgInfoRec
{
    unsigned int RESERVED_00;
    unsigned int FG_DEPTH_SRC;
    unsigned int US_CONFIG_FUDO;
    unsigned int US_PIXSIZE_FUDO;
    unsigned int US_FC_CTRL;
    unsigned int US_CODE_ADDR;
    unsigned int US_CODE_RANGE;
    unsigned int RESERVED_07;
    unsigned int RESERVED_08;
    unsigned int RESERVED_09;
    unsigned int RESERVED_10;
    unsigned int RESERVED_11;
    unsigned int RESERVED_12;
    unsigned int RESERVED_13;
    unsigned int RESERVED_14;
    unsigned int RESERVED_15;
    unsigned int RESERVED_16;
    unsigned int RESERVED_17;
    unsigned int RESERVED_18;
    unsigned int RESERVED_19;
    unsigned int RESERVED_20;
    unsigned int RESERVED_21;
    unsigned int RESERVED_22;
    unsigned int RESERVED_23;
    unsigned int RESERVED_24;
}
AMUabiProgInfo;


//
///  ABI Program Info Note Section
//
typedef struct AMUabiProgInfoNoteRec
{
    unsigned int namesz;
    unsigned int descsz;
    unsigned int type;
    char name[ 8 ];
    AMUabiProgInfo progInfo[ 1 ];
}
AMUabiProgInfoNote;

//
///  ABI Inputs Note Section
//
typedef struct AMUabiInputsNoteRec
{
    unsigned int namesz;
    unsigned int descsz;
    unsigned int type;
    char name[ 8 ];
    unsigned int inputs[ 1 ];
}
AMUabiInputsNote;

//
///  ABI Outputs Note Section
//
typedef struct AMUabiOutputsNoteRec
{
    unsigned int namesz;
    unsigned int descsz;
    unsigned int type;
    char name[ 8 ];
    unsigned int outputs[ 1 ];
}
AMUabiOutputsNote;

//
///  ABI Conditional Outputs Note Section
//
typedef struct AMUabiCondOutNoteRec
{
    unsigned int namesz;
    unsigned int descsz;
    unsigned int type;
    char name[ 8 ];
    unsigned int condOut;
}
AMUabiCondOutNote;

//
///  ABI Float32 Constants Note Section
//
typedef struct AMUabiFloat32ConstsNoteRec
{
    unsigned int namesz;
    unsigned int descsz;
    unsigned int type;
    char name[ 8 ];
    unsigned int float32Consts[ 1 ];
}
AMUabiFloat32ConstsNote;

//
///  ABI Int32 Contants Note Section
//
typedef struct AMUabiInt32ConstsNoteRec
{
    unsigned int namesz;
    unsigned int descsz;
    unsigned int type;
    char name[ 8 ];
    unsigned int int32Consts[ 1 ];
}
AMUabiInt32ConstsNote;

//
///  ABI Bool32 Contants Note Section
//
typedef struct AMUabiBool32ConstsNoteRec
{
    unsigned int namesz;
    unsigned int descsz;
    unsigned int type;
    char name[ 8 ];
    unsigned int bool32Consts[ 1 ];
}
AMUabiBool32ConstsNote;

//
///  ABI Constants Data Section
//
typedef struct AMUabiConstsDataRec
{
    float float32[ 256 * 4 ];
    unsigned int int32[ 32 * 4 ];
    unsigned int bool32[ 32 ];
}
AMUabiConstsData;

//
///  ABI Early Exit Note Section
//
typedef struct AMUabiEarlyExitNoteRec
{
    unsigned int namesz;
    unsigned int descsz;
    unsigned int type;
    char name[ 8 ];
    unsigned int earlyExit;
}
AMUabiEarlyExitNote;

//
///  ABI Symbol Table Entry
//
typedef struct AMUabiSymbolRec
{
    unsigned int name;
    unsigned int value;
    unsigned int size;
    unsigned char info;
    unsigned char other ;
    unsigned char section;
}
AMUabiSymbol;

//
///  ABI Fixed Length String
//
typedef struct AMUabiFixedStringRec
{
    char str[ AMUabiMaxFixedStringLength ]; ///< fixed length NULL-terminated string
}
AMUabiFixedString;

//
///  ABI Constant Value Storage
//
typedef union AMUabiDataValueRec {
    float float32[ 4 ];
    unsigned int int32[ 4 ];
    unsigned int bool32[ 1 ];
} AMUabiDataValue;

//
///  ABI Literal Constant
//
typedef struct AMUabiLiteralConstRec
{
    unsigned int addr;
    AMUabiDataType type;
    AMUabiDataValue value;
}
AMUabiLiteralConst;

//
///  ABI User Constant
//
typedef struct AMUabiUserConstRec
{
    unsigned int addr;
    AMUabiDataType type;
    AMUabiFixedString name;
}
AMUabiUserConst;

//
/// ABI Constants Info Struct for Extraction Interface
//
typedef struct AMUabiConstsInfoRec
{

    unsigned int litConstsCount;                              ///< number of literal constants
    AMUabiLiteralConst litConsts[ AMUabiMaxLiteralConsts ];   ///< literal constants

    unsigned int userConstsCount;                             ///< number of user constants
    AMUabiUserConst userConsts[ AMUabiMaxUserConsts ];        ///< user constants
}
AMUabiConstsInfo;

//
/// ABI ELF Info Struct for Extraction Interface
//
typedef struct AMUabiElfInfoRec
{
    AMUabiProgInfoNote* progInfoNote;                       ///< program info note
    AMUabiInputsNote* inputsNote;                           ///< inputs note
    AMUabiOutputsNote* outputsNote;                         ///< outputs note
    AMUabiCondOutNote* condOutNote;                         ///< conditional output note
    AMUabiEarlyExitNote* earlyExitNote;                     ///< early exit note
    AMUabiFloat32ConstsNote* float32ConstsNote;             ///< float32 constants note
    AMUabiInt32ConstsNote* int32ConstsNote;                 ///< int32 constants note
    AMUabiBool32ConstsNote* bool32ConstsNote;               ///< bool32 constants note
    char* text;                                             ///< text section (program instructions)
    unsigned int textSize;                                  ///< size of text section (in bytes)
    AMUabiConstsData* constsData;                           ///< constants data section
    AMUabiSymbol* symtab;                                   ///< symbol table section
    unsigned int symtabSize;                                ///< size of symbol table section (in bytes)
    char* strtab;                                           ///< string table section
    unsigned int strtabSize;                                ///< size of string table section (in bytes)
}
AMUabiElfInfo;

///
///  @fn amuABICreateExecutable(
///        unsigned int inputCount, const unsigned int* inputs,
///        unsigned int outputCount, const unsigned int* outputs,
///        unsigned int condOut, unsigned int earlyExit,
///        unsigned int userConstsCount, AMUabiUserConst* userConsts,
///        unsigned int litConstsCount, AMUabiLiteralConst* litConsts,
///        AMUabiProgInfo progInfo, unsigned int textSize, const void* textData,
///        unsigned int* binarySize, void** binaryData  )
///
///  @brief Create an ATI CTM ABI binary executable from the given program data.
///
///  This function creates a binary program executable in the ATI CTM ABI format
///  by packing the given data into the appropriate binary representation.
///
///  It takes a list of inputs, outputs, constants and usage flags, as well
///  as the ISA header, and program instructions and returns a binary program
///  encoded in the ATI CTM ABI format.
///
///  This method allocates memory internally for the binary executable.  It
///  is necessary to free this dynamically allocated memory, otherwise a memory
///  leak will occur.
///
///  @param inputCount      (in)  Number of inputs referenced in the program
///  @param inputs          (in)  List of inputs referenced in the program
///  @param outputCount     (in)  Number of outputs referenced in the program
///  @param outputs         (in)  List of outputs referenced in the program
///  @param condOut         (in)  Usage flag for conditional output (1 = enabled, 0 = disabled)
///  @param earlyExit       (in)  Usage flag for early exit (1 = enabled, 0 = disabled)
///  @param userConstsCount (in)  Number of user constants referenced in the program
///  @param userConsts      (in)  List of user constants referenced in the program
///  @param litConstsCount  (in)  Number of literal constants referenced in the program
///  @param litConsts       (in)  List of literal constants referenced in the program
///  @param progInfo        (in)  Program info header in ISA format
///  @param textSize        (in)  Size of the ISA program text (executable instructions) in bytes.
///  @param textData        (in)  Pointer to the ISA program text (executable instructions)
///  @param binarySize      (out) Size of binary executable being returned upon success, 0 upon failure.
///  @param binaryData      (out) Pointer to an ATI CTM ABI binary executable upon success; NULL upon failure.
///
///  @return Returns 1 upon success; 0 upon failure.
///
///  @sa amuABIExtractReferences, amuABIExtractConstants
///
extern unsigned int amuABICreateExecutable(
        unsigned int inputCount, const unsigned int* inputs,
        unsigned int outputCount, const unsigned int* outputs,
        unsigned int condOut, unsigned int earlyExit,
        unsigned int userConstsCount, AMUabiUserConst* userConsts,
        unsigned int litConstsCount, AMUabiLiteralConst* litConsts,
        AMUabiProgInfo progInfo, unsigned int textSize, const void* textData,
        unsigned int* binarySize, void** binaryData );

///
///  @fn amuABIExtractReferences(const void* binary)
///
///  @brief Extract references to each of the data sections contained in the given binary executable.
///
///  This function examines a given binary program executable in the
///  ATI CTM ABI format and returns a struct containing references pointing
///  to each of the various data sections contained in the binary program.
///
///  Note that the returned struct references the internals of the
///  given binary and does not copy any data.
///
///  @param binary  (in)  Pointer to an existing ATI CTM ABI binary executable.
///
///  @return Returns a populated AMUabiElfInfo struct upon success; an uninitialized struct upon failure.
///
///  @sa amuABICreateExecutable, amuABIExtractConstants
///
extern AMUabiElfInfo amuABIExtractReferences( const void* binary );

///
///  @fn amuABIExtractConstants(const void* binary)
///
///  @brief Extract symbols and constant data contained in the given binary executable.
///
///  This function examines a given binary program executable in the
///  ATI CTM ABI format and returns a struct containing symbols and data
///  for all of the specified literal and user constants contained
///  in the binary.
///
///  Note that the returned struct copies data, and does not reference
///  the internals of the given binary.
///
///  @param binary   (in)  Pointer to an existing ATI CTM ABI binary executable.
///
///  @return Returns a populated AMUabiConstsInfo struct upon success; an uninitialized struct upon failure.
///
///  @sa amuABIExtractReferences, amuABICreateExecutable
///
extern AMUabiConstsInfo amuABIExtractConstants( const void* binary );

///
///  @fn amuABISetLiteralConstants(
///         AMUabiConstsInfo compOutput,
///         void* floatConstAddressCPU,
///         void* intConstAddressCPU,
///         void* boolConstAddressCPU)
///
///  @brief Setup literal constants defined in the shader
///
///  This function examines a given binary program executable in the
///  ATI CTM ABI format and initializes the literal constants it contains
///  by setting the corresponding values in the given CTM allocated system
///  memory buffers.
///
///  @param compOutput (in) The constants extracted from the binary executable.
///
///  @param floatConstAddressCPU (in) The address for float constants.
///
///  @param intConstAddressCPU (in) The address for integer constants.
///
///  @param boolConstAddressCPU (in) The address for boolean constants.
///
///  @sa amuABIExtractConstants, amuABICreateExecutable, amuABISetUserConstant
///
extern void amuABISetLiteralConstants( AMUabiConstsInfo compOutput,
                                       void* floatConstAddressCPU,
                                       void* intConstAddressCPU,
                                       void* boolConstAddressCPU );

///
///  @fn amuABISetUserConstant(
///         AMUabiConstsInfo compOutput,
///         void* addressCPU,
///         const char* name,
///         const void* value,
///         AMUabiDataType type)
///
///  @brief Setup user defined constants in binary
///
///  This function examines a given binary program executable in the
///  ATI CTM ABI format and initializes a specific uniform constant
///  given by name as listed in the ELF symbol table, by setting
///  the corresponding values in the given CTM allocated system
///  memory buffers.
///
///  @param compOutput (in) The constants extracted from the binary executable.
///
///  @param addressCPU (in) The address for constants
///
///  @param name (in) The name of the constant as a string
///
///  @param value (in) The value to initialize the constant to
///
///  @param type (in) The datatype of the constant
///
///  @sa amuABIExtractConstants, amuABICreateExecutable, amuABISetLiteralConstants
///
extern void amuABISetUserConstant( AMUabiConstsInfo compOutput,
                                   void* addressCPU,
                                   const char* name,
                                   const void* value,
                                   AMUabiDataType type );

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // _AMU_ABI_H_
