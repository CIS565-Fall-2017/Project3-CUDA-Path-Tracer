//
//  Copyright (c) 2006, ATI Technologies Inc.
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions
//  are met:
//
//  Redistributions of source code must retain the above copyright
//  notice, this list of conditions and the following disclaimer.
//
//  Redistributions in binary form must reproduce the above copyright
//  notice, this list of conditions and the following disclaimer in the
//  documentation and/or other materials provided with the distribution.
//
//  Neither the name of ATI Technologies Inc., nor the names of its
//  affiliates, subsidiaries or contributors may be used to endorse or
//  promote products derived from this software without specific prior
//  written permission.
//
//  THIS SOFTWARE IS PROVIDED BY ATI TECHNOLOGIES INC., ITS AFFILIATES,
//  SUBSIDIARIES AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
//  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
//  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
//  IN NO EVENT SHALL ATI TECHNOLOGIES INC., ITS AFFILIATES, SUBSIDIARIES
//  OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
//  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
//  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
//  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
//  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
//  SUCH DAMAGE.
//
//  Under no circumstances will the license grant above be construed as
//  granting, by implication, estoppel or otherwise, a license to any
//  technology belonging to ATI Technologies Inc. other than a copyright
//  license to this software.  For greater certainty this license does not
//  convey any rights, by implication, estoppel or otherwise, under or to
//  any patents or pending applications belonging to ATI Technologies Inc.
//  All rights not expressly granted herein are expressly reserved by ATI
//  Technologies Inc.
//

#ifndef _AMU_ISA_INT_H_
#define _AMU_ISA_INT_H_

#include "amuISABin.h"

//
//  data types shared by multiple instructions
//
typedef struct _AMUisaReg {
    unsigned int      id;
    AMUisaFldBool     rel;
} AMUisaReg;

//
//  data types for input instructions
//
typedef struct _AMUisaInpEnv {
    AMUisaFldInpBool  inpWait;
    AMUisaFldInpBool  wrtInact;
    AMUisaFldInpBool  aluWait;
    AMUisaFldInpBool  acqSmph;
    AMUisaFldInpBool  ignUncv;
    AMUisaFldInpBool  unscaled;
} AMUisaInpEnv;

typedef struct _AMUisaInpPred {
    AMUisaFldPredSel  vsel;
    AMUisaFldInpBool  vinv;
    AMUisaFldPredSel  ssel;
    AMUisaFldInpBool  sinv;
} AMUisaInpPred;

typedef struct _AMUisaInpSwiz {
    AMUisaFldInpSwiz  c0;
    AMUisaFldInpSwiz  c1;
    AMUisaFldInpSwiz  c2;
    AMUisaFldInpSwiz  c3;
} AMUisaInpSwiz;

typedef struct _AMUisaInpDstMask {
    AMUisaFldInpBool  c0;
    AMUisaFldInpBool  c1;
    AMUisaFldInpBool  c2;
    AMUisaFldInpBool  c3;
} AMUisaInpDstMask;

typedef struct _AMUisaInpDst {
    AMUisaReg         reg;
    AMUisaInpDstMask  mask;
} AMUisaInpDst;

typedef struct _AMUisaInpSrc {
    AMUisaReg         reg;
    AMUisaInpSwiz     swiz;
} AMUisaInpSrc;

typedef struct _AMUisaInpSmp {
    AMUisaFldInpSmp   id;
    AMUisaInpSwiz     swiz;
} AMUisaInpSmp;

typedef struct _AMUisaInpInt {
    AMUisaInpEnv      env;
    AMUisaInpPred     pred;
    AMUisaFldInpOp    op;
    AMUisaInpDst      dst;
    AMUisaInpSrc      src;
    AMUisaInpSrc      tdx;
    AMUisaInpSrc      tdy;
    AMUisaInpSmp      smp;
} AMUisaInpInt;

//
//  data types for flow control instructions
//
typedef struct _AMUisaFlwInstAddr {
    unsigned int      addr;
} AMUisaFlwInstAddr;

typedef struct _AMUisaFlwBoolAddr {
    unsigned int      addr;
} AMUisaFlwBoolAddr;

typedef struct _AMUisaFlwIntAddr {
    unsigned int      addr;
} AMUisaFlwIntAddr;

typedef struct _AMUisaFlwPred {
    AMUisaFldPredSel  sel;
    AMUisaFldFlwBool  inv;
} AMUisaFlwPred;

typedef struct _AMUisaFlwEnv {
    AMUisaFldFlwBool  aluWait;
    AMUisaFldFlwBool  inpWait;
    AMUisaFldFlwBool  ignUncv;
} AMUisaFlwEnv;

typedef struct _AMUisaFlwJumpAddr {
    AMUisaFldFlwBool  global;
    AMUisaFlwInstAddr inst;
} AMUisaFlwJumpAddr;

typedef struct _AMUisaFlwFlags {
    AMUisaFldFlwAOp   addrOp;
    AMUisaFldFlwBOp   branchOp0;
    AMUisaFldFlwBOp   branchOp1;
    AMUisaFldFlwBool  elseOp;
    AMUisaFldPopCnt   popCnt;
    AMUisaFldFlwSIMD  simdOp;
    AMUisaFldJumpFunc jumpFunc;
} AMUisaFlwFlags;

typedef struct _AMUisaFlwInt {
    AMUisaFlwEnv      env;
    AMUisaFlwPred     pred;
    AMUisaFldFlwOp    op;
    AMUisaFlwJumpAddr jaddr;
    AMUisaFlwBoolAddr baddr;
    AMUisaFlwIntAddr  iaddr;
    AMUisaFlwFlags    flags;
} AMUisaFlwInt;

//
//  data types for alu and out instructions
//
typedef struct _AMUisaAluEnv {
    AMUisaFldAluBool      inpWait;
    AMUisaFldAluBool      wrtInact;
} AMUisaAluEnv;

typedef struct _AMUisaAluPred {
    AMUisaFldPredSel      sel;
    AMUisaFldAluBool      inv;
} AMUisaAluPred;

typedef struct _AMUisaAluSrcEl {
    AMUisaFldAluRegType   type;
    AMUisaReg             reg;
} AMUisaAluSrcEl;

typedef struct _AMUisaAluSrcs {
    AMUisaAluSrcEl        src0;
    AMUisaAluSrcEl        src1;
    AMUisaAluSrcEl        src2;
    AMUisaFldAluSrcpOp    preOp;
} AMUisaAluSrcs;

typedef struct _AMUisaAluAluOp {
    AMUisaFldAluBool      mask;
    AMUisaFldAluResultSel sel;
    AMUisaFldAluResultOp  op;
} AMUisaAluAluOp;

typedef struct _AMUisaAluOMod {
    AMUisaFldAluBool      clamp;
    AMUisaFldAluOmod      omod;
} AMUisaAluOMod;

typedef struct _AMUisaAluVecMask {
    AMUisaFldAluBool      c0;
    AMUisaFldAluBool      c1;
    AMUisaFldAluBool      c2;
} AMUisaAluVecMask;

typedef struct _AMUisaAluVecDst {
    AMUisaReg             reg;
    AMUisaAluVecMask      mask;
} AMUisaAluVecDst;

typedef struct _AMUisaAluVecOut {
    AMUisaFldAluTarget    target;
    AMUisaAluVecMask      mask;
} AMUisaAluVecOut;

typedef struct _AMUisaAluVecPredOut {
    AMUisaFldAluPredOp    op;
    AMUisaAluVecMask      mask;
} AMUisaAluVecPredOut;

typedef struct _AMUisaAluVecSwiz {
    AMUisaFldAluSwizzle   c0;
    AMUisaFldAluSwizzle   c1;
    AMUisaFldAluSwizzle   c2;
} AMUisaAluVecSwiz;

typedef struct _AMUisaAluVecArg {
    AMUisaFldAluSrcSel    sel;
    AMUisaAluVecSwiz      swiz;
    AMUisaFldAluImod      mod;
} AMUisaAluVecArg;

typedef struct _AMUisaAluVecArgs {
    AMUisaAluSrcs         src;
    AMUisaAluVecArg       arg0;
    AMUisaAluVecArg       arg1;
    AMUisaAluVecArg       arg2;
} AMUisaAluVecArgs;

typedef struct _AMUisaAluVecOpAlu {
    AMUisaAluPred         pred;
    AMUisaFldAluVectorOp  op;
    AMUisaAluOMod         mod;
    AMUisaAluVecDst       dst;
    AMUisaAluVecPredOut   predout;
    AMUisaAluVecArgs      vargs;
} AMUisaAluVecOpAlu;

typedef struct _AMUisaAluVecOpOut {
    AMUisaAluPred         pred;
    AMUisaFldAluVectorOp  op;
    AMUisaAluOMod         mod;
    AMUisaAluVecDst       dst;
    AMUisaAluVecOut       out;
    AMUisaAluVecArgs      vargs;
} AMUisaAluVecOpOut;

typedef struct _AMUisaAluSclDst {
    AMUisaReg             reg;
    AMUisaFldAluBool      mask;
} AMUisaAluSclDst;

typedef struct _AMUisaAluSclOut {
    AMUisaFldAluTarget    target;
    AMUisaFldAluBool      mask;
} AMUisaAluSclOut;

typedef struct _AMUisaAluSclPredOut {
    AMUisaFldAluPredOp    op;
    AMUisaFldAluBool      mask;
} AMUisaAluSclPredOut;

typedef struct _AMUisaAluSclWOut {
    AMUisaFldAluBool      wout;
} AMUisaAluSclWOut;

typedef struct _AMUisaAluSclArg {
    AMUisaFldAluSrcSel    sel;
    AMUisaFldAluSwizzle   swiz;
    AMUisaFldAluImod      mod;
} AMUisaAluSclArg;

typedef struct _AMUisaAluSclArgs {
    AMUisaAluSrcs         src;
    AMUisaAluSclArg       arg0;
    AMUisaAluSclArg       arg1;
    AMUisaAluSclArg       arg2;
} AMUisaAluSclArgs;

typedef struct _AMUisaAluSclOpAlu {
    AMUisaAluPred         pred;
    AMUisaFldAluScalarOp  op;
    AMUisaAluOMod         mod;
    AMUisaAluSclDst       dst;
    AMUisaAluSclPredOut   predout;
    AMUisaAluSclWOut      wout;
    AMUisaAluSclArgs      sargs;
} AMUisaAluSclOpAlu;

typedef struct _AMUisaAluSclOpOut {
    AMUisaAluPred         pred;
    AMUisaFldAluScalarOp  op;
    AMUisaAluOMod         mod;
    AMUisaAluSclDst       dst;
    AMUisaAluSclOut       out;
    AMUisaAluSclWOut      wout;
    AMUisaAluSclArgs      sargs;
} AMUisaAluSclOpOut;

typedef struct _AMUisaAluInt {
    AMUisaAluEnv          env;
    AMUisaAluAluOp        alu;
    AMUisaAluVecOpAlu     vec;
    AMUisaAluSclOpAlu     scl;
    AMUisaFldAluBool      nop;
} AMUisaAluInt;

typedef struct _AMUisaOutInt {
    AMUisaAluEnv          env;
    AMUisaAluAluOp        alu;
    AMUisaAluVecOpOut     vec;
    AMUisaAluSclOpOut     scl;
    AMUisaFldAluBool      nop;
    AMUisaFldAluBool      last;
} AMUisaOutInt;

//
//  union of all possible instruction formats
//
typedef struct _AMUisaInstInt {
    AMUisaFldInstType type;
    union {
        AMUisaAluInt alu;
        AMUisaOutInt out;
        AMUisaInpInt inp;
        AMUisaFlwInt flw;
    } u;
} AMUisaInstInt;

#endif // _AMU_ISA_INT_H_
