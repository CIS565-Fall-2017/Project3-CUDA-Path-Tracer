//
//  Copyright (c) 2006, ATI Technologies Inc.
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions
//  are met:
//
//  Redistributions of source code must retain the above copyright
//  notice, this list of conditions and the following disclaimer.
//
//  Redistributions in binary form must reproduce the above copyright
//  notice, this list of conditions and the following disclaimer in the
//  documentation and/or other materials provided with the distribution.
//
//  Neither the name of ATI Technologies Inc., nor the names of its
//  affiliates, subsidiaries or contributors may be used to endorse or
//  promote products derived from this software without specific prior
//  written permission.
//
//  THIS SOFTWARE IS PROVIDED BY ATI TECHNOLOGIES INC., ITS AFFILIATES,
//  SUBSIDIARIES AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
//  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
//  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
//  IN NO EVENT SHALL ATI TECHNOLOGIES INC., ITS AFFILIATES, SUBSIDIARIES
//  OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
//  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
//  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
//  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
//  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
//  SUCH DAMAGE.
//
//  Under no circumstances will the license grant above be construed as
//  granting, by implication, estoppel or otherwise, a license to any
//  technology belonging to ATI Technologies Inc. other than a copyright
//  license to this software.  For greater certainty this license does not
//  convey any rights, by implication, estoppel or otherwise, under or to
//  any patents or pending applications belonging to ATI Technologies Inc.
//  All rights not expressly granted herein are expressly reserved by ATI
//  Technologies Inc.
//

#ifndef _AMU_ISA_H_
#define _AMU_ISA_H_

#include "amuISABin.h"
#include "amuISAInt.h"

typedef void (*LogFunction)(const char* msg);

extern AMUisaInpInt amuISAUnpackInp(const AMUisaInpBin& inpbin);
extern AMUisaFlwInt amuISAUnpackFlw(const AMUisaFlwBin& flwbin);
extern AMUisaAluInt amuISAUnpackAlu(const AMUisaAluBin& alubin);
extern AMUisaOutInt amuISAUnpackOut(const AMUisaOutBin& outbin);
extern AMUisaInpBin amuISAPackInp(const AMUisaInpInt& inp);
extern AMUisaFlwBin amuISAPackFlw(const AMUisaFlwInt& flw);
extern AMUisaAluBin amuISAPackAlu(const AMUisaAluInt& alu);
extern AMUisaOutBin amuISAPackOut(const AMUisaOutInt& out);
extern void         amuISALogInpInt(const AMUisaInpInt& inp, const LogFunction log);
extern void         amuISALogFlwInt(const AMUisaFlwInt& flw, const LogFunction log);
extern void         amuISALogAluInt(const AMUisaAluInt& alu, const LogFunction log);
extern void         amuISALogOutInt(const AMUisaOutInt& out, const LogFunction log);
extern void         amuISALogSctInt(const AMUisaOutInt& out, const LogFunction log);
extern void         amuISALogInstBin(const AMUisaInstBin& instbin, unsigned int scatter, const LogFunction log);

#endif // _AMU_ISA_H_
