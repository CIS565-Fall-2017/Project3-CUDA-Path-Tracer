//
//  Copyright (c) 2006, ATI Technologies Inc.
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions
//  are met:
//
//  Redistributions of source code must retain the above copyright
//  notice, this list of conditions and the following disclaimer.
//
//  Redistributions in binary form must reproduce the above copyright
//  notice, this list of conditions and the following disclaimer in the
//  documentation and/or other materials provided with the distribution.
//
//  Neither the name of ATI Technologies Inc., nor the names of its
//  affiliates, subsidiaries or contributors may be used to endorse or
//  promote products derived from this software without specific prior
//  written permission.
//
//  THIS SOFTWARE IS PROVIDED BY ATI TECHNOLOGIES INC., ITS AFFILIATES,
//  SUBSIDIARIES AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
//  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
//  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
//  IN NO EVENT SHALL ATI TECHNOLOGIES INC., ITS AFFILIATES, SUBSIDIARIES
//  OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
//  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
//  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
//  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
//  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
//  SUCH DAMAGE.
//
//  Under no circumstances will the license grant above be construed as
//  granting, by implication, estoppel or otherwise, a license to any
//  technology belonging to ATI Technologies Inc. other than a copyright
//  license to this software.  For greater certainty this license does not
//  convey any rights, by implication, estoppel or otherwise, under or to
//  any patents or pending applications belonging to ATI Technologies Inc.
//  All rights not expressly granted herein are expressly reserved by ATI
//  Technologies Inc.
//

#ifndef _AMU_COMP_H_
#define _AMU_COMP_H_

///
///  @file  amuComp.h
///  @brief Interfaces Exported by ATI CTM Compiler Utility Library
///

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

static const unsigned int AMUcompVersionMajor   = 1;          ///< major version number
static const unsigned int AMUcompVersionMinor   = 0;          ///< minor version number
static const unsigned int AMUcompVersionUpdate  = 5;          ///< update version number
static const char AMUcompVersionQualifier[]     = "beta4";    ///< version qualifier

//
/// one define macro that may be passed to compiler
//
typedef struct AMUcompMacroRec {
    char* Name;       ///< definition name
    char* Definition; ///< definition value
} AMUcompMacro;

//
/// pointer to a function for handling messages returned by a compiler
//
typedef void (*LogFunction)(const char* msg);

//
/// opaque handle to a compiler
//
typedef struct AMUcompCompilerRec {}* AMUcompCompiler;

///
///  @fn amuCompOpenCompiler(void)
///
///  @brief Instantiate a compiler.
///
///  This function must be used to create a compiler instantiation.  All
///  compiler functions take a handle to a compiler created here.
///
///  @return Returns an opaque compiler handle.
///
///  @sa amuCompCloseCompiler
///
extern AMUcompCompiler amuCompOpenCompiler(void);

///
///  @fn amuCompCloseCompiler(AMUcompCompiler comp)
///
///  @brief Close a compiler instantiation.
///
///  This function shuts down an instantiation of a compiler.  The handle
///  is undefined after the function call.
///
///  @param comp  (in)  Handle to the compiler
///
///  @return No return value.
///
///  @sa amuCompOpenCompiler
///
extern void            amuCompCloseCompiler(AMUcompCompiler comp);

///
///  @fn amuCompCompile(
///            AMUcompCompiler     comp,
///            const char*         source,
///            unsigned int        sourceLen,
///            const AMUcompMacro* defines,
///            const char*         include,
///            const char*         entry,
///            unsigned int*       binarySize,
///            void**              binaryData,
///            LogFunction         logger)
///
///  @brief Compile a program.
///
///  This function compiles a program given by a string with an accompanying
///  length.  It takes a handle to an opened compiler, as well as parameters
///  for the compilation.  It returns a binary program encoded in the ATI CTM
///  ABI in ELF format.
///
///  The compiler allocates memory internally for the binary and ancilliary
///  data.  It is necessary to call amuCompFreeBinary to free this dynamically
///  allocated memory.  Otherwise a memory leak will occur.
///
///  Note that the binary contains information relating to the constant data
///  store, which needs to be submitted by the caller to the appropriate
//   constant data cache locations prior to program submission to CTM.
///
///  @param comp        (in)  Handle to the compiler
///  @param source      (in)  Program string (not necessarily NULL terminated)
///  @param sourceLen   (in)  Length of program string
///  @param defines     (in)  Pointer to a NULL terminated list of define macros
///  @param include     (in)  Pointer to a string specifying INCLUDE paths
///  @param entry       (in)  NULL terminated string specifying program entry point
///  @param binarySize  (out) Size of compiled binary
///  @param binaryData  (out) Pointer to an ATI CTM ABI binary executable upon success; NULL upon failure.
///  @param logger      (in)  function to provide message passing from compiler to application
///
///  @return Returns 1 upon success; 0 upon failure.
///
///  @sa amuCompOpenCompiler, amuCompFreeBinary
///
extern unsigned int amuCompCompile(AMUcompCompiler     comp,
                                   const char*         source,
                                   unsigned int        sourceLen,
                                   const AMUcompMacro* defines,
                                   const char*         include,
                                   const char*         entry,
                                   unsigned int*       binarySize,
                                   void**              binaryData,
                                   LogFunction         logger);

///
///  @fn amuCompFreeBinary(AMUcompCompiler comp, void* binary)
///
///  @brief Free data that has been allocated by the compiler.
///
///  This function frees memory that has been dynamically allocated
///  by a compiler when compiling a program.  Memory must be freed
///  with this function to avoid memory leaks.
///
///  @param comp   (in)  Handle to the compiler
///  @param binary (in)  Pointer to the binary data to free
///
///  @return No return value.
///
///  @sa amuCompCompile
///
extern void amuCompFreeBinary(AMUcompCompiler comp, void* binary);

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // _AMU_COMP_H_
