//
//  Copyright (c) 2006, ATI Technologies Inc.
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions
//  are met:
//
//  Redistributions of source code must retain the above copyright
//  notice, this list of conditions and the following disclaimer.
//
//  Redistributions in binary form must reproduce the above copyright
//  notice, this list of conditions and the following disclaimer in the
//  documentation and/or other materials provided with the distribution.
//
//  Neither the name of ATI Technologies Inc., nor the names of its
//  affiliates, subsidiaries or contributors may be used to endorse or
//  promote products derived from this software without specific prior
//  written permission.
//
//  THIS SOFTWARE IS PROVIDED BY ATI TECHNOLOGIES INC., ITS AFFILIATES,
//  SUBSIDIARIES AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
//  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
//  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
//  IN NO EVENT SHALL ATI TECHNOLOGIES INC., ITS AFFILIATES, SUBSIDIARIES
//  OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
//  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
//  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
//  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
//  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
//  SUCH DAMAGE.
//
//  Under no circumstances will the license grant above be construed as
//  granting, by implication, estoppel or otherwise, a license to any
//  technology belonging to ATI Technologies Inc. other than a copyright
//  license to this software.  For greater certainty this license does not
//  convey any rights, by implication, estoppel or otherwise, under or to
//  any patents or pending applications belonging to ATI Technologies Inc.
//  All rights not expressly granted herein are expressly reserved by ATI
//  Technologies Inc.
//

#ifndef _AMU_ASM_H_
#define _AMU_ASM_H_

///
///  @file  amuAsm.h
///  @brief Interfaces Exported by the ATI ASM Utility Library
///

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

//
/// pointer to a function for handling messages returned by the assembler
//
typedef void (*LogFunction)(const char* msg);

///
///  @fn amuAsmAssemble(
///            const char*   prog,
///            unsigned int* binarySize,
///            void*         binary,
///            LogFunction   log);
///
///  @brief Assemble a program.
///
///  This function assembles a program given by a null-terminated string.  It
///  returns a binary program encoded in the ATI CTM ABI in ELF format.
///
///  The assembler does not allocate storage for the binary; the caller must
///  ensure that there is sufficient storage behind the binary pointer.
///
///  @param prog       (in)  Program string (NULL terminated)
///  @param binarySize (out) Length of assembled ELF binary
///  @param binary     (out) Pointer to where the binary will be created
///  @param log        (in)  Function to provide message passing to application
///
///  @return Returns 1 upon success; 0 upon failure.
///
///  @sa amuAsmDissasemble
///
extern unsigned int amuAsmAssemble(const char*   prog,
                                   unsigned int* binarySize,
                                   void*         binary,
                                   LogFunction   log);


///
///  @fn amuAsmDisassemble(
///           void*         binary,
///           LogFunction   log);
///
///  @brief Disassemble a program.
///
///  This function disassembles a program given as an ELF binary.  It
///  sends its disassembled output (or error messages) back to the
///  application through the log function pointer.
///
///  @param binary  (in)   Pointer to the binary
///  @param log     (in)   Function to provide message passing to application
///
///  @return Returns 1 upon success; 0 upon failure.
///
///  @sa amuAsmDissasemble
///
extern unsigned int amuAsmDisassemble(void*        binary,
                                      LogFunction  log);

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // _AMU_ASM_H_
