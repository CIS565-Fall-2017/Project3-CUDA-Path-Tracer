//
//  Copyright (c) 2006, ATI Technologies Inc.
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions
//  are met:
//
//  Redistributions of source code must retain the above copyright
//  notice, this list of conditions and the following disclaimer.
//
//  Redistributions in binary form must reproduce the above copyright
//  notice, this list of conditions and the following disclaimer in the
//  documentation and/or other materials provided with the distribution.
//
//  Neither the name of ATI Technologies Inc., nor the names of its
//  affiliates, subsidiaries or contributors may be used to endorse or
//  promote products derived from this software without specific prior
//  written permission.
//
//  THIS SOFTWARE IS PROVIDED BY ATI TECHNOLOGIES INC., ITS AFFILIATES,
//  SUBSIDIARIES AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
//  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
//  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
//  IN NO EVENT SHALL ATI TECHNOLOGIES INC., ITS AFFILIATES, SUBSIDIARIES
//  OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
//  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
//  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
//  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
//  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
//  SUCH DAMAGE.
//
//  Under no circumstances will the license grant above be construed as
//  granting, by implication, estoppel or otherwise, a license to any
//  technology belonging to ATI Technologies Inc. other than a copyright
//  license to this software.  For greater certainty this license does not
//  convey any rights, by implication, estoppel or otherwise, under or to
//  any patents or pending applications belonging to ATI Technologies Inc.
//  All rights not expressly granted herein are expressly reserved by ATI
//  Technologies Inc.
//

#ifndef _AMU_CBUF_PACK_H_
#define _AMU_CBUF_PACK_H_

///
///  @file  amuCbufPack.h
///  @brief Interfaces Exported by ATI CTM Command Buffer Packer Utility Library
///

//
/// ATI CTM command buffer packer class
//
class AMUcbufPack
{
public:
    AMUcbufPack(unsigned int* cbuf, unsigned int size);
    ~AMUcbufPack(void);

public:
    void reset(void);
    unsigned int getCommandBufferSize(void);

public:
    unsigned int appendInitPerfCounters(unsigned int flags);
    unsigned int appendStartPerfCounters(void);
    unsigned int appendStopPerfCounters(void);
    unsigned int appendReadPerfCounters(unsigned int addr);
    unsigned int appendSetCondVal(unsigned int val);
    unsigned int appendSetDomain(unsigned int i0, unsigned int j0, unsigned int i1, unsigned int j1);
    unsigned int appendStartProgram(void);
    unsigned int appendWaitForIdle(void);
    unsigned int appendSetOffsetFmt(unsigned int id, unsigned int addr, unsigned int fmt, unsigned int tiling, unsigned int count);
    unsigned int appendSetInstFmt(unsigned int addr, unsigned int fmt, unsigned int tiling, unsigned int width);
    unsigned int appendSetInpFmt(unsigned int input, unsigned int addr, unsigned int fmt, unsigned int tiling, unsigned int width, unsigned int height);
    unsigned int appendSetOutFmt(unsigned int output, unsigned int addr, unsigned int fmt, unsigned int tiling, unsigned int width, unsigned int height);
    unsigned int appendSetCondOutFmt(unsigned int addr, unsigned int fmt, unsigned int tiling, unsigned int width, unsigned int height);
    unsigned int appendSetConstfFmt(unsigned int addr, unsigned int fmt, unsigned int tiling, unsigned int width);
    unsigned int appendSetConstiFmt(unsigned int addr, unsigned int fmt, unsigned int tiling, unsigned int width);
    unsigned int appendSetConstbFmt(unsigned int addr, unsigned int fmt, unsigned int tiling, unsigned int width);
    unsigned int appendInvInstCache(void);
    unsigned int appendInvConstfCache(void);
    unsigned int appendInvConstiCache(void);
    unsigned int appendInvConstbCache(void);
    unsigned int appendInvCondOutCache(void);
    unsigned int appendInvInpCache(void);
    unsigned int appendFlushOutCache(void);
    unsigned int appendFlushCondOutCache(void);
    unsigned int appendSetOutMask(unsigned int c0, unsigned int c1, unsigned int c2, unsigned int c3);
    unsigned int appendSetCondOutMask(unsigned int w);
    unsigned int appendSetCondTest(unsigned int test);
    unsigned int appendSetCondLoc(unsigned int loc);
    unsigned int appendSetParams(unsigned int addr);

protected:
    void*    allocateCmd(unsigned int size);

protected:
    unsigned int* _cbuf;
    unsigned int* _hi;
    unsigned int* _ptr;

};

#endif // _AMU_CBUF_PACK_H_

