#include <iostream>
#include "dxraster.h"
#include <brook/brook.hpp>
#include <brook/brt.hpp>
#include "../f3.h"
#include "../renderContextDX.h"
static const D3DVERTEXELEMENT9 kVertexFormat[] =
{
   { 0, 0, D3DDECLTYPE_FLOAT4, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0 },
   { 0, 4*sizeof(float), D3DDECLTYPE_FLOAT4, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0 },
   D3DDECL_END()
};



static IDirect3DVertexShader9* createVertexShader(
   IDirect3DDevice9* inDevice,
   const std::string& inSource )
{
   IDirect3DDevice9* device = inDevice;
   IDirect3DVertexShader9* resultShader;

   // assemble the shader
   HRESULT result;
   LPD3DXBUFFER codeBuffer;
   LPD3DXBUFFER errorBuffer;

   result = D3DXAssembleShader( inSource.c_str(), inSource.size(), NULL, NULL, 0, &codeBuffer, &errorBuffer );
   if( errorBuffer != NULL )
   {
      const char* errorMessage = (const char*)errorBuffer->GetBufferPointer();
      DX9Warn( "Vertex shader failed to compile:\n%s", errorMessage );
      throw -1;
   }
   else if( FAILED(result) )
   {
      DX9Warn( "Vertex shader failed to compile." );
      throw -1;
   }

   result = device->CreateVertexShader( (DWORD*)codeBuffer->GetBufferPointer(), &resultShader );
   codeBuffer->Release();

   if( FAILED(result) )
   {
      DX9Warn( "Failed to allocate vertex shader." );
      throw -1;
   }

   return resultShader;
}

static IDirect3DPixelShader9* createPixelShader(
   IDirect3DDevice9* inDevice,
   const std::string& inSource )
{
   IDirect3DDevice9* device = inDevice;
   IDirect3DPixelShader9* resultShader;

   // assemble the shader
   HRESULT result;
   LPD3DXBUFFER codeBuffer;
   LPD3DXBUFFER errorBuffer;

   result = D3DXAssembleShader( inSource.c_str(), inSource.size(), NULL, NULL, 0, &codeBuffer, &errorBuffer );
   if( errorBuffer != NULL )
   {
      const char* errorMessage = (const char*)errorBuffer->GetBufferPointer();
      DX9Warn( "Pixel shader failed to compile:\n%s", errorMessage );
      throw -1;
   }
   else if( FAILED(result) )
   {
      DX9Warn( "Pixel shader failed to compile." );
      throw -1;
   }

   result = device->CreatePixelShader( (DWORD*)codeBuffer->GetBufferPointer(), &resultShader );
   codeBuffer->Release();

   if( FAILED(result) )
   {
      DX9Warn( "Failed to allocate vertex shader." );
      throw -1;
   }

   return resultShader;
}




rasterDX::rasterDX(int countp, const F3*v0,const F3*v1,const F3*v2, F3 offset, RenderContextDX9 * ctx){
    count=countp;
    HRESULT result;
    _depthStencilSurface=NULL;
   _renderContext = ctx;
   IDirect3DDevice9* device = _renderContext->getDevice();
   result = device->CreateVertexBuffer(
       sizeof(DXVertex)*3*count, /*D3DUSAGE_DYNAMIC | */D3DUSAGE_WRITEONLY, 0, D3DPOOL_DEFAULT, &_vertexBuffer, NULL );
   if( FAILED(result) ) throw -1;
   result = device->CreateVertexDeclaration( kVertexFormat, &_vertexDecl );
   if( FAILED(result) ) throw -1;
//offset.v[0]=offset.v[1]=offset.v[2]=0;
/*
   count=1;
   F3 t0,t1,t2;
   t0.v[0]=-.125;
   t0.v[1]=19.259f+.25;
   t0.v[2]=82.639f-.5;
   t1.v[0]=-3;
   t1.v[1]=19.259f+1;
   t1.v[2]=82.639f-.5;
   t2.v[0]=0;
   t2.v[1]=19.259f+.125;
   t2.v[2]=82.639f-.5;
   v0=&t0;
   v1=&t1;
   v2=&t2;
*/
   DXVertex* vertices;
   result = _vertexBuffer->Lock( 0, 0, (void**)&vertices, D3DLOCK_DISCARD );
   if( FAILED(result) ) throw -1;
   for (int i=0;i<count;++i) {
       for (int j=0;j<3;++j) {
	   const F3*whicharray=(j==0?v0:(j==1?v1:v2));
	   F3 which =whicharray[i];
	   DXVertex* tmp=&vertices[i*3+j];
	   tmp->x=which.v[0]+offset.v[0];
	   tmp->y=which.v[1]+offset.v[1];
	   tmp->z=which.v[2]+offset.v[2];
	   tmp->w=1.0;//which.v[2]+offset.v[2];	   
	   tmp->tx=(j==1?1.0f:0.0f);
	   tmp->ty=(j==2?1.0f:0.0f);
           tmp->tz=(float)i;
	   tmp->tw=(float)i;
       }
   }
   result = _vertexBuffer->Unlock();
   if( FAILED(result) ) throw -1;
   FILE * pp = fopen("ctm/rasterdxps.ps","rb");
   fseek(pp,0,SEEK_END);
   long plen=ftell(pp);
   fseek(pp,0,SEEK_SET);
   char * kPixelShader=(char*)malloc(plen);
   fread(kPixelShader,plen,1,pp);
   fclose(pp);
   FILE * vp = fopen("ctm/rasterdxvs.vs","rb");
   fseek(vp,0,SEEK_END);
   long vlen=ftell(vp);
   fseek(vp,0,SEEK_SET);
   char * kVertexShader=(char*)malloc(vlen);
   fread(kVertexShader,vlen,1,vp);
   fclose(vp);
   _vertexShader = createVertexShader( device, std::string(kVertexShader,vlen) );
   _pixelShader = createPixelShader( device, std::string(kPixelShader,plen) );
}
extern void clearstream(brook::stream);
extern void clearstreamy(brook::stream);

void MultMatrix(float dest[], float mat[], float m[]) {
    register int i,j;
    for (j=0;j<4;++j) {

		float tmp[4]={mat[j],mat[4+j],mat[8+j],mat[12+j]};
	for (i=0;i<4;i+=1) {
	    dest[4*i+j]=m[4*i]*tmp[0]+m[4*i+1]*tmp[1]+m[4*i+2]*tmp[2]+m[4*i+3]*tmp[3];
	}
    }
}
void GFXFrustum(float * m,float *i, 
                 float left, float right,
	 	 float bottom, float top,
		 float nearval, float farval )
{
   float x, y, a, b, c, d;
   x = (((float)2.0)*nearval) / (right-left);
   y = (((float)2.0)*nearval) / (top-bottom);
   a = (right+left) / (right-left);
   b = (top+bottom) / (top-bottom);
   c = -(farval+nearval) / ( farval-nearval);
   d = -(((float)2.0)*farval*nearval) / (farval-nearval);  /* error? */

#define M(row,col)  m[col*4+row]
   M(0,0) = x;     M(0,1) = 0.0F;  M(0,2) = a;      M(0,3) = 0.0F;
   M(1,0) = 0.0F;  M(1,1) = y;     M(1,2) = b;      M(1,3) = 0.0F;
   M(2,0) = 0.0F;  M(2,1) = 0.0F;  M(2,2) = c;      M(2,3) = d;
   M(3,0) = 0.0F;  M(3,1) = 0.0F;  M(3,2) = -1.0F;  M(3,3) = 0.0F;
#undef M
#define M(row,col) i[col*4+row]
   M(0,0) = 1.0f/x;  M(0,1) = 0.0f;  M(0,2) = 0.0f;   M(0,3) = a/x;
   M(1,0) = 0.0F;  M(1,1) = 1.0f/y;  M(1,2) = 0.0F;   M(1,3) = b/y;
   M(2,0) = 0.0F;  M(2,1) = 0.0F;  M(2,2) = 0.0F;   M(2,3) =-1.0F;
   M(3,0) = 0.0F;  M(3,1) = 0.0F;  M(3,2) = 1.0f/d;  M(3,3) = (float)c/d;
#undef M
}
static void gl_Frustum (float *projection, float * invprojection, float left,float right, float bottom, float top, float nearval,float farval){
  GFXFrustum (projection,invprojection,left,right,bottom,top,nearval,farval);
}
void doswap(float &a, float &b) {
    float tmp=a;
    a=b;
    b=tmp;
}
void transpose(float * m) {
#define M(row,col)  m[col*4+row]
    doswap(M(1,0),M(0,1));
    doswap(M(2,0),M(0,2));
    doswap(M(3,0),M(0,3));
    doswap(M(2,1),M(1,2));
    doswap(M(3,1),M(1,3));
    doswap(M(3,2),M(2,3));
#undef M    
}
void PrintMatrix(float *m) {
	for (int i=0;i<4;++i){
		for (int j=0;j<4;++j){
#define M(row,col)  m[col*4+row]
			printf ("%f ",M(j,i));
		}
		printf ("\n");
	}
}
void /*GFXDRVAPI*/ GFXPerspective(float * projection, float*invprojection, float fov, float aspect, float znear, float zfar, float cockpit_offset)
{
  //  gluPerspective (fov,aspect,znear,zfar);


   float xmin, xmax, ymin, ymax;



   ymax = znear * tanf( fov * M_PI / ((float)360.0) ); //78.0 --> 4.7046

   ymin = -ymax; //-4.7046

   xmin = (ymin-cockpit_offset/2) * aspect;//-6.2571
   xmax = (ymax+cockpit_offset/2) * aspect;//6.2571
   ymin-=cockpit_offset;
   gl_Frustum(projection,invprojection, xmin, xmax, ymin, ymax, znear, zfar );
//   ConstructAndLoadProjection();
}
void PrintTransform(float *mat, F3 v, bool wextend) {
    float tmp[4]={v.v[0],v.v[1],v.v[2],wextend?v.v[2]:1.0f};
    float rez[4];
    rez[0]=mat[0]*tmp[0]+mat[1]*tmp[1]+mat[2]*tmp[2]+mat[3]*tmp[3];
    mat+=4;
    rez[1]=mat[0]*tmp[0]+mat[1]*tmp[1]+mat[2]*tmp[2]+mat[3]*tmp[3];    
    mat+=4;
    rez[2]=mat[0]*tmp[0]+mat[1]*tmp[1]+mat[2]*tmp[2]+mat[3]*tmp[3];
    mat+=4;
    rez[3]=mat[0]*tmp[0]+mat[1]*tmp[1]+mat[2]*tmp[2]+mat[3]*tmp[3];
    printf ("v[%.3f, %.3f,%.3f,%.3f]\n",rez[0],rez[1],rez[2],rez[3]);
}
void rasterDX::draw(int w, int h, const RayCTM rays[],ctmstream stream, float fov){
 CameraFrame& sceneSpaceCamera=rays->cam->getSceneSpaceCameraFrame();
 float ModelWorld[16]={1,0,0,0,
		       0,1,0,0,
		       0,0,1,0,
		       0,0,0,1};
 float ModelViewTrans[16]={1,0,0,0,
		       0,1,0,0,
		       0,0,1,0,
			   -(sceneSpaceCamera.position.x+rays->bbox.rayOffset.v[0]),
			   -(sceneSpaceCamera.position.y+rays->bbox.rayOffset.v[1]),
			   -(sceneSpaceCamera.position.z+rays->bbox.rayOffset.v[2]),
		       1};//fixme
 F3 fore,right,up;
 F3_FROM_FLOAT3(fore,sceneSpaceCamera.direction);
 fore.v[0]=-fore.v[0];//not sure why, but DX seems backwards "It's on backwards!..." "Quick do something" "It must have been a microconverter malfunction I'll try and reverse the beam.... Lock 1, Lock 2, Loch Lowen...
 fore.v[1]=-fore.v[1];
 fore.v[2]=-fore.v[2];
 F3_FROM_FLOAT3(up,sceneSpaceCamera.up);
 up.v[0]=-up.v[0];
 up.v[1]=-up.v[1];
 up.v[2]=-up.v[2];
/*
 fore.v[0]=0;
 fore.v[1]=0;
 fore.v[2]=-1;
 up.v[0]=0;
 up.v[1]=1;
 up.v[2]=0;
*/
 F3_CROSS(right,fore,up);
 F3_CROSS(up,right,fore);
 F3_SCALE(right,1.0f/sqrtf(F3_DOT(right,right)));
 F3_SCALE(up,1.0f/sqrtf(F3_DOT(up,up)));
 float ModelViewOrient[16]={
     right.x,right.y,right.z,0,
     up.x,up.y,up.z,0,
     fore.x,fore.y,fore.z,0,
     0,0,0,1};
 float Projection[16]={1,0,0,0,
		       0,1,0,0,
		       0,0,1,0,
		       0,0,0,1};
 float IProjection[16]={1,0,0,0,
			0,1,0,0,
			0,0,1,0,
			0,0,0,1};
 float ModelViewProj[16];
 float distance = 100000000;
 float aspect = (float)w/h;
 float ModelView[16];
 float viewsize[4]={(float)w,(float)h,0,0};
 float bboxmin[4]={rays->bbox.min.x,rays->bbox.min.y,rays->bbox.min.z,0};
 float bboxmax[4]={rays->bbox.max.x,rays->bbox.max.y,rays->bbox.max.z,0};
 float origin[4]={ sceneSpaceCamera.position.x +rays->bbox.rayOffset.v[0],
		   sceneSpaceCamera.position.y +rays->bbox.rayOffset.v[1],
		   sceneSpaceCamera.position.z +rays->bbox.rayOffset.v[2],0};
/*
 printf ("Fore %f %f %f\n Up, %f %f %f\nCamPos %f %f %f\nRayOffset %f %f %f\n",	 sceneSpaceCamera.direction.x,sceneSpaceCamera.direction.y,sceneSpaceCamera.direction.z,
	 sceneSpaceCamera.up.x,sceneSpaceCamera.up.y,sceneSpaceCamera.up.z,
	 sceneSpaceCamera.position.x,sceneSpaceCamera.position.y,sceneSpaceCamera.position.z,
rays->bbox.rayOffset.v[0],rays->bbox.rayOffset.v[1],rays->bbox.rayOffset.v[2]);
*/
 transpose(ModelViewOrient);
 MultMatrix(ModelView,ModelViewOrient,ModelViewTrans);

 GFXPerspective(Projection,IProjection,fov,aspect,.1f,distance*1.1f,0);
// transpose(Projection);
 MultMatrix(ModelViewProj,Projection,ModelView);
/*
   static float * mem=(float*)malloc(w*h*sizeof(float)*4);
   for ( int i=0;i<( int)w*h*4;++i)
   mem[i]=i%8<4?(float).1:(float).9;
   streamRead(stream.stream[0],mem);
*/
//    clearstreamy(stream.stream[0]);
   HRESULT result;
   IDirect3DDevice9* device = _renderContext->getDevice();

   if (_depthStencilSurface==NULL) {
     result = device->CreateDepthStencilSurface(
	 w,
	 h,
	 D3DFMT_D24S8,
	 D3DMULTISAMPLE_NONE,
	 0,
	 FALSE,
	 &_depthStencilSurface,
	 NULL );
     if (FAILED( result)) {
	 assert(0&&"CreateDepthStencilSurface failed" );
     }
   }
   result = device->SetDepthStencilSurface( _depthStencilSurface );
   if (FAILED(result)) {
       assert(0&&"SetStencilSurface failed" );
   }
   
   result = device->BeginScene();
   if( FAILED(result) ) throw -1;
   result = device->SetRenderTarget( 1, NULL);
   result = device->SetRenderTarget( 2, NULL);
   result = device->SetRenderTarget( 3, NULL);

   IDirect3DTexture9* resultTexture = (IDirect3DTexture9*) stream.stream[0]->getIndexedFieldRenderData(0);
   LPDIRECT3DSURFACE9 surfaceHandle;
   result=resultTexture->GetSurfaceLevel(0,&surfaceHandle);

   result = device->SetRenderTarget( 0, surfaceHandle);

   
   D3DVIEWPORT9 viewport;
   viewport.X = 0;
   viewport.Y = 0;
   viewport.Width = w;
   viewport.Height = h;
   viewport.MinZ = 0.0f;
   viewport.MaxZ = 1.0f;
   result = device->SetViewport( &viewport );
   if( FAILED(result) ) throw -1;	
   result=device->SetRenderState( D3DRS_ZENABLE, D3DZB_TRUE );
   if( FAILED(result) ) throw -1;

   result = device->SetRenderState( D3DRS_ZWRITEENABLE, TRUE);
   if( FAILED(result) ) throw -1;

   result = device->SetRenderState( D3DRS_ZFUNC, D3DCMP_LESSEQUAL );
   if( FAILED(result) ) throw -1;
   result = device->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE);
   if( FAILED(result) ) throw -1;
   result=device->EndScene();
   if( FAILED(result) ) throw -1;
   result=device->Clear(0,NULL,D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER,D3DCOLOR_XRGB(0,0,0),1.0f,0);
   if( FAILED(result) ) throw -1;
   result=device->BeginScene();
   if( FAILED(result) ) throw -1;

  result = device->SetVertexShader( _vertexShader );
   if( FAILED(result) ) throw -1;
   result = device->SetVertexShaderConstantF( 0, origin, 1);
   result = device->SetVertexShaderConstantF( 1, bboxmin, 1);
   result = device->SetVertexShaderConstantF( 2, bboxmax, 1);
   result = device->SetVertexShaderConstantF( 3, viewsize, 1);
/*
   printf ("ModelViewTrans\n");
   PrintMatrix(ModelViewTrans);
   printf ("ModelViewProj\n");
PrintMatrix(ModelViewProj);

   F3 t0,t1,t2;
   t0.v[0]=(float)(-.125+rays->bbox.rayOffset.v[0]);
   t0.v[1]=(float)(19.259f+.25+rays->bbox.rayOffset.v[1]);
t0.v[2]=(float)(82.639f-.5+rays->bbox.rayOffset.v[2]);
t1.v[0]=(float)(-3+rays->bbox.rayOffset.v[0]);
t1.v[1]=(float)(19.259f+1+rays->bbox.rayOffset.v[1]);
t1.v[2]=(float)(82.639f-.5+rays->bbox.rayOffset.v[2]);
t2.v[0]=(float)(0+rays->bbox.rayOffset.v[0]);
t2.v[1]=(float)(19.259f+.125+rays->bbox.rayOffset.v[1]);
t2.v[2]=(float)(82.639f-.5+rays->bbox.rayOffset.v[2]);
*/
   transpose(ModelView);
   transpose(ModelViewProj);
/*
   printf ("ModelView *t\n");
   PrintTransform(ModelView,t0,false);
   PrintTransform(ModelView,t1,false);
   PrintTransform(ModelView,t2,false);
   printf ("ModelViewProj *t\n");
   PrintTransform(ModelViewProj,t0,false);
   PrintTransform(ModelViewProj,t1,false);
   PrintTransform(ModelViewProj,t2,false);
   printf ("ModelView *t extend\n");
   PrintTransform(ModelView,t0,true);
   PrintTransform(ModelView,t1,true);
   PrintTransform(ModelView,t2,true);
   printf ("ModelViewProj *t extend\n");
   PrintTransform(ModelViewProj,t0,true);
   PrintTransform(ModelViewProj,t1,true);
   PrintTransform(ModelViewProj,t2,true);
*/
   result = device->SetVertexShaderConstantF( 4,ModelWorld,4 );
   result = device->SetVertexShaderConstantF( 8,ModelViewProj,1 );
   result = device->SetVertexShaderConstantF( 9,ModelViewProj+4,1 );
   result = device->SetVertexShaderConstantF( 10,ModelViewProj+8,1 );
   result = device->SetVertexShaderConstantF( 11,ModelViewProj+12,1 );
   if( FAILED(result) ) throw -1;
   result = device->SetPixelShader( _pixelShader );
   if( FAILED(result) ) throw -1;
   result = device->SetPixelShaderConstantF( 0, origin, 1);
   result = device->SetPixelShaderConstantF( 1, bboxmin, 1);
   result = device->SetPixelShaderConstantF( 2, bboxmax, 1);
   result = device->SetPixelShaderConstantF( 3, viewsize, 1);
   if( FAILED(result) ) throw -1;
   

   if( FAILED(result) ) throw -1;

   if( FAILED(result) ) throw -1;

   result = device->SetVertexDeclaration( _vertexDecl );
   if( FAILED(result) ) throw -1;

   result = device->SetStreamSource( 0, _vertexBuffer, 0, sizeof(DXVertex) );
   if( FAILED(result) ) throw -1;

   result = device->DrawPrimitive( D3DPT_TRIANGLELIST, 0, count );
   if( FAILED(result) ) throw -1;


  // result = device->Present( NULL, NULL, NULL, NULL );

   result = device->EndScene();
   if( FAILED(result) ) {
	   assert(0&&"FAILED TO END SCENE");
	   throw -1;
   }

   result = device->SetDepthStencilSurface( _depthStencilSurface );
   if (FAILED(result)) {
       assert(0&&"SetStencilSurface failed" );
   }
   result=device->SetRenderState( D3DRS_ZENABLE, D3DZB_FALSE );
   if( FAILED(result) ) throw -1;

   result = device->SetRenderState( D3DRS_ZWRITEENABLE, FALSE);
   if( FAILED(result) ) throw -1;

   

   //DX9AssertResult( result, "Present Failed" );
}
