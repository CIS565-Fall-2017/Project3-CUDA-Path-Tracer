
/*
 * ctmDisplayGDI.h --
 *
 *      XXX
 */

#ifndef __CTM_CTMDISPLAYGDI_H__
#define __CTM_CTMDISPLAYGDI_H__

#include <windows.h>
#include "ctmDisplay.h"
#include "../renderContextGDI.h"

class PixelDisplayerCtmGdi : public IPixelDisplayerCTM
{
public:
   PixelDisplayerCtmGdi( RenderContextGDI* inRenderContext );

   void Display( int inWidth, int inHeight, const PixelCTM* inPixels );

private:
   RenderContextGDI* _renderContext;

};

#endif
