#include "ctmTracer.h"
struct PixelCTM;
class DefaultHitShaderNewBrook:public IStandardShaderCTM
{
    bool _gdi;
    const Scene *scene;
    const CameraManager *cam;
    ITracerCTM* tracer;
    uint32 triangleWidth;
    uint32 triangleHeight;
    brook::stream* verticesGPU;
    //brook::stream* colorsGPU;
    brook::stream* normalsGPU;
    brook::stream* specularGPU; // Alpha holds specular exponent.
    brook::stream* textureGPU;
    unsigned int textureWidth,textureHeight;
    brook::stream* rayColorGPU[4];
    brook::stream* framebufferGPU;
    unsigned char* framebufferCPU;
    bool rayColorGPUinit;
    uint32 numLoops;
    uint32 maxNumLights;
    float specAddition;
    float specCutoff;
    float ambient;
    float diffuse;//sometimes contained in scene
    int shadow;
    int sceneshadow;
    public:
    DefaultHitShaderNewBrook(
      const Scene *scene,
      const CameraManager *cam,
						ITracerCTM* inTracer, const Opts&inOptions);

   virtual void Shade(
         uint32 inCount,
         const SampleCTM* inSamples,
         const RayCTM* inRays,
         const HitCTM* inHits,
         PixelCTM* ioPixels,
         bool inShouldRelease );

   virtual uint32 GetBatchGranularity() { return 1; }

};
