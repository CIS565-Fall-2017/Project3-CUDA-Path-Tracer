/*

 * kdtreeCTM.cpp --
 *
 *      k-D tree spatial subdivision accelerator.
 */
 

#include "../sampler.h"
#include "kdtreeBrook.h"
#include "brooktracer.hpp"
#include <assert.h>
#include <errno.h>
#include <algorithm>

#include "../scenecache.h"
#include "../log.h"
#include "../timer.h"
#include "../ctm/ctmTracer.h"
#include "common.h"
extern bool yesrasterize;
extern bool norasterize;
extern double fetch1count;
extern double fetch2count;
extern double fetch4count;
void processdat(float * datao, int width, int height) {
    float *data=datao;
    float sum[4]={0,0,0,0};
    float ave[4];
    float maxi[4]={0,0,0,0};
    float mini[4]={FLT_MAX,FLT_MAX,FLT_MAX,FLT_MAX};
    float var[4]={0,0,0,0};
    float stddev[4];
    for (int i=0;i<width*height;++i) {
	for (int j=0;j<4;++j) {
	    sum[j]+=data[j];
	    if (data[j]!=1) {
		//printf ("Error %f found at %dx%d\n",data[j],i,j);
	    }
	    if (data[j]>maxi[j])
		maxi[j]=data[j];
	    if (data[j]<mini[j])
		mini[j]=data[j];
	}
	data+=4;
    }
    for (int j=0;j<4;++j) {
	ave[j]=sum[j]/(width*height);
    }
    data=datao;
    for (int i=0;i<width*height;++i) {
	for (int j=0;j<4;++j) {
	    var[j]+=(data[j]-ave[j])*(data[j]-ave[j]);
	}
	data+=4;
    }
    printf ("\n;;    Total;   Ave;Std;  Min; Max\n");
    for (int j=0;j<4;++j) {
	if (width!=height) {
	    sum[j]*=width;
	    sum[j]/=height;
	}
	var[j]/=(width*height-1);
	stddev[j]=sqrt(var[j]);
	if (j==0) printf ("Restarts ");
	if (j==1) printf ("Nodes Vis");
	if (j==2) printf ("Triangles");
	if (j==3) printf ("XtraShdwN");
	printf (";");
	if (j!=1)
	    printf ("    ");
	printf ("%.0f",sum[j]);
	printf (";%.2f;%.2f;%.0f;%.0f\n",ave[j],stddev[j],mini[j],maxi[j]);
    }
    
}
void CopyKDTreeGPUFat( KDTree* builtTree, PaddedCtmKdTreeNode* _nodes, BoundingBoxCTM* _bbox, unsigned int kdtreeWidth, bool fetch4);

extern bool display (int w,int h,const RayCTM[], float* outputAddy, ctmstream output, float fov);
int brookMaxWidth=2048;
const int PADDING=1;
extern bool yespacketize;
extern bool nopacketize;

#define memcpyBroadcastBrook memcpy
KDTreeBrook::KDTreeBrook(const Scene& scene, const Opts& options, BoundingBoxCTM* bbox)
{
  
  hitTT=hitUU=hitVV=hitID=NULL;
  hitBackingStore=NULL;
  _useRaster=GetKeyValueInt("useRaster",options.accelOpts,true)?true:false;
  benchmark=GetKeyValueInt("benchmark",options.accelOpts,0);
  packetized=options.packets;
  printf("fov %f\n",scene.fov()); 
  this->fov=scene.fov();
  this->_bbox = bbox;
  _dotrace = GetKeyValueInt( "doTrace", options.accelOpts, 0 )?true:false;
  float kdtreeScale= (float)GetKeyValueInt( "minNodeExtentRatio", options.accelOpts, 2048 );
  float isectCost= (float)GetKeyValueFloat( "isectCost", options.accelOpts, 1.0 );
  printf ("Using kdtree of scale 1/%.0f isectCost %f\n",kdtreeScale,isectCost);
  _repeatFrameSubmitCount = GetKeyValueInt(
    "frameCount", options.accelOpts, 1 );
  if( _repeatFrameSubmitCount < 1 )
  {
    fprintf( stderr, "Invalid frame count %d.\n", _repeatFrameSubmitCount );
    exit( 1 );
  }

  KDTreeBuildOptions buildOptions;
  buildOptions.minNodeExtentRatio = 1.0f/kdtreeScale;///*1./2048;//*/.015625f/65536.0f/4.0f;
  buildOptions.isectCost=isectCost;
  //  buildOptions.minAbsoluteProbability=2.0f;
  KDTree* builtTree = BuildKDTreeCached( options, &scene, buildOptions );
  _nodeCount = builtTree->getNodeCount();
#ifdef FAT_NODES
  _nodes = (CtmKdTreeNode*)malloc((_nodeCount+brookMaxWidth) * sizeof(PaddedCtmKdTreeNode) );
#else
  _nodes = (CtmKdTreeNode*)malloc((_nodeCount+brookMaxWidth) * sizeof(CtmKdTreeNode) );
#endif
  if (_nodes==NULL) {
	printf ("Failed to allocate %d bytes for kdtree\n",_nodeCount*sizeof(CtmKdTreeNode));

  }    
  kdtreeWidth =brookMaxWidth;
#ifdef FAT_NODES
  CopyKDTreeGPUFat(builtTree,(PaddedCtmKdTreeNode*)_nodes,_bbox,kdtreeWidth,false);
#else
  CopyKDTreeGPU( builtTree, _nodes, _bbox );
#endif
  _triangleCount = builtTree->getPrimitiveIndexCount();
  const int* builtIndices = builtTree->getPrimitiveIndices();
  
   _triangleDataA = (float *) malloc(
     _triangleCount * sizeof(float)*4 );
   _triangleDataB = (float *) malloc(
     _triangleCount * sizeof(float)*4 );
   _triangleDataC = (float *) malloc(
     _triangleCount * sizeof(float)*4 );

   
   unsigned int tc=_triangleCount;
   TriWidth=brookMaxWidth;//tc/TriHeight+(tc%TriHeight?1:0);
   unsigned int tcroundup=tc/TriWidth+(tc%TriWidth?1:0);
   TriHeight=PADDING*(tcroundup/PADDING + (tcroundup%PADDING?1:0));
   printf ("Width %d Height %d\n",TriWidth,TriHeight);
   float *triangleIDs=(float*)malloc(TriWidth*TriHeight*sizeof(float));
   for( uint32 ii = 0; ii < _triangleCount; ii++ )
   {
       float triID=(float)builtIndices[ii];
       memcpyBroadcastBrook(&triangleIDs[ii],&triID,sizeof(float));
   }
   CopyTrianglesGPU( _triangleCount, builtIndices, scene.vertices(0),scene.vertices(1), scene.vertices(2), _bbox,
					 _triangleDataA, _triangleDataB, _triangleDataC );
   
   delete builtTree; // v0, v1, v2 are const pointers to the builtTree.
   triangleIDsGPU=new brook::stream(brook::getStreamType((float*)NULL),TriHeight,TriWidth,-1);
   streamRead(*triangleIDsGPU,triangleIDs);

   triangles0 = (float*)malloc(16*3*TriWidth*TriHeight);
   
   // Copy in data
   float * AA=_triangleDataA;
   float * BB=_triangleDataB;
   float * CC=_triangleDataC;
   fflush(stdout);
   
   for (unsigned int j=0;j<TriHeight;++j) {
       for (unsigned int i=0;i<TriWidth;++i) {
	   if (AA-_triangleDataA>=(ptrdiff_t)_triangleCount*4)break;
	   memcpyBroadcastBrook(triangles0+4*(3*j*TriWidth+i),AA,sizeof(float)*4);
	   AA+=4;
	   memcpyBroadcastBrook(triangles0+4*((3*j+1)*TriWidth+i),BB,sizeof(float)*4);
	   BB+=4;
	   memcpyBroadcastBrook(triangles0+4*((3*j+2)*TriWidth+i),CC,sizeof(float)*4);
	   CC+=4;
       }
   }
   triangles = new brook::stream(brook::getStreamType((float4*)NULL),TriHeight*3,TriWidth,-1);
   streamRead(*triangles,triangles0);
   

    kdtreeHeight =_nodeCount/kdtreeWidth+((_nodeCount%kdtreeWidth)?1:0);
    //if (kdtreeHeight<4)kdtreeHeight=4;
    kdtreeHeight = (kdtreeHeight/PADDING+ (kdtreeHeight%PADDING?1:0))*PADDING;
    // Bind inputs
#ifdef FAT_NODES
    kdtree= new brook::stream(brook::getStreamType((float4*)NULL),kdtreeHeight,kdtreeWidth,-1);
#else
    kdtree= new brook::stream(brook::getStreamType((float2*)NULL),kdtreeHeight,kdtreeWidth,-1);
#endif
    
    streamRead(*kdtree,_nodes);
    fprintf(stderr, "kdtree should be on hardware now\n");
}

KDTreeBrook::~KDTreeBrook(void)
{
    delete kdtree;
    delete triangles;
    delete triangleIDsGPU;
}
uint32 KDTreeBrook::getBatchGranularity() {
  return 1;
}

float4 arrayFloat4(float inp[]) {
    return float4(inp[0],inp[1],inp[2],inp[3]);
}


void
KDTreeBrook::intersect(const RayCTM rays[],
                     uint32 numRays, HitCTM hits[])
{

    bool rebin_packets=false;

    unsigned int Height=rays->height;
    unsigned int Width=rays->width;
    hits->height = Height;
    hits->intersector=this;
    hits->width = Width;
    if (yespacketize) {
      packetized=true;
      yespacketize=false;
    }
    if (nopacketize) {
      packetized=false;
      nopacketize=false;
    }
    if (yesrasterize){
	_useRaster=true;
	yesrasterize=false;
    }
    if (norasterize){
	_useRaster=false;
	norasterize=false;
    }
    if (hitTT==NULL) {
	hitTT=new brook::stream(brook::getStreamType((float4*)NULL),Height,Width,-1);
	hitUU=new brook::stream(brook::getStreamType((float4*)NULL),Height,Width,-1);
	hitVV=new brook::stream(brook::getStreamType((float4*)NULL),Height,Width,-1);
	hitID=new brook::stream(brook::getStreamType((float4*)NULL),Height,Width,-1);
	if (_useRaster||packetized==false) {
	    unifiedHitBuffer=new brook::stream(brook::getStreamType((float4*)NULL),Height*2,Width*2,-1);
	}
	
    }
    
    hits->tHitPtr.stream=hitTT;
    hits->uuPtr.stream=hitUU;
    hits->vvPtr.stream=hitVV;
    hits->triNumPtr.stream=hitID;
#ifdef _WIN32
    if (_useRaster&&(rays->raysO.v[0]!=-666.0f||rays->raysO.v[1]!=-666.0f||rays->raysO.v[2]!=-666.0f)) {
	//FIXME stupidly GPU compliant--copies some of the stuff twice, half as fast on dual gpu
	if(hitBackingStore==NULL){
	    hitBackingStore=(float*)malloc( sizeof(float)*16*Width*Height);   
	}
	ctmstream hitbuffer;
	hitbuffer.stream=unifiedHitBuffer;
	if (display(Width*2,Height*2,rays,hitBackingStore,hitbuffer, fov))
	    streamRead(*unifiedHitBuffer,hitBackingStore);
	brookrastercopy(*unifiedHitBuffer,*hitTT,*hitUU,*hitVV,*hitID);
	return;
    }
#endif

    float triangleIndex[ 4 ] = {0,0,0,0};
    triangleIndex[3]=(float)kdtreeWidth;
    triangleIndex[2]=(float)_nodeCount;
    triangleIndex[0]=(float)_triangleCount;
    triangleIndex[1]=(float)TriWidth;
    float initialHit[4]={.000000000f,1.0f,2.0,.00001f};
    float bboxMin[4]={_bbox->min.v[0]-1,_bbox->min.v[1]-1,_bbox->min.v[2]-1};
    float bboxMax[4]={_bbox->max.v[0]+1,_bbox->max.v[1]+1,_bbox->max.v[2]+1};
    int idiotic[4]={255,0,0,0};

    float raysO[4]={rays->raysO.v[0],//rays[0].o.v[0]+_bbox->rayOffset.v[0],
                    rays->raysO.v[1],//rays[0].o.v[BUNDLE_SIZE]+_bbox->rayOffset.v[1],
                    rays->raysO.v[2],//rays[0].o.v[2*BUNDLE_SIZE]+_bbox->rayOffset.v[2],
					6.123456789f};
	// badray unused
    float badray[4]={9.123456789f,
                    9.123456789f,
                    9.123456789f,
		     9.123456789f};
    float rayIndexOffset[4]={0,(float)Height,0,0};
    double a= Timer_GetMS();
    int iter;
    fetch1count=0;
    fetch2count=0;
    fetch4count=0;
    for (iter=0;iter<(benchmark?benchmark:1);++iter) {
	if (packetized) {
	    brookTrace(arrayFloat4(triangleIndex),
		   arrayFloat4(initialHit),
		   arrayFloat4(bboxMin),
		   arrayFloat4(bboxMax),
		   arrayFloat4(badray),
		   arrayFloat4(raysO),
		   arrayFloat4(rayIndexOffset),
		   arrayFloat4((float*)_nodes),
		   *kdtree,
		   *triangles,
		   *rays->rays.stream,
		   *rays->raysOXYZ,
		   *hitTT,
		   *hitUU,
		   *hitVV,
		   *hitID);
	}else {
	    brookTraceNoPackets(arrayFloat4(triangleIndex),
		   arrayFloat4(initialHit),
		   arrayFloat4(bboxMin),
		   arrayFloat4(bboxMax),
		   arrayFloat4(badray),
		   arrayFloat4(raysO),
		   arrayFloat4(rayIndexOffset),
		   arrayFloat4((float*)_nodes),
		   *kdtree,
		   *triangles,
		   *rays->rays.stream,
		   *rays->raysOXYZ,
		   *unifiedHitBuffer);
	}
	if (benchmark>1&&iter==0){
	  float data[16];
	  streamWrite((packetized?hitUU:unifiedHitBuffer)->domain(int2(0,0),int2(1,1)),data);	  
	  a=Timer_GetMS();
	}
    }
    if (benchmark>1) iter-=1;//not timed the first slow one
    if (benchmark) {
      float data[16];
      streamWrite((packetized?hitUU:unifiedHitBuffer)->domain(int2(0,0),int2(1,1)),data);
      
	//write real perf code
    }
    if (!packetized)
	brookrastercopy(*unifiedHitBuffer,*hitTT,*hitUU,*hitVV,*hitID);
    if(0) {
	static float * hitData=(float*)malloc(Width*Height*4*sizeof(float));
	streamWrite(*hitUU,hitData);
    
	processdat(hitData,Width,Height);
    }
    double b= Timer_GetMS();
	
    if (fetch1count!=0||fetch2count!=0||fetch4count!=0)
    printf ("Fetch 1's: %.0f, Fetch 2's: %.0f, Fetch 4's %.0f\nTotal Fetches %.0f  Floats Read %.0f  Bytes Read %.0f\n",
	    fetch1count,
	    fetch2count,
	    fetch4count,
	    fetch1count+fetch2count+fetch4count,
	    fetch1count+2*fetch2count+4*fetch4count,
	    (fetch1count+2*fetch2count+4*fetch4count)*4);
    //float tmp;
    //streamRead(hitID->domain(int2(0,0),int2(1,1)),&tmp);
    printf ("%d Rays took %f mseconds for %f million rays per second\n",
            numRays*iter,
            (b-a),
            iter*numRays/(b-a)/1000.);
    fflush(stdout);

}

void
KDTreeBrook::intersectPacket(const RayCTM rays[],
                           uint32 numRays, HitCTM hits[])
{
  intersect( rays, numRays, hits );
}

void
KDTreeBrook::intersectP(const RayCTM rays[],
                      uint32 numRays, HitCTM hits[])
{
  intersect( rays, numRays, hits );
}

void
KDTreeBrook::intersectPacketP(const RayCTM rays[],
                            uint32 numRays, HitCTM hits[])
{
  intersect( rays, numRays, hits );
}

