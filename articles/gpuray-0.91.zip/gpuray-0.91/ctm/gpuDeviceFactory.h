#ifndef __GPU_DEVICE_FACTORY_H
#define __GPU_DEVICE_FACTORY_H

struct GPUDevice;

extern GPUDevice *createGPUDevice(unsigned int numCards=1);

#endif
