#include <assert.h>

#include "ctmTracer.h"

#include "../scenecache.h"
#include "../log.h"
#include "../timer.h"

#include "common.h"

float mymax (float a, float b) {
    return a>b?a:b;
}
bool acquireST(const Scene * scene, int trinum, float * st0, float * st1, float *st2, bool *horizontal,bool*vertical, bool*axis_aligned) {
    float kdst[3][4];

    Vec3f locs[3];
    Vec3f bbmin=scene->bboxMin();
    Vec3f bbmax=scene->bboxMax();
    Vec3f emin=scene->bboxMin();
    Vec3f emax=scene->bboxMax();
    if (emax.y-535<1&&emax.y>535)
	emax.y=160;
    bbmax.x=mymax(fabs(bbmax.x),fabs(bbmin.x));
    bbmax.y=mymax(fabs(bbmax.y),fabs(bbmin.y));
    bbmax.z=mymax(fabs(bbmax.z),fabs(bbmin.z));
    bbmin.x=-bbmax.x;
    bbmin.y=-bbmax.y;
    bbmin.z=-bbmax.z;
    for (int i=0;i<3;i++) {
	locs[i].x=(scene->vertices(i)[trinum].v[0]-bbmin.x)/(bbmax.x-bbmin.x);;
	locs[i].y=(scene->vertices(i)[trinum].v[1]-bbmin.y)/(bbmax.y-bbmin.y);
	locs[i].z=(scene->vertices(i)[trinum].v[2]-bbmin.z)/(bbmax.z-bbmin.z);
    }
    *vertical=locs[0].z==locs[1].z&&locs[0].z==locs[2].z;
    *horizontal=locs[0].x==locs[1].x&&locs[0].x==locs[2].x;
    *axis_aligned=(locs[0].y==locs[1].y&&locs[0].y==locs[2].y)||*vertical||*horizontal;
    bool robot=false;
    bool aw=true,bw=true,cw=true,dw=true,ew=true,fw=true;
    int zzz=20;
    for (int i=0;i<3;i++) {
		if (emin.z+zzz>scene->vertices(i)[trinum].v[2]) {
		    //dst[2]=dst[3]=0;
		    //printf ("ScoreB");
		}else aw=false;
		if (emax.z-zzz<scene->vertices(i)[trinum].v[2]){
		    //dst[2]=dst[3]=0;
		    //printf ("ScoreC");
		}else bw=false;
    		if (emin.x+zzz>scene->vertices(i)[trinum].v[0]) {
		    //dst[2]=dst[3]=0;
		    //printf ("ScoreA");
		}else cw=false;
		if (emax.x-zzz<scene->vertices(i)[trinum].v[0]){
		    //dst[2]=dst[3]=0;
		    //printf ("Score");
		}else dw=false;
		if (emin.y+zzz>scene->vertices(i)[trinum].v[1]) {
		    //dst[2]=dst[3]=0;
		    //printf ("ScoreEW");
		}else ew=false;
		if (emax.y+zzz<scene->vertices(i)[trinum].v[1]){
		    //dst[2]=dst[3]=0;
		    //printf ("ScoreF");
		}else fw=false;
    }
    for (int i=0;i<3;i++) {
	float*dst=kdst[i];
	
	bool glassy=scene->specColours()?(scene->specColours()[trinum*3+i].v[0]<.3):false;
	if (aw||bw||cw||dw||fw) {
	    dst[2]=dst[3]=-.5;
	}else if (*axis_aligned) {
            if(*vertical) {
		dst[2]=locs[i].x*4.0f*(glassy?-1:1);
		dst[3]=locs[i].y*8.0f;

            }else if (*horizontal) {
		dst[3]=locs[i].y*8.0f;
		dst[2]=locs[i].z*4.0f*(glassy?-1:1);


            }else {
	      dst[2]=-(float)fmod(.25f+locs[i].x,1.0f)*4;//default use xz mapping
	      dst[3]=-(float)fmod(.25f+locs[i].z,1.0f)*4;


            }
	    
	}else {
	    if (locs[i].x>.25&&locs[i].x<.75&&locs[i].z>.25&&locs[i].z<.75) {
		dst[2]=-(locs[i].x)*4.0f;
		
		dst[3]=-(locs[i].y)*8.0f;
		if (locs[i].x>.25+.125&&locs[i].x<.75-.125&&locs[i].z>.25+.125&&locs[i].z<.75-.125) {
		    robot=true;
		    dst[3]=(locs[i].x-.25f-.125f)*5.0f+.2f;
		    
		    dst[2]=(locs[i].z-.25f-.125f)*5.0f+.2f;
		    if (locs[i].x>.25+.125+.05&&locs[i].x<.75-.125-.05&&locs[i].z>.25+.125&&locs[i].z<.75-.125) {
			dst[3]=(locs[i].x-.25f-.125f-.0625f)*5.0f+.2f;
			
			dst[2]=(locs[i].z-.25f-.125f-.0625f)*5.0f+.2f;
			
			if (locs[i].x>.25+.125+.0625&&locs[i].x<.75-.125-.0625&&locs[i].z>.25+.125+.0625+.03125&&locs[i].z<.75-.125-.0625-.03125) {
			    dst[3]=(locs[i].x-.25f-.125f-.0625f-.03125f)*5.0f+.15f;
			    
			    dst[2]=(locs[i].z-.25f-.125f-.0625f-.03125f)*5.0f+.15f;
			}else if (locs[i].z>.5+.03125&&locs[i].z<.5+.08125&&locs[i].x>.25+.125+.0625&&locs[i].x<.75-.125-.0625) {
			    dst[2]=(locs[i].x-.25f-.125f-.0625f-.03125f)*5.0f+.2f;
			    
			    dst[3]=(locs[i].z-.5f-.03125f)*5.0f+.2f;
			}else if  (locs[i].z < .5-.03125&&locs[i].z > .5-.0625&&
				   .25+.125+.0625<locs[i].x&&
				   locs[i].x<.75-.125-.0625) {
			    dst[3]=(locs[i].x-.25f-.125f-.0625f-.03125f)*5.0f+.2f;			    
			    dst[2]=(locs[i].z-.5f+.03125f)*5.0f+.15f;
			}
			
		    }
		    
		}
		dst[3]=-dst[3];
	    }else {
		dst[2]=locs[i].x*4.0f*(glassy?-1:1);
		dst[3]=locs[i].y*8.0f;
		
	    }
	    
	}
/*
  if (dst[3]>1.0&&dst[3]<2.0) dst[3]=1.0f-dst[3];
  if (dst[2]>1.0&&dst[2]<2.0) dst[2]=1.0f-dst[2];
  if (dst[3]>-1.0&&dst[3]<0.0) dst[3]=-dst[3];
  if (dst[2]>-1.0&&dst[2]<0.0) dst[2]=-dst[2];
*/
	
	
    }
    st0[0]=kdst[0][2];
    st0[1]=kdst[0][3];
    st1[0]=kdst[1][2];
    st1[1]=kdst[1][3];
    st2[0]=kdst[2][2];
    st2[1]=kdst[2][3];
    return robot;
}


void CopyKDTreeGPU( KDTree* builtTree, CtmKdTreeNode* _nodes, BoundingBoxCTM* _bbox)
{
    CopyKDTreeGPUOpt(builtTree,_nodes,_bbox,false);
}


void CopyTrianglesGPU ( unsigned int _triangleCount, const int* builtIndices,
						const F3* v0, const F3* v1, const F3* v2, const BoundingBoxCTM* _bbox,
						float *_triangleDataA, float* _triangleDataB, float* _triangleDataC )
{
   for( uint32 ii = 0; ii < _triangleCount; ii++ )
   {
      F3Packet packet;
      F3 triV0, e1, e2, e2xe1;
      uint32 triangleIndex;
	  triangleIndex = builtIndices[ii];

      triV0 = v0[triangleIndex];
      F3_SUB(e1, v1[triangleIndex], v0[triangleIndex]);
      F3_SUB(e2, v2[triangleIndex], v0[triangleIndex]);
      F3_CROSS(e2xe1, e2, e1);

      packet.v[0] = triV0.v[0]+_bbox->rayOffset.v[0];
      packet.v[1] = triV0.v[1]+_bbox->rayOffset.v[1];
      packet.v[2] = triV0.v[2]+_bbox->rayOffset.v[2];
      packet.v[3] = (float)triangleIndex;//e2xe1.v[0];

      packet.v[4] = e1.v[0];
      packet.v[5] = e1.v[1];
      packet.v[6] = e1.v[2];
      packet.v[7] = (float)triangleIndex;//e2xe1.v[1];

      packet.v[8] = e2.v[0];
      packet.v[9] = e2.v[1];
      packet.v[10] = e2.v[2];
      packet.v[11] = (float)triangleIndex;//sssse2xe1.v[2];

      memcpy(&_triangleDataA[ii*4],&packet.v[0],sizeof(float)*4);//normal cpu-cpu copy, no broadcast
      memcpy(&_triangleDataB[ii*4],&packet.v[4],sizeof(float)*4);//normal cpu-cpu copy, no broadcast
      memcpy(&_triangleDataC[ii*4],&packet.v[8],sizeof(float)*4);//normal cpu-cpu copy, no broadcast
   }
}
void CopyKDTreeGPUFat( KDTree* builtTree, PaddedCtmKdTreeNode* _nodes, BoundingBoxCTM* _bbox, unsigned int kdtreeWidth, bool fetch4)
{
  {
    BoundingBox bounds = builtTree->getBounds();
    for( uint32 ii = 0; ii < 3; ii++ )
    {
      _bbox->rayOffset.v[ii] = 1-bounds.minimum[ii];
      _bbox->min.v[ii] = bounds.minimum[ii]+_bbox->rayOffset.v[ii];
      _bbox->max.v[ii] = bounds.maximum[ii]+_bbox->rayOffset.v[ii];
    }
  }
  uint32 _nodeCount = builtTree->getNodeCount();
  PRINT(("k-d tree node count %d\n", _nodeCount));
  PRINT(("k-d tree triangle index count %d\n", builtTree->getPrimitiveIndexCount()));
  const KDTreeNode* builtNodes = builtTree->getNodes();

  uint32 triangleIndexCount = builtTree->getPrimitiveIndexCount();
  const int* builtIndices = builtTree->getPrimitiveIndices();

  for( uint32 ii = 0; ii < _nodeCount; ii++ )
  {
    if( ii == 1 ) continue;

      KDTreeNode builtNode = builtNodes[ii];
      PaddedCtmKdTreeNode& node = _nodes[ii];

      uint32 splitAxis = builtNode.split.leftChild & 0x3;

      if( splitAxis == 0x3 )
      {
         uint32 firstPrimitiveIndex, primitiveCount;

         primitiveCount = builtNode.leaf.numPrimitives;
         firstPrimitiveIndex = builtNode.leaf.firstPrimitive >> 2;

         node.fatleaf.primitiveCount_tag = (float)primitiveCount;
         node.fatleaf.firstPrimitiveIndex = (float)firstPrimitiveIndex;
	 node.fatleaf.threeSirThree=3.0f;
	 node.fatleaf.pad0=0.0f;
      }
      else
      {
         float splitValue;
         uint32 leftChild;

         splitValue = builtNode.split.splitValue+_bbox->rayOffset.v[splitAxis];
         leftChild = builtNode.split.leftChild >> 3;
	 
         assert( leftChild % 1 == 0 );
         node.fatsplit.leftChildIndexX = (float)(leftChild%kdtreeWidth);//(float)leftChild;//(leftChild%kdtreeWidth);
         node.fatsplit.leftChildIndexY = (float)(leftChild/kdtreeWidth);//(float)splitValue;//(leftChild/kdtreeWidth);
         node.fatsplit.splitValue = splitValue;
	 node.fatsplit.axis=(float)splitAxis;
	 if (fetch4) {
	     node.fatsplit.leftChildIndexX*=2;
	     node.fatsplit.leftChildIndexY*=2;
	 }
      }
   }
}

