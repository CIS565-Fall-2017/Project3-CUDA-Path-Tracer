bool acquireST(const Scene*,int trinum, float*st0, float*st1,float*st2, bool *horizontal, bool * vertical, bool*axis_aligned);
void CopyKDTreeGPUFat( KDTree* builtTree, PaddedCtmKdTreeNode* _nodes, BoundingBoxCTM* _bbox, unsigned int kdtreeWidth, bool fetch4);
template <typename Node> void CopyKDTreeGPUOpt( KDTree* builtTree, Node* _nodes, BoundingBoxCTM* _bbox, bool swizzle)
{
  {
    BoundingBox bounds = builtTree->getBounds();
    for( uint32 ii = 0; ii < 3; ii++ )
    {
      _bbox->rayOffset.v[ii] = 1-bounds.minimum[ii];
      _bbox->min.v[ii] = bounds.minimum[ii]+_bbox->rayOffset.v[ii];
      _bbox->max.v[ii] = bounds.maximum[ii]+_bbox->rayOffset.v[ii];
    }
  }
  uint32 _nodeCount = builtTree->getNodeCount();
  PRINT(("k-d tree node count %d\n", _nodeCount));
  PRINT(("k-d tree triangle index count %d\n", builtTree->getPrimitiveIndexCount()));
  const KDTreeNode* builtNodes = builtTree->getNodes();

  uint32 triangleIndexCount = builtTree->getPrimitiveIndexCount();
  const int* builtIndices = builtTree->getPrimitiveIndices();

  for( uint32 ii = 0; ii < _nodeCount; ii++ )
  {
    if( ii == 1 ) continue;

  KDTreeNode builtNode = builtNodes[ii];
    
      uint32 splitAxis = builtNode.split.leftChild & 0x3;

      if( splitAxis != 0x3 )
          {
         float splitValue;
         uint32 leftChild;

         splitValue = builtNode.split.splitValue+_bbox->rayOffset.v[splitAxis];
         leftChild = builtNode.split.leftChild >> 3;

         assert( leftChild % 1 == 0 );
      }
  }

  for( uint32 ii = 0; ii < _nodeCount; ii++ )
  {
    if( ii == 1 ) continue;

      KDTreeNode builtNode = builtNodes[ii];
      Node& node = _nodes[ii];

      uint32 splitAxis = builtNode.split.leftChild & 0x3;

      if( splitAxis == 0x3 )
      {
         uint32 firstPrimitiveIndex, primitiveCount;

         primitiveCount = builtNode.leaf.numPrimitives;
         firstPrimitiveIndex = builtNode.leaf.firstPrimitive >> 2;

         node.leaf.primitiveCount_tag = (-(float)primitiveCount) -1.0f;
         node.leaf.firstPrimitiveIndex = (-(float)firstPrimitiveIndex) -1.0f;
      }
      else
      {
         float splitValue;
         uint32 leftChild;

         splitValue = builtNode.split.splitValue+_bbox->rayOffset.v[splitAxis];
         leftChild = builtNode.split.leftChild >> 3;

         assert( leftChild % 1 == 0 );

         node.split.leftChildIndex_splitAxis = (float)leftChild;
         node.split.splitValue = splitValue;
         assert(leftChild>0||ii==1);
         if (splitAxis&2)
           node.split.leftChildIndex_splitAxis*=-1.0f;
         assert (splitValue>0);
         if (splitAxis&1)
           node.split.splitValue*=-1.0f;
      }
   }
  if (swizzle) {
      for( uint32 ii = 0; ii < _nodeCount; ii+=2 ){
	  float tmp=_nodes[ii].split.splitValue;
	  _nodes[ii].split.splitValue=_nodes[ii+1].split.leftChildIndex_splitAxis;
	  _nodes[ii+1].split.leftChildIndex_splitAxis=tmp;
	  
      }
  }
}

void CopyKDTreeGPU( KDTree* builtTree, CtmKdTreeNode* _nodes, BoundingBoxCTM* _bbox);
void CopyTrianglesGPU ( unsigned int _triangleCount, const int* builtIndices,
                        const F3* v0, const F3* v1, const F3* v2, const BoundingBoxCTM* _bbox,
                        float *_triangleDataA, float* _triangleDataB, float* _triangleDataC );
