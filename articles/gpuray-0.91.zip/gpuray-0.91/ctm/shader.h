/*
 * shader.h --
 *
 *      CTM shader implementations
 */

#ifndef __CTM_SHADER_H__
#define __CTM_SHADER_H__

#include "ctmTracer.h"  /* For IHitShaderCTM */

struct PixelCTM;

typedef IPixelDisplayerCTM IPixelCallbackCTM;


class DefaultHitShaderCTM : public IStandardShaderCTM
{
   GPUDevice *device;
   bool _gdi;
   const Scene *scene;
   const CameraManager *cam;
   ITracerCTM* tracer;
   uint32 triangleWidth;
   uint32 triangleHeight;
   uint32 verticesGPU;
   uint32 colorsGPU;
   uint32 normalsGPU;
   uint32 specularGPU; // Alpha holds specular exponent.
   uint32 textureGPU;

   uint32 textureWidth,textureHeight;
   uint32 rayColorGPU[4];
   bool rayColorGPUinit;
   uint32 numLoops;
   uint32 maxNumLights;
   float specAddition;
   float specCutoff;
   float ambient;
   float diffuse;//sometimes contained in scene
   int shadow;
   int sceneshadow;
   
public:
    DefaultHitShaderCTM(GPUDevice *dev,
      const Scene *scene,
      const CameraManager *cam,
						ITracerCTM* inTracer, const Opts&inOptions);

   virtual void Shade(
         uint32 inCount,
         const SampleCTM* inSamples,
         const RayCTM* inRays,
         const HitCTM* inHits,
         PixelCTM* ioPixels,
         bool inShouldRelease );

   virtual uint32 GetBatchGranularity() { return 1; }
};


class SimpleShaderCTM : public IStandardShaderCTM
{
public:
   SimpleShaderCTM(const Scene *scene, const CameraManager *cam ) {
      _scene = scene;
      _cam = cam;
   }

   virtual void Shade(
         uint32 inCount,
         const SampleCTM* inSamples,
         const RayCTM* inRays,
         const HitCTM* inHits,
         PixelCTM* ioPixels,
         bool inShouldRelease );

   virtual uint32 GetBatchGranularity() { return 1; }

private:
   const Scene *_scene;
   const CameraManager *_cam;
};

#endif
