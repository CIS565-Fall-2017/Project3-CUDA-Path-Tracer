/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * ctmDisplay.cpp --
 *
 *      Helper classes for displaying pixels traced on the CTM.
 */
#include "ctmDisplay.h"

#include <assert.h>
#include <memory.h>
#include "../fileIO/ppmImage.h"

#ifdef USE_BROOK
#include <brook/brook.hpp>
#endif
WriteImagePixelDisplayerCTM::WriteImagePixelDisplayerCTM(
   ppmImage* inOutputImage )
{
   _outputImage = inOutputImage;
}

void WriteImagePixelDisplayerCTM::Display(
   int inWidth, int inHeight,
   const PixelCTM* inPixels )
{
#ifdef USE_BROOK
    if (inPixels->stream)
	streamWrite(*inPixels->stream,inPixels->AGPmemory);
#endif

   assert( _outputImage->Width() == inWidth );
   assert( _outputImage->Height() == inHeight );
   _outputImage->setByteData(true);
   memcpy( _outputImage->Data(), inPixels->AGPmemory,
           inWidth*inHeight*4*sizeof(char) );
}
