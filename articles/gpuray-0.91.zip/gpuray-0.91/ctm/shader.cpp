/*
 * shader.cpp --
 *
 *      CTM Shader implementation
 */
#include "gpuDevice.h"

#include <math.h>
#include <assert.h>
#include "simdIntrinsics.h"

#include "shader.h"
#include "kdtreeCTM.h"
#include "ctmDisplay.h"
#include "../sampler.h"
#include "../log.h"
#include "common.h"
#include "ppm.h"
/*
 * InterpolateBary --
 *
 *      Takes 3 values and computes their weighted average according to the
 *      specified barycentric weights.
 *
 * Results:
 *      See above (weighted average of v0, v1, v2)
 *
 */

/*
 * ShadeLocalLight --
 *
 *      Helper routine that computes the contribution of the given point
 *      light to given hit.  Currently it only does simple diffuse shading.
 *
 * Results:
 *      void, but *rgb[] is filled in.
 */


static inline uint32 roundUp( uint32 n, uint32 d )
{
   return d * ( (n + d-1) / d );
}

unsigned char floatToChar(float ftc) {
	if (ftc>1)
		return 255;
	if (ftc<0)
		return 0;
	return (unsigned char)(ftc*255);
}

DefaultHitShaderCTM::DefaultHitShaderCTM(
	GPUDevice *dev,
	const Scene *scene,
	const CameraManager *cam,
	ITracerCTM* inTracer, const Opts&inOptions) {
	device = dev;
	this->scene = scene;
	this->cam = cam;
	tracer = inTracer;
	triangleWidth = 4096;
	this->_gdi=inOptions.gdi;
	unsigned int PADDING = 16;
	uint32 numtris = scene->nTris();
	unsigned int tcroundup = numtris/triangleWidth+(numtris%triangleWidth?1:0);
	triangleHeight = 3*PADDING*(tcroundup/PADDING + (tcroundup%PADDING?1:0));
	float *normalsCPU = reinterpret_cast<float*>((unsigned char*)device->outputAddressCPU+device->bytecountAGP);
	uint32 normalsAGP = device->outputAddressGPU+device->bytecountAGP;
	this->normalsGPU = device->info.baseAddressGPU+device->bytecountGPU;
	device->bytecountAGP += 4*triangleWidth*triangleHeight*sizeof(float);
	device->bytecountGPU += 4*triangleWidth*triangleHeight*sizeof(float);
	unsigned char *specularCPU = reinterpret_cast<unsigned char*>((unsigned char*)device->outputAddressCPU+device->bytecountAGP);
	uint32 specularAGP = device->outputAddressGPU+device->bytecountAGP;
	this->specularGPU = device->info.baseAddressGPU+device->bytecountGPU;
	device->bytecountAGP += 4*triangleWidth*triangleHeight*sizeof(char);
	device->bytecountGPU += 4*triangleWidth*triangleHeight*sizeof(char);
	unsigned char *colorsCPU = reinterpret_cast<unsigned char*>((unsigned char*)device->outputAddressCPU+device->bytecountAGP);
	uint32 colorsAGP = device->outputAddressGPU+device->bytecountAGP;
	this->colorsGPU = device->info.baseAddressGPU+device->bytecountGPU;
	device->bytecountAGP += 4*triangleWidth*triangleHeight*sizeof(char);
	device->bytecountGPU += 4*triangleWidth*triangleHeight*sizeof(char);
	float smin=FLT_MAX;
	float smax=-FLT_MAX;
	float emin=FLT_MAX;
	float emax=-FLT_MAX;

	for (uint32 trinum=0;trinum<scene->nTris();trinum++) {


          for (int i=0;i<3;i++) {
            F3 src = scene->normals(i)[trinum];
            float *fdst = &normalsCPU[(trinum%triangleWidth + triangleWidth*(i+3*(trinum/triangleWidth)))*4];
            float dst[4];
            
            dst[0]=src.v[0];
            dst[1]=src.v[1];
            if (src.v[2]<0) dst[0]+=10.0;
            memcpyBroadcast(fdst,dst,sizeof(float)*4);
	  }
	  float kdst[3][2];
	  bool horizontal,vertical,axis_aligned;
          bool robot=acquireST(scene,trinum,kdst[0],kdst[1],kdst[2],&horizontal,&vertical,&axis_aligned);
	  for (int i=0;i<3;++i) {
            float *fdst = &normalsCPU[(trinum%triangleWidth + triangleWidth*(i+3*(trinum/triangleWidth)))*4];

            memcpyBroadcast(fdst+2,kdst[i],sizeof(float)*2);
	  }          
          for (int i=0;i<3;i++) {
			F3 src = scene->colours(i)[trinum];
			unsigned char *fdst = &colorsCPU[(trinum%triangleWidth + triangleWidth*(i+3*(trinum/triangleWidth)))*4];
                        unsigned char dst[4];
			if (axis_aligned&&!horizontal&&!vertical){
			    if (src.v[2]<.5)
				src.v[1]=src.v[2]=src.v[0]=.2f;
			}
			dst[0]=floatToChar(src.v[0]);
			dst[1]=floatToChar(src.v[1]);
			dst[2]=floatToChar(src.v[2]);
			dst[3]=123;
                        memcpyBroadcast(fdst,dst,sizeof(char)*4);
		}
		if (scene->specColours()) {
			for (int i=0;i<3;i++) {
				F3 srcSpec = scene->specColours()[trinum*3+i];
				float srcSpecExp = scene->specExps()[trinum*3+i];
				unsigned char *fdst = &specularCPU[(trinum%triangleWidth + triangleWidth*(i+3*(trinum/triangleWidth)))*4];
                                unsigned char dst[4];
				dst[0]=floatToChar(robot?srcSpec.v[0]*0.0f+1.0f:1.0f- srcSpec.v[0]);
				dst[1]=floatToChar(robot?srcSpec.v[1]*0.0f+1.0f:1.0f-srcSpec.v[1]);
				dst[2]=floatToChar(robot?srcSpec.v[2]*0.0f+1.0f:1.0f-srcSpec.v[2]);
				dst[3]=floatToChar(srcSpecExp?1.0f/srcSpecExp:1.0f);
				if (srcSpecExp<emin)emin=srcSpecExp;
				if (srcSpecExp>emax)emax=srcSpecExp;

				if (srcSpec.v[0]<smin)smin=srcSpec.v[0];
				if (srcSpec.v[0]>smax)smax=srcSpec.v[0];

				if (srcSpec.v[1]<smin)smin=srcSpec.v[1];
				if (srcSpec.v[1]>smax)smax=srcSpec.v[1];

				if (srcSpec.v[2]<smin)smin=srcSpec.v[2];
				if (srcSpec.v[2]>smax)smax=srcSpec.v[2];
                                memcpyBroadcast(fdst,dst,sizeof(char)*4);			
			}
		}else {
			//
		}
			
	}
	if (!scene->specColours()) {
	    memsetBroadcast (specularCPU,0,triangleWidth*triangleHeight*4*sizeof(char));
	}
	//printf ("Specular min %f, specular max %f , exp min %f, exp max %f\n",smin,smax,emin,emax);
	DUALcbufPack* cbp=new DUALcbufPack((( unsigned int* ) device->cbufAddressCPU),1024*512);
	//copy1(cbp, device, colorsAGP, colorsGPU, triangleWidth, triangleHeight, true, AMU_CBUF_FLD_FORMAT_UINT8_4);
///	copy1(cbp, device, verticesAGP, verticesGPU, triangleWidth, triangleHeight, true, AMU_CBUF_FLD_FORMAT_FLOAT32_4);
	copy1(cbp, device, normalsAGP, normalsGPU, triangleWidth, triangleHeight, true, AMU_CBUF_FLD_FORMAT_FLOAT32_4);
	copy1(cbp, device, specularAGP, specularGPU, triangleWidth, triangleHeight*2, true, AMU_CBUF_FLD_FORMAT_UINT8_4);
	AMuint32 cbufsize = cbp->getCommandBufferSize();
    delete cbp;
    unsigned int bufid = dualSubmitCommandBuffer( device->vm, device->cbufAddressGPU, cbufsize );
    while ( dualCommandBufferConsumed( device->vm, bufid ) == 0 ){ ; }
    device->bytecountAGP -= (2*sizeof(float) + 4*sizeof(char) + 4*sizeof(char))*triangleWidth*triangleHeight;
	unsigned char *textureCPU = reinterpret_cast<unsigned char*>((unsigned char*)device->outputAddressCPU+device->bytecountAGP);
	uint32 textureAGP = device->outputAddressGPU+device->bytecountAGP;
	this->textureGPU = device->info.baseAddressGPU+device->bytecountGPU;
	unsigned char *data;

	if (readPPM("scenes/texture.ppm",&data,&textureWidth,&textureHeight)) {
	    uint32 swid,shei;
	    unsigned char * sdata;
	    if (readPPM("scenes/texturespec.ppm",&sdata,&swid,&shei)&&swid==textureWidth&&shei==textureHeight){
		for (uint32 j=0;j<textureHeight;++j) {
		    for (uint32 i=0;i<textureWidth;++i) {
			memcpyBroadcast(textureCPU,data,3);
			textureCPU+=3;
			data+=3;
			memcpyBroadcast(textureCPU,sdata,1);
			textureCPU++;
			sdata+=3;
		    }
		}
		free(sdata);
	    }else {
		for (uint32 j=0;j<textureHeight;++j) {
		    for (uint32 i=0;i<textureWidth;++i) {
			memcpyBroadcast(textureCPU,data,3);
			textureCPU+=3;
			data+=3;
			unsigned char twofiftyfive=255;
			memcpyBroadcast(textureCPU,&twofiftyfive,1);
			textureCPU++;
		    }
		}

	    }
	    free(data);
	}else {	    
	    memsetBroadcast(textureCPU,255,16*16*4);
	    textureWidth=textureHeight=16;
	}
	int modulo=(4*textureWidth*textureHeight*sizeof(char))%2048;
	device->bytecountAGP += 4*textureWidth*textureHeight*sizeof(char)+(modulo?2048-modulo:0);
        
	device->bytecountGPU += 4*textureWidth*textureHeight*sizeof(char)+(modulo?2048-modulo:0);//padding
	cbp=new DUALcbufPack((( unsigned int* ) device->cbufAddressCPU),1024*512);
	copy1(cbp, device, textureAGP, textureGPU, textureWidth, textureHeight, true, AMU_CBUF_FLD_FORMAT_UINT8_4);
 	cbufsize = cbp->getCommandBufferSize();
	delete cbp;
	bufid = dualSubmitCommandBuffer( device->vm, device->cbufAddressGPU, cbufsize );
	while ( dualCommandBufferConsumed( device->vm, bufid ) == 0 ){ ; }
	device->bytecountAGP -= 4*textureWidth*textureHeight*sizeof(char);
	
	rayColorGPUinit=false;
	numLoops=GetKeyValueInt("bounces",inOptions.shadeOpts,2)+1;
	this->shadow=this->sceneshadow=GetKeyValueInt("shadow",inOptions.shadeOpts,0);
	maxNumLights=GetKeyValueInt("numLights",inOptions.shadeOpts,3);
	specAddition=GetKeyValueFloat("specAdd",inOptions.shadeOpts,.1f);
	specCutoff=GetKeyValueFloat("specCutoff",inOptions.shadeOpts,.01f);
	ambient=GetKeyValueFloat("ambient",inOptions.shadeOpts,maxNumLights==0?.2f:0.0f);
	diffuse=GetKeyValueFloat("diffuse",inOptions.shadeOpts,maxNumLights==0?.8f:0.0f);
}
extern bool morebounces;
extern bool lessbounces;
extern bool morespec;
extern bool lessspec;
extern bool morecutoff;
extern bool lesscutoff;
extern bool toggleshadow;
void
DefaultHitShaderCTM::Shade(
   uint32 inCount,
   const SampleCTM* inSamples,
   const RayCTM* inRays,
   const HitCTM* inHits,
   PixelCTM* ioPixels,
   bool inShouldRelease )
{
    if (toggleshadow) {

	if (shadow) shadow=0;
	else shadow=sceneshadow;
	toggleshadow=false;
    }
	if (morespec) {
		specAddition+=.05f;
		morespec=false;
	}
	if (lessspec) {
		specAddition-=.05f;
		lessspec=false;
	}

	if (morecutoff) {
		specCutoff+=.0125f;
		morecutoff=false;
	}
	if (lesscutoff) {
		specCutoff-=.0125f;
		lesscutoff=false;
	}

	if(morebounces) {
		numLoops++;
		morebounces=false;
	}
	if (lessbounces) {
		if (numLoops>1)
			numLoops--;
		lessbounces=false;
	}
	//uint32 numLoops=3;
	bool final=false;
	bool firstloop=true;
	uint32 Width = inRays->width;
	uint32 Height = inRays->height;
	uint32 rayColorAGP[4];
	PixelCTM *rayColorCPU[4];

	RayGPUCTM newRays[2]={*inRays,*inRays};
	newRays[0].ResetOrigin();
	newRays[1].ResetOrigin();
	newRays[1].rays.ctm.ptr=device->info.baseAddressGPUb;

	for (uint32 bounce=0;bounce<numLoops;bounce++) {
		if (bounce==numLoops-1) {
			final=true;
		}
		if (bounce>0) {
			firstloop=false;
		}
		DUALcbufPack cbpMem((( unsigned int* ) device->cbufAddressCPU),1024*512);
		DUALcbufPack *cbp = &cbpMem;
		float inoutWeight[4]={1.0,1.0,0.0,0.0};
		if (firstloop) {
			inoutWeight[0]=0.0;
			inoutWeight[1]=1.0;
		}
		if (!rayColorGPUinit) {
			rayColorGPUinit=true;
			rayColorGPU[0] = device->bytecountGPU + device->info.baseAddressGPU;
			device->bytecountGPU += 4*sizeof(char)*Width*Height;
			rayColorGPU[1] = device->bytecountGPU + device->info.baseAddressGPU;
			device->bytecountGPU += 4*sizeof(char)*Width*Height;
			rayColorGPU[2] = device->bytecountGPU + device->info.baseAddressGPU;
			device->bytecountGPU += 4*sizeof(char)*Width*Height;
			rayColorGPU[3] = device->bytecountGPU + device->info.baseAddressGPU;
			device->bytecountGPU += 4*sizeof(char)*Width*Height;
		}
		if (final&&0) {
			rayColorAGP[0] = device->info.baseAddressSYSc;
			rayColorCPU[0] = (PixelCTM*)((char*)device->info.baseAddressCPUc);
			rayColorAGP[1] = device->info.baseAddressSYSc+Width*Height*4;
			rayColorCPU[1] = (PixelCTM*)((char*)device->info.baseAddressCPUc+Width*Height*4);
			rayColorAGP[2] = device->info.baseAddressSYSc+Width*Height*8;
			rayColorCPU[2] = (PixelCTM*)((char*)device->info.baseAddressCPUc+Width*Height*8);
			rayColorAGP[3] = device->info.baseAddressSYSc+Width*Height*12;
			rayColorCPU[3] = (PixelCTM*)((char*)device->info.baseAddressCPUc+Width*Height*12);
		} else {
			rayColorAGP[0]=rayColorGPU[0];
			rayColorAGP[1]=rayColorGPU[1];
			rayColorAGP[2]=rayColorGPU[2];
			rayColorAGP[3]=rayColorGPU[3];
		}





//UPDATE ORIGIN
		float raysO[4]={newRays[(bounce)%2].raysO.v[0],//rays[0].o.v[0]+_bbox->rayOffset.v[0],
						newRays[(bounce)%2].raysO.v[1],//rays[0].o.v[BUNDLE_SIZE]+_bbox->rayOffset.v[1],
						newRays[(bounce)%2].raysO.v[2],//rays[0].o.v[2*BUNDLE_SIZE]+_bbox->rayOffset.v[2],
						6.123456789f};
		if (firstloop) {
			raysO[0]=inRays->raysO.v[0];
			raysO[1]=inRays->raysO.v[1];
			raysO[2]=inRays->raysO.v[2];
		}
		setUserConstant (device,device->originShader_constants,device->fconstOriginShaderAddressCPU,"c5",raysO,AMU_ABI_FLOAT32);
		cbp->appendSetInpFmt( 0, newRays[(bounce)%2].rays.ctm.ptr,   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  inRays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:0, Width,Height);
		cbp->appendSetInpFmt( 1, newRays[(bounce)%2].rays.ctm.ptr+Width*Height*sizeof(float)*4,   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  inRays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:0, Width,Height);
		cbp->appendSetInpFmt( 2, newRays[(bounce)%2].rays.ctm.ptr+Width*Height*sizeof(float)*8,   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  inRays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:0, Width,Height);
		cbp->appendSetInpFmt( 3, newRays[(bounce)%2].rays.ctm.ptr+Width*Height*sizeof(float)*12,   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  inRays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:0, Width,Height);
		cbp->appendSetInpFmt( 13, inHits->tHitPtr.ctm.ptr, AMU_CBUF_FLD_FORMAT_FLOAT32_4,  AMU_CBUF_FLD_TILING_TILED0, Width,Height);
		cbp->appendSetInpFmt( 14, newRays[(bounce)%2].rays.ctm.ptr+Width*Height*sizeof(float)*16,   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  inRays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:0, Width,Height);
		cbp->appendSetInpFmt( 15, newRays[(bounce)%2].rays.ctm.ptr+Width*Height*sizeof(float)*20,   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  inRays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:0, Width,Height);

		for (unsigned int i=0;i<16;++i) {
			char name[4]={'s','1','0'+(i%10),'\0'};
			if (i<10) {
				name[1]=name[2];
				name[2]=name[3];
			}
			// FIXME which one?
			//setUserConstant (device,device->originShader_constants,device->iconstOriginShaderAddressCPU,name,&i,AMU_ABI_INT32);
			setUserConstant (device,device->originShader_constants,device->fconstOriginShaderAddressCPU,name,&i,AMU_ABI_INT32);
		}
		cbp->appendFlushOutCache();		
		setLiteralConstants(device, device->originShader_constants, device->fconstOriginShaderAddressCPU, device->iconstOriginShaderAddressCPU );
               cbp->appendSetOutFmt( 0, newRays[(1+bounce)%2].rays.ctm.ptr+12*sizeof(float)*Width*Height, AMU_CBUF_FLD_FORMAT_FLOAT32_4, inRays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:AMU_CBUF_FLD_TILING_LINEAR, Width, Height );
               cbp->appendSetOutFmt( 1, newRays[(1+bounce)%2].rays.ctm.ptr+16*sizeof(float)*Width*Height, AMU_CBUF_FLD_FORMAT_FLOAT32_4, inRays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:AMU_CBUF_FLD_TILING_LINEAR, Width, Height );
               cbp->appendSetOutFmt( 2, newRays[(1+bounce)%2].rays.ctm.ptr+20*sizeof(float)*Width*Height, AMU_CBUF_FLD_FORMAT_FLOAT32_4, inRays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:AMU_CBUF_FLD_TILING_LINEAR, Width, Height );

		cbp->appendSetInstFmt( device->originShaderKernelAddressGPU, 0, 0, 0 );
		cbp->appendInvInstCache();
		cbp->appendSetConstfFmt( device->fconstOriginShaderAddressGPU, 0, 0, 0 );
		cbp->appendInvConstfCache();
		// Integers
		//cbp->appendSetConstiFmt( device->iconstOriginShaderAddressGPU, 0, 0, 0 );
		//cbp->appendInvConstiCache();
		// Set domain of output
		cbp->appendSetDomainTiled( 0, 0, Width - 1, Height - 1 );
		// After setting everything up, start program
		cbp->appendStartProgram();

//SHADE

		cbp->appendInvInpCache(); // optimization - we do need this because hitTT shares with rayColorGPU[3] (13)
		cbp->appendSetInpFmt( 0, newRays[(bounce)%2].rays.ctm.ptr,   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  inRays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:0, Width,Height);
		cbp->appendSetInpFmt( 1, newRays[(bounce)%2].rays.ctm.ptr+Width*Height*sizeof(float)*4,   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  inRays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:0, Width,Height);
		cbp->appendSetInpFmt( 2, newRays[(bounce)%2].rays.ctm.ptr+Width*Height*sizeof(float)*8,   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  inRays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:0, Width,Height);
		cbp->appendSetInpFmt( 3, newRays[(1+bounce)%2].rays.ctm.ptr+Width*Height*sizeof(float)*12,   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  inRays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:0, Width,Height);
//		cbp->appendSetInpFmt( 3, inHits->tHitPtr.ctm.ptr, AMU_CBUF_FLD_FORMAT_FLOAT32_4,  AMU_CBUF_FLD_TILING_TILED0, Width,Height);//ack ran out of texture units--- deal with the tt in the updateOrigin function hopefully we don't need fog---if so need separate pass
		cbp->appendSetInpFmt( 4, inHits->uuPtr.ctm.ptr,   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  AMU_CBUF_FLD_TILING_TILED0, Width,Height);
		cbp->appendSetInpFmt( 5, inHits->vvPtr.ctm.ptr,   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  AMU_CBUF_FLD_TILING_TILED0, Width,Height);
		cbp->appendSetInpFmt( 6, inHits->triNumPtr.ctm.ptr,   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  AMU_CBUF_FLD_TILING_TILED0, Width,Height);
		cbp->appendSetInpFmt( 7, normalsGPU, AMU_CBUF_FLD_FORMAT_FLOAT32_4,  AMU_CBUF_FLD_TILING_TILED0, triangleWidth, triangleHeight);
		cbp->appendSetInpFmt( 8, specularGPU, AMU_CBUF_FLD_FORMAT_UINT8_4,  AMU_CBUF_FLD_TILING_TILED0, triangleWidth, triangleHeight*2);
                cbp->appendSetInpFmt( 9, textureGPU, AMU_CBUF_FLD_FORMAT_UINT8_4,  AMU_CBUF_FLD_TILING_TILED0, textureWidth, textureHeight);
		cbp->appendSetInpFmt( 10, rayColorGPU[0], AMU_CBUF_FLD_FORMAT_UINT8_4, AMU_CBUF_FLD_TILING_TILED0, Width, Height );
		cbp->appendSetInpFmt( 11, rayColorGPU[1], AMU_CBUF_FLD_FORMAT_UINT8_4, AMU_CBUF_FLD_TILING_TILED0, Width, Height );
		cbp->appendSetInpFmt( 12, rayColorGPU[2], AMU_CBUF_FLD_FORMAT_UINT8_4, AMU_CBUF_FLD_TILING_TILED0, Width, Height );
		cbp->appendSetInpFmt( 13, rayColorGPU[3], AMU_CBUF_FLD_FORMAT_UINT8_4, AMU_CBUF_FLD_TILING_TILED0, Width, Height );
		cbp->appendSetInpFmt( 14, newRays[(1+bounce)%2].rays.ctm.ptr+Width*Height*sizeof(float)*16,   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  inRays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:0, Width,Height);
		cbp->appendSetInpFmt( 15, newRays[(1+bounce)%2].rays.ctm.ptr+Width*Height*sizeof(float)*20,   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  inRays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:0, Width,Height);

		
		float rayIndexOffset[4]={0,(float)Height,0,0};
		float bboxMin[4]={inRays->bbox.min.v[0],inRays->bbox.min.v[1],inRays->bbox.min.v[2]};
		float bboxMax[4]={inRays->bbox.max.v[0],inRays->bbox.max.v[1],inRays->bbox.max.v[2]};
		float rayOffset[4]={inRays->bbox.rayOffset.v[0],inRays->bbox.rayOffset.v[1],inRays->bbox.rayOffset.v[2]};
		float hitTTdims[4]={(float)Width,(float)Height};
                float useShadow[4]={(float)this->shadow,0,0,0};

                uint32 numlight=scene->numLights();
                if (numlight>maxNumLights)numlight=maxNumLights;
		float sceneSize[4]={(float)triangleWidth, (float)triangleHeight, (float)numlight, 0.f};
//                printf ("Using %d lights (max lights %d)\n",numlight,maxNumLights);
		if (scene->numLights()>3&&maxNumLights>3) {
			printf ("ERROR Scene uses %d lights!!! Currently shader hardcoded to only use 3 to prevent hourlong compile times with fxc and increase potential runtime\n",scene->numLights());
		}
		float specAdditionAndCutoff[4]={specAddition,specCutoff,ambient,diffuse};
		setUserConstant(device, device->uberShader_constants, device->fconstUberShaderAddressCPU, "c2",bboxMin,  AMU_ABI_FLOAT32 );
		setUserConstant(device, device->uberShader_constants, device->fconstUberShaderAddressCPU, "c3",bboxMax,  AMU_ABI_FLOAT32 );
		setUserConstant(device, device->uberShader_constants, device->fconstUberShaderAddressCPU, "c6",rayIndexOffset,  AMU_ABI_FLOAT32 );
		setUserConstant(device, device->uberShader_constants, device->fconstUberShaderAddressCPU, "c7",rayOffset,  AMU_ABI_FLOAT32 );
		setUserConstant(device, device->uberShader_constants, device->fconstUberShaderAddressCPU, "c16", sceneSize,  AMU_ABI_FLOAT32 );
		setUserConstant(device, device->uberShader_constants, device->fconstUberShaderAddressCPU, "c17", inoutWeight,  AMU_ABI_FLOAT32 );
		setUserConstant(device, device->uberShader_constants, device->fconstUberShaderAddressCPU, "c18", specAdditionAndCutoff,  AMU_ABI_FLOAT32 );
		float textureSize[4]={(float)textureWidth-1.0f,(float)textureHeight-1.0f,0.0f,0.0f};
		setUserConstant(device, device->uberShader_constants, device->fconstUberShaderAddressCPU, "c20", textureSize,  AMU_ABI_FLOAT32);
		setUserConstant(device, device->uberShader_constants, device->fconstUberShaderAddressCPU, "c31",hitTTdims,  AMU_ABI_FLOAT32 );
		float zed[4]={0};
		setUserConstant(device, device->uberShader_constants, device->fconstUberShaderAddressCPU, "c48",zed,  AMU_ABI_FLOAT32 );
		for (unsigned int i=0;i<scene->numLights()&&i<8;++i) {
			LightInfo light = scene->pointLight(i);
			char c0[4]={'c','0'+(i+32)/10,'0'+(i+32)%10,'\0'};
			char c1[4]={'c','0'+(i+40)/10,'0'+(i+40)%10,'\0'};
			float pos[4]={light.position.x+inRays->bbox.rayOffset.v[0], light.position.y+inRays->bbox.rayOffset.v[1], light.position.z+inRays->bbox.rayOffset.v[2]};
			float intensityAtten[4]={light.diffIntensity.x, light.diffIntensity.y, light.diffIntensity.z, 1.f/(light.distAtten*light.distAtten)};
			setUserConstant(device, device->uberShader_constants, device->fconstUberShaderAddressCPU, c0, pos, AMU_ABI_FLOAT32 );
			setUserConstant(device, device->uberShader_constants, device->fconstUberShaderAddressCPU, c1, intensityAtten, AMU_ABI_FLOAT32 );
		}

    
		for (unsigned int i=0;i<16;++i) {
			char name[4]={'s','1','0'+(i%10),'\0'};
			if (i<10) {
				name[1]=name[2];
				name[2]=name[3];
			}
			// FIXME which one?
			//setUserConstant (device,device->uberShader_constants,device->iconstUberShaderAddressCPU,name,&i,AMU_ABI_INT32);
			setUserConstant (device,device->uberShader_constants,device->fconstUberShaderAddressCPU,name,&i,AMU_ABI_INT32);
		}
		cbp->appendSetOutFmt( 0, rayColorAGP[0], AMU_CBUF_FLD_FORMAT_UINT8_4, 1||final==false?AMU_CBUF_FLD_TILING_TILED0:AMU_CBUF_FLD_TILING_LINEAR, Width, Height );
		cbp->appendSetOutFmt( 1, rayColorAGP[1], AMU_CBUF_FLD_FORMAT_UINT8_4, 1||final==false?AMU_CBUF_FLD_TILING_TILED0:AMU_CBUF_FLD_TILING_LINEAR, Width, Height );
		cbp->appendSetOutFmt( 2, rayColorAGP[2], AMU_CBUF_FLD_FORMAT_UINT8_4, 1||final==false?AMU_CBUF_FLD_TILING_TILED0:AMU_CBUF_FLD_TILING_LINEAR, Width, Height );
		cbp->appendSetOutFmt( 3, rayColorAGP[3], AMU_CBUF_FLD_FORMAT_UINT8_4, 1||final==false?AMU_CBUF_FLD_TILING_TILED0:AMU_CBUF_FLD_TILING_LINEAR, Width, Height );
    
		cbp->appendFlushOutCache();
		setLiteralConstants(device, device->uberShader_constants, device->fconstUberShaderAddressCPU, device->iconstUberShaderAddressCPU );
		cbp->appendSetInstFmt( device->uberShaderKernelAddressGPU, 0, 0, 0 );
		cbp->appendInvInstCache();
		cbp->appendSetConstfFmt( device->fconstUberShaderAddressGPU, 0, 0, 0 );
		cbp->appendInvConstfCache();
		// Integers
		cbp->appendSetConstiFmt( device->iconstUberShaderAddressGPU, 0, 0, 0 );
		cbp->appendInvConstiCache();
		// Set domain of output
		cbp->appendSetDomainTiled( 0, 0, Width - 1, Height - 1 );
		// After setting everything up, start program
		//if (final||firstloop)
			cbp->appendStartProgram();


//BOUNCE DIRECTION

		if (!final) {



			setUserConstant(device, device->bounceShader_constants, device->fconstBounceShaderAddressCPU, "c2",bboxMin,  AMU_ABI_FLOAT32 );
			setUserConstant(device, device->bounceShader_constants, device->fconstBounceShaderAddressCPU, "c3",bboxMax,  AMU_ABI_FLOAT32 );
			setUserConstant(device, device->bounceShader_constants, device->fconstBounceShaderAddressCPU, "c16", sceneSize,  AMU_ABI_FLOAT32 );
			setUserConstant(device, device->bounceShader_constants, device->fconstBounceShaderAddressCPU, "c18", specAdditionAndCutoff,  AMU_ABI_FLOAT32 );
                        setUserConstant(device, device->bounceShader_constants, device->fconstBounceShaderAddressCPU, "c19", useShadow,  AMU_ABI_FLOAT32 );

			setUserConstant(device, device->bounceShader_constants, device->fconstBounceShaderAddressCPU, "c31",hitTTdims,  AMU_ABI_FLOAT32 );
		for (unsigned int i=0;i<scene->numLights()&&i<8;++i) {
			LightInfo light = scene->pointLight(i);
			char c0[4]={'c','0'+(i+32)/10,'0'+(i+32)%10,'\0'};
			char c1[4]={'c','0'+(i+40)/10,'0'+(i+40)%10,'\0'};
			float pos[4]={light.position.x+inRays->bbox.rayOffset.v[0], light.position.y+inRays->bbox.rayOffset.v[1], light.position.z+inRays->bbox.rayOffset.v[2]};
			float intensityAtten[4]={light.diffIntensity.x, light.diffIntensity.y, light.diffIntensity.z, 1.f/(light.distAtten*light.distAtten)};
			setUserConstant(device, device->bounceShader_constants, device->fconstBounceShaderAddressCPU, c0, pos, AMU_ABI_FLOAT32 );
			setUserConstant(device, device->bounceShader_constants, device->fconstBounceShaderAddressCPU, c1, intensityAtten, AMU_ABI_FLOAT32 );
		}


			for (unsigned int i=0;i<16;++i) {
				char name[4]={'s','1','0'+(i%10),'\0'};
				if (i<10) {
					name[1]=name[2];
					name[2]=name[3];
				}
				// FIXME which one?
				//setUserConstant (device,device->bounceShader_constants,device->iconstBounceShaderAddressCPU,name,&i,AMU_ABI_INT32);
				setUserConstant (device,device->bounceShader_constants,device->fconstBounceShaderAddressCPU,name,&i,AMU_ABI_INT32);
			}
			cbp->appendFlushOutCache();		
			setLiteralConstants(device, device->bounceShader_constants, device->fconstBounceShaderAddressCPU, device->iconstBounceShaderAddressCPU );
			cbp->appendSetInpFmt( 0, true?newRays[bounce%2].rays.ctm.ptr:device->outputAddressGPU+device->bytecountAGP,   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  inRays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:0, Width,Height);
			cbp->appendSetInpFmt( 1, true?newRays[bounce%2].rays.ctm.ptr+Width*Height*sizeof(float)*4:device->outputAddressGPU+device->bytecountAGP+4*sizeof(float)*Width*Height,   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  inRays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:0, Width,Height);
			cbp->appendSetInpFmt( 2, true?newRays[bounce%2].rays.ctm.ptr+Width*Height*sizeof(float)*8:device->outputAddressGPU+device->bytecountAGP+8*sizeof(float)*Width*Height,   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  inRays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:0, Width,Height);
			cbp->appendSetInpFmt( 3, newRays[(bounce+1)%2].rays.ctm.ptr+Width*Height*sizeof(float)*12,   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  inRays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:0, Width,Height);
//		cbp->appendSetInpFmt( 3, inHits->tHitPtr, AMU_CBUF_FLD_FORMAT_FLOAT32_4,  AMU_CBUF_FLD_TILING_TILED0, Width,Height);
			cbp->appendSetInpFmt( 4, inHits->uuPtr.ctm.ptr,   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  AMU_CBUF_FLD_TILING_TILED0, Width,Height);
			cbp->appendSetInpFmt( 5, inHits->vvPtr.ctm.ptr,   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  AMU_CBUF_FLD_TILING_TILED0, Width,Height);
			cbp->appendSetInpFmt( 6, inHits->triNumPtr.ctm.ptr,   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  AMU_CBUF_FLD_TILING_TILED0, Width,Height);
			cbp->appendSetInpFmt( 7, normalsGPU, AMU_CBUF_FLD_FORMAT_FLOAT32_4,  AMU_CBUF_FLD_TILING_TILED0, triangleWidth, triangleHeight);
			cbp->appendSetInpFmt( 8, specularGPU, AMU_CBUF_FLD_FORMAT_UINT8_4,  AMU_CBUF_FLD_TILING_TILED0, triangleWidth, triangleHeight*2);
			cbp->appendSetInpFmt( 13, rayColorGPU[3], AMU_CBUF_FLD_FORMAT_UINT8_4, AMU_CBUF_FLD_TILING_TILED0, Width, Height );
			cbp->appendSetInpFmt( 14, newRays[(1+bounce)%2].rays.ctm.ptr+Width*Height*sizeof(float)*16,   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  inRays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:0, Width,Height);
			cbp->appendSetInpFmt( 15, newRays[(1+bounce)%2].rays.ctm.ptr+Width*Height*sizeof(float)*20,   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  inRays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:0, Width,Height);
			cbp->appendSetOutFmt( 0, newRays[(1+bounce)%2].rays.ctm.ptr, AMU_CBUF_FLD_FORMAT_FLOAT32_4, inRays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:AMU_CBUF_FLD_TILING_LINEAR, Width, Height );
			cbp->appendSetOutFmt( 1, newRays[(1+bounce)%2].rays.ctm.ptr+4*sizeof(float)*Width*Height, AMU_CBUF_FLD_FORMAT_FLOAT32_4, inRays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:AMU_CBUF_FLD_TILING_LINEAR, Width, Height );
			cbp->appendSetOutFmt( 2, newRays[(1+bounce)%2].rays.ctm.ptr+8*sizeof(float)*Width*Height, AMU_CBUF_FLD_FORMAT_FLOAT32_4, inRays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:AMU_CBUF_FLD_TILING_LINEAR, Width, Height );
//			cbp->appendSetOutFmt( 3, device->outputAddressGPU+device->bytecountAGP+12*sizeof(float)*Width*Height, AMU_CBUF_FLD_FORMAT_FLOAT32_4, inRays->tiled?AMU_CBUF_FLD_TILING_TILED0:AMU_CBUF_FLD_TILING_LINEAR, Width, Height );
			cbp->appendSetInstFmt( device->bounceShaderKernelAddressGPU, 0, 0, 0 );
			cbp->appendInvInstCache();
			cbp->appendSetConstfFmt( device->fconstBounceShaderAddressGPU, 0, 0, 0 );
			cbp->appendInvConstfCache();
			// Integers
			cbp->appendSetConstiFmt( device->iconstBounceShaderAddressGPU, 0, 0, 0 );
			cbp->appendInvConstiCache();
			cbp->appendInvInpCache();
			// Set domain of output
			cbp->appendSetDomainTiled( 0, 0, Width - 1, Height - 1 );
			// After setting everything up, start program
			cbp->appendStartProgram();

/*CPU version--d0esnt' work with read/modify/write
			cbp->appendSetOutFmt( 0, device->outputAddressGPU+device->bytecountAGP, AMU_CBUF_FLD_FORMAT_FLOAT32_4, inRays->tiled?AMU_CBUF_FLD_TILING_TILED0:AMU_CBUF_FLD_TILING_LINEAR, Width, Height );
			cbp->appendSetOutFmt( 1,  device->outputAddressGPU+device->bytecountAGP+4*sizeof(float)*Width*Height, AMU_CBUF_FLD_FORMAT_FLOAT32_4, inRays->tiled?AMU_CBUF_FLD_TILING_TILED0:AMU_CBUF_FLD_TILING_LINEAR, Width, Height );
			cbp->appendSetOutFmt( 2, device->outputAddressGPU+device->bytecountAGP+8*sizeof(float)*Width*Height, AMU_CBUF_FLD_FORMAT_FLOAT32_4, inRays->tiled?AMU_CBUF_FLD_TILING_TILED0:AMU_CBUF_FLD_TILING_LINEAR, Width, Height );
			cbp->appendSetOutFmt( 3, device->outputAddressGPU+device->bytecountAGP+12*sizeof(float)*Width*Height, AMU_CBUF_FLD_FORMAT_FLOAT32_4, inRays->tiled?AMU_CBUF_FLD_TILING_TILED0:AMU_CBUF_FLD_TILING_LINEAR, Width, Height );
			cbp->appendStartProgram();
*/
		}
		AMuint32 cbufsize = cbp->getCommandBufferSize();
		unsigned int bufid = dualSubmitCommandBuffer( device->vm, device->cbufAddressGPU, cbufsize );
		while ( dualCommandBufferConsumed( device->vm, bufid ) == 0 ){ ; }

		if (!final) {
/*
			float *mem=(float*)((char*)device->outputAddressCPU+device->bytecountAGP);
			printf("inp %f %f %f %f\n",mem[Width*Height*12],mem[Width*Height*12+1],mem[Width*Height*12+2],mem[Width*Height*12+3]);
			printf("outRays at %x %f %f %f\n",newRays[(1+bounce)%2].ptr,mem[0],mem[Width*Height*4],mem[Width*Height*8]);
*/
			fflush(stdout);
			if (1) {//firstloop) {
				inHits->intersector->intersect(&newRays[(bounce+1)%2],inCount,const_cast<HitCTM*>(inHits));//fixme ugly 
			}
		}
		if (shadow) break;
	}
        fflush(stderr);
        std::vector <PixelCTM*>dRayColorCPU[4];
        dRayColorCPU[0].resize(numCards);
        dRayColorCPU[1].resize(numCards);
        dRayColorCPU[2].resize(numCards);
        dRayColorCPU[3].resize(numCards);
        {
          for (int cardNo=0;cardNo<numCards;++cardNo) {
            for (unsigned int j=0;j<4;++j) {
              dRayColorCPU[j][cardNo]=pointerTrans(rayColorCPU[j],cardNo);
            }
          }
        }
        int cardNo=0;

        PixelCTM*d0=dRayColorCPU[0][cardNo];
        PixelCTM*d1=dRayColorCPU[1][cardNo];
        PixelCTM*d2=dRayColorCPU[2][cardNo];
	gltilesize*=2;
	DUALcbufPack cbpMem((( unsigned int* ) device->cbufAddressCPU),1024*512);

	DUALcbufPack* cbp=&cbpMem;
        unsigned int outerCardNo=0;
        int GDIadd=_gdi?0:Height*2-1;
        int GDIaddID=_gdi?0:1;
        int GDImul=_gdi?1:-1;
        float gdiarray[4]={(float)GDIadd,(float)shadow,(float)GDImul,(float)_gdi};
        setUserConstant (device,device->swizzleDisplay_constants,device->fconstSwizzleDisplayAddressCPU,"c0",gdiarray,AMU_ABI_FLOAT32);
        unsigned int s0=0;
        unsigned int s1=1;
        unsigned int s2=2;
        setUserConstant (device,device->swizzleDisplay_constants,device->fconstSwizzleDisplayAddressCPU,"s0",&s0,AMU_ABI_INT32);
        setUserConstant (device,device->swizzleDisplay_constants,device->fconstSwizzleDisplayAddressCPU,"s1",&s1,AMU_ABI_INT32);
        setUserConstant (device,device->swizzleDisplay_constants,device->fconstSwizzleDisplayAddressCPU,"s2",&s2,AMU_ABI_INT32);//iconst
        
        cbp->appendSetInpFmt( 0, rayColorAGP[0], AMU_CBUF_FLD_FORMAT_UINT8_4, 1||final==false?AMU_CBUF_FLD_TILING_TILED0:AMU_CBUF_FLD_TILING_LINEAR, Width, Height );
        cbp->appendSetInpFmt( 1, rayColorAGP[1], AMU_CBUF_FLD_FORMAT_UINT8_4, 1||final==false?AMU_CBUF_FLD_TILING_TILED0:AMU_CBUF_FLD_TILING_LINEAR, Width, Height );
        cbp->appendSetInpFmt( 2, rayColorAGP[2], AMU_CBUF_FLD_FORMAT_UINT8_4, 1||final==false?AMU_CBUF_FLD_TILING_TILED0:AMU_CBUF_FLD_TILING_LINEAR, Width, Height );
        cbp->appendSetInpFmt( 3, inHits->tHitPtr.ctm.ptr, AMU_CBUF_FLD_FORMAT_FLOAT32_4, AMU_CBUF_FLD_TILING_TILED0, Width, Height );
	bool useCachedOutput=true;
	unsigned char * hostMem=(unsigned char*)(useCachedOutput?device->info.baseAddressCPUc:((unsigned char*)device->outputAddressCPU+device->bytecountAGP));
	AMuint32 hostAGP=useCachedOutput?device->info.baseAddressSYSc:(device->outputAddressGPU+device->bytecountAGP);
        
        cbp->appendSetOutFmt( 0, hostAGP, AMU_CBUF_FLD_FORMAT_UINT8_4, AMU_CBUF_FLD_TILING_LINEAR, Width*2, Height*2 );
        cbp->appendFlushOutCache();
        setLiteralConstants(device, device->swizzleDisplay_constants, device->fconstSwizzleDisplayAddressCPU, device->iconstSwizzleDisplayAddressCPU );
        cbp->appendSetInstFmt( device->swizzleDisplayKernelAddressGPU, 0, 0, 0 );
        cbp->appendInvInstCache();
        cbp->appendSetConstfFmt( device->fconstSwizzleDisplayAddressGPU, 0, 0, 0 );
        cbp->appendInvConstfCache();

        cbp->appendSetDomainTiled( 0, 0, Width*2 - 1, Height*2 - 1 );//this should be fixed to be specialtiled
        // After setting everything up, start program
        cbp->appendStartProgram();
        cbp->appendFlushOutCache();
        AMuint32 cbufsize = cbp->getCommandBufferSize();
        unsigned int bufid = dualSubmitCommandBuffer( device->vm, device->cbufAddressGPU, cbufsize );
        while ( dualCommandBufferConsumed( device->vm, bufid ) == 0 ){ ; }

                
        
        
        if (Height*2%gltilesize!=0) {
          fprintf (stderr,"Framebuffer %d not divisible by tilesize %d\n",Height,gltilesize);
        }
        if (Width*2%gltilesize!=0) {
          fprintf (stderr,"Framebuffer %d not divisible by tilesize %d\n",Width,gltilesize);
        }
	ioPixels->AGPmemory=pointerTrans(hostMem,0);
	if (numCards>1) {
	    for (uint32 ii=0;ii<Height*2;ii+=gltilesize) {
		uint32 ilim=ii+gltilesize;
		for (uint32 i=ii;i<ilim;++i) {         
		    cardNo=outerCardNo;
		    
		    for (uint32 jj=0;jj<Width*2;jj+=gltilesize) {
			size_t offset=(i*Width*2+jj)*4;
			if (cardNo!=0)
			    memcpy((char*)ioPixels->AGPmemory+offset,pointerTrans(hostMem,cardNo)+offset,gltilesize*4);
			cardNo++;
			cardNo%=numCards;
		    }
		}
		cardNo++;
		cardNo%=numCards;
		outerCardNo=cardNo;
	    }
	}else {
	    //memcpy(*ioPixels,pointerTrans(hostMem,0),Width*Height*4*4);
	}
	gltilesize/=2;

}
//   device->bytecount -= Width*Height*sizeof(char)*16;
