#include "ctmTracer.h"

#include "../timer.h"
#include "../sampler.h"
#include "../log.h"
#include "brooktracer.hpp"
static float float_min (float a, float b) {
  return a>b?b:a;
}
static float float_max (float a, float b) {
  return a>b?a:b;
}

RayGeneratorNewBrook::RayGeneratorNewBrook(
   CameraManager* inCameraManager,
   IPrimaryRayCallbackCTM* inContinuation,
   BoundingBoxCTM* bbox )
{
   _cameraManager = inCameraManager;
   _continuation = inContinuation;
   _bbox = bbox;
   rayLocationGPU[0] = NULL;
   rayLocationGPU[1] = NULL;
}


extern int ray_quadrant(const RayPacketCTM &a, int offset);

void
RayGeneratorNewBrook::Generate( int inWidth, int inHeight )
{
   unsigned int numRays = inWidth * inHeight;
   int Width = inWidth/2;
   int Height = inHeight/2;
   CameraInfo cam = _cameraManager->getSceneSpaceCameraInfo();


   if (this->rayLocationGPU[0]==NULL) {
       this->rayLocationGPU[0]=new brook::stream(brook::getStreamType((float4x3*)NULL),inHeight,inWidth,-1);
       this->rayLocationGPU[1]=new brook::stream(brook::getStreamType((float4x3*)NULL),inHeight,inWidth,-1);
   }
   {
      float camT[4]={cam.tx,cam.ty};
      float camU[4]={cam.u.x,cam.u.y,cam.u.z};
      float camV[4]={-cam.v.x,-cam.v.y,-cam.v.z};//flip it to match ogl
      float camW[4]={cam.w.x,cam.w.y,cam.w.z};
      float camFrom[4]={cam.from.x,cam.from.y,cam.from.z};
      float bboxMin[4]={_bbox->min.v[0],_bbox->min.v[1],_bbox->min.v[2]};
      float bboxMax[4]={_bbox->max.v[0],_bbox->max.v[1],_bbox->max.v[2]};
      float rayOffset[4]={_bbox->rayOffset.v[0],_bbox->rayOffset.v[1],_bbox->rayOffset.v[2]};
      float size[4]={(float)Width, (float)Height, 1.0f/(float)Width, 1.0f/(float)Height};
      brookRayGen(arrayFloat4(camT),
		  arrayFloat4(camU),
		  arrayFloat4(camV),
		  arrayFloat4(camW),
		  arrayFloat4(camFrom),
		  arrayFloat4(bboxMin),
		  arrayFloat4(bboxMax),
		  arrayFloat4(rayOffset),
		  arrayFloat4(size),
		  *rayLocationGPU[0]);
   }
    RayCTM raysStack;
    RayCTM *raysAddress=&raysStack;
    raysAddress->rays.stream = rayLocationGPU[0];
    raysAddress->raysOXYZ=rayLocationGPU[1];
    raysAddress->raysO.v[0]=cam.from.x+_bbox->rayOffset.v[0];
    raysAddress->raysO.v[1]=cam.from.y+_bbox->rayOffset.v[1];
    raysAddress->raysO.v[2]=cam.from.z+_bbox->rayOffset.v[2];
    raysAddress->width = Width;
    raysAddress->height = Height;
    raysAddress->bbox = *_bbox;
    raysAddress->cam=_cameraManager;
    _continuation->Call( inWidth, inHeight, raysAddress );
}
