/*
 * simdIntrinsics.h --
 *
 *      4-way vector intrinsics for each platform.
 *      Currently implemented by emulating SSE
 *      using altivec.
 */

#ifndef CTM_SIMDINTRINSICS_H
#define CTM_SIMDINTRINSICS_H

#ifdef _MSC_VER
#define ALIGN16(x)      __declspec(align(16)) x
#else
#define ALIGN16(x)      x __attribute__ ((aligned(16)))
#endif

#define _MM_DOT_PS(a, b) \
      _mm_add_ps(_mm_add_ps(_mm_mul_ps(a[0], b[0]), _mm_mul_ps(a[1], b[1])), \
                 _mm_mul_ps(a[2], b[2]))

#if defined(_SSE2_) || defined(_WIN32)

#include <xmmintrin.h>
#include <emmintrin.h>

#else

#include <altivec.h>

typedef vector float __m128;
typedef vector signed int __m128i;

#define _mm_set_ps(_z,_y,_x,_w)   ((vector float){(_w), (_x), (_y), (_z)})
#define _mm_set1_ps(_a)           ((vector float)(_a))
#define _mm_setzero_ps()          ((vector float)0.0f)
#define _mm_set1_epi32(_a)        ((vector signed int)(_a))

#define _mm_add_ps                vec_add
#define _mm_sub_ps                vec_sub
#define _mm_mul_ps(_a,_b)         vec_madd(_a,_b,(vector float)0.0f)

#define _mm_or_ps                 vec_or
#define _mm_and_ps                vec_and
#define _mm_andnot_ps(_a,_b)      vec_andc(_b,_a)
#define _mm_or_si128              vec_or
#define _mm_and_si128             vec_and
#define _mm_andnot_si128(_a,_b)   vec_andc(_b,_a)

#define _mm_rcp_ps                vec_re
#define _mm_rsqrt_ps              vec_rsqrte

/* Jeremy uses the output of comparisons
 * as a float, so we need to convert
 * them explicitly for alitvec
 */

static inline vector float
_vec_toFloat( vector signed int x )
{
  union { vector float f; vector signed int i; } converter;
  converter.i = x;
  return converter.f;
}

#define _mm_cmplt_ps(_a,_b)       \
  _vec_toFloat( vec_cmplt(_a,_b) )
#define _mm_cmpgt_ps(_a,_b)       \
  _vec_toFloat( vec_cmpgt(_a,_b) )
#define _mm_cmple_ps(_a,_b)       \
  _vec_toFloat( vec_cmple(_a,_b) )
#define _mm_cmpge_ps(_a,_b)       \
  _vec_toFloat( vec_cmpge(_a,_b) )
#define _mm_min_ps                vec_min
#define _mm_max_ps                vec_max

#define _mm_load_ps(_p)           (*((vector float*) _p))
#define _mm_store_ps(_p,_a)       (*((vector float*) _p) = _a)
#define _mm_load_si128(_p)        (*((vector signed int*) _p))
#define _mm_store_si128(_p,_a)    (*((vector signed int*) _p) = _a)

#define _mm_shuffle_ps            vec_perm

#define _MM_SHUFFLE(_a,_b,_c,_d)                       \
   ((vector unsigned char){                            \
     (_a)*4 + 0, (_a)*4 + 1, (_a)*4 + 2, (_a)*4 + 3,   \
     (_b)*4 + 0, (_b)*4 + 1, (_b)*4 + 2, (_b)*4 + 3,   \
     (_c)*4 + 0, (_c)*4 + 1, (_c)*4 + 2, (_c)*4 + 3,   \
     (_d)*4 + 0, (_d)*4 + 1, (_d)*4 + 2, (_d)*4 + 3 } )

#define _mm_movemask_ps(_a)       vec_any_ne(_a,(vector float)0.0f)


#endif

#endif
