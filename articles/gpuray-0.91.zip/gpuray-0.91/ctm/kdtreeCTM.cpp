/*

 * kdtreeCTM.cpp --
 *
 *      k-D tree spatial subdivision accelerator.
 */
 
#include "gpuDevice.h"
#include <windows.h>
#include "../sampler.h"
#include "kdtreeCTM.h"
#include <assert.h>
#include <errno.h>
#include <algorithm>

#include "../scenecache.h"
#include "../log.h"
#include "../timer.h"
#include "../ctm/ctmTracer.h"
#include "common.h"
extern bool yesrasterize;
extern bool norasterize;
extern bool yespacketize;
extern bool nopacketize;
/////////////////////////////////////////
static bool use_kdtree=true;
#define PADDING 16
#ifdef USE_CTM
void addCacheStats(int cache_miss,int cycles, int time);
extern bool display (int w,int h,const RayCTM[], float* outputAddy, ctmstream outputAddyGPU, float fov);

static float time_fixup (float input, float x, float y, float z){
  return input*sqrt(x*x+y*y+z*z);
}
void
logFunction( const char* msg )
{
    printf( "%s", msg );
	fflush(stdout);
}
void
fileFunction( const char* msg )
{
  FILE * fp = fopen ("output.asm","a");
  fprintf(fp, "%s", msg );
  fclose(fp);
}

#else
typedef unsigned int AMuint32;
struct AMmanagedDeviceInfo{
    AMuint32 baseAddressSYS;
    void * baseAddressCPU;
};
struct AMmanagedDevice{
};
enum AMUTYPE {
    AMU_CBUF_FLD_FORMAT_FLOAT32_1,
    AMU_CBUF_FLD_FORMAT_FLOAT32_2,
    AMU_CBUF_FLD_FORMAT_FLOAT32_4
};
class AMUcbufPack{
 public:
    AMUcbufPack(unsigned int * addy, unsigned int size){}
    void appendFlushOutCache(){}
    void appendFlushInpCache(){}
    void appendSetOutFmt(unsigned int,
                         AMuint32,
                         AMUTYPE,
                         unsigned int,
                         AMuint32 width,
                         AMuint32 height){}
    void appendSetInpFmt(unsigned int,
                         AMuint32,
                         AMUTYPE,
                         unsigned int,
                         AMuint32 width,
                         AMuint32 height){}
    
};
#endif

DUALcbufPack* copy1(DUALcbufPack * cbp, GPUDevice* device,
                   unsigned int input,
                   unsigned int output,
		    unsigned int TriWidth, unsigned int TriHeight, bool tiled, _AMUcbufFldFormat components, bool backcopy) {
  cbp->appendFlushOutCache();
    
    
    // Setup program literal constants
    setLiteralConstants(device, device->copy1_constants, device->fconst1AddressCPU, device->iconst1AddressCPU );
    
    // Flush Output cache
    cbp->appendFlushOutCache();
    
    // Flush conditional output cache
    cbp->appendFlushCondOutCache();
    
    cbp->appendSetInpFmt(0,input,components,(backcopy&&tiled)?AMU_CBUF_FLD_TILING_TILED0:AMU_CBUF_FLD_TILING_LINEAR,TriWidth,TriHeight);
    
    
    cbp->appendSetOutFmt( 0, output, components,  tiled?AMU_CBUF_FLD_TILING_TILED0:AMU_CBUF_FLD_TILING_LINEAR, TriWidth, TriHeight );

    
    // Invalidate input cache
    cbp->appendInvInpCache();
    
    // Invalidate conditional output cache
    cbp->appendInvCondOutCache();
    
    // Set instruction format
    cbp->appendSetInstFmt( device->copy1KernelAddressGPU, 0, 0, 0 );
    cbp->appendInvInstCache();
    
    // Setup constants and invalidate constant caches
    
    // Floats
    cbp->appendSetConstfFmt( device->fconst1AddressGPU, 0, 0, 0 );
    cbp->appendInvConstfCache();
    // Integers
    cbp->appendSetConstiFmt( device->iconst1AddressGPU, 0, 0, 0 );
    cbp->appendInvConstiCache();
    
    // Set domain of output
    cbp->appendSetDomainBroadcast( 0, 0, TriWidth - 1, TriHeight - 1 );
    
    // After setting everything up, start program
    cbp->appendStartProgram();
  return cbp;
}




DUALcbufPack* copyFetch4(DUALcbufPack * cbp, GPUDevice* device,
                   unsigned int input,
                   unsigned int output,
                   unsigned int TriWidth, unsigned int TriHeight) {
  cbp->appendFlushOutCache();
    
    
    // Setup program literal constants
    setLiteralConstants(device, device->copyF4_constants, device->fconstF4AddressCPU, device->iconstF4AddressCPU );
    
    // Flush Output cache
    cbp->appendFlushOutCache();
    
    // Flush conditional output cache
    cbp->appendFlushCondOutCache();
    
    cbp->appendSetInpFmt(0,input,AMU_CBUF_FLD_FORMAT_FLOAT32_4,AMU_CBUF_FLD_TILING_LINEAR,TriWidth,TriHeight);
    
    
    cbp->appendSetOutFmt( 0, output, AMU_CBUF_FLD_FORMAT_FLOAT32_1,  AMU_CBUF_FLD_TILING_TILED2, TriWidth*2, TriHeight*2 );

    
    // Invalidate input cache
    cbp->appendInvInpCache();
    
    // Invalidate conditional output cache
    cbp->appendInvCondOutCache();
    
    // Set instruction format
    cbp->appendSetInstFmt( device->copyF4KernelAddressGPU, 0, 0, 0 );
    cbp->appendInvInstCache();
    
    // Setup constants and invalidate constant caches
    
    // Floats
    cbp->appendSetConstfFmt( device->fconstF4AddressGPU, 0, 0, 0 );
    cbp->appendInvConstfCache();
    // Integers
    cbp->appendSetConstiFmt( device->iconstF4AddressGPU, 0, 0, 0 );
    cbp->appendInvConstiCache();
    
    // Set domain of output
    cbp->appendSetDomainBroadcast( 0, 0, TriWidth*2 - 1, TriHeight*2 - 1 );
    
    // After setting everything up, start program
    cbp->appendStartProgram();
  return cbp;
}


DUALcbufPack* revCopyFetch4(DUALcbufPack * cbp, GPUDevice* device,
			    unsigned int input,
			    unsigned int output,
			    unsigned int TriWidth, unsigned int TriHeight) {
  cbp->appendFlushOutCache();
    
    
    // Setup program literal constants
    setLiteralConstants(device, device->copy4F_constants, device->fconst4FAddressCPU, device->iconst4FAddressCPU );
    
    // Flush Output cache
    cbp->appendFlushOutCache();
    
    // Flush conditional output cache
    cbp->appendFlushCondOutCache();
    
    cbp->appendSetOutFmt(0,input,AMU_CBUF_FLD_FORMAT_FLOAT32_4,AMU_CBUF_FLD_TILING_LINEAR,TriWidth,TriHeight);
    
    
    cbp->appendSetInpFmt( 0, output, AMU_CBUF_FLD_FORMAT_FLOAT32_1,  AMU_CBUF_FLD_TILING_TILED2, TriWidth*2, TriHeight*2 );

    
    // Invalidate input cache
    cbp->appendInvInpCache();
    
    // Invalidate conditional output cache
    cbp->appendInvCondOutCache();
    
    // Set instruction format
    cbp->appendSetInstFmt( device->copy4FKernelAddressGPU, 0, 0, 0 );
    cbp->appendInvInstCache();
    
    // Setup constants and invalidate constant caches
    
    // Floats
    cbp->appendSetConstfFmt( device->fconst4FAddressGPU, 0, 0, 0 );
    cbp->appendInvConstfCache();
    // Integers
    cbp->appendSetConstiFmt( device->iconst4FAddressGPU, 0, 0, 0 );
    cbp->appendInvConstiCache();
    
    // Set domain of output
    cbp->appendSetDomainBroadcast( 0, 0, TriWidth - 1, TriHeight - 1 );
    
    // After setting everything up, start program
    cbp->appendStartProgram();
  return cbp;
}





KDTreeCTM::KDTreeCTM(const Scene& scene, const Opts& options, GPUDevice *device, BoundingBoxCTM* bbox)
{
  kdtreeWidth =2048;
  packetized=options.packets;
  forcefirstpacket=GetKeyValueInt( "packetfirst", options.accelOpts, 1 )?true:false;
  usefetch4=GetKeyValueInt("fetch4",options.accelOpts,true)?true:false;
  if (usefetch4) {
      printf ("Using Fetch4 to bring in packets\n");
  }else {
      printf ("Not using Fetch4 to bring in packets\n");
  }
  debug_kernel=GetKeyValueInt("debug",options.accelOpts,0);
  debug_offset=GetKeyValueInt("debug_offset",options.accelOpts,0);
  _useRaster=GetKeyValueInt("useRaster",options.accelOpts,true)?true:false;
  _offsetAlign= GetKeyValueInt( "ctmAlign", options.accelOpts,2048 );;
  printf("fov %f\n",scene.fov()); this->_bbox = bbox;
  this->fov=scene.fov();
  this->device = device;
  hitSize = 0;
  hitLocation = 0xffffffff;
#ifdef USE_CTM  
  benchmark=GetKeyValueInt("benchmark",options.accelOpts,0);
  tricpumem=GetKeyValueInt("tri_agp",options.accelOpts,0)?1:0;
  kdcpumem=GetKeyValueInt("kdtree_agp",options.accelOpts,0)?1:0;
  cpulinearmem=GetKeyValueInt("linear_agp",options.accelOpts,0)?1:0;
  if (options.packets)
      cpulinearmem=0;
  _offsetRay = GetKeyValueInt( "offsetRay", options.accelOpts, 0 );
  _offsetTriangle = GetKeyValueInt( "offsetTriangle", options.accelOpts, 0 );
  _offsetKdtree = GetKeyValueInt( "offsetKdtree", options.accelOpts, 0 );
  _offsetTT = GetKeyValueInt( "offsetTT", options.accelOpts, 0 );
  _offsetUU = GetKeyValueInt( "offsetUU", options.accelOpts, 0 );
  _offsetVV = GetKeyValueInt( "offsetVV", options.accelOpts, 0 );
  _offsetID = GetKeyValueInt( "offsetID", options.accelOpts, 0 );
  _dotrace = GetKeyValueInt( "doTrace", options.accelOpts, 0 )?true:false;
  float kdtreeScale= (float)GetKeyValueInt( "minNodeExtentRatio", options.accelOpts, 1820 );
  float kdtreeCost= (float)GetKeyValueInt( "isectCost", options.accelOpts, 40 );
  printf ("Using kdtree of scale 1/%.0f\n",kdtreeScale);
#endif
  _repeatFrameSubmitCount = GetKeyValueInt(
    "frameCount", options.accelOpts, 1 );
  if( _repeatFrameSubmitCount < 1 )
  {
//    fprintf( stderr, "Invalid frame count %d.\n", _repeatFrameSubmitCount );
    exit( 1 );
  }

  KDTreeBuildOptions buildOptions;
  buildOptions.minNodeExtentRatio = 1.0f/kdtreeScale;///*1./2048;//*/.015625f/65536.0f/4.0f;
  buildOptions.isectCost=kdtreeCost;
  //  buildOptions.minAbsoluteProbability=2.0f;
  KDTree* builtTree = BuildKDTreeCached( options, &scene, buildOptions );
  _nodeCount = builtTree->getNodeCount();
  _nodes = (PaddedCtmKdTreeNode*)malloc(_nodeCount * sizeof(PaddedCtmKdTreeNode) );
  printf ("%d kdtree nodes\n",_nodeCount);
  memset(_nodes,0,_nodeCount * sizeof(PaddedCtmKdTreeNode));
  if (_nodes==NULL) {
	printf ("Failed to allocated %d bytes for kdtree\n",_nodeCount*sizeof(PaddedCtmKdTreeNode));

  }
  CopyKDTreeGPUFat( builtTree, _nodes, _bbox,kdtreeWidth,usefetch4);
  //CopyKDTreeGPUOpt( builtTree, _nodes, _bbox,false);

  _triangleCount = builtTree->getPrimitiveIndexCount();
  const int* builtIndices = builtTree->getPrimitiveIndices();
  
   _triangleDataA = (float *) AllocateAligned(
     _triangleCount * sizeof(float)*4, 128 );
   _triangleDataB = (float *) AllocateAligned(
     _triangleCount * sizeof(float)*4, 128 );
   _triangleDataC = (float *) AllocateAligned(
     _triangleCount * sizeof(float)*4, 128 );
   
   const F3* v0 = scene.vertices(0);
   const F3* v1 = scene.vertices(1);
   const F3* v2 = scene.vertices(2);
   _bruteForceTriCount=scene.nTris();
   unsigned int tc=_triangleCount;
   TriWidth=2048;//tc/TriHeight+(tc%TriHeight?1:0);
   unsigned int tcroundup=tc/TriWidth+(tc%TriWidth?1:0);
   TriHeight=PADDING*(tcroundup/PADDING + (tcroundup%PADDING?1:0));
   printf ("Width %d Height %d\n",TriWidth,TriHeight);
   DUALcbufPack* cbp=new DUALcbufPack((( unsigned int* ) device->cbufAddressCPU),1024*512);
/*
   float *triangleIDs=reinterpret_cast<float*>((unsigned char*)device->outputAddressCPU+device->bytecountAGP);
   triangleIDsAGP=device->outputAddressGPU+device->bytecountAGP;
   triangleIDsGPU=device->info.baseAddressGPU+device->bytecountGPU;
   device->bytecountAGP+=TriWidth*TriHeight*sizeof(float);
   device->bytecountGPU+=TriWidth*TriHeight*sizeof(float);
   for( uint32 ii = 0; ii < _triangleCount; ii++ )
   {
	  float triID=(float)builtIndices[ii];
      memcpyBroadcast(&triangleIDs[ii],&triID,sizeof(float));
      }*/
   CopyTrianglesGPU( _triangleCount, builtIndices, v0, v1, v2, _bbox,
					 _triangleDataA, _triangleDataB, _triangleDataC );
   delete builtTree; // v0, v1, v2 are const pointers to the builtTree.
/*   cbp=copy1(cbp,device,triangleIDsAGP,triangleIDsGPU,TriWidth,TriHeight,true,AMU_CBUF_FLD_FORMAT_FLOAT32_1);
   if (!cpulinearmem)
       cbp=copy1(cbp,device,triangleIDsGPU,triangleIDsAGP,TriWidth,TriHeight,true,AMU_CBUF_FLD_FORMAT_FLOAT32_1,true);
*/
   
   device->bytecountGPU+=_offsetTriangle*_offsetAlign;


         assert( (unsigned int)(device->outputAddressGPU+device->bytecountAGP)%2048 == 0);
         triangles[0] = reinterpret_cast<float*>((unsigned char *)device->outputAddressCPU+device->bytecountAGP);
         trianglesAGP[0]=(device->outputAddressGPU+device->bytecountAGP);
         device->tri0AddressGPU = device->info.baseAddressGPU +device->bytecountGPU/*+ 128*1024*1024*/;
         assert(device->tri0AddressGPU%2048 == 0);
         device->bytecountAGP+=16*TriWidth*TriHeight;
         device->bytecountGPU+=16*TriWidth*TriHeight;


         assert( (unsigned int)(device->outputAddressGPU+device->bytecountAGP)%2048 == 0);
         triangles[1] = reinterpret_cast<float*>((unsigned char *)device->outputAddressCPU+device->bytecountAGP); 
         trianglesAGP[1]=(device->outputAddressGPU+device->bytecountAGP);
         device->tri1AddressGPU = device->info.baseAddressGPU + device->bytecountGPU;
         assert(device->tri1AddressGPU%2048 == 0);
         device->bytecountAGP+=16*TriWidth*TriHeight;
         device->bytecountGPU+=16*TriWidth*TriHeight;


         assert( (unsigned int)(device->outputAddressGPU+device->bytecountAGP)%2048 == 0);
         triangles[2] = reinterpret_cast<float*>((unsigned char *)device->outputAddressCPU+device->bytecountAGP); 
         trianglesAGP[2]=(device->outputAddressGPU+device->bytecountAGP);
         device->tri2AddressGPU = device->info.baseAddressGPU+device->bytecountGPU;
         assert(device->tri2AddressGPU%2048 == 0);
         device->bytecountAGP+=16*TriWidth*TriHeight;
         device->bytecountGPU+=16*TriWidth*TriHeight;
         
         // Copy in data
         float * AA=_triangleDataA;
         float * BB=_triangleDataB;
         float * CC=_triangleDataC;
         fflush(stdout);
//	 printf ("len %d %d", trianglesAGP[0]-device->info.baseAddressSYS, device->bytecountAGP+device->outputAddressGPU-device->info.baseAddressSYS);
fflush(stdout);
         for (unsigned int j=0;j<TriHeight;++j) {
//	     printf ("%d/%d\n",j,TriHeight);
           for (unsigned int i=0;i<TriWidth;++i) {
//	       if (j>1500)
//		   printf ("%d/%d\n",i,TriWidth);  
             if (AA-_triangleDataA>=(ptrdiff_t)_triangleCount*4)break;
             memcpyBroadcast(triangles[0]+4*(3*j*TriWidth+i),AA,sizeof(float)*4);
             AA+=4;
             memcpyBroadcast(triangles[0]+4*((3*j+1)*TriWidth+i),BB,sizeof(float)*4);
             BB+=4;
             memcpyBroadcast(triangles[0]+4*((3*j+2)*TriWidth+i),CC,sizeof(float)*4);
             CC+=4;
             
             
           }
         }
         printf ("DONE\n");
         fflush(stdout);
         //memcpyBroadcast(triangles[0],_triangleDataA,_triangleCount*4*sizeof(float));
         //memcpyBroadcast(triangles[1],_triangleDataB,_triangleCount*4*sizeof(float));
         //memcpyBroadcast(triangles[2],_triangleDataC,_triangleCount*4*sizeof(float));
         // Bind Outputs


	 if (usefetch4) {
         cbp      =copyFetch4(cbp,device,
                         trianglesAGP[0]/*,trianglesAGP[1],trianglesAGP[2]*/,
                         device->tri0AddressGPU,/*device->tri1AddressGPU,device->tri2AddressGPU,*/
                         TriWidth,TriHeight*3);
         }else {
	     cbp=copy1(cbp,device,trianglesAGP[0],device->tri0AddressGPU,TriWidth,TriHeight*3,true,AMU_CBUF_FLD_FORMAT_FLOAT32_4);
	 }
	 if (!cpulinearmem)
	     cbp=copy1(cbp,device,device->tri0AddressGPU,trianglesAGP[0],TriWidth,TriHeight*3,true,AMU_CBUF_FLD_FORMAT_FLOAT32_4,true);

         /* cbp      =copy3(new DUALcbufPack(( unsigned int* ) device->cbufAddressCPU,1024*1024),device,
               trianglesAGP[0],trianglesAGP[1],trianglesAGP[2],
               device->tri0AddressGPU,device->tri0AddressGPU,device->tri0AddressGPU,
               TriWidth,TriHeight);*/
    AMuint32 cbufsize = cbp->getCommandBufferSize();
    delete cbp;
    unsigned int bufid = dualSubmitCommandBuffer( device->vm, device->cbufAddressGPU, cbufsize );
    while ( dualCommandBufferConsumed( device->vm, bufid ) == 0 ){ ; }
    if (tricpumem==0)
	device->bytecountAGP-=3*16*TriWidth*TriHeight;
    cbp=new DUALcbufPack((( unsigned int* ) device->cbufAddressCPU),1024*512);    
    //device->bytecount=3*16*TriWidth*TriHeight;
    device->bytecountGPU+=_offsetKdtree*_offsetAlign;
    //    kdtree=reinterpret_cast<float*>((unsigned char *)device->outputAddressCPU+device->bytecount); 
    kdtreeHeight =_nodeCount/kdtreeWidth+(((_nodeCount)%kdtreeWidth)?4:0);
    //if (kdtreeHeight<4)kdtreeHeight=4;
    kdtreeHeight = (kdtreeHeight/PADDING+ (kdtreeHeight%PADDING?4:0))*PADDING;
    // Bind inputs
    kdtree = reinterpret_cast<float*>((unsigned char *)device->outputAddressCPU+device->bytecountAGP);
    assert( (unsigned int)(device->outputAddressGPU+device->bytecountAGP)%2048 == 0);
    kdtreeAGP=(device->outputAddressGPU+device->bytecountAGP);
    // Copy in data
    memcpyBroadcast(kdtree,_nodes,sizeof(PaddedCtmKdTreeNode)*_nodeCount);

    // Bind Outputs
    device->kdtreeAddressGPU = device->info.baseAddressGPU+device->bytecountGPU;
    if (usefetch4) {
	cbp=copyFetch4(cbp,device,kdtreeAGP,device->kdtreeAddressGPU,kdtreeWidth,kdtreeHeight);//
    }else {
	cbp=copy1(cbp,device,kdtreeAGP,device->kdtreeAddressGPU,kdtreeWidth,kdtreeHeight,true,AMU_CBUF_FLD_FORMAT_FLOAT32_4);
    }
    if (!cpulinearmem)
	cbp=copy1(cbp,device,device->kdtreeAddressGPU,kdtreeAGP,kdtreeWidth,kdtreeHeight,true,AMU_CBUF_FLD_FORMAT_FLOAT32_4,true);
    
    

//    fprintf(stderr, "kdtree should be on hardware now\n");
    
    device->bytecountAGP+=sizeof(PaddedCtmKdTreeNode)*kdtreeWidth*kdtreeHeight;
    device->bytecountGPU+=sizeof(PaddedCtmKdTreeNode)*kdtreeWidth*kdtreeHeight;

    device->bytecountGPU+=_offsetRay*_offsetAlign;
    cbufsize = cbp->getCommandBufferSize();
    if ((size_t)device->bytecountAGP>(size_t)device->info.arenaSizeSYS){
      printf ("WARNING: Using %d space only %d available\n",device->bytecountAGP,device->info.arenaSizeSYS);
    }else {
      printf ("Using %d space for kdtree and triangles\n",device->bytecountAGP);
    }
    delete cbp;
    bufid = dualSubmitCommandBuffer( device->vm, device->cbufAddressGPU, cbufsize );
    while ( dualCommandBufferConsumed( device->vm, bufid ) == 0 ){ ; }

    //printf ("EARY kdtree bad node %f %f size %dx%d size: %d wh %d nodecount %d\n",kdtree[139269*2],kdtree[139269*2+1],kdtreeWidth,kdtreeHeight,sizeof(PaddedCtmKdTreeNode),kdtreeWidth*kdtreeHeight,_nodeCount);

}

KDTreeCTM::~KDTreeCTM(void)
{
  delete device;

}
uint32
KDTreeCTM::getBatchGranularity()
{
  return 1;
}
extern void processdat(float *,int wid,int hei);

#define __BrtFloat4 float4
#define __BrtFloat3 float3
#define __BrtFloat2 float2
#define __BrtFloat1 float1

#include "include/brtvector.hpp"
static float4 arrayfloat4(float *input) {
  return float4(input[0],input[1],input[2],input[3]);
}
void brookish_intersect (
        float4 scenecounts,//x = max triindex y = triwidth z = max node w = node width
        float4 tMinMax,//x = min y = max
        float4 bboxmin ,
        float4 bboxmax ,
        float4 debugme ,
        float4 raysO,
        float4* rays0,
        float4* rays1,
        float4* rays2,
        float4* rays3,
        float4* rays4,
        float4* rays5,
        
        float4* triangles,
        float2* kdtree,
        float1* trianlgeIndex,
        float2 wpos,
	float4 & hitTT,
	float4 & hitUU,
	float4 & hitVV,
	float4 & hitID);
//on 1024x1024 591x679 is b0rked
extern unsigned int gltilesize;
void
KDTreeCTM::intersect(const RayCTM rays[],
                     uint32 numRays, HitCTM hits[])
{
    bool rebin_packets=false;

    unsigned int Height=rays->height;
    unsigned int Width=rays->width;
	hits->height = Height;
	hits->intersector=this;
	hits->width = Width;
	
	if (hitSize==0) {

		hitLocation=device->info.baseAddressGPU+device->bytecountGPU;
		//printf("raylocation %d hit location GPU %d \n", rays->ptr, hitLocation);
		hitSize=(_offsetUU + _offsetVV + _offsetTT + _offsetID)*_offsetAlign + 4*16*Width*Height; // tt, uu, vv, numTri
		device->bytecountGPU += hitSize;
		hitLocationAGP=0?device->info.baseAddressSYSc:device->outputAddressGPU+device->bytecountAGP;
		hitLocationCPU=0?(float*)device->info.baseAddressCPUc:(float*)((char*)device->outputAddressCPU+device->bytecountAGP);
		device->bytecountAGP+=Width*Height*16*sizeof(float);
	}
	if (yesrasterize){
		_useRaster=true;
		yesrasterize=false;
	}
	if (norasterize){
		_useRaster=false;
		norasterize=false;
	}
	if (yespacketize){
		packetized=true;
		yespacketize=false;
	}
	if (nopacketize){
		packetized=false;
		nopacketize=false;
	}
	if (_useRaster&&(rays->raysO.v[0]!=-666.0f||rays->raysO.v[1]!=-666.0f||rays->raysO.v[2]!=-666.0f)) {
          //FIXME stupidly GPU compliant--copies some of the stuff twice, half as fast on dual gpu

		ctmstream hitLocationWish;
		hitLocationWish.ctm.ptr=hitLocationAGP;
		hitLocationWish.ctm.tiled=false;//maybe it can raster into host memory--anyhow we can dream

		display(Width*2,Height*2,rays,hitLocationCPU,hitLocationWish,fov);   
		DUALcbufPack* cbp = new DUALcbufPack( ( unsigned int* ) device->cbufAddressCPU, 1024 * 1024);
		cbp->appendSetInpFmt( 0,  hitLocationAGP, AMU_CBUF_FLD_FORMAT_FLOAT32_4, AMU_CBUF_FLD_TILING_LINEAR, Width*2,Height*2);//rays pos		
		setLiteralConstants(device, device->rasterShader_constants, device->fconstRasterShaderAddressCPU, device->iconstRasterShaderAddressCPU );
		cbp->appendFlushOutCache();
                
		int bytecount=hitLocation;
		hits->tHitPtr.ctm.ptr = bytecount;
		cbp->appendSetOutFmt( 0, hits->tHitPtr.ctm.ptr, AMU_CBUF_FLD_FORMAT_FLOAT32_4, AMU_CBUF_FLD_TILING_TILED0, Width, Height );
		bytecount+=16*Width*Height;
		bytecount+=_offsetUU*_offsetAlign;
		hits->uuPtr.ctm.ptr = bytecount;
		cbp->appendSetOutFmt( 1, hits->uuPtr.ctm.ptr, AMU_CBUF_FLD_FORMAT_FLOAT32_4, AMU_CBUF_FLD_TILING_TILED0, Width, Height );
		bytecount+=16*Width*Height;
		bytecount+=_offsetVV*_offsetAlign;
		hits->vvPtr.ctm.ptr = bytecount;
		cbp->appendSetOutFmt( 2, hits->vvPtr.ctm.ptr, AMU_CBUF_FLD_FORMAT_FLOAT32_4, AMU_CBUF_FLD_TILING_TILED0, Width, Height );
		bytecount+=_offsetID*_offsetAlign;
		bytecount+=16*Width*Height;
		hits->triNumPtr.ctm.ptr = bytecount;
		cbp->appendSetOutFmt( 3, hits->triNumPtr.ctm.ptr, AMU_CBUF_FLD_FORMAT_FLOAT32_4, AMU_CBUF_FLD_TILING_TILED0, Width, Height );
		bytecount+=16*Width*Height; 
		hits->triNumPtr.ctm.tiled=true;
		hits->uuPtr.ctm.tiled=true;
		hits->vvPtr.ctm.tiled=true;
		hits->tHitPtr.ctm.tiled=true;
		cbp->appendInvCondOutCache();
		cbp->appendSetInstFmt( device->rasterShaderKernelAddressGPU, 0, 0, 0 );
		cbp->appendInvInstCache();
		cbp->appendSetConstfFmt( device->fconstRasterShaderAddressGPU, 0, 0, 0 );
		cbp->appendInvConstfCache();
		// Integers
		cbp->appendSetConstiFmt( device->iconstRasterShaderAddressGPU, 0, 0, 0 );
		cbp->appendInvConstiCache();
		// Set domain of output
		cbp->appendSetDomainTiled( 0, 0, Width   - 1, Height   - 1 );
		// After setting everything up, start program
		cbp->appendStartProgram();
		AMuint32 cbufsize = cbp->getCommandBufferSize();
		unsigned int bufid = dualSubmitCommandBuffer( device->vm, device->cbufAddressGPU, cbufsize );
		while ( dualCommandBufferConsumed( device->vm, bufid ) == 0 ){ ; }
		return;
	}
    DUALcbufPack* cbp = new DUALcbufPack( ( unsigned int* ) device->cbufAddressCPU, 1024 * 1024);
    //cbp->appendInvInpCache();
    
    // Invalidate conditional output cache
    //cbp->appendInvCondOutCache();
    
    //cbp->appendInvConstfCache();
    //cbp->appendInvConstiCache();        
    
    cbp->appendFlushOutCache();
    
    // Flush conditional output cache
    //cbp->appendFlushCondOutCache();
    //printf("input fmt %d %d %d\n", rays->rays.ctm.ptr, device->kdtreeAddressGPU, device->tri0AddressGPU);
      cbp->appendSetInpFmt( 2,  rays->rays.ctm.ptr, AMU_CBUF_FLD_FORMAT_FLOAT32_4, rays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:0, Width,Height);//rays pos
      cbp->appendSetInpFmt( 3,  rays->rays.ctm.ptr+Width*Height*sizeof(float)*4, AMU_CBUF_FLD_FORMAT_FLOAT32_4, rays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:0, Width,Height);//rays pos
      cbp->appendSetInpFmt( 4,  rays->rays.ctm.ptr+Width*Height*sizeof(float)*8, AMU_CBUF_FLD_FORMAT_FLOAT32_4, rays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:0, Width,Height);//rays pos
      cbp->appendSetInpFmt( 5,  rays->rays.ctm.ptr+Width*Height*sizeof(float)*12, AMU_CBUF_FLD_FORMAT_FLOAT32_4, rays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:0, Width,Height);//rays pos
      cbp->appendSetInpFmt( 6,  rays->rays.ctm.ptr+Width*Height*sizeof(float)*16, AMU_CBUF_FLD_FORMAT_FLOAT32_4, rays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:0, Width,Height);//rays pos
      cbp->appendSetInpFmt( 7,  rays->rays.ctm.ptr+Width*Height*sizeof(float)*20, AMU_CBUF_FLD_FORMAT_FLOAT32_4, rays->rays.ctm.tiled?AMU_CBUF_FLD_TILING_TILED0:0, Width,Height);//rays pos


      /**/
      int bytecount=hitLocation;///hitdevice->outputAddressGPU+device->bytecountAGP;//hitLocation;
      int ktmpwidth=kdtreeWidth;
      int ktmpheight=kdtreeHeight;
      if (usefetch4) {
	  ktmpwidth*=2;
	  ktmpheight*=2;
      }
      if (!_quiet) printf ("kdsize %d x %d\n",kdtreeWidth*2,kdtreeHeight*2);
      cbp->appendSetInpFmt( 0, kdcpumem?kdtreeAGP:device->kdtreeAddressGPU, usefetch4?AMU_CBUF_FLD_FORMAT_FLOAT32_1:AMU_CBUF_FLD_FORMAT_FLOAT32_4,  cpulinearmem&&kdcpumem?AMU_CBUF_FLD_TILING_LINEAR:(usefetch4?AMU_CBUF_FLD_TILING_TILED2:AMU_CBUF_FLD_TILING_TILED0) ,ktmpwidth,ktmpheight);
      int ttmpwidth=TriWidth;
      int ttmpheight=TriHeight*3;
      if (usefetch4) {
	  ttmpwidth*=2;
	  ttmpheight*=2;
      }
      cbp->appendSetInpFmt( 1, tricpumem?trianglesAGP[0]:device->tri0AddressGPU,   usefetch4?AMU_CBUF_FLD_FORMAT_FLOAT32_1:AMU_CBUF_FLD_FORMAT_FLOAT32_4,  cpulinearmem&&tricpumem?AMU_CBUF_FLD_TILING_LINEAR:(usefetch4?AMU_CBUF_FLD_TILING_TILED2:AMU_CBUF_FLD_TILING_TILED0), ttmpwidth,ttmpheight);//triangles0
//      cbp->appendSetInpFmt( 8, triangleIDsGPU,   AMU_CBUF_FLD_FORMAT_FLOAT32_1,  AMU_CBUF_FLD_TILING_TILED0, TriWidth,TriHeight);//triangles0
    /*
    cbp->appendSetInpFmt( 7, device->tri1AddressGPU,   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  AMU_CBUF_FLD_TILING_TILED0, TriWidth,TriHeight);//triangles1
    cbp->appendSetInpFmt( 8, device->tri2AddressGPU,   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  AMU_CBUF_FLD_TILING_TILED0, TriWidth,TriHeight);//triangles2
    */
    /*/
    cbp->appendSetInpFmt( 9, kdtreeAGP, AMU_CBUF_FLD_FORMAT_FLOAT32_2,  AMU_CBUF_FLD_TILING_LINEAR,kdtreeWidth,kdtreeHeight);
    cbp->appendSetInpFmt( 6, trianglesAGP[0],   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  AMU_CBUF_FLD_TILING_LINEAR, TriWidth,TriHeight);//triangles0
    cbp->appendSetInpFmt( 7, trianglesAGP[1],   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  AMU_CBUF_FLD_TILING_LINEAR, TriWidth,TriHeight);//triangles1
    cbp->appendSetInpFmt( 8, trianglesAGP[2],   AMU_CBUF_FLD_FORMAT_FLOAT32_4,  AMU_CBUF_FLD_TILING_LINEAR, TriWidth,TriHeight);//triangles2
    //*/
    bytecount+=_offsetTT*_offsetAlign;
	hits->tHitPtr.ctm.ptr = bytecount;
    cbp->appendSetOutFmt( 0, hits->tHitPtr.ctm.ptr, AMU_CBUF_FLD_FORMAT_FLOAT32_4, AMU_CBUF_FLD_TILING_TILED0, Width, Height );
    bytecount+=16*Width*Height;
    bytecount+=_offsetUU*_offsetAlign;
    hits->uuPtr.ctm.ptr = bytecount;
    cbp->appendSetOutFmt( 1, hits->uuPtr.ctm.ptr, AMU_CBUF_FLD_FORMAT_FLOAT32_4, AMU_CBUF_FLD_TILING_TILED0, Width, Height );
        //    cbp->appendSetOutFmt( 1, device->outputAddressGPU, AMU_CBUF_FLD_FORMAT_FLOAT32_4, AMU_CBUF_FLD_TILING_LINEAR, Width,Height);
    bytecount+=16*Width*Height;
    bytecount+=_offsetVV*_offsetAlign;
	hits->vvPtr.ctm.ptr = bytecount;
    cbp->appendSetOutFmt( 2, hits->vvPtr.ctm.ptr, AMU_CBUF_FLD_FORMAT_FLOAT32_4, AMU_CBUF_FLD_TILING_TILED0, Width, Height );
    bytecount+=_offsetID*_offsetAlign;
    bytecount+=16*Width*Height;
	hits->triNumPtr.ctm.ptr = bytecount;
    cbp->appendSetOutFmt( 3, hits->triNumPtr.ctm.ptr, AMU_CBUF_FLD_FORMAT_FLOAT32_4, AMU_CBUF_FLD_TILING_TILED0, Width, Height );
    bytecount+=16*Width*Height; 
    hits->triNumPtr.ctm.tiled=true;
    hits->uuPtr.ctm.tiled=true;
    hits->vvPtr.ctm.tiled=true;
    hits->tHitPtr.ctm.tiled=true;

    //	printf ("Using %d space for rays\n",bytecount);

    float triangleIndex[ 4 ] = {0,0,0,0};
    triangleIndex[3]=(float)kdtreeWidth;
    triangleIndex[2]=(float)_nodeCount;
    const int num_samplers=16; 

    
    triangleIndex[0]=(float)_triangleCount;
    triangleIndex[1]=(float)TriWidth;
    float initialHit[4]={1.0f/16384.0f,1.0f,2.0,0};
    float bboxMin[4]={_bbox->min.v[0]-1,_bbox->min.v[1]-1,_bbox->min.v[2]-1};
    float bboxMax[4]={_bbox->max.v[0]+1,_bbox->max.v[1]+1,_bbox->max.v[2]+1};
    int idiotic[4]={255,0,0,0};
    int sly[4]={255,0,0,0};
	// rays0 unused
    float raysO[4]={rays->raysO.v[0],//rays[0].o.v[0]+_bbox->rayOffset.v[0],
                    rays->raysO.v[1],//rays[0].o.v[BUNDLE_SIZE]+_bbox->rayOffset.v[1],
                    rays->raysO.v[2],//rays[0].o.v[2*BUNDLE_SIZE]+_bbox->rayOffset.v[2],
					6.123456789f};
	// badray unused
    float badray[4]={9.123456789f,
                    9.123456789f,
                    9.123456789f,
					9.123456789f};
    float camT[4]={rays->camT.v[0],
		   rays->camT.v[1],
		   rays->camT.v[2],
		   0.0f};
    float camU[4]={rays->camU.v[0],
		   rays->camU.v[1],
		   rays->camU.v[2],
		   0.0f};
    float camV[4]={rays->camV.v[0],
		   rays->camV.v[1],
		   rays->camV.v[2],
		   0.0f};
    float camW[4]={rays->camW.v[0],
		   rays->camW.v[1],
		   rays->camW.v[2],
		   0.0f};
    float canvasSize[4]={(float)rays->width,
		   (float)rays->height,
		   1.0f/(float)rays->width,
		   1.0f/(float)rays->height};
    float eps[4]={.0000000f,.0000000f,.0000000f,.000000f};
    float addrMult[4]={usefetch4?2.0f:1.0f,usefetch4?2.0f:1.0f,1.0f,1.0f};
    float rayIndexOffset[4]={0,(float)Height,0,0};
    
//    if (!_quiet) printf ("Constants %f %f %f vs %f %f %f and %d\n",((float*)device->constants)[10],((float*)device->constants)[11],((float*)device->constants)[12],((float*)device->raytracerNoPacket_constants)[10],((float*)device->raytracerNoPacket_constants)[11],((float*)device->raytracerNoPacket_constants)[12], memcmp(device->constants,device->raytracerNoPacket_constants,sizeof(AMUabiConstsInfo)));
    /*  {
    float * a= (float*)device->raytracerNoPacket_constants;
    float * b= (float*)device->constants;
    int * d= (int*)device->raytracerNoPacket_constants;
    int * e= (int*)device->constants;
    int good=1;
    for (unsigned int i=0;i<256;++i){
      if (*d!=*e) good=0;
      printf ("%d %d: %f %f %d %d\n",i,good,*a,*b,*d,*e);
      ++a;++b;++d;++e;
    }
    }*/
    bool oldpacketize=packetized;
    if (rays->raysO.v[0]!=-666.0f||rays->raysO.v[1]!=-666.0f||rays->raysO.v[2]!=-666.0f) {
	if (forcefirstpacket) {
	    packetized=true;
	    if (!_quiet) {
		printf ("Forcing packets\n");
	    }
	}
    }

    AMUabiConstsInfo *constants=packetized?device->constants:device->raytracerNoPacket_constants;
    void * fconstAddressCPU = packetized?device->fconstAddressCPU:device->fconstRaytracerNoPacketAddressCPU;
    float *debugconst=((float*)fconstAddressCPU)+31*4;
    debugconst[0]=0;
    debugconst[1]=0;
    debugconst[2]=0;
    debugconst[3]=0;
    void * iconstAddressCPU = packetized?device->iconstAddressCPU:device->iconstRaytracerNoPacketAddressCPU;
    AMuint32 programAddressGPU=packetized?device->programAddressGPU:device->raytracerNoPacketKernelAddressGPU;
    AMuint32 fconstAddressGPU=packetized?device->fconstAddressGPU:device->fconstRaytracerNoPacketAddressGPU;
    AMuint32 iconstAddressGPU=packetized?device->iconstAddressGPU:device->iconstRaytracerNoPacketAddressGPU;

#ifdef USE_CTM
    setUserConstant(device, constants, fconstAddressCPU, "c0", triangleIndex,  AMU_ABI_FLOAT32 );
    setUserConstant(device, constants, fconstAddressCPU, "c1",initialHit,  AMU_ABI_FLOAT32 );
    setUserConstant(device, constants, fconstAddressCPU, "c2",bboxMin,  AMU_ABI_FLOAT32 );
    setUserConstant(device, constants, fconstAddressCPU, "c3",bboxMax,  AMU_ABI_FLOAT32 );
    setUserConstant(device, constants, fconstAddressCPU, "c4",badray,  AMU_ABI_FLOAT32 );
    setUserConstant(device, constants, fconstAddressCPU, "c5",raysO,  AMU_ABI_FLOAT32 );
    setUserConstant(device, constants, fconstAddressCPU, "c6",rayIndexOffset,  AMU_ABI_FLOAT32 );
    setUserConstant(device, constants, fconstAddressCPU, "c7",camT,  AMU_ABI_FLOAT32 );
    setUserConstant(device, constants, fconstAddressCPU, "c8",camU,  AMU_ABI_FLOAT32 );
    setUserConstant(device, constants, fconstAddressCPU, "c9",camV,  AMU_ABI_FLOAT32 );
    setUserConstant(device, constants, fconstAddressCPU, "c10",camW,  AMU_ABI_FLOAT32 );
    setUserConstant(device, constants, fconstAddressCPU, "c11",canvasSize,  AMU_ABI_FLOAT32 );

    setUserConstant(device, constants, fconstAddressCPU, "c12",(float*)_nodes,  AMU_ABI_FLOAT32 );
    setUserConstant(device, constants, fconstAddressCPU, "c13",eps,  AMU_ABI_FLOAT32 );
    setUserConstant(device, constants, fconstAddressCPU, "c14",addrMult,  AMU_ABI_FLOAT32 );
    
    setUserConstant(device, constants, iconstAddressCPU, "i0",sly,  AMU_ABI_INT32 );
    setUserConstant(device, constants, iconstAddressCPU, "i1",idiotic,  AMU_ABI_INT32 );
    setUserConstant(device, constants, iconstAddressCPU, "i2",idiotic,  AMU_ABI_INT32 );
    setUserConstant(device, constants, iconstAddressCPU, "i3",idiotic,  AMU_ABI_INT32 );
    setUserConstant(device, constants, iconstAddressCPU, "i4",idiotic,  AMU_ABI_INT32 );
    setUserConstant(device, constants, iconstAddressCPU, "i5",idiotic,  AMU_ABI_INT32 );
    setUserConstant(device, constants, iconstAddressCPU, "i6",idiotic,  AMU_ABI_INT32 );
    setUserConstant(device, constants, iconstAddressCPU, "i7",idiotic,  AMU_ABI_INT32 );
    
    for (unsigned int i=0;i<16;++i) {
        char name[4]={'s','1','0'+(i%10),'\0'};
		if (i<10) {
			name[1]=name[2];
			name[2]=name[3];
		}
        setUserConstant(device,constants,fconstAddressCPU,name,&i,AMU_ABI_INT32);
    }
    setLiteralConstants(device, constants, fconstAddressCPU, iconstAddressCPU );
    cbp->appendInvInpCache();
    cbp->appendSetInstFmt( programAddressGPU, 0, 0, 0 );
    cbp->appendInvInstCache();
    cbp->appendSetConstfFmt( fconstAddressGPU, 0, 0, 0 );
    cbp->appendInvConstfCache();
    
    cbp->appendSetConstiFmt( iconstAddressGPU, 0, 0, 0 );
    cbp->appendInvConstiCache();
    unsigned int* perf = (unsigned int*)device->perfCountAddressCPU;
    
    memset (perf,0,4*sizeof(int));

    AMuint32 cbufsize = cbp->getCommandBufferSize();
    //Node 139269.000000 outer 2.000000 inner 3.000000 [-0.902586 -0.901537]
    //intf ("kdtree bad node %f %f\n",kdtree[139269*2],kdtree[139269*2+1]);
    fflush(stdout);
    delete cbp;
    unsigned int bufid = dualSubmitCommandBuffer( device->vm, device->cbufAddressGPU, cbufsize );
    while ( dualCommandBufferConsumed( device->vm, bufid ) == 0 ){ ; }


    cbp = new DUALcbufPack((unsigned int *)device->cbufAddressCPU,1024*512);
    int iter=benchmark?benchmark:1;
    if (debug_kernel) {
	printf ("PERF COUNTERS COMING RIGHT UP\n");
	cbp->appendInitPerfCounters(true);
	cbp->appendStartPerfCounters();
    }
    if (!packetized) {
      cbp->appendSetOutFmt( 0, device->info.baseAddressGPU+device->bytecountGPU, AMU_CBUF_FLD_FORMAT_FLOAT32_4, AMU_CBUF_FLD_TILING_TILED0, Width*2, Height*2 );
      gltilesize*=2;
    }
    for (int i=0;i<iter;++i) {
      cbp->appendSetDomainTiled( 0, 0, (packetized?Width:2*Width)-1, (packetized?Height:2*Height)- 1 );
      cbp->appendStartProgram();
    }
    if (debug_kernel) {
	printf ("PERF COUNTERS COMING RIGHT UP\n");
	cbp->appendStopPerfCounters();
	cbp->appendReadPerfCounters(device->perfCountAddressGPU);
    }
    cbufsize = cbp->getCommandBufferSize();
    delete cbp;
    double a= Timer_GetMS();
    bufid = dualSubmitCommandBuffer( device->vm, device->cbufAddressGPU, cbufsize );
    while ( dualCommandBufferConsumed( device->vm, bufid ) == 0 ){ ; }

    double b= Timer_GetMS();
    if (!packetized) {
	gltilesize/=2;
    }
    if (debug_kernel||!_quiet)
	addCacheStats(4*perf[2], perf[0],perf[1]);
    if (!_quiet) printf("CLOCKS[%d] 3D_BUSY[%d] (%d%% busy) TX_MISS[%d]\n", perf[0], perf[1], (int)(100.f * (float)perf[1] / (float)perf[0]), perf[2]);
//    memset (perf,0,4*sizeof(int));

    if (debug_kernel) {
      for (int i=0;i<debug_kernel;++i) {

	  float* tmp=(float*)((char*)device->outputAddressCPU+device->bytecountAGP);
        memset(tmp,0x7f, 65536*sizeof(float));
        debugconst[0]=(float)i;
        debugconst[3]=1.0;
        cbp = new DUALcbufPack((unsigned int *)device->cbufAddressCPU,1024*512);    
        cbp->appendInvConstfCache();
        cbp->appendFlushOutCache();
        cbp->appendSetOutFmt( packetized?0:0, device->outputAddressGPU+device->bytecountAGP, AMU_CBUF_FLD_FORMAT_FLOAT32_4, AMU_CBUF_FLD_TILING_LINEAR, (packetized?Width:2*Width),(packetized?Height:2*Height));
	if (packetized) {
	    cbp->appendSetOutFmt( 1, device->outputAddressGPU+device->bytecountAGP+Width*Height*sizeof(float)*4, AMU_CBUF_FLD_FORMAT_FLOAT32_4, AMU_CBUF_FLD_TILING_LINEAR, (packetized?Width:2*Width),(packetized?Height:2*Height));
	    cbp->appendSetOutFmt( 2, device->outputAddressGPU+device->bytecountAGP+Width*Height*sizeof(float)*8, AMU_CBUF_FLD_FORMAT_FLOAT32_4, AMU_CBUF_FLD_TILING_LINEAR, (packetized?Width:2*Width),(packetized?Height:2*Height));
	    cbp->appendSetOutFmt( 3, device->outputAddressGPU+device->bytecountAGP+Width*Height*sizeof(float)*12, AMU_CBUF_FLD_FORMAT_FLOAT32_4, AMU_CBUF_FLD_TILING_LINEAR, (packetized?Width:2*Width),(packetized?Height:2*Height));
	}
        cbp->appendFlushOutCache();
        cbp->appendSetDomainTiled( 0, 0, (packetized?Width:2*Width)-1, (packetized?Height:2*Height)- 1 );
        cbp->appendInvCondOutCache();

        cbp->appendStartProgram();

        cbufsize = cbp->getCommandBufferSize();
        delete cbp;
        bufid = dualSubmitCommandBuffer( device->vm, device->cbufAddressGPU, cbufsize );
        while ( dualCommandBufferConsumed( device->vm, bufid ) == 0 ){ ; }
        {
        for (int i=0;i<128*128;++i) {
          if (*(tmp+4*i+3)==-1){
            //printf ("Error on %d\n",4*i);
          }
        }
        }
        static int mycount=0;
        if (mycount++>=debug_offset) {
          int offt=4*(Width*Height/2+Width/2);
          if (!_quiet) printf("%4d: %f %f %f %f\n",i,*(tmp+offt),*(tmp+offt+1),*(tmp+offt+2),*(tmp+offt+3));
	  if (packetized) {
	      if (!_quiet) printf("%4d: %f %f %f %f\n",i,*(tmp+Width*Height*4+offt),*(tmp+Width*Height*4+offt+1),*(tmp+Width*Height*4+offt+2),*(tmp+Width*Height*4+offt+3));
	      if (!_quiet) printf("%4d: %f %f %f %f\n",i,*(tmp+Width*Height*8+offt),*(tmp+Width*Height*8+offt+1),*(tmp+Width*Height*8+offt+2),*(tmp+Width*Height*8+offt+3));
	      if (!_quiet) printf("%4d: %f %f %f %f\n",i,*(tmp+Width*Height*12+offt),*(tmp+Width*Height*12+offt+1),*(tmp+Width*Height*12+offt+2),*(tmp+Width*Height*12+offt+3));
	  }
          else processdat((float*)tmp,packetized?Width:(Width*2),packetized?Height:(2*Height));
        }
	if (_quiet)printf ("CacheMiss;%d\nClocks  ;%d\n",perf[2]*4,perf[0]);
      }
    }

    if (!packetized) {
      DUALcbufPack* cbp = new DUALcbufPack( ( unsigned int* ) device->cbufAddressCPU, 1024 * 1024);      
      cbp->appendSetInpFmt( 0, device->info.baseAddressGPU+device->bytecountGPU, AMU_CBUF_FLD_FORMAT_FLOAT32_4, AMU_CBUF_FLD_TILING_TILED0, Width*2, Height*2 );
      cbp->appendSetOutFmt( 0, hits->tHitPtr.ctm.ptr, AMU_CBUF_FLD_FORMAT_FLOAT32_4, AMU_CBUF_FLD_TILING_TILED0, Width, Height );
      cbp->appendSetOutFmt( 1, hits->uuPtr.ctm.ptr, AMU_CBUF_FLD_FORMAT_FLOAT32_4, AMU_CBUF_FLD_TILING_TILED0, Width, Height );
      cbp->appendSetOutFmt( 2, hits->vvPtr.ctm.ptr, AMU_CBUF_FLD_FORMAT_FLOAT32_4, AMU_CBUF_FLD_TILING_TILED0, Width, Height );
      cbp->appendSetOutFmt( 3, hits->triNumPtr.ctm.ptr, AMU_CBUF_FLD_FORMAT_FLOAT32_4, AMU_CBUF_FLD_TILING_TILED0, Width, Height );
      setLiteralConstants(device, device->rasterShader_constants, device->fconstRasterShaderAddressCPU, device->iconstRasterShaderAddressCPU );
      cbp->appendFlushOutCache();
      cbp->appendInvCondOutCache();
      cbp->appendSetInstFmt( device->rasterShaderKernelAddressGPU, 0, 0, 0 );
      cbp->appendInvInstCache();
      cbp->appendSetConstfFmt( device->fconstRasterShaderAddressGPU, 0, 0, 0 );
      cbp->appendInvConstfCache();
      // Integers
      cbp->appendSetConstiFmt( device->iconstRasterShaderAddressGPU, 0, 0, 0 );
      cbp->appendInvConstiCache();
      // Set domain of output
      cbp->appendSetDomainTiled( 0, 0, Width   - 1, Height   - 1 );
      // After setting everything up, start program
      cbp->appendStartProgram();
      AMuint32 cbufsize = cbp->getCommandBufferSize();
      unsigned int bufid = dualSubmitCommandBuffer( device->vm, device->cbufAddressGPU, cbufsize );
      while ( dualCommandBufferConsumed( device->vm, bufid ) == 0 ){ ; }
    }
    if (debug_kernel==0||!_quiet) {
	if (_quiet) {
	    printf ("%.3f;",iter*numRays/(b-a)/1000.);
	}else {
	    printf ("%f million rays/second: %d Rays took %f mseconds\n",
		    iter*numRays/(b-a)/1000.,
		    numRays*iter,
		    (b-a));
	}
    }

   packetized=oldpacketize;    
    fflush(stdout);
#endif
}

void
KDTreeCTM::intersectPacket(const RayCTM rays[],
                           uint32 numRays, HitCTM hits[])
{
  intersect( rays, numRays, hits );
}

void
KDTreeCTM::intersectP(const RayCTM rays[],
                      uint32 numRays, HitCTM hits[])
{
  intersect( rays, numRays, hits );
}

void
KDTreeCTM::intersectPacketP(const RayCTM rays[],
                            uint32 numRays, HitCTM hits[])
{
  intersect( rays, numRays, hits );
}

