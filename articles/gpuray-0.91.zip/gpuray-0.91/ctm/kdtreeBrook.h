/*
 * kdtreeCTM.h --
 *
 *      k-D tree / axis-aligned bounding box tree acceleration structure.
 */

#ifndef __CELL_KDTREEBROOK_H__
#define __CELL_KDTREEBROOK_H__

#include <math.h>
#include <brook/brook.hpp>
#include "../scene.h"
#include "../ctm/ctmTypes.h"
#include "../ctm/acceleratorCTM.h"
#include "../ctm/gpuDeviceFactory.h"

class KDTreeBrook : public AcceleratorCTM
{
public:
  KDTreeBrook(const Scene& scene, const Opts& options, BoundingBoxCTM *bbox);
  virtual ~KDTreeBrook(void);
  uint32 getBatchGranularity();
  void IntersectRay(const RayCTM &ray, HitCTM *hit);
  void intersect(const RayCTM rays[],
                 uint32 numRays, HitCTM hits[]);
  void intersectPacket(const RayCTM rays[],
                       uint32 numRays, HitCTM hits[]);

  void intersectP(const RayCTM rays[],
                  uint32 numRays, HitCTM hits[]);
  void intersectPacketP(const RayCTM rays[],
                        uint32 numRays, HitCTM hits[]);

protected:
    brook::stream*hitTT;
    brook::stream*hitUU;
    brook::stream*hitVV;
    brook::stream*hitID;
    brook::stream*triangles;
    brook::stream*kdtree;
    brook::stream*triangleIDsGPU;
    brook::stream*unifiedHitBuffer;
    uint32 _triangleCount;
    unsigned int TriWidth;
    unsigned int TriHeight;
    float fov;
    float * _triangleDataA;
    float * _triangleDataB;
    float * _triangleDataC;
    float * triangles0;
    unsigned int kdtreeWidth;    
    unsigned int kdtreeHeight;
    uint32 _nodeCount;
    CtmKdTreeNode* _nodes;
    float *hitBackingStore;
    int benchmark;
    bool _dotrace;
    bool _useRaster;
    unsigned int _repeatFrameSubmitCount;
    BoundingBoxCTM *_bbox;
    bool packetized;
    uint32 _bruteForceTriCount;
    float* triangleIDs;
};

#endif
