/*
 * kdtreeCTM.cpp --
 *
 *      k-D tree spatial subdivision accelerator.
 */
#include "../sampler.h"
#include "kdtreeCTM.h"
#include <assert.h>
#include <errno.h>
#include <brook/brook.hpp>
#include "../scenecache.h"
#include "../log.h"
#include "../timer.h"
#include "../cpu/cpuTracer.h"
/////////////////////////////////////////
bool use_kdtree=true;
namespace brook {
static const StreamType float4x3[] = {__BRTFLOAT4, __BRTFLOAT4, __BRTFLOAT4, __BRTNONE};
}
struct CTMData {
  brook::stream * triAddressGPU;
  brook::stream * kdtreeAddressGPU;

  brook::stream * RayDGPU;
  brook::stream * HitTT;
  brook::stream * HitUU;
  brook::stream * HitVV;
  brook::stream * HitID;
  //not sure if this belongs in class  AMUcbufPack* cbp;
  CTMData(unsigned int cardID=0) {
      triAddressGPU=NULL;

      kdtreeAddressGPU=NULL;
      RayDGPU=NULL;
      HitTT=NULL;
      HitUU=NULL;
      HitVV=NULL;
      HitID=NULL;
  }
  ~CTMData() {
      if (triAddressGPU) {
          delete triAddressGPU;
      }
      if (kdtreeAddressGPU) {
          delete kdtreeAddressGPU;
      }
      if (RayDGPU) {
          delete RayDGPU;
      }
      if (HitTT) delete HitTT;
      if (HitUU) delete HitUU;
      if (HitVV) delete HitVV;
      if (HitID) delete HitID;
  }
};
void  brookTrace (const float4  scenecounts,
		const float4  tMinMax,
		const float4  bboxmin,
		const float4  bboxmax,
		const float4  debugme,
		const float4  raysO,
		::brook::stream raysD,
		::brook::stream triangles,
		::brook::stream kdtree,
		::brook::stream hitTT,
		::brook::stream hitUU,
		::brook::stream hitVV,
                  ::brook::stream hitID);
KDTreeCTM::KDTreeCTM(const Scene& scene, const Opts& options)
{
  bytecount=0;
  device = new CTMData;
#ifdef USE_CTM  
  _threadCount = GetKeyValueInt( "speCount", options.accelOpts, 8 );
  if( _threadCount < 1 || _threadCount > kMaximumThreadCount )
  {
    fprintf( stderr, "Invalid SPE thread count %d.\n", _threadCount );
    exit( 1 );
  }
#endif
  _repeatFrameSubmitCount = GetKeyValueInt(
    "frameCount", options.accelOpts, 1 );
  if( _repeatFrameSubmitCount < 1 )
  {
    fprintf( stderr, "Invalid frame count %d.\n", _repeatFrameSubmitCount );
    exit( 1 );
  }

  KDTreeBuildOptions buildOptions;
  buildOptions.minNodeExtentRatio = 1.0f/1024.0f;
  //  buildOptions.minAbsoluteProbability=2.0f;
  KDTree* builtTree = BuildKDTreeCached( options, &scene, buildOptions );

  {
    BoundingBox bounds = builtTree->getBounds();
    for( uint32 ii = 0; ii < 3; ii++ )
    {
      _rayOffset.v[ii] = 1-bounds.minimum[ii];
      _bboxMin.v[ii] = bounds.minimum[ii]+_rayOffset.v[ii];
      _bboxMax.v[ii] = bounds.maximum[ii]+_rayOffset.v[ii];
    }
  }
  _nodeCount = builtTree->getNodeCount();
  kdtreeWidth =2048;
  kdtreeHeight =_nodeCount/kdtreeWidth+((_nodeCount%kdtreeWidth)?1:0);
  kdtreeHeight = (kdtreeHeight/4+ (kdtreeHeight%4?1:0))*4;

  PRINT(("k-d tree node count %d\n", _nodeCount));
  PRINT(("k-d tree triangle index count %d\n", builtTree->getPrimitiveIndexCount()));
  const KDTreeNode* builtNodes = builtTree->getNodes();

  _nodes = (CtmKdTreeNode*) AllocateAligned(
    kdtreeWidth*kdtreeHeight * sizeof(CtmKdTreeNode), 128 );
  uint32 triangleIndexCount = builtTree->getPrimitiveIndexCount();
  const int* builtIndices = builtTree->getPrimitiveIndices();


  int* whoIsMyParent = new int[ _nodeCount ];
  whoIsMyParent[0] = -1;

  for( uint32 ii = 0; ii < _nodeCount; ii++ )
  {
    if( ii == 1 ) continue;

  KDTreeNode builtNode = builtNodes[ii];
    
      uint32 splitAxis = builtNode.split.leftChild & 0x3;

      if( splitAxis != 0x3 )
          {
         float splitValue;
         uint32 leftChild;

         splitValue = builtNode.split.splitValue+_rayOffset.v[splitAxis];
         leftChild = builtNode.split.leftChild >> 3;

         assert( leftChild % 1 == 0 );

         whoIsMyParent[ leftChild ] = ii;
         whoIsMyParent[ leftChild+1 ] = ii;
      }
  }

  for( uint32 ii = 0; ii < _nodeCount; ii++ )
  {
    if( ii == 1 ) continue;

      KDTreeNode builtNode = builtNodes[ii];
      CtmKdTreeNode& node = _nodes[ii];

      uint32 splitAxis = builtNode.split.leftChild & 0x3;

      if( splitAxis == 0x3 )
      {
         uint32 firstPrimitiveIndex, primitiveCount;

         primitiveCount = builtNode.leaf.numPrimitives;
         firstPrimitiveIndex = builtNode.leaf.firstPrimitive >> 2;

         node.leaf.primitiveCount_tag = (-(float)primitiveCount) -1.0f;
         node.leaf.firstPrimitiveIndex = (-(float)firstPrimitiveIndex) -1.0f;

      }
      else
      {
         float splitValue;
         uint32 leftChild;

         splitValue = builtNode.split.splitValue+_rayOffset.v[splitAxis];
         leftChild = builtNode.split.leftChild >> 3;

         assert( leftChild % 1 == 0 );

         node.split.leftChildIndex_splitAxis = (float)leftChild;
         node.split.splitValue = splitValue;
         assert(leftChild>0||ii==1);
         if (splitAxis&2)
           node.split.leftChildIndex_splitAxis*=-1.0f;
         assert (splitValue>0);
         if (splitAxis&1)
           node.split.splitValue*=-1.0f;
      }
   }


   _triangleCount = triangleIndexCount;

    unsigned int tc=(use_kdtree?_triangleCount:_bruteForceTriCount);
    TriWidth=2048;//tc/TriHeight+(tc%TriHeight?1:0);
    unsigned int tcroundup=tc/TriWidth+(tc%TriWidth?1:0);
    TriHeight=4*(tcroundup/4 + (tcroundup%4?1:0));
    printf ("Width %d Height %d\n",TriWidth,TriHeight);

   _triangleIDs = new uint32[ _triangleCount ];
   _triangleDataA = (float *)malloc(
                                    TriWidth*TriHeight * sizeof(float)*12);

   _triangleDataB = _triangleDataA+4;
   _triangleDataC = _triangleDataB+4;
   device->triAddressGPU = new brook::stream(brook::float4x3,TriHeight,TriWidth,-1);
   const F3* v0 = scene.vertices(0);
   const F3* v1 = scene.vertices(1);
   const F3* v2 = scene.vertices(2);
   _bruteForceTriCount=scene.nTris();
   this->_v0=new F3[_bruteForceTriCount];
   this->_v1=new F3[_bruteForceTriCount];
   this->_v2=new F3[_bruteForceTriCount];
   for (uint32 ii=0;ii<_bruteForceTriCount;++ii) {
     for (uint32 jj=0;jj<3;++jj) {
       this->_v0[ii].v[jj]=v0[ii].v[jj]+_rayOffset.v[jj];
       this->_v1[ii].v[jj]=v1[ii].v[jj]+_rayOffset.v[jj];
       this->_v2[ii].v[jj]=v2[ii].v[jj]+_rayOffset.v[jj];
     }
   }
   for( uint32 ii = 0; ii < triangleIndexCount; ii++ )
   {
      F3Packet packet;
      F3 triV0, e1, e2, e2xe1;
      uint32 triangleIndex;

      triangleIndex = _triangleIDs[ii] = builtIndices[ii];

      triV0 = v0[triangleIndex];
      F3_SUB(e1, v1[triangleIndex], v0[triangleIndex]);
      F3_SUB(e2, v2[triangleIndex], v0[triangleIndex]);
      F3_CROSS(e2xe1, e2, e1);

      packet.v[0] = triV0.v[0]+_rayOffset.v[0];
      packet.v[1] = triV0.v[1]+_rayOffset.v[1];
      packet.v[2] = triV0.v[2]+_rayOffset.v[2];
      packet.v[3] = e2xe1.v[0];

      packet.v[4] = e1.v[0];
      packet.v[5] = e1.v[1];
      packet.v[6] = e1.v[2];
      packet.v[7] = e2xe1.v[1];

      packet.v[8] = e2.v[0];
      packet.v[9] = e2.v[1];
      packet.v[10] = e2.v[2];
      packet.v[11] = e2xe1.v[2];

      memcpy(&_triangleDataA[ii*4*3],&packet.v[0],sizeof(float)*4);
      memcpy(&_triangleDataA[ii*4*3+4],&packet.v[4],sizeof(float)*4);
      memcpy(&_triangleDataA[ii*4*3+8],&packet.v[8],sizeof(float)*4);
   }
   delete builtTree;
   streamRead(*device->triAddressGPU,_triangleDataA);
   // Bind inputs
   device->kdtreeAddressGPU = new brook::stream(::brook::getStreamType((float2*)0),kdtreeHeight,kdtreeWidth,-1);   
   streamRead(*device->kdtreeAddressGPU,_nodes);
}

KDTreeCTM::~KDTreeCTM(void)
{
  delete device;

}
uint32
KDTreeCTM::getBatchGranularity()
{
  return 1;
}

void KDTreeCTM::IntersectRay(const RayCPU &ray,
                  HitCPU *hit) 
{
   unsigned int jj;

   for (jj = 0; jj < BUNDLE_SIZE; jj++) {
      float tBest, uBest, vBest;
      int triBest;
      F3 o, d;
      unsigned int ii;

      tBest = FLT_MAX;
      triBest = -1;
      d.x = ray.d.v[jj];
      d.y = ray.d.v[BUNDLE_SIZE + jj];
      d.z = ray.d.v[2*BUNDLE_SIZE + jj];
      o.x = ray.o.v[jj];
      o.y = ray.o.v[BUNDLE_SIZE + jj];
      o.z = ray.o.v[2*BUNDLE_SIZE + jj];
      for (ii = 0; ii <_bruteForceTriCount; ii++) {
         F3 edge1, edge2;
         F3 pvec, qvec, tvec;
         float invDet, time, uu, vv;

         F3_SUB(edge1, _v1[ii], _v0[ii]);
         F3_SUB(edge2, _v2[ii], _v0[ii]);
         F3_CROSS(pvec, d, edge2);
         invDet = 1.0f / F3_DOT(edge1, pvec);
         F3_SUB(tvec, o, _v0[ii]);
         F3_CROSS(qvec, tvec, edge1);

         /*
          * Test if the time the ray hits the plane of the triangle falls
          * within the ray's current interval
          */

         time = F3_DOT(edge2, qvec) * invDet;
         if (time > tBest || time < 0) {
           ///STAT_INC_BY(TriMissTHit, time > tBest);
           continue;
         }

         /*
          * Make sure the ray hits the triangle (and not just the triangle's
          * plane)
          */

         uu = F3_DOT(tvec, pvec) * invDet;
         vv = F3_DOT(d, qvec) * invDet;
         if (uu < 0 || vv < 0 || uu + vv > 1.0f) {
           ///STAT_INC(TriMissBary);
           continue;
         }
         tBest = time;
         uBest = uu;
         vBest = vv;
         triBest = ii;
         ///STAT_INC(TriHit);
      }
      hit->tHit[jj] = tBest;
      hit->uu[jj] = uBest;
      hit->vv[jj] = vBest;
      hit->triNum[jj] = triBest;
   }

}
#define __BrtFloat4 float4
#define __BrtFloat3 float3
#define __BrtFloat2 float2
#define __BrtFloat1 float1

#include "include/brtvector.hpp"
float4 arrayfloat4(float *input) {
  return float4(input[0],input[1],input[2],input[3]);
}
void brookish_intersect (
        float4 scenecounts,//x = max triindex y = triwidth z = max node w = node width
        float4 tMinMax,//x = min y = max
        float4 bboxmin ,
        float4 bboxmax ,
        float4 debugme ,
        float4 raysO,
        float4* rays3,
        float4* rays4,
        float4* rays5,
        
        float4* triangles0,
        float4* triangles1,
        float4* triangles2,
        float2* kdtree,
        float2 wpos,
	float4 & hitTT,
	float4 & hitUU,
	float4 & hitVV,
	float4 & hitID);
//on 1024x1024 591x679 is b0rked
float4 fromArray (float *a) {
    return float4(a[0],a[1],a[2],a[3]);
}
extern double fetch1count;
extern double fetch2count;
extern double fetch4count;
                           
void
KDTreeCTM::intersect(const RayCPU rays[],
                     uint32 numRays, HitCPU hits[])
{
    unsigned int Width=numRays/1024;
    if (Width==1)
        Width++;
    assert(numRays%1024==0);
    unsigned int Height=1024/BUNDLE_SIZE;
    
    static float * output[4]={(float*) malloc(sizeof(float)*4*Width*Height),
                              (float*) malloc(sizeof(float)*4*Width*Height),
                              (float*) malloc(sizeof(float)*4*Width*Height),
                              (float*) malloc(sizeof(float)*4*Width*Height)};
    
    static float * raysD = (float*) malloc(sizeof(float)*12*Width*Height);
    
    unsigned int whichbadray=0;
    unsigned int whichgoodray=0;
      
    float badray[4]={0,0,0,0};
      
    {
            
      //example 1 uint32 badcoord[2]={321,506};
      //uint32 goodcoord[2]={322,506};
      uint32 badcoord[2]={212,169};
      uint32 goodcoord[2]={211,169};
      for (unsigned int i=0;i<numRays;i+=BUNDLE_SIZE) {
        for (int j=0;j<BUNDLE_SIZE;++j) {
          uint32 x,y;
          Sampler_IndexTo2D(i+j,256,&x,&y);
          if (x==badcoord[0]&&y==badcoord[1]) {//if (x==295&&y==339) {//589x679   
            badray[0]=(float)((i/4)%Width);
            badray[1]=(float)((i/4)/Width);
            printf ("Yo y'all the bad ray is %f and %f or total of %d\n",badray[0],badray[1],i+j);
            whichbadray = i+j;
          }
          if (x==goodcoord[0]&&y==goodcoord[1]) {//if (x==296&&y==339) {//590x679
            badray[2]=(float)((i/4)%Width);
            badray[3]=(float)((i/4)/Width);
            printf ("Yo y'all the good ray is %f and %f or total of %d\n",badray[2],badray[3],i+j);
            whichgoodray = i+j;
          }
          raysD[i*3+j]=rays[i/4].d.v[j];
          raysD[i*3+BUNDLE_SIZE+j]=rays[i/4].d.v[BUNDLE_SIZE+j];
          raysD[i*3+2*BUNDLE_SIZE+j]=rays[i/4].d.v[BUNDLE_SIZE*2+j];         
        }
      }
      if (device->RayDGPU==NULL)
          device->RayDGPU= new brook::stream(brook::float4x3,Height,Width,-1);
      if (device->HitTT==NULL)
          device->HitTT= new brook::stream(brook::getStreamType((float4*)0),Height,Width,-1);
      if (device->HitUU==NULL)
          device->HitUU= new brook::stream(brook::getStreamType((float4*)0),Height,Width,-1);
      if (device->HitVV==NULL)
          device->HitVV= new brook::stream(brook::getStreamType((float4*)0),Height,Width,-1);
      if (device->HitID==NULL)
          device->HitID= new brook::stream(brook::getStreamType((float4*)0),Height,Width,-1);
      streamRead(*device->RayDGPU,raysD);
    }
    float triangleIndex[ 4 ] = {0,0,0,0};
    triangleIndex[3]=(float)kdtreeWidth;
    triangleIndex[2]=(float)_nodeCount;
    const int num_samplers=16;

    
    triangleIndex[0]=(float)(use_kdtree?_triangleCount:_bruteForceTriCount);
    triangleIndex[1]=(float)TriWidth;
    float initialHit[4]={.000000000001f,1000000.,0,0};
    float bboxMin[4]={_bboxMin.v[0]-1,_bboxMin.v[1]-1,_bboxMin.v[2]-1};
    float bboxMax[4]={_bboxMax.v[0]+1,_bboxMax.v[1]+1,_bboxMax.v[2]+1};
    int idiotic[4]={253,0,0,0};
    float raysO[4]={rays[0].o.v[0]+_rayOffset.v[0],
                    rays[0].o.v[BUNDLE_SIZE]+_rayOffset.v[1],
                    rays[0].o.v[2*BUNDLE_SIZE]+_rayOffset.v[2],0};
    fetch1count=0;
    fetch2count=0;
    fetch4count=0;
    for (int i=0;i<1;++i) {

    brookTrace(fromArray(triangleIndex),
               fromArray(initialHit),
               fromArray(bboxMin),
               fromArray(bboxMax),
               fromArray(badray),
               fromArray(raysO),
               *device->RayDGPU,
               *device->triAddressGPU,
               *device->kdtreeAddressGPU,
               *device->HitTT,
               *device->HitUU,
               *device->HitVV,
               *device->HitID);
    }
    streamWrite(*device->HitTT,output[0]);
    streamWrite(*device->HitUU,output[1]);
    streamWrite(*device->HitVV,output[2]);
    streamWrite(*device->HitID,output[3]);
    if (fetch1count!=0||fetch2count!=0||fetch4count!=0)
    printf ("Fetch 1's: %.0f, Fetch 2's: %.0f, Fetch 4's %.0f\nTotal Fetches %.0f  Floats Read %.0f  Bytes Read %.0f\n",
	    fetch1count,
	    fetch2count,
	    fetch4count,
	    fetch1count+fetch2count+fetch4count,
	    fetch1count+2*fetch2count+4*fetch4count,
	    (fetch1count+2*fetch2count+4*fetch4count)*4);
	    
    //CALL HERE
    for (unsigned int i=0;i<4;++i) {
        for (unsigned int j=0;j<BUNDLE_SIZE;++j) {
       printf ("output[%d][%d]: %f\n",i,j,output[i][(whichgoodray/BUNDLE_SIZE)*BUNDLE_SIZE+j]);
     }
   }
   printf ("Bad\n");
   for (unsigned int i=0;i<4;++i) {
     for (unsigned int j=0;j<BUNDLE_SIZE;++j) {
       printf ("output[%d][%d]: %f\n",i,j,output[i][(whichbadray/BUNDLE_SIZE)*BUNDLE_SIZE+j]);
     }
   }
   fflush(stdout);

    int copysize=numRays;//(Width*Height<numRays?Width*Height:numRays);
    for (unsigned int i=0;i<numRays;i+=BUNDLE_SIZE) {
      if (i==0/*||i==numRays-BUNDLE_SIZE*/) {
        hits[i/BUNDLE_SIZE].tHit[0]=.1f;
        hits[i/BUNDLE_SIZE].uu[0]=.7f;
        hits[i/BUNDLE_SIZE].vv[0]=.7f;
        hits[i/BUNDLE_SIZE].triNum[0]=0;
      }else
        for (int j=0;j<BUNDLE_SIZE;++j) {
            hits[i/BUNDLE_SIZE].tHit[j]=output[0][i+j];
            hits[i/BUNDLE_SIZE].uu[j]=output[1][i+j];
            hits[i/BUNDLE_SIZE].vv[j]=output[2][i+j];
            
            uint32 triangleIndex = (uint32)output[3][i+j];
            if(use_kdtree) {
                triangleIndex = triangleIndex < 0 ? -1 : _triangleIDs[triangleIndex];
            }
            hits[i/BUNDLE_SIZE].triNum[j]=triangleIndex;
        }
    }
    if(0)
        for(unsigned int ii = 0, numPackets = numRays / BUNDLE_SIZE; ii < numPackets; ii+=2) {
            memset(&hits[ii],0,sizeof(HitCPU));
            IntersectRay(rays[ii], &hits[ii]);
        }
}

void
KDTreeCTM::intersectPacket(const RayCPU rays[],
                           uint32 numRays, HitCPU hits[])
{
  intersect( rays, numRays, hits );
}

void
KDTreeCTM::intersectP(const RayCPU rays[],
                      uint32 numRays, HitCPU hits[])
{
  intersect( rays, numRays, hits );
}

void
KDTreeCTM::intersectPacketP(const RayCPU rays[],
                            uint32 numRays, HitCPU hits[])
{
  intersect( rays, numRays, hits );
}

