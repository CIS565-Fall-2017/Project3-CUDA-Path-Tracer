#include "ctmDisplayDX.h"


PixelDisplayerCtmDX::PixelDisplayerCtmDX( RenderContextDX9* inRenderContext, BrookContext*inBrookContext ):PixelDisplayerBrookDX9(inRenderContext,inBrookContext){
    
} 

void PixelDisplayerCtmDX::Display( int inWidth, int inHeight, const PixelCTM* inPixels ){
    this->PixelDisplayerBrookDX9::Display(*inPixels->stream);
}
