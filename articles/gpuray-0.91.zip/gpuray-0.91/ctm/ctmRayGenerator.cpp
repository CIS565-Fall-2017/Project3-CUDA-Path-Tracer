#include "gpuDevice.h"

#include "ctmTracer.h"
#include <xmmintrin.h>
#include "../timer.h"
#include "../sampler.h"
#include "../log.h"

static float float_min (float a, float b) {
  return a>b?b:a;
}
static float float_max (float a, float b) {
  return a>b?a:b;
}

RayGeneratorCTM::RayGeneratorCTM(
   CameraManager* inCameraManager,
   IPrimaryRayCallbackCTM* inContinuation,
   GPUDevice* device,
   BoundingBoxCTM* bbox )
{
   _cameraManager = inCameraManager;
   _continuation = inContinuation;
   this->device = device;
   _bbox = bbox;
   raySize = 0;
   rayLocationGPU = 0x8fffffff;
}

struct SimpleRay {
  F3 o;
  F3 d;
};
SimpleRay fromRay(RayPacketCTM a, int which) {
  SimpleRay ret;
  ret.o.v[0]=a.o.v[BUNDLE_SIZE*0+which];
  ret.o.v[1]=a.o.v[BUNDLE_SIZE*1+which];
  ret.o.v[2]=a.o.v[BUNDLE_SIZE*2+which];

  ret.d.v[0]=a.d.v[BUNDLE_SIZE*0+which];
  ret.d.v[1]=a.d.v[BUNDLE_SIZE*1+which];
  ret.d.v[2]=a.d.v[BUNDLE_SIZE*2+which];
  return ret;
}
void toRay(SimpleRay a, RayPacketCTM &ret, int which ){
  ret.o.v[BUNDLE_SIZE*0+which]=a.o.v[0];
  ret.o.v[BUNDLE_SIZE*1+which]=a.o.v[1];
  ret.o.v[BUNDLE_SIZE*2+which]=a.o.v[2];

  ret.d.v[BUNDLE_SIZE*0+which]=a.d.v[0];
  ret.d.v[BUNDLE_SIZE*1+which]=a.d.v[1];
  ret.d.v[BUNDLE_SIZE*2+which]=a.d.v[2];
}

void RayAssign(float * raysOX,float * raysOY, float * raysOZ,float * raysDX,float * raysDY, float * raysDZ,
               const RayPacketCTM* rays,
               int j,
               F3 _rayOffset,
               F3 _bboxMin,
               F3 _bboxMax) {

          float ray_eps=.0625f;
          float X,Y,Z,raydx,raydy,raydz;
#if 0
          float bbmin=_bboxMin.v[0];
          float bbmax=_bboxMax.v[0];
          bbmin=bbmin*.48f+bbmax*.33f;
          bbmax=_bboxMin.v[0]*.33f+bbmax*.48f;
          X=(float)(bbmin+((bbmax-bbmin)*(double)rand()/(double)RAND_MAX));
          bbmin=_bboxMin.v[1];
          bbmax=_bboxMax.v[1];
          bbmin=bbmin*.48f+bbmax*.33f;
          bbmax=_bboxMin.v[1]*.33f+bbmax*.48f;
          Y =(float)(bbmin+((bbmax-bbmin)*(double)rand()/(double)RAND_MAX));
          bbmin=_bboxMin.v[2];
          bbmax=_bboxMax.v[2];
          bbmin=bbmin*.48f+bbmax*.33f;
          bbmax=_bboxMin.v[2]*.33f+bbmax*.48f;
          Z=(float)(bbmin+((bbmax-bbmin)*(double)rand()/(double)RAND_MAX));
          raydx=(float)(-0.0f+1*(double)rand()/(double)RAND_MAX);//rays[0].d.v[j];
          raydy=(float)(0.0f-.02*(double)rand()/(double)RAND_MAX);//rays[0].d.v[BUNDLE_SIZE+j];
          raydz=(float)(-0.0f+1*(double)rand()/(double)RAND_MAX);//rays[0].d.v[BUNDLE_SIZE*2+j]
#endif
          raydx=rays[0].d.v[j];
          raydy=rays[0].d.v[BUNDLE_SIZE+j];
          raydz=rays[0].d.v[BUNDLE_SIZE*2+j];
          X=rays[0].o.v[j];
          Y=rays[0].o.v[BUNDLE_SIZE+j];
          Z=rays[0].o.v[BUNDLE_SIZE*2+j];

          float len=sqrt(raydx*raydx+raydy*raydy+raydz*raydz);
          raydx/=len;
          raydy/=len;
          raydz/=len;
          float rayox=X+_rayOffset.v[0]+raydx*ray_eps;

          float rayoy=Y+_rayOffset.v[1]+raydy*ray_eps;
          float rayoz=Z+_rayOffset.v[2]+raydz*ray_eps;
          len=raydx*raydx+raydy*raydy+raydz*raydz;
          if  (len<.999||len>1.001)
            printf ("ray too long or short\n");
          
          float tmp1 = (_bboxMin.v[0]-rayox)/raydx;
          float tmp2 = (_bboxMax.v[0]-rayox)/raydx;
          float tfarX=float_max(tmp1,tmp2);

          tmp1 = (_bboxMin.v[1]-rayoy)/raydy;
          tmp2 = (_bboxMax.v[1]-rayoy)/raydy;
          float tfarY=float_max(tmp1,tmp2);

          tmp1 = (_bboxMin.v[2]-rayoz)/raydz;
          tmp2 = (_bboxMax.v[2]-rayoz)/raydz;
          float tfarZ=float_max(tmp1,tmp2);
          
          //tmin=max(tmin,max(tnearX,max(tnearY,tnearZ)));
          float tmax=float_min(tfarX,float_min(tfarY,tfarZ));
		  static int index=0;
		  index++;
          if (tmax>0){
			  /*
			  if (fabs(raysOX[0]-rayox)>.1 ||
				  fabs(raysOY[0]-rayoy)>.1 ||
				  fabs(raysOZ[0]-rayoz)>.1 ||
				  fabs(raysDX[0]-raydx*tmax)>.1 ||
				  fabs(raysDY[0]-raydy*tmax)>.1 ||
				  fabs(raysDZ[0]-raydz*tmax)>.1) {
				  printf("Rays do not match at %d: d: (GPU %f = CPU %f, %f=%f, %f=%f) o: (%f=%f, %f=%f, %f=%f)\n",
						 index, raysOX[0], rayox, raysOY[0], rayoy, raysOZ[0], rayoz,
						 raysDX[0], raydx*tmax, raysDY[0], raydy*tmax, raysDZ[0], raydz*tmax);
			  }
			  */
            raysDX[0]=raydx*tmax;
            raysDY[0]=raydy*tmax;
            raysDZ[0]=raydz*tmax;
          } else {
            raysDX[0]=raydx;
            raysDY[0]=raydy;
            raysDZ[0]=raydz;

          }
          raysOX[0]=rayox;
          raysOY[0]=rayoy;
          raysOZ[0]=rayoz;
		  /*
		  printf("RayAssign D(%x,%x,%x), O(%x,%x,%x)\n",
				 raysDX, raysDY, raysDZ,
				 raysOX, raysOY, raysOZ);
		  */
}       

int ray_quadrant(const RayPacketCTM &a, int offset){
  int x = (a.d.v[BUNDLE_SIZE*0+offset]>=0);
  int y = (a.d.v[BUNDLE_SIZE*1+offset]>=0);
  int z = (a.d.v[BUNDLE_SIZE*2+offset]>=0);
  return x+y*2+z*4;
}
				   
void
RayGeneratorCTM::Generate( int inWidth, int inHeight )
{
   unsigned int numRays = inWidth * inHeight;
   int Width = inWidth/2;
   int Height = inHeight/2;
   CameraInfo cam = _cameraManager->getSceneSpaceCameraInfo();
    bool tiledrays=true;

   if (raySize==0) {

      raySize=48*2*Width*Height;

      rayLocationGPU=device->info.baseAddressGPUb;//+raySize;
	  //backup ray location--should have just enough for a 2048x2048 image...hopefully
	  if (raySize>device->info.arenaSizeGPU) {
		  printf ("ERROR: Using %d bytes of arena b for rays, only %d available\n",raySize,device->info.arenaSizeGPUb);
	  }else {
		  printf ("Using only %d bytes of arena b for rays, %d available\n",raySize,device->info.arenaSizeGPUb);
	  }
	  fflush(stdout);
//      device->bytecountGPU += raySize; //putting it in backup area
   }
//   uint32 rayByteOffset = rayLocation-device->info.baseAddressGPU;
//   unsigned char* cpuRayLocation =(unsigned char *)device->outputAddressCPU+(rayByteOffset);
   {
      float camT[4]={cam.tx,cam.ty};
      float camU[4]={cam.u.x,cam.u.y,cam.u.z};
      float camV[4]={-cam.v.x,-cam.v.y,-cam.v.z};//flip it to match ogl
      float camW[4]={cam.w.x,cam.w.y,cam.w.z};
      float camFrom[4]={cam.from.x,cam.from.y,cam.from.z};
      float bboxMin[4]={_bbox->min.v[0],_bbox->min.v[1],_bbox->min.v[2]};
      float bboxMax[4]={_bbox->max.v[0],_bbox->max.v[1],_bbox->max.v[2]};
      float rayOffset[4]={_bbox->rayOffset.v[0],_bbox->rayOffset.v[1],_bbox->rayOffset.v[2]};
	  float size[4]={(float)Width, (float)Height, 1.0f/(float)Width, 1.0f/(float)Height};
      setUserConstant(device, device->rayGen_constants, device->fconstRayGenAddressCPU, "c0", camT,  AMU_ABI_FLOAT32 );
      setUserConstant(device, device->rayGen_constants, device->fconstRayGenAddressCPU, "c1", camU,  AMU_ABI_FLOAT32 );
      setUserConstant(device, device->rayGen_constants, device->fconstRayGenAddressCPU, "c2", camV,  AMU_ABI_FLOAT32 );
      setUserConstant(device, device->rayGen_constants, device->fconstRayGenAddressCPU, "c3", camW,  AMU_ABI_FLOAT32 );
      setUserConstant(device, device->rayGen_constants, device->fconstRayGenAddressCPU, "c4", camFrom,  AMU_ABI_FLOAT32 );
      setUserConstant(device, device->rayGen_constants, device->fconstRayGenAddressCPU, "c5", bboxMin,  AMU_ABI_FLOAT32 );
      setUserConstant(device, device->rayGen_constants, device->fconstRayGenAddressCPU, "c6", bboxMax,  AMU_ABI_FLOAT32 );
      setUserConstant(device, device->rayGen_constants, device->fconstRayGenAddressCPU, "c7", rayOffset,  AMU_ABI_FLOAT32 );
      setUserConstant(device, device->rayGen_constants, device->fconstRayGenAddressCPU, "c8", size,  AMU_ABI_FLOAT32 );
      DUALcbufPack cbpMem((( unsigned int* ) device->cbufAddressCPU),1024*512);
	  DUALcbufPack *cbp = &cbpMem;
      cbp->appendFlushOutCache();
      setLiteralConstants(device, device->rayGen_constants, device->fconstRayGenAddressCPU, device->iconstRayGenAddressCPU );
      cbp->appendFlushOutCache();
      cbp->appendSetOutFmt( 0, rayLocationGPU, AMU_CBUF_FLD_FORMAT_FLOAT32_4, tiledrays?AMU_CBUF_FLD_TILING_TILED0:AMU_CBUF_FLD_TILING_LINEAR, Width, Height   );
      cbp->appendSetOutFmt( 1, rayLocationGPU+Width*Height*sizeof(float)*4, AMU_CBUF_FLD_FORMAT_FLOAT32_4, tiledrays?AMU_CBUF_FLD_TILING_TILED0:AMU_CBUF_FLD_TILING_LINEAR, Width, Height );
      cbp->appendSetOutFmt( 2, rayLocationGPU+Width*Height*sizeof(float)*8, AMU_CBUF_FLD_FORMAT_FLOAT32_4, tiledrays?AMU_CBUF_FLD_TILING_TILED0:AMU_CBUF_FLD_TILING_LINEAR, Width, Height );
      cbp->appendInvCondOutCache();
      cbp->appendSetInstFmt( device->rayGenKernelAddressGPU, 0, 0, 0 );
      cbp->appendInvInstCache();
      cbp->appendSetConstfFmt( device->fconstRayGenAddressGPU, 0, 0, 0 );
      cbp->appendInvConstfCache();
      // Integers
      cbp->appendSetConstiFmt( device->iconstRayGenAddressGPU, 0, 0, 0 );
      cbp->appendInvConstiCache();
      // Set domain of output
      cbp->appendSetDomainTiled( 0, 0, Width   - 1, Height   - 1 );
      // After setting everything up, start program
      cbp->appendStartProgram();
      AMuint32 cbufsize = cbp->getCommandBufferSize();
      unsigned int bufid = dualSubmitCommandBuffer( device->vm, device->cbufAddressGPU, cbufsize );
      while ( dualCommandBufferConsumed( device->vm, bufid ) == 0 ){ ; }
   }
#if 0
   RayPacketCTM *rays = (RayPacketCTM *) AllocateAligned(numRays * sizeof(RayPacketCTM), 16);

   __m128 camTx, camTy, camU[3], camV[3], camW[3];
   __m128 invW, invH, one;
   float t;

   int ii;

   t = Timer_GetMS();
   camTx = _mm_set1_ps(cam.tx);
   camTy = _mm_set1_ps(cam.ty);
   camU[0] = _mm_set1_ps(cam.u.x);
   camU[1] = _mm_set1_ps(cam.u.y);
   camU[2] = _mm_set1_ps(cam.u.z);
   camV[0] = _mm_set1_ps(cam.v.x);
   camV[1] = _mm_set1_ps(cam.v.y);
   camV[2] = _mm_set1_ps(cam.v.z);
   camW[0] = _mm_set1_ps(cam.w.x);
   camW[1] = _mm_set1_ps(cam.w.y);
   camW[2] = _mm_set1_ps(cam.w.z);

   invW = _mm_rcp_ps(_mm_set1_ps((float) inWidth));
   invH = _mm_rcp_ps(_mm_set1_ps((float) inHeight));
   one = _mm_set1_ps(1.0f);


   /*
    * Generate eye rays... (in the same order as krnGenEyeRays())
    */

   for (ii = 0; ii < inHeight * inWidth; ii += BUNDLE_SIZE) {
      __m128 filmX, filmY;
      __m128 rayD[3], norm;
      uint32 x[BUNDLE_SIZE], y[BUNDLE_SIZE], pos;

      pos = ii / BUNDLE_SIZE;

      /*
       * All rays have the same origin: the camera location.
       */

      rays[pos].o.x0 =
         rays[pos].o.x1 = rays[pos].o.x2 = rays[pos].o.x3 = cam.from.x;
      rays[pos].o.y0 =
         rays[pos].o.y1 = rays[pos].o.y2 = rays[pos].o.y3 = cam.from.y;
      rays[pos].o.z0 =
         rays[pos].o.z1 = rays[pos].o.z2 = rays[pos].o.z3 = cam.from.z;


      /*
       * Now determine the direction by sampling the film plane and
       * computing the ray corresponding to the chosen (x, y) location.
       *
       * Since we're generating four packed rays at a time, we actually
       * compute four samples.
       *
       * The scaled film position for (x, y) is (1 - 2x/width, 1 - 2y/height)
       */

      Sampler_IndexTo2D(ii, inWidth, &x[0], &y[0]);
      Sampler_IndexTo2D(ii + 1, inWidth, &x[1], &y[1]);
      Sampler_IndexTo2D(ii + 2, inWidth, &x[2], &y[2]);
      Sampler_IndexTo2D(ii + 3, inWidth, &x[3], &y[3]);

      filmX = _mm_set_ps(x[3] * 2.0f, x[2] * 2.0f, x[1] * 2.0f, x[0] * 2.0f);
      filmY = _mm_set_ps(y[3] * 2.0f, y[2] * 2.0f, y[1] * 2.0f, y[0] * 2.0f);

      filmX = _mm_sub_ps(one, _mm_mul_ps(filmX, invW));
      filmY = _mm_sub_ps(one, _mm_mul_ps(filmY, invH));
      filmX = _mm_mul_ps(camTy, filmX);
      filmY = _mm_mul_ps(camTy, filmY);

      rayD[0] = _mm_add_ps(camW[0], _mm_add_ps(_mm_mul_ps(filmX, camU[0]),
         _mm_mul_ps(filmY, camV[0])));
      rayD[1] = _mm_add_ps(camW[1], _mm_add_ps(_mm_mul_ps(filmX, camU[1]),
         _mm_mul_ps(filmY, camV[1])));
      rayD[2] = _mm_add_ps(camW[2], _mm_add_ps(_mm_mul_ps(filmX, camU[2]),
         _mm_mul_ps(filmY, camV[2])));

      norm = _mm_add_ps(_mm_add_ps(_mm_mul_ps(rayD[0], rayD[0]),
         _mm_mul_ps(rayD[1], rayD[1])),
         _mm_mul_ps(rayD[2], rayD[2]));
      norm = _mm_rsqrt_ps(norm);
      rayD[0] = _mm_mul_ps(rayD[0], norm);
      rayD[1] = _mm_mul_ps(rayD[1], norm);
      rayD[2] = _mm_mul_ps(rayD[2], norm);

      _mm_store_ps(&rays[pos].d.x0, rayD[0]);
      _mm_store_ps(&rays[pos].d.y0, rayD[1]);
      _mm_store_ps(&rays[pos].d.z0, rayD[2]);

   }
   t = Timer_GetMS() -t;
   PRINT(("SSE Eye Ray Generation took %5.2f msecs\n", t));
   double ms;
   ms=Timer_GetMS();
    float * raysDX = reinterpret_cast<float*>(cpuRayLocation);
    float * raysDY = reinterpret_cast<float*>(cpuRayLocation+8*sizeof(float)*Width*Height);
    float * raysDZ = reinterpret_cast<float*>(cpuRayLocation+16*sizeof(float)*Width*Height);

    float * raysOX = reinterpret_cast<float*>(cpuRayLocation+4*sizeof(float));
    float * raysOY = reinterpret_cast<float*>(cpuRayLocation+4*sizeof(float)+8*sizeof(float)*Width*Height);
    float * raysOZ = reinterpret_cast<float*>(cpuRayLocation+4*sizeof(float)+16*sizeof(float)*Width*Height);
    unsigned int whichbadray=0;
    unsigned int whichgoodray=0;
      
    float badray[4]={0,0,0,0};
    static std::vector <SimpleRay>mismatched[8];
    static std::vector <int>mismatchedints[8];
    static std::vector <int>freebundles;
    static std::vector <std::pair<int,int> > pairs;
    freebundles.resize(0);
    pairs.resize(0);
  printf("Time: %5.6f\n", Timer_GetMS() -ms);
    for (int i=0;i<8;++i) {
      mismatched[i].resize(0);
      mismatchedints[i].resize(0);
    }
    {
      bool rebin_packets = false;
//      assert( (unsigned int)(device->outputAddressGPU+device->bytecount+16*Width*Height)%2048 == 0);
//      assert( (unsigned int)(device->outputAddressGPU+device->bytecount)%2048 == 0);
      
      //example 1 uint32 badcoord[2]={321,506};
      //uint32 goodcoord[2]={322,506};
      uint32 badcoord[2]={0,0};
      uint32 goodcoord[2]={0,0};
      //std::sort(const_cast<RayCPU*>(rays),const_cast<RayPacketCTM*>(rays+numRays/BUNDLE_SIZE),RayLess());
      for (unsigned int i=0;i<numRays;i+=BUNDLE_SIZE) {

          int dominant=ray_quadrant(rays[i/BUNDLE_SIZE],0);
          for (int j=1;j<BUNDLE_SIZE;++j) {
            if (ray_quadrant(rays[i/BUNDLE_SIZE],j)!=dominant) {
              if (rebin_packets) {
                for (int k=0;k<BUNDLE_SIZE;++k) {            
                  int quad=ray_quadrant(rays[i/BUNDLE_SIZE],k);
                  mismatched[quad].push_back(fromRay(rays[i/BUNDLE_SIZE],k));
                  mismatchedints[quad].push_back(i+k);
                }
                freebundles.push_back(i/BUNDLE_SIZE);
                break;
              }else {
                toRay(fromRay(rays[i/BUNDLE_SIZE],0),*const_cast<RayPacketCTM*>(&rays[i/BUNDLE_SIZE]),j);
              }
              
            }
          }
      
        for (int j=0;j<BUNDLE_SIZE;++j) {
          uint32 x,y;
          Sampler_IndexTo2D(i+j,256,&x,&y);
          if (x==badcoord[0]&&y==badcoord[1]) {//if (x==295&&y==339) {//589x679   
            badray[0]=(float)((i/4)%Width);
            badray[1]=(float)((i/4)/Width);
            //printf ("Yo y'all the bad ray is %f and %f or total of %d\n",badray[0],badray[1],i+j);
            whichbadray = i+j;
          }
          if (x==goodcoord[0]&&y==goodcoord[1]) {//if (x==296&&y==339) {//590x679
            badray[2]=(float)((i/4)%Width);
            badray[3]=(float)((i/4)/Width);
            //printf ("Yo y'all the good ray is %f and %f or total of %d\n",badray[2],badray[3],i+j);
            whichgoodray = i+j;
          }
          RayAssign(raysOX+i*2+j,raysOY+i*2+j,raysOZ+i*2+j,raysDX+i*2+j,raysDY+i*2+j,raysDZ+i*2+j,&rays[i/4],j,_bbox->rayOffset,_bbox->min,_bbox->max);
        }
      }
      printf ("Packet Rebin: %d %d %d %d %d %d %d %d\n",mismatched[0].size(),mismatched[1].size(),mismatched[2].size(),mismatched[3].size(),mismatched[4].size(),mismatched[5].size(),mismatched[6].size(),mismatched[7].size());
      unsigned int fbs=freebundles.size();
      int quadindex=0;      
      int misind=0;
      for (unsigned int i=0;i<fbs;++i) {
        int which=freebundles[i];
        for (unsigned int j=0;j<BUNDLE_SIZE;++j) {
          while (quadindex<8&&misind>=(int)mismatched[quadindex].size()) {
            quadindex++;
            misind=0;
          }
          if (quadindex<8) {
            RayPacketCTM tmp;
            toRay(mismatched[quadindex][misind],tmp,j);
            int ind=which*BUNDLE_SIZE*2+j;
            RayAssign(raysOX+ind,raysOY+ind,raysOZ+ind,
                      raysDX+ind,raysDY+ind,raysDZ+ind,
                      &tmp,j,_bbox->rayOffset,_bbox->min,_bbox->max);
            pairs.push_back(std::pair<int,int>(mismatchedints[quadindex][misind],
                                               which*BUNDLE_SIZE+j));
            misind++;
          }
        }
      }
    }
  printf("Time: %5.6f\n", Timer_GetMS() -ms);
    //copy rays onto the GPU
    DUALcbufPack* copyRay= new DUALcbufPack((unsigned int*)device->cbufRayCopyAddressCPU,1024*512);
	printf("copy1(output=%d, input=%d)\n", device->outputAddressGPU+rayByteOffset, rayLocation);
    copyRay=copy1(copyRay,device,
                  device->outputAddressGPU+rayByteOffset,
                  rayLocation,
                  Width*2,Height*3,true,tiledrays,4);
    printf ("Ray Width %d Height %d\n",Width,Height);
    AMuint32 cbufsize = copyRay->getCommandBufferSize();
    delete copyRay;
    unsigned int bufid = dualSubmitCommandBuffer( device->vm, device->cbufRayCopyAddressGPU, cbufsize );
    while ( dualCommandBufferConsumed( device->vm, bufid ) == 0 ){ ; }
  printf("Time: %5.6f\n", Timer_GetMS() -ms);
#endif
    RayCTM *raysAddress = new RayCTM[1];
    raysAddress->rays.ctm.ptr = rayLocationGPU;
    raysAddress->rays.ctm.tiled = tiledrays;
	raysAddress->raysO.v[0]=cam.from.x+_bbox->rayOffset.v[0];
    raysAddress->raysO.v[1]=cam.from.y+_bbox->rayOffset.v[1];
    raysAddress->raysO.v[2]=cam.from.z+_bbox->rayOffset.v[2];
    raysAddress->camT.v[0]=cam.tx;
    raysAddress->camT.v[1]=cam.ty;
    raysAddress->camU.v[0]=cam.u.x;
    raysAddress->camU.v[1]=cam.u.y;
    raysAddress->camU.v[2]=cam.u.z;
    raysAddress->camV.v[0]=-cam.v.x;
    raysAddress->camV.v[1]=-cam.v.y;
    raysAddress->camV.v[2]=-cam.v.z;
    raysAddress->camW.v[0]=cam.w.x;
    raysAddress->camW.v[1]=cam.w.y;
    raysAddress->camW.v[2]=cam.w.z;
	raysAddress->width = Width;
	raysAddress->height = Height;
	raysAddress->bbox = *_bbox;
	raysAddress->cam=_cameraManager;
    _continuation->Call( inWidth, inHeight, raysAddress );
#if 0
    FreeAligned(rays);
#endif
}

