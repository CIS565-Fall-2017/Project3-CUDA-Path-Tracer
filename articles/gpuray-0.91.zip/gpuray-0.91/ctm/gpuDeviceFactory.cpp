#include <vector>
#include <map>
#include "gpuDeviceFactory.h"
#include "gpuDevice.h"
#include <GL/glut.h>
#include "../timer.h"
#include <windows.h>
int numCards=1;
int curCard=0;
GPUDevice * dev=NULL;
GPUDevice *createGPUDevice(unsigned int numcardss) {
  numCards=numcardss;  
  return (dev=new GPUDevice[numCards]);
}
void printAssemblyFunction(const char * msg) {
    FILE * fp = fopen ("ctm/raytracer.r5xx","ab");
    fprintf (fp,"%s",msg);
    fclose(fp);
}

void printNoPacketAssemblyFunction(const char * msg) {
    FILE * fp = fopen ("ctm/raytracer-single.r5xx","ab");
    fprintf (fp,"%s",msg);
    fclose(fp);
}
void setLiteralConstants(GPUDevice * device, const AMUabiConstsInfo *compOutput, void* floatConstAddressCPU, void* intConstAddressCPU )
{
    //
    // submit all literal values
    //
    float * cf = NULL;
    const float* vf = NULL;
    unsigned char* ci = NULL;
    const unsigned int *vi = NULL;
    for ( int cardNo=0;cardNo<numCards;++cardNo) {
      for ( unsigned int c = 0; c < compOutput->litConstsCount; c++ )
      {
        switch ( compOutput->litConsts[ c ].type )
        {
        case AMU_ABI_FLOAT32:
            {
                cf = pointerTrans(&( ( float* ) floatConstAddressCPU ) [ 4 * compOutput->litConsts[ c ].addr ],cardNo);
                vf = compOutput->litConsts[ c ].value.float32;
                cf[ 0 ] = vf[ 0 ];
                cf[ 1 ] = vf[ 1 ];
                cf[ 2 ] = vf[ 2 ];
                cf[ 3 ] = vf[ 3 ];
                break;//break out inner loop but not outer loop
            }
        case AMU_ABI_INT32:
            {
                ci = pointerTrans(&( ( unsigned char* ) intConstAddressCPU ) [ 4 * compOutput->litConsts[ c ].addr ],cardNo);
                vi = compOutput->litConsts[ c ].value.int32;
                ci[ 0 ] = vi[ 0 ];
                ci[ 1 ] = vi[ 1 ];
                ci[ 2 ] = vi[ 2 ];
                ci[ 3 ] = vi[ 3 ];
                break;//break out inner loop not outer loop
            }
        default:
            break;
        };
      }
    }
}

void setUserConstant( GPUDevice * device, const AMUabiConstsInfo *compOutput, void* addressCPU, const char* name, const void* value, AMUabiDataType type )
{
    //
    //  Scan through compiler output and find the given user constant
    //
  for ( int cardNo=0;cardNo<numCards;++cardNo) {
    for ( unsigned int u = 0; u < compOutput->userConstsCount; u++ )
    {
        if ( strcmp( compOutput->userConsts[ u ].name.str, name ) == 0 )
        {
            if ( compOutput->userConsts[ u ].type == AMU_ABI_FLOAT32 && type == AMU_ABI_FLOAT32 )
            {
                //
                //  Set the user constant's value
                //
                float * c = pointerTrans(&( ( float* ) addressCPU ) [ 4 * compOutput->userConsts[ u ].addr ],cardNo);
                float* v = ( float* ) value;
                c[ 0 ] = v[ 0 ];
                c[ 1 ] = v[ 1 ];
                c[ 2 ] = v[ 2 ];
                c[ 3 ] = v[ 3 ];
                break ;//break out of the inner loop, but not the outer loop
            }
            else if ( compOutput->userConsts[ u ].type == AMU_ABI_INT32 && type == AMU_ABI_INT32 )
            {
                //
                //  Set the user constant's value
                //
                unsigned char * c = pointerTrans(&( ( unsigned char* ) addressCPU ) [ 4 * compOutput->userConsts[ u ].addr ],cardNo);
                unsigned char* v = ( unsigned char* ) value;
                c[ 0 ] = v[ 0 ];
                c[ 1 ] = v[ 1 ];
                c[ 2 ] = v[ 2 ];
                c[ 3 ] = v[ 3 ];
                break ; //break out of inner loop but not the outer loop
            }
        }
    }
  }
}



DUALcbufPack::DUALcbufPack (unsigned int * cbuf, unsigned int size) {
  cbufs= new AMUcbufPack* [numCards];
  for (int cardNo=0;cardNo<numCards;++cardNo) {
    cbufs[cardNo]=new AMUcbufPack(pointerTrans(cbuf,cardNo),size);        
  }  
  i0=0;i1=0;j0=0;j1=1;
  broadcast=true;
}
DUALcbufPack::~DUALcbufPack () {

  for (int cardNo=0;cardNo<numCards;++cardNo) {
    delete cbufs[cardNo];
  }
  delete[]cbufs;
}



void DUALcbufPack::reset () {
  for (int cardNo=0;cardNo<numCards;++cardNo) {
    cbufs[cardNo]->reset();
  }
}
unsigned int DUALcbufPack::getCommandBufferSize () {
  unsigned int retval=0;
  for (int cardNo=0;cardNo<numCards;++cardNo) {
    unsigned int tmp=cbufs[cardNo]->getCommandBufferSize();
    if (tmp>retval)
      retval=tmp;
  }
  return retval;
}
unsigned int DUALcbufPack::appendWaitForIdle () {
  unsigned int retval=0;
  for (int cardNo=0;cardNo<numCards;++cardNo) {
    retval=cbufs[cardNo]->appendWaitForIdle();
    if (retval==0) printf ("IDLE ERROR\n");
  }
  return retval;
}


unsigned int DUALcbufPack::appendInvInstCache () {
  unsigned int retval=0;
  for (int cardNo=0;cardNo<numCards;++cardNo) {
    retval=cbufs[cardNo]->appendInvInstCache();
    if (retval==0) printf ("INV INST ERROR\n");
  }
  return retval;
}
unsigned int DUALcbufPack::appendInvConstfCache () {
  unsigned int retval=0;
  for (int cardNo=0;cardNo<numCards;++cardNo) {
    retval=cbufs[cardNo]->appendInvConstfCache();
    if (retval==0) printf ("INV CONST ERROR\n");
  }
  return retval;
}
unsigned int DUALcbufPack::appendInvConstbCache () {
  unsigned int retval=0;
  for (int cardNo=0;cardNo<numCards;++cardNo) {
    retval=cbufs[cardNo]->appendInvConstbCache();
    if (retval==0) printf ("INV CONSTB IDLE ERROR\n");
  }
  return retval;
}
unsigned int DUALcbufPack::appendInvConstiCache () {
  unsigned int retval=0;
  for (int cardNo=0;cardNo<numCards;++cardNo) {
    retval=cbufs[cardNo]->appendInvConstiCache();
    if (retval==0) printf ("INV CONSTI ERROR\n");
  }
  return retval;
}
unsigned int DUALcbufPack::appendInvCondOutCache () {
  unsigned int retval=0;
  for (int cardNo=0;cardNo<numCards;++cardNo) {
    retval=cbufs[cardNo]->appendInvCondOutCache();
    if (retval==0) printf ("INV CONDOUT ERROR\n");
  }
  return retval;
}
unsigned int DUALcbufPack::appendInvInpCache () {
  unsigned int retval=0;
  for (int cardNo=0;cardNo<numCards;++cardNo) {
    retval=cbufs[cardNo]->appendInvInpCache();
    if (retval==0) printf ("INV INP ERROR\n");
  }
  return retval;
}
unsigned int DUALcbufPack::appendFlushOutCache () {
  unsigned int retval=0;
  for (int cardNo=0;cardNo<numCards;++cardNo) {
    retval=cbufs[cardNo]->appendFlushOutCache();
    if (retval==0) printf ("FLUSHOUT ERROR\n");
  }
  return retval;
}
unsigned int DUALcbufPack::appendFlushCondOutCache () {
  unsigned int retval=0;
  for (int cardNo=0;cardNo<numCards;++cardNo) {
    retval=cbufs[cardNo]->appendFlushCondOutCache();
    if (retval==0) printf ("FLUSHCONDOUT ERROR\n");
  }
  return retval;
}


unsigned int DUALcbufPack::appendSetInstFmt (unsigned int addr, unsigned int fmt, unsigned int tiling, unsigned int width){
  unsigned int retval=0;
  for (int cardNo=0;cardNo<numCards;++cardNo) {
    retval=cbufs[cardNo]->appendSetInstFmt(addrTrans(addr,cardNo),fmt,tiling,width);
    if (retval==0) printf ("INST FMT ERROR\n");
  }
  return retval;
}


unsigned int DUALcbufPack::appendSetInpFmt (unsigned int input, unsigned int addr, unsigned int fmt, unsigned int tiling, unsigned int width, unsigned int height){
  unsigned int retval=0;
  for (int cardNo=0;cardNo<numCards;++cardNo) {
    retval=cbufs[cardNo]->appendSetInpFmt(input, addrTrans(addr,cardNo),fmt,tiling,width,height);
    if (retval==0) printf ("INP FMT ERROR\n");
  }
  return retval;
}
unsigned int DUALcbufPack::appendInitPerfCounters(unsigned int flags) {
  unsigned int retval=0;
  for (int cardNo=0;cardNo<numCards;++cardNo) {
    retval=cbufs[cardNo]->appendInitPerfCounters(flags);
    if (retval==0) printf ("PERF ERROR\n");
  }
  return retval;
}


unsigned int DUALcbufPack::appendReadPerfCounters(unsigned int addr) {
  unsigned int retval=0;
  for (int cardNo=0;cardNo<numCards;++cardNo) {
    retval=cbufs[cardNo]->appendReadPerfCounters(addrTrans(addr,cardNo));
    if (retval==0) printf ("PERF ERROR\n");
  }
  return retval;
}
unsigned int DUALcbufPack::appendSetCondVal(unsigned int val) {
  unsigned int retval=0;
  for (int cardNo=0;cardNo<numCards;++cardNo) {
    retval=cbufs[cardNo]->appendSetCondVal(val);
    if (retval==0) printf ("COND SET ERROR\n");
  }
  return retval;
}
unsigned int DUALcbufPack::appendStartPerfCounters() {
  unsigned int retval=0;
  for (int cardNo=0;cardNo<numCards;++cardNo) {
    retval=cbufs[cardNo]->appendStartPerfCounters();
    if (retval==0) printf ("PERF START ERROR\n");
  }
  return retval;
}

unsigned int DUALcbufPack::appendStopPerfCounters() {
  unsigned int retval=0;
  for (int cardNo=0;cardNo<numCards;++cardNo) {
    retval=cbufs[cardNo]->appendStopPerfCounters();
    if (retval==0) printf ("PERF START ERROR\n");
  }
  return retval;
}

unsigned int DUALcbufPack::appendSetOutFmt (unsigned int output, unsigned int addr, unsigned int fmt, unsigned int tiling, unsigned int width, unsigned int height){
  unsigned int retval=0;
  for (int cardNo=0;cardNo<numCards;++cardNo) {
    retval=cbufs[cardNo]->appendSetOutFmt(output, addrTrans(addr,cardNo),fmt,tiling,width,height);
    if (retval==0) printf ("SETOUT ERROR\n");
  }
  return retval;
}

unsigned int DUALcbufPack::appendSetConstfFmt (unsigned int addr, unsigned int fmt, unsigned int tiling, unsigned int width){
  unsigned int retval=0;
  for (int cardNo=0;cardNo<numCards;++cardNo) {
    retval=cbufs[cardNo]->appendSetConstfFmt(addrTrans(addr,cardNo),fmt,tiling,width);
    if (retval==0) printf ("SETCONST ERROR\n");
  }
  return retval;
}

unsigned int DUALcbufPack::appendSetConstiFmt (unsigned int addr, unsigned int fmt, unsigned int tiling, unsigned int width){
  unsigned int retval=0;
  for (int cardNo=0;cardNo<numCards;++cardNo) {
    retval=cbufs[cardNo]->appendSetConstiFmt(addrTrans(addr,cardNo),fmt,tiling,width);
    if (retval==0) printf ("SET CONSTI ERROR\n");
  }
  return retval;
}

unsigned int DUALcbufPack::appendSetConstbFmt (unsigned int addr, unsigned int fmt, unsigned int tiling, unsigned int width){
  unsigned int retval=0;
  for (int cardNo=0;cardNo<numCards;++cardNo) {
    retval=cbufs[cardNo]->appendSetConstbFmt(addrTrans(addr,cardNo),fmt,tiling,width);
    if (retval==0) printf ("SET CONSTB ERROR\n");
  }
  return retval;
}

unsigned int DUALcbufPack::appendSetCondOutFmt (unsigned int addr, unsigned int fmt, unsigned int tiling, unsigned int width, unsigned int height){
  unsigned int retval=0;
  for (int cardNo=0;cardNo<numCards;++cardNo) {
    retval=cbufs[cardNo]->appendSetCondOutFmt(addrTrans(addr,cardNo),fmt,tiling,width,height);
    if (retval==0) printf ("SET CONDOUT ERROR\n");
  }
  return retval;
}

unsigned int DUALcbufPack::appendSetDomainBroadcast (unsigned int i0, unsigned int j0, unsigned int i1, unsigned int j1){
  this->i0=i0;
  this->i1=i1;
  this->j0=j0;
  this->j1=j1;
  this->broadcast=true;
  unsigned int retval=0;
  for (int cardNo=0;cardNo<numCards;++cardNo) {
    retval=cbufs[cardNo]->appendSetDomain(i0,j0,i1,j1);
    if (retval==0) printf ("SETDOMA ERROR\n");
  }
  return retval;
}

unsigned int DUALcbufPack::appendSetDomainTiled (unsigned int i0, unsigned int j0, unsigned int i1, unsigned int j1){
  this->i0=i0;
  this->i1=i1;
  this->j0=j0;
  this->j1=j1;
  this->broadcast=false;
  return 1;
}

unsigned int gltilesize=32;
unsigned int DUALcbufPack::appendStartProgram(void){
  unsigned int retval=0;
  if (this->broadcast||numCards==1) {
    for (int cardNo=0;cardNo<numCards;++cardNo) {
      if (!this->broadcast) 
      {
        retval=cbufs[cardNo]->appendSetDomain(i0,j0,i1,j1);    
	if (retval==0) printf ("SET DOMAIN ERROR\n");
      }
      retval=cbufs[cardNo]->appendStartProgram();    
      if (retval==0) printf ("STARTPROG ERROR\n");
    }
  }else {
    unsigned int cardNo=0;
    for (unsigned int j=j0;j<=j1;j+=gltilesize) {
      for (unsigned int i=i0;i<=i1;i+=gltilesize) {
        unsigned int ilim=i+gltilesize-1;
        unsigned int jlim=j+gltilesize-1;
        if (ilim>i1)
          ilim=i1;
        if (jlim>j1)
          jlim=j1;
        //printf ("Rendering from (%d,%d) to (%d, %d)\n",i,j,ilim,jlim);
        retval=cbufs[cardNo]->appendSetDomain(i,j,ilim,jlim);
	if (retval==0) printf ("SET DOMAIN ERROR\n");
//	if (cardNo==0)
	retval=cbufs[cardNo]->appendStartProgram();
	if (retval==0) printf ("STARPTOF ERROR\n");
        cardNo++;
        cardNo%=numCards;
      }
	  cardNo++;
	  cardNo%=numCards;
    }
  }
  return retval;
}
struct cbuffer{
    AMmanagedDevice dev;
    AMuint32 addr;
    AMuint32 size;
    AMuint32 *bufids;
};
DWORD WINAPI submitToCard (LPVOID dat) {
    cbuffer * d=(cbuffer*)dat;
    *d->bufids=amSubmitCommandBuffer(d->dev,d->addr,d->size);
    return NULL;
}
std::map<AMuint32,std::vector<AMuint32> >inflightbufs;
bool justprinted=false;
extern AMuint32 dualSubmitCommandBuffer(AMmanagedDevice vm, AMuint32 addr, AMuint32 size){
  std::vector <AMuint32> bufids(numCards);
  std::vector <HANDLE> threadids(numCards);
  std::vector <cbuffer> dats(numCards);
  bool threaded=false;
  for (int cardNo=0;cardNo<numCards;++cardNo) {
      float before=Timer_GetMS();
      dats[cardNo].dev=dev[cardNo].vm;
      dats[cardNo].addr=addrTrans(addr,cardNo);
      dats[cardNo].size=size;
      dats[cardNo].bufids=&bufids[cardNo];
      DWORD tmpo=0;
      if (threaded) {
	  threadids[cardNo]=CreateThread(NULL,0,submitToCard,&dats[cardNo],0,&tmpo);
      }else {
	  submitToCard(&dats[cardNo]);
      }
      //bufids[cardNo]=amSubmitCommandBuffer(dev[cardNo].vm,addrTrans(addr,cardNo),size);
      //if (bufids[cardNo]==0) printf ("FAILED Submitting %d\n",bufids[cardNo]);
      float after=Timer_GetMS();
      if (after-before>1||justprinted) {
	  printf ("Before submit %d: %f sec\n",cardNo,before);
	  printf ("After submit %d: %f sec\n",cardNo,after);
	  justprinted=true;
      }
  }
  if (threaded) {
      for (int cardNo=0;cardNo<numCards;++cardNo) {
	  WaitForSingleObject(threadids[cardNo],INFINITE);
      }
  }
  AMuint32 buf=bufids[0];
  inflightbufs[buf].swap(bufids);
  return buf;
}

extern AMuint32 dualCommandBufferConsumed(AMmanagedDevice vm, AMuint32 buf){
  AMuint32 retval=1;
  for (int cardNo=0;cardNo<numCards;++cardNo) {
    if (justprinted)
	printf ("Before consumed %d: %f sec\n",cardNo,Timer_GetMS());
    retval=retval&&amCommandBufferConsumed(dev[cardNo].vm,inflightbufs[buf][cardNo]);    
    if (justprinted)
	printf ("After consumed %d: %f sec\n",cardNo,Timer_GetMS());
    //if (retval!=1) printf ("Consumed %d\n",retval);
  }
  justprinted=false;
  return retval;
}
struct f4{
  float x;
  float y;
  float z;
  float w;
};

//FIXME dual GPU should have a more intelligent way to get the data from OpenGL... this is exceedingly stupid...it reads all the data into gpu0's AGP space then doles it out to the other GPU's
extern void dualReadFloat4Pixels(unsigned int minX, unsigned int minY, unsigned int Width, unsigned int Height, void * output0){
  f4 * output=(f4*)output0;
  unsigned int i0=minX;
  unsigned int i1=Width-1;
  unsigned int j0=minY;
  unsigned int j1=Height-1;
  unsigned int cardNo=0;
  glReadPixels (minX, minY,
                Width,
                Height, 
                GL_RGBA,
                GL_FLOAT, 
                output);
  unsigned int outerCardNo=0;
  for (unsigned int jj=j0;jj<=j1;jj+=gltilesize) {

    unsigned int jlim=jj+gltilesize-1;
    if (jlim>j1)
      jlim=j1;
    for (unsigned int j=jj;j<=jlim;j++) {
      cardNo=outerCardNo;
      for (unsigned int i=i0;i<=i1;i+=gltilesize) {      
        if (cardNo!=0)//already on 0th card
          memcpy(pointerTrans(output,cardNo),output,sizeof(f4)*gltilesize);
        cardNo++;
        cardNo%=numCards;
        output+=gltilesize;
      }
    }
    outerCardNo=(cardNo+1)%numCards;// transitioning in a j tile
  }
}
