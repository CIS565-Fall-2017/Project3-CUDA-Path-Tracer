/*
 * shader.cpp --
 *
 *      CTM Shader implementation
 */

#include <math.h>
#include <assert.h>


#include "brookshader.h"
#include "kdtreeBrook.h"
#include "ctmDisplay.h"
#include "../sampler.h"
#include "../log.h"
#include "brooktracer.hpp"
#include "common.h"
#include "ppm.h"
static unsigned char floatToChar(float ftc) {
	if (ftc>1)
		return 255;
	if (ftc<0)
		return 0;
	return (unsigned char)(ftc*255);
}
extern int brookMaxWidth;
#define memcpyBroadcast memcpy
#define memsetBroadcast memset

DefaultHitShaderNewBrook::DefaultHitShaderNewBrook(
	const Scene *scene,
	const CameraManager *cam,
	ITracerCTM* inTracer, const Opts&inOptions) {
	this->scene = scene;
	this->cam = cam;
	tracer = inTracer;
	triangleWidth = brookMaxWidth;
	this->_gdi=inOptions.gdi;
	unsigned int PADDING = 16;
	uint32 numtris = scene->nTris();
	unsigned char * textureCPU;
	unsigned char*data;
	if (readPPM("scenes/texture.ppm",&data,&textureWidth,&textureHeight)) {
	    uint32 swid,shei;
	    unsigned char * textureCPUa=textureCPU=(unsigned char*)malloc(textureWidth*textureHeight*4);
	    unsigned char * sdata;
	    if (readPPM("scenes/texturespec.ppm",&sdata,&swid,&shei)&&swid==textureWidth&&shei==textureHeight){
		for (uint32 j=0;j<textureHeight;++j) {
		    for (uint32 i=0;i<textureWidth;++i) {
			*textureCPUa++=*data++;
			*textureCPUa++=*data++;
			*textureCPUa++=*data++;
			*textureCPUa++=*sdata++;
			sdata+=2;
		    }
		}
		free(sdata);
	    }else {
		for (uint32 j=0;j<textureHeight;++j) {
		    for (uint32 i=0;i<textureWidth;++i) {
			*textureCPUa++=*data++;
			*textureCPUa++=*data++;
			*textureCPUa++=*data++;
			*textureCPUa++=255;
		    }
		}

	    }
	    free(data);
	}else {	    
	    textureWidth=textureHeight=16;
	    textureCPU=(unsigned char*)malloc(textureWidth*textureHeight*4);
	    memset(textureCPU,255,16*16*4);
	}
	textureGPU= new brook::stream (brook::getStreamType((fixed4*)NULL),textureHeight,textureWidth,-1);
	streamRead(*textureGPU,textureCPU);
	free(textureCPU);
	unsigned int tcroundup = numtris/triangleWidth+(numtris%triangleWidth?1:0);
	triangleHeight = 3*PADDING*(tcroundup/PADDING + (tcroundup%PADDING?1:0));
	normalsGPU= new brook::stream (brook::getStreamType((float4*)NULL),triangleHeight,triangleWidth,-1);
	//	colorsGPU= new brook::stream (brook::getStreamType((fixed4*)NULL),triangleHeight,triangleWidth,-1);
	specularGPU= new brook::stream (brook::getStreamType((fixed4*)NULL),triangleHeight*2,triangleWidth,-1);
	float smin=FLT_MAX;
	float smax=-FLT_MAX;
	float emin=FLT_MAX;
	float emax=-FLT_MAX;
	float * normalsCPU = (float*)malloc(triangleWidth*triangleHeight*4*sizeof(float));
	unsigned char * specularCPU = (unsigned char*)malloc(triangleWidth*triangleHeight*4*sizeof(char)*2);
	unsigned char * colorsCPU = specularCPU+triangleWidth*triangleHeight*4*sizeof(char);

	for (uint32 trinum=0;trinum<scene->nTris();trinum++) {
	    bool horizontal,vertical,axis_aligned;
	    float st[3][2];
	    bool robot= acquireST(scene,trinum,st[0],st[1],st[2],&horizontal,&vertical,&axis_aligned);
	    
	    for (int i=0;i<3;i++) {
		F3 src = scene->normals(i)[trinum];
		float *fdst = &normalsCPU[(trinum%triangleWidth + triangleWidth*(i+3*(trinum/triangleWidth)))*4];
		float dst[4];
		float dist = (float)sqrt(src.v[0]*src.v[0]+src.v[1]*src.v[1]+src.v[2]*src.v[2]);
		if (dist==0.f) {
		    dist=1.f;
		}
		dst[0]=src.v[0]/dist;
		dst[1]=src.v[1]/dist;
		if (src.v[2]<0)
		    dst[0]+=10;
		dst[2]=st[i][0];
		dst[3]=st[i][1];
		memcpy(fdst,dst,sizeof(float)*4);
//			dst[2]=src.v[2]/dist;
//			dst[3]=123.456f;
	    }
	    
	    for (int i=0;i<3;i++) {
		F3 src = scene->colours(i)[trinum];
		unsigned char *fdst = &colorsCPU[(trinum%triangleWidth + triangleWidth*(i+3*(trinum/triangleWidth)))*4];
		unsigned char dst[4];
		if (axis_aligned&&!horizontal&&!vertical){
		    if (src.v[2]<.5)
			src.v[1]=src.v[2]=src.v[0]=.2f;
		}
		dst[0]=floatToChar(src.v[0]);
		dst[1]=floatToChar(src.v[1]);
		dst[2]=floatToChar(src.v[2]);
		dst[3]=123;
		memcpy(fdst,dst,sizeof(char)*4);
	    }
		if (scene->specColours()) {
			for (int i=0;i<3;i++) {
				F3 srcSpec = scene->specColours()[trinum*3+i];
				float srcSpecExp = scene->specExps()[trinum*3+i];
				unsigned char *fdst = &specularCPU[(trinum%triangleWidth + triangleWidth*(i+3*(trinum/triangleWidth)))*4];
                                unsigned char dst[4];
				dst[0]=floatToChar(robot?srcSpec.v[0]*0.0f+1.0f:1.0f- srcSpec.v[0]);
				dst[1]=floatToChar(robot?srcSpec.v[1]*0.0f+1.0f:1.0f-srcSpec.v[1]);
				dst[2]=floatToChar(robot?srcSpec.v[2]*0.0f+1.0f:1.0f-srcSpec.v[2]);
				dst[3]=floatToChar(srcSpecExp?1.0f/srcSpecExp:1.0f);
				if (srcSpecExp<emin)emin=srcSpecExp;
				if (srcSpecExp>emax)emax=srcSpecExp;

				if (srcSpec.v[0]<smin)smin=srcSpec.v[0];
				if (srcSpec.v[0]>smax)smax=srcSpec.v[0];

				if (srcSpec.v[1]<smin)smin=srcSpec.v[1];
				if (srcSpec.v[1]>smax)smax=srcSpec.v[1];

				if (srcSpec.v[2]<smin)smin=srcSpec.v[2];
				if (srcSpec.v[2]>smax)smax=srcSpec.v[2];
                                memcpyBroadcast(fdst,dst,sizeof(char)*4);			
			}
		}else {
		}
			
	}
	if (!scene->specColours()) {
	    memsetBroadcast (specularCPU,0,triangleWidth*triangleHeight*4*sizeof(char));	
	}
	printf ("Specular min %f, specular max %f , exp min %f, exp max %f\n",smin,smax,emin,emax);
	//streamRead(*colorsGPU,colorsCPU);
	//free(colorsCPU);//now in the specularGPU array
	streamRead(*normalsGPU,normalsCPU);
	free(normalsCPU);
	streamRead(*specularGPU,specularCPU);
	free(specularCPU);	
	rayColorGPUinit=false;
	numLoops=GetKeyValueInt("bounces",inOptions.shadeOpts,2)+1;
	maxNumLights=GetKeyValueInt("numLights",inOptions.shadeOpts,3);
	specAddition=GetKeyValueFloat("specAdd",inOptions.shadeOpts,.1f);
	specCutoff=GetKeyValueFloat("specCutoff",inOptions.shadeOpts,.01f);
	ambient=GetKeyValueFloat("ambient",inOptions.shadeOpts,maxNumLights==0?.2f:0.0f);
	diffuse=GetKeyValueFloat("diffuse",inOptions.shadeOpts,maxNumLights==0?.8f:0.0f);
	this->shadow=this->sceneshadow=GetKeyValueInt("shadow",inOptions.shadeOpts,0);
}
extern bool morebounces;
extern bool lessbounces;
extern bool morespec;
extern bool lessspec;
extern bool morecutoff;
extern bool lesscutoff;
extern bool toggleshadow;
void
DefaultHitShaderNewBrook::Shade(
   uint32 inCount,
   const SampleCTM* inSamples,
   const RayCTM* inRays,
   const HitCTM* inHits,
   PixelCTM* ioPixels,
   bool inShouldRelease )
{
    if (toggleshadow) {
	
	if (shadow) shadow=0;
	else shadow=sceneshadow;
	toggleshadow=false;
    }

	if (morespec) {
		specAddition+=.05f;
		morespec=false;
	}
	if (lessspec) {
		specAddition-=.05f;
		lessspec=false;
	}

	if (morecutoff) {
		specCutoff+=.0125f;
		morecutoff=false;
	}
	if (lesscutoff) {
		specCutoff-=.0125f;
		lesscutoff=false;
	}

	if(morebounces) {
		numLoops++;
		morebounces=false;
	}
	if (lessbounces) {
		if (numLoops>1)
			numLoops--;
		lessbounces=false;
	}
	//uint32 numLoops=3;
	bool final=false;
	bool firstloop=true;
	uint32 Width = inRays->width;
	uint32 Height = inRays->height;
	brook::stream* rayColorAGP[4];
	if (!rayColorGPUinit) {
	    rayColorGPUinit=true;
	    rayColorGPU[0]= new brook::stream(brook::getStreamType((fixed4*)NULL),Height,Width,-1);
	    rayColorGPU[1]= new brook::stream(brook::getStreamType((fixed4*)NULL),Height,Width,-1);
	    rayColorGPU[2]= new brook::stream(brook::getStreamType((fixed4*)NULL),Height,Width,-1);
	    rayColorGPU[3]= new brook::stream(brook::getStreamType((fixed4*)NULL),Height,Width,-1);
	    framebufferGPU=new brook::stream(brook::getStreamType((fixed4*)NULL),Height*2,Width*2,-1);
	    framebufferCPU=(unsigned char*)malloc(sizeof(unsigned char)*4/*just in case*/*4*Width*Height*4);
	}


	RayGPUCTM newRays[2]={*inRays,*inRays};
	newRays[0].ResetOrigin();
	newRays[1].ResetOrigin();
//	newRays[1].rays.ctm.ptr=device->info.baseAddressGPUb;

	for (uint32 bounce=0;bounce<numLoops;bounce++) {
		if (bounce==numLoops-1) {
			final=true;
		}
		if (bounce>0) {
			firstloop=false;
		}
		float inoutWeight[4]={1.0,1.0,0.0,0.0};
		if (firstloop) {
			inoutWeight[0]=0.0;
			inoutWeight[1]=1.0;
		}
		rayColorAGP[0]=rayColorGPU[0];
		rayColorAGP[1]=rayColorGPU[1];
		rayColorAGP[2]=rayColorGPU[2];
		rayColorAGP[3]=rayColorGPU[3];
//UPDATE ORIGIN
		float raysO[4]={newRays[(bounce)%2].raysO.v[0],//rays[0].o.v[0]+_bbox->rayOffset.v[0],
						newRays[(bounce)%2].raysO.v[1],//rays[0].o.v[BUNDLE_SIZE]+_bbox->rayOffset.v[1],
						newRays[(bounce)%2].raysO.v[2],//rays[0].o.v[2*BUNDLE_SIZE]+_bbox->rayOffset.v[2],
						6.123456789f};
		if (firstloop) {
			raysO[0]=inRays->raysO.v[0];
			raysO[1]=inRays->raysO.v[1];
			raysO[2]=inRays->raysO.v[2];
		}
		brookUpdateRayOrigin(arrayFloat4(raysO),
				     *inRays->rays.stream,
				     *inRays->raysOXYZ,
				     *inHits->tHitPtr.stream,
				     *inRays->raysOXYZ);
//SHADE
	
		float rayIndexOffset[4]={0,(float)Height,0,0};
		float bboxMin[4]={inRays->bbox.min.v[0],inRays->bbox.min.v[1],inRays->bbox.min.v[2]};
		float bboxMax[4]={inRays->bbox.max.v[0],inRays->bbox.max.v[1],inRays->bbox.max.v[2]};
		float rayOffset[4]={inRays->bbox.rayOffset.v[0],inRays->bbox.rayOffset.v[1],inRays->bbox.rayOffset.v[2]};
		float hitTTdims[4]={(float)Width,(float)Height};
                uint32 numlight=scene->numLights();
                if (numlight>maxNumLights)numlight=maxNumLights;
		float sceneSize[4]={(float)triangleWidth, (float)triangleHeight, (float)numlight, 0.f};
                float useShadow[4]={(float)this->shadow,0,0,0};
		if (scene->numLights()>3&&maxNumLights>3) {
			printf ("ERROR Scene uses %d lights!!! Currently shader hardcoded to only use 3 to prevent hourlong compile times with fxc and increase potential runtime\n",scene->numLights());
		}
		float specAdditionAndCutoff[4]={specAddition,specCutoff,ambient,diffuse};
		float texturesize[4]={(float)textureWidth,(float)textureHeight,0.0f,0.0f};
		float lightpos[8][4];
		float lightcol[8][4];
		for (unsigned int i=0;i<scene->numLights()&&i<8;++i) {
			LightInfo light = scene->pointLight(i);
			char c0[4]={'c','0'+(i+32)/10,'0'+(i+32)%10,'\0'};
			char c1[4]={'c','0'+(i+40)/10,'0'+(i+40)%10,'\0'};
			float pos[4]={light.position.x+inRays->bbox.rayOffset.v[0], light.position.y+inRays->bbox.rayOffset.v[1], light.position.z+inRays->bbox.rayOffset.v[2]};
			float intensityAtten[4]={light.diffIntensity.x, light.diffIntensity.y, light.diffIntensity.z, 1.f/(light.distAtten*light.distAtten)};
			memcpy(lightpos[i],pos,sizeof(float)*4);
			memcpy(lightcol[i],intensityAtten,sizeof(float)*4);
		}
		brookUberShader(arrayFloat4(bboxMin),
				arrayFloat4(bboxMax),
				arrayFloat4(rayIndexOffset),
				arrayFloat4(rayOffset),
				arrayFloat4(sceneSize),
				arrayFloat4(inoutWeight),
				arrayFloat4(specAdditionAndCutoff),
				arrayFloat4(texturesize),
				arrayFloat4(lightpos[0]),
				arrayFloat4(lightpos[1]),
				arrayFloat4(lightpos[2]),
				arrayFloat4(lightpos[3]),
				arrayFloat4(lightcol[0]),
				arrayFloat4(lightcol[1]),
				arrayFloat4(lightcol[2]),
				arrayFloat4(lightcol[3]),
				*inRays->rays.stream,
				*inRays->raysOXYZ,
				*inHits->uuPtr.stream,
				*inHits->vvPtr.stream,
				*inHits->triNumPtr.stream,
				*normalsGPU,
				*specularGPU,
				*textureGPU,
				*rayColorGPU[0],
				*rayColorGPU[1],
				*rayColorGPU[2],
				*rayColorGPU[3],

				*rayColorAGP[0],
				*rayColorAGP[1],
				*rayColorAGP[2],
				*rayColorAGP[3]);
    
//BOUNCE DIRECTION

		if (!final) {
		    brookBounceShader(
				*inRays->rays.stream,
				*inRays->raysOXYZ,
				*inHits->uuPtr.stream,
				*inHits->vvPtr.stream,
				*inHits->triNumPtr.stream,
				*normalsGPU,
				*specularGPU,
				*rayColorAGP[3],
				arrayFloat4(hitTTdims),
				arrayFloat4(bboxMin),
				arrayFloat4(bboxMax),
				arrayFloat4(sceneSize),
				arrayFloat4(specAdditionAndCutoff),
				(float)this->shadow,
				arrayFloat4(lightpos[0]),
				arrayFloat4(lightpos[1]),
				arrayFloat4(lightpos[2]),
				*inRays->rays.stream);
		}
		if (!final) {
		    inHits->intersector->intersect(&newRays[(bounce+1)%2],inCount,const_cast<HitCTM*>(inHits));//fixme ugly 
		}
		if (shadow)
		    break;
	}

        int GDIadd=_gdi?0:Height*2-1;
        int GDIaddID=_gdi?0:1;
        int GDImul=_gdi?1:-1;
        float gdiarray[4]={(float)GDIadd,(float)shadow,(float)GDImul,(float)_gdi};

	brookSwizzleDisplay(arrayFloat4(gdiarray),
			    *inHits->tHitPtr.stream,
			    *rayColorAGP[2],
			    *rayColorAGP[1],
			    *rayColorAGP[0],
			    *framebufferGPU);
	ioPixels->stream=framebufferGPU;
	ioPixels->AGPmemory=framebufferCPU;
}


