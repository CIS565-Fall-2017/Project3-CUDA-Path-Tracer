/*
 * kdtreeCTM.h --
 *
 *      k-D tree / axis-aligned bounding box tree acceleration structure.
 */

#ifndef __CELL_KDTREECTM_H__
#define __CELL_KDTREECTM_H__

#include <math.h>
extern "C" {
    //#include <libspe.h>
}

#include "../scene.h"
#include "../ctm/ctmTypes.h"
#include "../ctm/acceleratorCTM.h"
#include "../ctm/gpuDeviceFactory.h"

class KDTreeCTM : public AcceleratorCTM
{
  GPUDevice *device;
public:
  KDTreeCTM(const Scene& scene, const Opts& options, GPUDevice *device, BoundingBoxCTM *bbox);
  virtual ~KDTreeCTM(void);
  uint32 getBatchGranularity();
  void IntersectRay(const RayCTM &ray, HitCTM *hit);
  void intersect(const RayCTM rays[],
                 uint32 numRays, HitCTM hits[]);
  void intersectPacket(const RayCTM rays[],
                       uint32 numRays, HitCTM hits[]);

  void intersectP(const RayCTM rays[],
                  uint32 numRays, HitCTM hits[]);
  void intersectPacketP(const RayCTM rays[],
                        uint32 numRays, HitCTM hits[]);

protected:
	uint32 hitLocation;
	uint32 hitLocationAGP;
	float *hitLocationCPU;
	uint32 hitSize;
    bool usefetch4;
    bool packetized;
    unsigned int TriWidth;
    unsigned int TriHeight;
    float fov;
    float * triangles[3];
    unsigned int trianglesAGP[3];
    unsigned int kdtreeAGP;
    unsigned int triangleIDsAGP;
    unsigned int triangleIDsGPU;
    float * kdtree;
    unsigned int kdtreeWidth;

  unsigned int kdtreeHeight;
  bool _dotrace;
  bool _useRaster;
  int debug_kernel;
  int debug_offset;
  unsigned int benchmark;
  unsigned int _offsetAlign;
  unsigned int _offsetRay;
  unsigned int _offsetTriangle;
  unsigned int _offsetKdtree;
  unsigned int _offsetTT;
  unsigned int _offsetUU;
  unsigned int _offsetVV;
  unsigned int _offsetID;
  bool forcefirstpacket;

  bool kdcpumem;  
  bool tricpumem;  
  bool cpulinearmem;
  BoundingBoxCTM *_bbox;
  
  enum { kMaximumThreadCount = 16 };
  enum { kAlignment = 128 };

  // number of SPE threads to launch
  // can range from 1-16 for our dual-processor
  // blades, but will scale best in the 1-8 range
  uint32 _threadCount;
    //speid_t _speThreadIDs[kMaximumThreadCount];

  // control for how many times to re-submit the same frame
  // (when testing throughput rather than end-to-end latency)
  uint32 _repeatFrameSubmitCount;
  uint32 _nodeCount;
  PaddedCtmKdTreeNode* _nodes;
  uint32 _bruteForceTriCount;
  uint32 _triangleCount;
  //float* _triangleIDs;
  float *_triangleDataA;
  float *_triangleDataB;
  float *_triangleDataC;
};

#endif
