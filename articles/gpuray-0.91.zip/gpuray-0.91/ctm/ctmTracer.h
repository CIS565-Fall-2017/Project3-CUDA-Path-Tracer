/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * ctmTracer.h --
 *
 *      Helper classes for ray-tracing with the CTM
 */

#ifndef __CTM_CTMTRACER_H__
#define __CTM_CTMTRACER_H__

#include "../main.h"
#include "../cameraManager.h"
#include "../scene.h"
#include "../ctm/acceleratorCTM.h"
#include "../tracer.h"
#include "gpuDeviceFactory.h"

class IPixelDisplayerCTM;
class IStandardShaderCTM;

struct PixelCTM
{
    unsigned char *AGPmemory;
    brook::stream *stream;
    PixelCTM(){AGPmemory=NULL;stream=NULL;}
};

struct SampleCTM
{
   uint32 pixelIndex[BUNDLE_SIZE];
   uint32 recursionDepth[BUNDLE_SIZE];
   PixelCTM weight[BUNDLE_SIZE];
};
class KDTree;
void CopyKDTreeGPU( KDTree* builtTree, CtmKdTreeNode* _nodes, BoundingBoxCTM* _bbox);
void CopyTrianglesGPU ( uint32 _triangleCount, const int* builtIndices,
			const F3* v0, const F3* v1, const F3* v2, const BoundingBoxCTM* _bbox,
			float *_triangleDataA, float* _triangleDataB, float* _triangleDataC );

/*
 * ReallocateAligned --
 *
 *      Resizes an AllocateAligned() chunk of memory.
 *
 * Returns:
 *     A pointer to the allocated block.
 */

void* ReallocateAligned( void* ptr, size_t oldsize, size_t size, size_t alignment );

/*
 * AllocateAligned --
 *
 *     Allocates a block of 'size' bytes, aligned
 *     to an 'alignment'-byte boundary.
 *
 * Returns:
 *     A pointer to the allocated block.
 */

void* AllocateAligned( size_t size, size_t alignment );

/*
 * FreeAligned --
 *
 *     Frees a block of memory previously allocated
 *     with AllocateAligned.
 *
 * Returns:
 *     None.
 */

void FreeAligned( void* buffer );

/*
 * IHitCallbackCTM --
 *
 *     Interface for any computation that can
 *     take rays and associated hits as input
 *     and "process" them.
 */

class IHitCallbackCTM
{
public:
   virtual void Call(
      uint32 inCount,
      const RayCTM* inRays,
      const HitCTM* inHits ) = 0;
};

class ITracerCTM
{
public:
   virtual void Trace(
      uint32 inCount,
      const SampleCTM* inSamples,
      const RayCTM* inRays,
      PixelCTM* ioPixels ) = 0;

   virtual uint32 GetBatchGranularity() = 0;
};

class IPrimaryTracerCTM
{
public:
   virtual void Trace(
      uint32 inWidth, uint32 inHeight,
      const RayCTM* inRays ) = 0;
};

class IIntersectorCTM
{
public:
   virtual void Intersect(
      uint32 inCount,
      const RayCTM* inRays,
      IHitCallbackCTM* inContinuation ) = 0;
   virtual void IntersectP(
      uint32 inCount,
      const RayCTM* inRays,
      IHitCallbackCTM* inContinuation ) = 0;
};

class IBaseRayIntersectorCTM
{
public:
   virtual void Intersect(
      uint32 inCount,
      const RayCTM* inRays,
      IHitCallbackCTM* inContinuation ) = 0;
   virtual void IntersectP(
      uint32 inCount,
      const RayCTM* inRays,
      IHitCallbackCTM* inContinuation ) = 0;
   virtual uint32 GetBatchGranularity() = 0;
};

class IPrimaryRayCallbackCTM
{
public:
   virtual void Call(
      uint32 inWidth, uint32 inHeight,
      const RayCTM* inRays ) = 0;
};

class DefaultTracerCTM : public ITracerCTM
{
public:
   DefaultTracerCTM(
      IBaseRayIntersectorCTM* inIntersector )
   {
      _intersector = inIntersector;
      _shader = NULL;
   }

   void setShader( IStandardShaderCTM* inShader )
   {
      _shader = inShader;
   }

   virtual void Trace(
      uint32 inCount,
      const SampleCTM* inSamples,
      const RayCTM* inRays,
      PixelCTM* ioPixels );

   virtual uint32 GetBatchGranularity() {
      return _intersector->GetBatchGranularity();
   }

private:
   IBaseRayIntersectorCTM* _intersector;
   IStandardShaderCTM* _shader;
};

class DefaultBaseRayIntersectorCTM : public IBaseRayIntersectorCTM
{
public:
   DefaultBaseRayIntersectorCTM(
      const Opts& inOptions,
      Scene* inScene,
      ToggleOption* inUsePacketsOptions,
      GPUDevice *device,
      BoundingBoxCTM* bbox );

   void Intersect(
      uint32 inCount,
      const RayCTM* inRays,
      IHitCallbackCTM* inContinuation );
   void IntersectP(
      uint32 inCount,
      const RayCTM* inRays,
      IHitCallbackCTM* inContinuation );

   virtual uint32 GetBatchGranularity() {
      return _accelCTM->getBatchGranularity();
   }

private:
   Scene *_scene;
   ToggleOption *_usePacketsOption;

   AcceleratorCTM *_accelCTM;
};

class PrimaryRayCallbackCTM : public IPrimaryRayCallbackCTM
{
public:
   PrimaryRayCallbackCTM(
      ITracerCTM* inTracer,
      IPixelDisplayerCTM* inPixelDisplayer )
   {
      _tracer = inTracer;
      _pixelDisplayer = inPixelDisplayer;
   }

   virtual void Call(
      uint32 inWidth, uint32 inHeight,
      const RayCTM* inRays );

private:
   ITracerCTM* _tracer;
   IPixelDisplayerCTM* _pixelDisplayer;
};

class RayGeneratorCTM : public IRayGenerator
{
public:
   RayGeneratorCTM(
      CameraManager* inCameraManager,
      IPrimaryRayCallbackCTM* inContinuation,
      GPUDevice* device,
      BoundingBoxCTM* bbox );

   void Generate( int inWidth, int inHeight );

private:
   uint32 rayLocationGPU;
   uint32 raySize;
   GPUDevice* device;
   CameraManager* _cameraManager;
   IPrimaryRayCallbackCTM* _continuation;
   BoundingBoxCTM* _bbox;
};


class RayGeneratorNewBrook : public IRayGenerator
{
public:
   RayGeneratorNewBrook(
      CameraManager* inCameraManager,
      IPrimaryRayCallbackCTM* inContinuation,
      BoundingBoxCTM* bbox );

   void Generate( int inWidth, int inHeight );

private:
   brook::stream * rayLocationGPU[2];
   CameraManager* _cameraManager;
   IPrimaryRayCallbackCTM* _continuation;
   BoundingBoxCTM* _bbox;
};
class IStandardShaderCTM
{
public:
   virtual void Shade(
         uint32 inCount,
         const SampleCTM* inSamples,
         const RayCTM* inRays,
         const HitCTM* inHits,
         PixelCTM* ioPixels,
         bool inShouldRelease ) = 0;

   virtual uint32 GetBatchGranularity() = 0;
};

#endif
