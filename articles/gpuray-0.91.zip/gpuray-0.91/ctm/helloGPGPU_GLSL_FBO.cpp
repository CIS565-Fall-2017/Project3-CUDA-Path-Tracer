//---------------------------------------------------------------------------
//                               www.GPGPU.org
//                                Sample Code
//---------------------------------------------------------------------------
// Copyright (c) 2004 Mark J. Harris and GPGPU.org
// Copyright (c) 2004 3Dlabs Inc. Ltd.
//---------------------------------------------------------------------------
// This software is provided 'as-is', without any express or implied
// warranty. In no event will the authors be held liable for any
// damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any
// purpose, including commercial applications, and to alter it and
// redistribute it freely, subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented; you
//    must not claim that you wrote the original software. If you use
//    this software in a product, an acknowledgment in the product
//    documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such, and
//    must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source
//    distribution.
//
//---------------------------------------------------------------------------
// Author: Mark Harris (harrism@gpgpu.org) - original helloGPGPU
// Author: Mike Weiblen (mike.weiblen@3dlabs.com) - GLSL version
// Author: Martin Dvh (nldudok1 olifantasia.com) - FBO (Framebuffer Object) version
// Author: Aaron Lefohn  - Framebuffer Object (FBO) and Renderbuffer class version
//---------------------------------------------------------------------------
// GPGPU Lesson 0: "helloGPGPU_GLSL" (a GLSL version of "helloGPGPU")
//---------------------------------------------------------------------------
//
// GPGPU CONCEPTS Introduced:
//
//      1.) Texture = Array
//      2.) Fragment Program = Computational Kernel.
//      3.) One-to-one Pixel to Texel Mapping:
//          a) Data-Dimensioned Viewport, and
//          b) Orthographic Projection.
//      4.) Viewport-Sized Quad = Data Stream Generator.
//      5.) Copy To Texture = feedback.
//
//      For details of each of these concepts, see the explanations in the
//      inline "GPGPU CONCEPT" comments in the code below.
//
// APPLICATION Demonstrated: A simple post-process edge detection filter.
//
//---------------------------------------------------------------------------
// Notes regarding this "helloGPGPU_GLSL_FBO" source code.
// This example was derived from the "helloGPGPU_GLSL" sourcecode which in its turn was based on "helloGPGPU.cpp" v1.0.1
// The major modification is that now this example uses Framebuffer objects to implement render-to-texture
// This is a new opengl feature and is easier to use then using pbuffers.
// It is also much faster then copy-to-texture and also faster then using pbuffers for doing render-to-texture
// This is because context switches are not neccesary, even when using more then 2 textures/surfaces.
// I used the concepts from the Nvidia Opengl Framebuffer Object presentation document and
// the framebuffer object extension specification at the opengl extension registry.
// For this example to work you need a videodriver which supports the FBO extension
// At the time of writing (19 april 2005) I only know of FBOs being supported in
// NVIDIA Beta drivers for windows version 75.x or greater.(I don't know about other vendors)
//
// I also included visual studio 7.1 and visual studio 6 project and solution files.
// The visual studio 6 project file is not recently tested.
// There is also still a linux makefile. This will be usefull as soon as drivers for linux appear which include FBO support.
// Note that the example requires a recent glew.h and glew32s.lib, available at
// http://glew.sourceforge.net. You need version 1.31 or higher
//
// References:
//   http://gpgpu.sourceforge.net/
//   http://oss.sgi.com/projects/ogl-sample/registry/EXT/framebuffer_object.txt
//   http://download.nvidia.com/developer/presentations/2005/GDC/OpenGL_Day/OpenGL_FrameBuffer_Object.pdf
//   http://glew.sourceforge.net
//
//  Thanks to Mark and Mike for making the original example
//  Also Thanks for the opengl ARB and Nvidia for defining and implementing framebufferobject support
// (Please also implement this for linux soon)
//
//  -- Martin Dvh, April 2005
//---------------------------------------------------------------------------
// Notes regarding the "helloGPGPU_GLSL" source code which was the base for "helloGPGPU_GLSL_FBO":
//
// This example was derived from the original "helloGPGPU.cpp" v1.0.1
// by Mark J. Harris.  It demonstrates the same simple post-process edge
// detection filter, but instead implemented using the OpenGL Shading Language
// (also known as "GLSL"), an extension of the OpenGL v1.5 specification.
// Because the GLSL compiler is an integral part of a vendor's OpenGL driver,
// no additional GLSL development tools are required.
// This example was developed/tested on 3Dlabs Wildcat Realizm.
//
// I intentionally minimized changes to the structure of the original code
// to support a side-by-side comparison of the implementations.
//
// Thanks to Mark for making the original helloGPGPU example available!
//
// -- Mike Weiblen, May 2004
//
//
// [MJH:]
// This example has also been tested on NVIDIA GeForce FX and GeForce 6800 GPUs.
//
// Note that the example requires glew.h and glew32s.lib, available at
// http://glew.sourceforge.net.
//
// Thanks to Mike for modifying the example.  I have actually changed my
// original code to match; for example the inline Cg code instead of an
// external file.
//
// -- Mark Harris, June 2004
//
// References:
//    http://gpgpu.sourceforge.net/
//    http://glew.sourceforge.net/
//    http://www.xmission.com/~nate/glut.html
//
//
// [AEL]
// This example encapsulates the FBO code written by Mike Weiblen in an FBO
// class that is now included in the visual studio project. This is intended
// to serve as a simple example of our Framebuffer object and renderbuffer classes.
//
// -- Aaron Lefohn, June 2005
//---------------------------------------------------------------------------

#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
//define GLEW_STATIC 1
#include <GL/glew.h>
#include <GL/glut.h>

#include "ctmTypes.h"
#include "framebufferObject.h"
#include "renderbuffer.h"
#include "glErrorUtil.h"
#include "../timer.h"
#include "../log.h"
#include "../renderContext.h"
#include "dxraster.h"
extern void dualReadFloat4Pixels(unsigned int minX, unsigned int minY, unsigned int Width, unsigned int Height, void * output);

// forward declarations
class HelloGPGPU;
void reshape(int w, int h);

// globals
HelloGPGPU  *g_pHello=NULL;
Iraster * g_raster=NULL;

// This shader performs a 9-tap Laplacian edge detection filter.
// (converted from the separate "edges.cg" file to embedded GLSL string)
static const char *edgeFragSource = {
"uniform sampler2D texUnit;"
"void main(void)"
"{"
"   const float offset = 1.0 / 512.0;"
"   vec2 texCoord = gl_TexCoord[0].xy;"
"   vec4 c  = texture2D(texUnit, texCoord);"
"   vec4 bl = texture2D(texUnit, texCoord + vec2(-offset, -offset));"
"   vec4 l  = texture2D(texUnit, texCoord + vec2(-offset,     0.0));"
"   vec4 tl = texture2D(texUnit, texCoord + vec2(-offset,  offset));"
"   vec4 t  = texture2D(texUnit, texCoord + vec2(    0.0,  offset));"
"   vec4 ur = texture2D(texUnit, texCoord + vec2( offset,  offset));"
"   vec4 r  = texture2D(texUnit, texCoord + vec2( offset,     0.0));"
"   vec4 br = texture2D(texUnit, texCoord + vec2( offset,  offset));"
"   vec4 b  = texture2D(texUnit, texCoord + vec2(    0.0, -offset));"
"   gl_FragColor = 0.5 * (c + 0.0 * (bl + l + tl + t + ur + r + br + b));"
"}"
};

static const char *teapotvert={
"uniform vec2 size;\n"
"	void main() {\n"	
"		gl_TexCoord[0] = gl_MultiTexCoord0;\n"
"		gl_TexCoord[1] = gl_MultiTexCoord1;\n"
"		gl_Position = ftransform();\n"
"       gl_Position.xy+=vec2(0,0)/size;\n"
"	}\n"
};

static const char *teapotsource= {
"vec3 mymax (vec3 a,vec3 b) {\n"
"return vec3(a.x<b.x?b.x:a.x,a.y<b.y?b.y:a.y,a.z<b.z?b.z:a.z);}\n"
"float timeClipToBBox(vec3 origin, vec3 dest, vec3 bboxmin, vec3 bboxmax) {\n"
"vec3 dir=dest-origin;\n"
"vec3 tmp1=(bboxmin-origin)/dir;\n"
"vec3 tmp2=(bboxmax-origin)/dir;\n"
"vec3 tfar=mymax(tmp1,tmp2);\n"
"return min (tfar.x,min(tfar.y,tfar.z));\n"
"}\n"
"float len(vec3 v){\n"
"  return sqrt(v.x*v.x+v.y*v.y+v.z*v.z);\n"
"}\n"
"uniform vec3 origin;uniform vec3 bboxmin; uniform vec3 bboxmax;\n"
"void main(void)\n"
"{\n"
"   float time=1.0/timeClipToBBox(origin,gl_TexCoord[0].xyz,bboxmin,bboxmax);\n"
"   gl_FragColor = vec4(time,gl_TexCoord[1].xyz);\n"
"}"
};
//char * memory=(char*)malloc(2048*2048*sizeof(float)*4+2048);
// This class encapsulates all of the GPGPU functionality of the example.
class HelloGPGPU
{
public: // methods
    HelloGPGPU(int count,const F3*v0,const F3*v1,const F3*v2, F3 offset)
		: _rAngle(0),
		_iWidth(0),
		_iHeight(0),
		_fbo(),// create a new frame buffer object
		_rb()  // optional: create a new render buffer object
	{
		_fbo.Bind(); // Bind framebuffer object.
          size_t vboSize=sizeof(float)*3*3*count;
          numTris=count;
          glGenBuffersARB(3,scene);
          for (int jj=0;jj<1;++jj) {
            glBindBufferARB(GL_ARRAY_BUFFER_ARB,scene[jj]);
            glBufferDataARB(GL_ARRAY_BUFFER_ARB,vboSize,NULL,GL_STATIC_DRAW_ARB);
            float * vbo=(float*)glMapBufferARB(GL_ARRAY_BUFFER_ARB,GL_WRITE_ONLY_ARB);
            for(int i=0;i<count;++i){
              float data[9]={v0[i].v[0]+offset.v[0],
                             v0[i].v[1]+offset.v[1],
                             v0[i].v[2]+offset.v[2],
                             v1[i].v[0]+offset.v[0],
                             v1[i].v[1]+offset.v[1],
                             v1[i].v[2]+offset.v[2],
                             v2[i].v[0]+offset.v[0],
                             v2[i].v[1]+offset.v[1],
                             v2[i].v[2]+offset.v[2]};
              memcpy(vbo+i*9,data,sizeof(float)*9);
            }//do we need 2 copies of thing to hold same data? guess not
            glUnmapBufferARB(GL_ARRAY_BUFFER_ARB);
          }
          glBindBufferARB(GL_ARRAY_BUFFER_ARB,scene[2]);
          glBufferDataARB(GL_ARRAY_BUFFER_ARB,vboSize,NULL,GL_STATIC_DRAW_ARB);
          float * vbo=(float*)glMapBufferARB(GL_ARRAY_BUFFER_ARB,GL_WRITE_ONLY_ARB);
            for(int i=0;i<count;++i){
              vbo[i*9+0]=0.0f;
              vbo[i*9+1]=0.0f;
              vbo[i*9+2]=(float)i;
              
              vbo[i*9+3]=1.0f;
              vbo[i*9+4]=0.0f;
              vbo[i*9+5]=(float)i;
              
              vbo[i*9+6]=0.0f;
              vbo[i*9+7]=1.0f;
              vbo[i*9+8]=(float)i;
            }
            glUnmapBufferARB(GL_ARRAY_BUFFER_ARB);
          
		// Create a simple 2D texture.
		// This example uses render to texture  by using the new Framebuffer Objects.
		//At the time of writing (1 july 2005) these are only implemented
		//in NVIDIA drivers for windows/linux.(I don't know about other vendors)
		//glew version 1.31 or newer is required.

		// GPGPU CONCEPT 1: Texture = Array.
		// Textures are the GPGPU equivalent of arrays in standard
		// computation. Here we allocate a texture large enough to fit our
		// data (which is arbitrary in this example).

		// OpenGL Good Programming Practice : Check errors
		// - OpenGL errors accumulate silently until checked.
		//   This utility checks the accumulated errors and reports
		//   them (to cerr by default). The error checking disappears
		//   with release builds by defining NDEBUG.
		// GPGPU CONCEPT 2: Fragment Program = Computational Kernel.
		// A fragment program can be thought of as a small computational
		// kernel that is applied in parallel to many fragments
		// simultaneously.  Here we load a kernel that performs an edge
		// detection filter on an image.
		_programObject = glCreateProgramObjectARB();
		CheckErrorsGL("BEGIN : Configuring Shader");

		// Create the edge detection fragment program
		_fragmentShader = glCreateShaderObjectARB(GL_FRAGMENT_SHADER_ARB);
		glShaderSourceARB(_fragmentShader, 1, &edgeFragSource, NULL);
		glCompileShaderARB(_fragmentShader);
		glAttachObjectARB(_programObject, _fragmentShader);

		// Link the shader into a complete GLSL program.
		glLinkProgramARB(_programObject);
		GLint progLinkSuccess;
		glGetObjectParameterivARB(_programObject, GL_OBJECT_LINK_STATUS_ARB,
			&progLinkSuccess);
		if (!progLinkSuccess)
		{
			fprintf(stderr, "Filter shader could not be linked\n");
			exit(1);
		}

		
		_programObjectT = glCreateProgramObjectARB();
		CheckErrorsGL("BEGIN : Configuring Shader");

		// Create the edge detection fragment program
		_vertexShaderT = glCreateShaderObjectARB(GL_VERTEX_SHADER_ARB);
		glShaderSourceARB(_vertexShaderT, 1, &teapotvert, NULL);
		glCompileShaderARB(_vertexShaderT);
		glAttachObjectARB(_programObjectT, _vertexShaderT);


		_fragmentShaderT = glCreateShaderObjectARB(GL_FRAGMENT_SHADER_ARB);
		glShaderSourceARB(_fragmentShaderT, 1, &teapotsource, NULL);
		glCompileShaderARB(_fragmentShaderT);
		glAttachObjectARB(_programObjectT, _fragmentShaderT);

		// Link the shader into a complete GLSL program.
		glLinkProgramARB(_programObjectT);
		glGetObjectParameterivARB(_programObjectT, GL_OBJECT_LINK_STATUS_ARB,
			&progLinkSuccess);
		if (!progLinkSuccess)
		{
			char error[4096];size_t length;
			glGetInfoLogARB(_fragmentShaderT, 4096, (GLsizei*) &length, error);
			fprintf(stderr, "Filter shader could not be linked %s\n",error);
			exit(1);
		}

		// Get location of the sampler uniform
		_texUnit = glGetUniformLocationARB(_programObject, "texUnit");
	_size = glGetUniformLocationARB(_programObjectT, "size");
	_origin = glGetUniformLocationARB(_programObjectT, "origin");
	_bboxmin = glGetUniformLocationARB(_programObjectT, "bboxmin");
	_bboxmax = glGetUniformLocationARB(_programObjectT, "bboxmax");
		CheckErrorsGL("END : Configuring Shader");
		FramebufferObject::Disable();
	}

	~HelloGPGPU()
    {
    }
	void allocateTextures(unsigned int iWidth, unsigned int iHeight) {
		this->_iWidth=iWidth;
		this->_iHeight=iHeight;
		CheckErrorsGL("BEGIN : Creating textures");
		glGenTextures(2, _iTexture); // create (reference to) a new texture

		// initialize the two textures
		// The first is used as rendering target for the sample scene
		//This one is used as reading source for the filter
		//The destination of the filter is the second texture
		//This second texture is the source for the final rendering display to the screen
		for(int i=0;i<2;i++)
		{
			glBindTexture(GL_TEXTURE_2D, _iTexture[i]);
			// (set texture parameters here)
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
			//create the texture
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA_FLOAT32_ATI /*GL_RGBA8*/, _iWidth, _iHeight,
						 0, GL_RGB, GL_FLOAT, 0);
		}
		CheckErrorsGL("END : Creating textures");
		
		_fbo.Bind(); // Bind framebuffer object.
		CheckErrorsGL("BEGIN : Configuring FBO");

		// Attach texture to framebuffer color buffer
		_fbo.AttachTexture(GL_COLOR_ATTACHMENT0_EXT, GL_TEXTURE_2D, _iTexture[0]);
		_fbo.AttachTexture(GL_COLOR_ATTACHMENT1_EXT, GL_TEXTURE_2D, _iTexture[1]);

		// Optional: initialize depth renderbuffer
		_rb.Set( GL_DEPTH_COMPONENT24, _iWidth, _iHeight );
		_fbo.AttachRenderBuffer( GL_DEPTH_ATTACHMENT_EXT, _rb.GetId() );

		// Validate the FBO after attaching textures and render buffers
		_fbo.IsValid();

		// Disable FBO rendering for now...
		FramebufferObject::Disable();
		CheckErrorsGL("END : Configuring FBO");

		
	}
    void update(unsigned int iWidth, unsigned int iHeight, const RayCTM rays[], float * output, float fov)		
    {
		_fbo.Bind(); 									 // Render to the FBO

		if (iWidth!=this->_iWidth||iHeight!=this->_iHeight) {
			allocateTextures(iWidth,iHeight);
		}
		_fbo.Bind(); 									 // Render to the FBO
		CheckErrorsGL("BEGIN : HelloGPGPU::update()");

		glDrawBuffer(GL_COLOR_ATTACHMENT0_EXT);			 // Draw into the first texture
        _rAngle += 0.5f;
		CheckErrorsGL("HelloGPGPU::update() : After FBO setup");

        // store the window viewport dimensions so we can reset them,
        // and set the viewport to the dimensions of our texture
        int vp[4];
        glGetIntegerv(GL_VIEWPORT, vp);

        // GPGPU CONCEPT 3a: One-to-one Pixel to Texel Mapping: A Data-
        //                   Dimensioned Viewport.
        // We need a one-to-one mapping of pixels to texels in order to
        // ensure every element of our texture is processed. By setting our
        // viewport to the dimensions of our destination texture and drawing
        // a screen-sized quad (see below), we ensure that every pixel of our
        // texel is generated and processed in the fragment program.
        glViewport(0, 0, _iWidth, _iHeight);

        // Render a teapot and 3 tori
        glEnable(GL_DEPTH_TEST);
        glDepthFunc (GL_LEQUAL);
        glClear(GL_DEPTH_BUFFER_BIT);
        //glColor4f(0,1,1,1);    
        double tt = Timer_GetMS();
        glUseProgramObjectARB(_programObjectT);
        glMatrixMode(GL_PROJECTION);
        glPushMatrix();
        glLoadIdentity();
        float aspect = (float) _iWidth / _iHeight;
        
        // XXX Really need to use transformed bboxMax.  This is wrong sometimes.
        CameraFrame& sceneSpaceCamera=rays->cam->getSceneSpaceCameraFrame();
        float distance = 100000000;/*sceneSpaceCamera.direction.z > 0 ?
                                     scene.bboxMax().z - sceneSpaceCamera.position.z :
                                     scene.bboxMin().z -sceneSpaceCamera.position.z;*/
       printf("FAKE fov %f %f\n",rays->cam->getSceneSpaceCameraInfo().fov,fov);
        gluPerspective(/*cam->getSceneSpaceCameraInfo().fov*180/M_PI*/fov, aspect, 0.1f, distance * 1.1f);
        glMatrixMode(GL_MODELVIEW);
        glPushMatrix();
        glLoadIdentity();
        
        gluLookAt(sceneSpaceCamera.position.x+rays->bbox.rayOffset.v[0],
                  sceneSpaceCamera.position.y+rays->bbox.rayOffset.v[1],
                  sceneSpaceCamera.position.z+rays->bbox.rayOffset.v[2],
                  
                  sceneSpaceCamera.position.x +rays->bbox.rayOffset.v[0]+
                  sceneSpaceCamera.direction.x,
                  sceneSpaceCamera.position.y +rays->bbox.rayOffset.v[1]+
                  sceneSpaceCamera.direction.y,
                  sceneSpaceCamera.position.z +rays->bbox.rayOffset.v[2]+
                  sceneSpaceCamera.direction.z,
                  
                  sceneSpaceCamera.up.x,
                  sceneSpaceCamera.up.y,
                  sceneSpaceCamera.up.z);
        /*		printf ("CAMINFO %f %f %f %f %f %f %f %f %f %f %f %f\n",
                        sceneSpaceCamera.position.x,
                        sceneSpaceCamera.position.y,
                        sceneSpaceCamera.position.z,
                        
                        sceneSpaceCamera.position.x +
                        sceneSpaceCamera.direction.x,
                        sceneSpaceCamera.position.y +
                        sceneSpaceCamera.direction.y,
                        sceneSpaceCamera.position.z +
                        sceneSpaceCamera.direction.z,
                        
                        sceneSpaceCamera.up.x,
                        sceneSpaceCamera.up.y,
                        sceneSpaceCamera.up.z);*/
	//glTranslatef(0,0,-10000);_origin = glGetUniformLocationARB(_programObjectT, "origin");
        glUniform3fARB(_origin, sceneSpaceCamera.position.x +rays->bbox.rayOffset.v[0],sceneSpaceCamera.position.y +rays->bbox.rayOffset.v[1],sceneSpaceCamera.position.z +rays->bbox.rayOffset.v[2]);
        glUniform3fARB(_bboxmin,rays->bbox.min.x,rays->bbox.min.y,rays->bbox.min.z);
        glUniform2fARB(_size,(float)_iWidth,(float)_iHeight);
	glUniform3fARB(_bboxmax,rays->bbox.max.x,rays->bbox.max.y,rays->bbox.max.z);
        //	glCallList(scene);
        glEnableClientState(GL_VERTEX_ARRAY);
        glBindBufferARB(GL_ARRAY_BUFFER_ARB,scene[0]);
        glVertexPointer(3,GL_FLOAT,0,(float*)NULL);
        glClientActiveTextureARB(GL_TEXTURE0);
        glEnableClientState (GL_TEXTURE_COORD_ARRAY);
        //glBindBufferARB(GL_ARRAY_BUFFER_ARB,scene[1]);
        glTexCoordPointer(3,GL_FLOAT,0,(float*)NULL);
        
        glClientActiveTextureARB(GL_TEXTURE1);
        glEnableClientState (GL_TEXTURE_COORD_ARRAY);
        glBindBufferARB(GL_ARRAY_BUFFER_ARB,scene[2]);
        glTexCoordPointer(3,GL_FLOAT,0,(float*)NULL);
        glDrawArrays(GL_TRIANGLES, 0, numTris * 3);
		//glutSolidTeapot(.5);
        glPopMatrix();
        glMatrixMode(GL_PROJECTION);
        glPopMatrix();
        
        CheckErrorsGL("HelloGPGPU::update() : After first render pass");
        
        glDrawBuffer(GL_COLOR_ATTACHMENT1_EXT);
        glPixelStorei(GL_PACK_ALIGNMENT,1);   
        // read back the whole thing, 
        int minX=0;int minY=0;
        glFinish();
        //glReadPixels (minX, minY,  1, 1,       GL_RGBA,    GL_FLOAT, output);
        double t = Timer_GetMS()-tt;
        PRINT(("Raster: Time is %f, FPS is %6.2f. %6.3f million pix/sec\n", t, 1000.0f / t,this->_iWidth*this->_iHeight/(t*1000)));
#ifdef USE_CTM
        dualReadFloat4Pixels (minX, 
                        minY,
                        _iWidth,
                        _iHeight, 
                        output);
#else
        glReadPixels (minX, minY,  1, 1,       GL_RGBA,    GL_FLOAT, output);
#endif
        t = Timer_GetMS()-tt;
        PRINT(("Post-Write Rstr is %f, FPS is %6.2f. %6.3f million pix/sec\n", t, 1000.0f / t,this->_iWidth*this->_iHeight/(t*1000)));
        /*
		FILE *fp=fopen("output.ppm","wb");
		fprintf(fp,"P6\n%d %d\n255\n",_iWidth,_iHeight);
		for(int i=0;i<_iWidth*_iHeight;i++){
			char r=255*output[i*4+0];
			char g=255*output[i*4+1];
			char b=255*output[i*4+2];
			fprintf(fp,"%c%c%c",r,g,b);
		}
		fclose(fp);*/
		glDisable(GL_DEPTH_TEST);
        glUseProgramObjectARB(0);

		FramebufferObject::Disable();
		//Draw into the second texture
        // read from the first texture
        //glBindTexture(GL_TEXTURE_2D, _iTexture[0]);
        //No need for copy glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, _iWidth, _iHeight);

        // run the edge detection filter over the geometry texture
        // Activate the edge detection filter program
     
		CheckErrorsGL("END : HelloGPGPU::display()");
    }

protected: // data
    int           _iWidth, _iHeight; // The dimensions of our array
    float         _rAngle;           // used for animation

    GLuint			   _iTexture[2]; // The texture used as a data array
	FramebufferObject  _fbo;		 // The framebuffer object used for rendering to the texture
	Renderbuffer	   _rb;	         // Optional: The renderbuffer object used for depth

    GLuint scene[3];
    size_t numTris;
    GLhandleARB   _programObject;    // the program used to update
    GLhandleARB   _fragmentShader;

    GLhandleARB   _programObjectT;    // the program used to update
    GLhandleARB   _fragmentShaderT;
    GLhandleARB   _vertexShaderT;

    GLint         _texUnit;          // a parameter to the fragment program

	GLint _origin;
	GLint _size;
	GLint _bboxmin;
	GLint _bboxmax;

};

// GLUT idle function
void idle()
{
    glutPostRedisplay();
}

// GLUT display function
bool display(int w, int h, const RayCTM rays[],float * output, ctmstream outputstream, float fov)
{
    if (g_pHello==NULL&&g_raster!=NULL) {//don't use GL..
	g_raster->draw(w,h,rays,outputstream,fov);
	return false;
    }else {
	g_pHello->update(w,h,rays,output,fov);  // update the scene and run the edge detect filter
	return true;
    }
    //g_pHello->display(); // display the results
    //glutSwapBuffers();
}

// GLUT reshape function
void reshape(int w, int h)
{
    if (h == 0) h = 1;

    glViewport(0, 0, w, h);

    // GPGPU CONCEPT 3b: One-to-one Pixel to Texel Mapping: An Orthographic
    //                   Projection.
    // This code sets the projection matrix to orthographic with a range of
    // [-1,1] in the X and Y dimensions. This allows a trivial mapping of
    // pixels to texels.
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-1, 1, -1, 1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

// Called at startup
void initialize(int count,const F3*v0,const F3*v1,const F3*v2, F3 offset)
{
    // Initialize the "OpenGL Extension Wrangler" library
    glewInit();

    // Ensure we have the necessary OpenGL Shading Language extensions.
    if (glewGetExtension("GL_ARB_fragment_shader")      != GL_TRUE ||
        glewGetExtension("GL_ARB_vertex_shader")        != GL_TRUE ||
        glewGetExtension("GL_ARB_shader_objects")       != GL_TRUE ||
        glewGetExtension("GL_ARB_shading_language_100") != GL_TRUE)
    {
        fprintf(stderr, "Driver does not support OpenGL Shading Language\n");
        exit(1);
    }

    // Create the example object
    g_pHello = new HelloGPGPU(count,v0,v1,v2,offset);
}

// The main function
int main2(int count,const F3*v0,const F3*v1,const F3*v2, F3 offset, bool init_display, IRenderContext * ctx)
{

    if (ctx==NULL||strcmp(ctx->getRenderSystem()->getRenderSystemID(),"dx9")!=0) {
	if (init_display ) {
		glutInitDisplayMode(GLUT_RGBA);
		glutInitWindowSize(16, 16);
		glutCreateWindow("Hello, GPGPU! (GLSL version)");
	}

	initialize(count,v0,v1,v2, offset);
    }else {
	//do DX9 THang
	g_raster=new rasterDX(count,v0,v1,v2,offset,(RenderContextDX9*)ctx);
    }
    return 0;
}
