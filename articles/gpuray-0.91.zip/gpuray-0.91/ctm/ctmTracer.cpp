/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * ctmTracer.cpp --
 *
 *      Helper classes for ray-tracing with the CTM
 */
#include "ctmTracer.h"


#include <assert.h>
#ifdef _WIN32
#include <winsock2.h>
#pragma comment(lib, "ws2_32")
#else
#include <arpa/inet.h>
#endif

#ifdef USE_CTM
#include "kdtreeCTM.h"
#endif
#ifdef USE_BROOK
#include "kdtreeBrook.h"
#endif
#include "../log.h"
#include "../timer.h"
#include "../sampler.h"
#include "shader.h"
#include "ctmDisplay.h"
#include "../f3.h"

#include "../ctm/kdtreeCTM.h"
/*
 * ReallocateAligned --
 *
 *      Extends an aligned allocation to a new size.
 *
 * Returns:
 *     A pointer to the allocated block.
 */


/*
 * DefaultTracerCTM::Trace --
 *
 *     Intersect rays, shade the hits,
 *     and composite the results into
 *     the image data provided.
 *
 * Returns:
 *     None.
 */

int stat_cache_miss[64];
int stat_clocks[64];
int stat_time[64];
int stat_counter=0;
void addCacheStats(int miss, int cycle, int t) {
    if (stat_counter<64) {
	stat_cache_miss[stat_counter]=miss;
	stat_time[stat_counter]=t;
	stat_clocks[stat_counter]=cycle;
	stat_counter+=1;
    }
}


void DefaultTracerCTM::Trace(
   uint32 inCount,
   const SampleCTM* inSamples,
   const RayCTM* inRays,
   PixelCTM* ioPixels )
{
   class Callback : public IHitCallbackCTM
   {
   public:
      virtual void Call(
         uint32 inCount,
         const RayCTM* inRays,
         const HitCTM* inHits )
      {
         shader->Shade( inCount,
                        samples,
                        inRays,
                        inHits,
                        pixels,
                        true );
      }
      
      IStandardShaderCTM* shader;
      const SampleCTM* samples;
      PixelCTM* pixels;
   };

   Callback callback;
   callback.shader = _shader;
   callback.samples = inSamples;
   callback.pixels = ioPixels;
  
   _intersector->Intersect( inCount, inRays, &callback );
}

DefaultBaseRayIntersectorCTM::DefaultBaseRayIntersectorCTM(
   const Opts& inOptions,
   Scene* inScene,
   ToggleOption* inUsePacketsOptions,
   GPUDevice* device,
   BoundingBoxCTM* bbox )
{
   const char *accel = inOptions.accelName ? inOptions.accelName : "kdtree";
   float t;

   _scene = inScene;
   _usePacketsOption = inUsePacketsOptions;

   t = Timer_GetMS();
   if (strcmp(accel, "kdtree") == 0) {
#ifdef USE_CTM
     _accelCTM = new KDTreeCTM(*_scene, inOptions, device, bbox);
#endif
#ifdef USE_BROOK
   } else if (strcmp(accel, "kdtree-brook") == 0) {
     _accelCTM = new KDTreeBrook(*_scene, inOptions,  bbox);
#endif
   } else {
      fprintf(stderr, "Unknown CTM based accelerator: %s\n", accel);
      Usage(inOptions.progName);
   }
   t = Timer_GetMS() - t;

   PRINTTIME(("Constructing %s took %5.2f msecs.\n", accel, t));
   if (inOptions.buildOnly) {
      exit(0);
   }
}

void
DefaultBaseRayIntersectorCTM::Intersect(
   uint32 inCount,
   const RayCTM* inRays,
   IHitCallbackCTM* inContinuation )
{
   int numRays = inCount;
   HitCTM *hits;
   const RayCTM* rays;
   float t;

   rays = inRays;
   HitCTM hitstack;
   hits = &hitstack;


   if (_usePacketsOption->isEnabled()) {
      PRINT(("Casting the rays (packets)...\n"));
      t = Timer_GetMS();
      _accelCTM->intersectPacket(rays, numRays, hits);
      t = Timer_GetMS() - t;

   } else {
      PRINT(("Casting the rays (ctm)...\n"));
      t = Timer_GetMS();
      _accelCTM->intersect(rays, numRays, hits);
      t = Timer_GetMS() - t;
   }
   if (!_quiet) {
       PRINTTIME(("Raycasting took %5.2f msecs (%5.2f fps) for %d rays and %d triangles.\n",
		  t, 1000.0f / t, numRays, _scene->nTris()));
       PRINTTIME(("\t%5.2f MRays per second (%.2f usecs per ray).\n",
		  numRays / t / 1000.0f, t * 1000.0 / numRays));
   }
   t = Timer_GetMS();
   inContinuation->Call( inCount, inRays, hits );
   t = Timer_GetMS() - t;
   if (stat_counter) {
       printf ("\nCacheMiss;");
       for (int i=0;i<stat_counter;++i) {
	   printf("%d;",stat_cache_miss[i]);
       }
       printf ("\nCycles   ;");
       for (int i=0;i<stat_counter;++i) {
	   printf("%d;",stat_time[i]);       
       }
       printf ("\nBusyCycle;");
       for (int i=0;i<stat_counter;++i) {
	   printf("%d;",stat_clocks[i]);
       }
   }
   stat_counter=0;
   PRINTTIME(("\nShading took %5.4f msecs for a %d-pixel image.\n", t, inCount));
}

void
DefaultBaseRayIntersectorCTM::IntersectP(
   uint32 inCount,
   const RayCTM* inRays,
   IHitCallbackCTM* inContinuation )
{
   int numRays = inCount;
   const RayCTM *rays;
   HitCTM *hits;
   float t;

   rays = inRays;
   hits = (HitCTM *) malloc( sizeof(HitCTM));


   if (_usePacketsOption->isEnabled()) {
      PRINT(("Casting the shadow rays (packets)...\n"));
      t = Timer_GetMS();
      _accelCTM->intersectPacketP(rays, numRays, hits);
      t = Timer_GetMS() - t;

   } else {
      PRINT(("Casting the rays (ctm)...\n"));
      t = Timer_GetMS();
      _accelCTM->intersectP(rays, numRays, hits);
      t = Timer_GetMS() - t;
   }

   PRINTTIME(("Raycasting took %5.2f msecs (%5.2f fps) for %d rays and %d triangles.\n",
      t, 1000.0f / t, numRays, _scene->nTris()));
   PRINTTIME(("\t%5.2f MRays per second (%.2f usecs per ray).\n",
      numRays / t / 1000.0f, t * 1000.0 / numRays));

   t = Timer_GetMS();
   inContinuation->Call( inCount, inRays, hits );
   t = Timer_GetMS() - t;
   PRINTTIME(("Shading took %5.2f msecs for a %d-pixel image.\n", t, inCount));
}

/*
 * DumpBoundRayIntersectorCTM::DumpBoundRayIntersectorCTM --
 *
 *     Initializes a DumpBoundRayIntersectorCTM that will
 *     dump rays to the specified file name before passing
 *     them on to the "inner" intersector.
 *
 * Returns:
 *     None.
 */

void
PrimaryRayCallbackCTM::Call(
   uint32 inWidth, uint32 inHeight,
   const RayCTM* inRays )
{
   uint32 count = inWidth * inHeight;

   assert( count % BUNDLE_SIZE == 0 );

   uint32 bundleCount = count / BUNDLE_SIZE;

   SampleCTM* samples = NULL;/*(SampleCTM*) AllocateAligned(
                              bundleCount*sizeof(SampleCTM), 16 );*/
   
   static PixelCTM pixels;
   PRINT(("rayType:primary %d\n", count));
   _tracer->Trace( count, samples, inRays, &pixels );

   _pixelDisplayer->Display( inWidth, inHeight, &pixels );
   //FreeAligned(samples);
   //delete[] pixels;
}

