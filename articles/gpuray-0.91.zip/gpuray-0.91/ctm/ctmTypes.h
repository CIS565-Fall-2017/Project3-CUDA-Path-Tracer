/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * ctmTypes.h --
 *
 *      The structs / typedefs used by the CTM version of the raytracer
 *
 */

#ifndef __CTMTYPES_H__
#define __CTMTYPES_H__

#include "../f3.h"
#include "../common/commonTypes.h"
#include "../cameraManager.h"
namespace brook {
    class stream;
}
class AcceleratorCTM;
typedef struct BoundingBoxCTM {
  F3 rayOffset;
  F3 min;
  F3 max;
} BoundingBoxCTM;
typedef union {
    brook::stream *stream;
    struct ctmptr{
	uint32 ptr;
	bool tiled;
    }ctm;
} ctmstream;
typedef struct RayGPUCTM {
   ctmstream rays;
   brook::stream *raysOXYZ;//for brook only
   uint32 width;
   uint32 height;
   BoundingBoxCTM bbox;
   F3 raysO;
   F3 camT;
   F3 camU;
   F3 camV;
   F3 camW;
	CameraManager* cam;
	RayGPUCTM(){
		cam=NULL;
		raysOXYZ=NULL;
		ResetOrigin();
	}
	void ResetOrigin() {
		raysO.v[0]=-666.0f;
		raysO.v[1]=-666.0f;
		raysO.v[2]=-666.0f;
	}
} RayGPUCTM;

typedef struct RayPacketCTM {
   F3Packet o;
   F3Packet d;
} RayPacketCTM;

typedef struct RayIntervalCTM {
   F3Packet o;
   float tmin[BUNDLE_SIZE];
   F3Packet d;
   float tmax[BUNDLE_SIZE];
} RayIntervalCTM;

typedef RayGPUCTM RayCTM;

typedef struct HitPacketCTM {
   float tHit[BUNDLE_SIZE];
   float uu[BUNDLE_SIZE];
   float vv[BUNDLE_SIZE];
   int triNum[BUNDLE_SIZE];
} HitPacketCTM
;
class KDTreeCTM;
typedef struct HitGPUCTM {
   ctmstream tHitPtr;
   ctmstream uuPtr;
   ctmstream vvPtr;
   ctmstream triNumPtr;
   uint32 width;
   uint32 height;
   mutable AcceleratorCTM* intersector;
} HitGPUCTM;

typedef HitGPUCTM HitCTM;
union CtmKdTreeNode
{
  struct
  {
    float primitiveCount_tag;
    float firstPrimitiveIndex;
  } leaf;
  struct
  {
     float leftChildIndex_splitAxis;
     float splitValue;
  } split;
};


union PaddedCtmKdTreeNode
{
  struct
  {
    float primitiveCount_tag;
    float firstPrimitiveIndex;
      float pad0,pad1;
  } leaf;
  struct
  {
     float leftChildIndex_splitAxis;
     float splitValue;
      float pad0,pad1;
  } split;

  struct
  {
    float primitiveCount_tag;
    float firstPrimitiveIndex;
    float pad0;
    float threeSirThree;//must be 3
  } fatleaf;
  struct
  {
      float leftChildIndexX;
      float leftChildIndexY;
      float splitValue;
      float axis;
  } fatsplit;



};


#endif
