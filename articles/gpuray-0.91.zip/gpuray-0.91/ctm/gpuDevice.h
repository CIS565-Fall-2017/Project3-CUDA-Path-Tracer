#ifndef __GPU_DEVICE_H
#define __GPU_DEVICE_H

#ifdef USE_CTM
#include "amDeviceManaged.h"
#include "amuComp.h"
#include "amuABI.h"
#include "amuCbufPack.h"
#include "amuCbufTypes.h"
#include "amuAsm.h"
#endif
#include <stdio.h>
#include <assert.h>
#include <string>

extern void logFunction(const char *msg);
extern void printAssemblyFunction(const char * msg);
extern void printNoPacketAssemblyFunction(const char * msg);
extern int numCards;
extern int curCard;
struct GPUDevice {
  AMmanagedDeviceInfo info;
  AMmanagedDevice vm; 
  AMuint32 cbufAddressGPU;
  void* cbufAddressCPU;

  AMuint32 cbufRayCopyAddressGPU;
  void* cbufRayCopyAddressCPU;

  AMuint32 programAddressGPU;
  void* programAddressCPU;

  AMuint32 copy1KernelAddressGPU;
  void* copy1KernelAddressCPU;
  AMuint32 copyF4KernelAddressGPU;
  void* copyF4KernelAddressCPU;
  AMuint32 copy4FKernelAddressGPU;
  void* copy4FKernelAddressCPU;
  AMuint32 fconstAddressGPU;
  void* fconstAddressCPU;
  AMuint32 iconstAddressGPU;
  void* iconstAddressCPU;
    
  AMuint32 fconstF4AddressGPU;
  void* fconstF4AddressCPU;
  AMuint32 iconstF4AddressGPU;
  void* iconstF4AddressCPU;


  AMuint32 fconst4FAddressGPU;
  void* fconst4FAddressCPU;
  AMuint32 iconst4FAddressGPU;
  void* iconst4FAddressCPU;
    
  AMuint32 fconst1AddressGPU;
  void* fconst1AddressCPU;
  AMuint32 iconst1AddressGPU;
  void* iconst1AddressCPU;
    
  AMuint32 rayGenKernelAddressGPU;
  void* rayGenKernelAddressCPU;
  AMuint32 fconstRayGenAddressGPU;
  void* fconstRayGenAddressCPU;
  AMuint32 iconstRayGenAddressGPU;
  void* iconstRayGenAddressCPU;
    
  AMuint32 raytracerNoPacketKernelAddressGPU;
  void* raytracerNoPacketKernelAddressCPU;
  AMuint32 fconstRaytracerNoPacketAddressGPU;
  void* fconstRaytracerNoPacketAddressCPU;
  AMuint32 iconstRaytracerNoPacketAddressGPU;
  void* iconstRaytracerNoPacketAddressCPU;
    


  AMuint32 uberShaderKernelAddressGPU;
  void* uberShaderKernelAddressCPU;
  AMuint32 fconstUberShaderAddressGPU;
  void* fconstUberShaderAddressCPU;
  AMuint32 iconstUberShaderAddressGPU;
  void* iconstUberShaderAddressCPU;
    
  AMuint32 bounceShaderKernelAddressGPU;
  void* bounceShaderKernelAddressCPU;
  AMuint32 fconstBounceShaderAddressGPU;
  void* fconstBounceShaderAddressCPU;
  AMuint32 iconstBounceShaderAddressGPU;
  void* iconstBounceShaderAddressCPU;

  AMuint32 originShaderKernelAddressGPU;
  void* originShaderKernelAddressCPU;
  AMuint32 fconstOriginShaderAddressGPU;
  void* fconstOriginShaderAddressCPU;
  AMuint32 iconstOriginShaderAddressGPU;
  void* iconstOriginShaderAddressCPU;


  AMuint32 rasterShaderKernelAddressGPU;
  void* rasterShaderKernelAddressCPU;
  AMuint32 fconstRasterShaderAddressGPU;
  void* fconstRasterShaderAddressCPU;
  AMuint32 iconstRasterShaderAddressGPU;
  void* iconstRasterShaderAddressCPU;


  AMuint32 swizzleDisplayKernelAddressGPU;
  void* swizzleDisplayKernelAddressCPU;
  AMuint32 fconstSwizzleDisplayAddressGPU;
  void* fconstSwizzleDisplayAddressCPU;
  AMuint32 iconstSwizzleDisplayAddressGPU;
  void* iconstSwizzleDisplayAddressCPU;

  AMuint32 perfCountAddressGPU;
  void* perfCountAddressCPU;


    
  AMuint32 outputAddressGPU;
  void* outputAddressCPU;
  AMuint32 tri0AddressGPU;
  AMuint32 tri1AddressGPU;
  AMuint32 tri2AddressGPU;
  AMuint32 kdtreeAddressGPU;


  AMuint32 RayDXGPU;
  AMuint32 RayDYGPU;
  AMuint32 RayDZGPU;

  int bytecountGPU; // Not mirrored
  int bytecountAGP; // Mirrored with CPU.

#ifdef USE_CTM
  AMUabiConstsInfo *constants;
  AMUabiConstsInfo *raytracerNoPacket_constants;
  AMUabiConstsInfo *copy1_constants;
  AMUabiConstsInfo *copyF4_constants;
  AMUabiConstsInfo *copy4F_constants;
  AMUabiConstsInfo *rayGen_constants;
  AMUabiConstsInfo *uberShader_constants;
  AMUabiConstsInfo *bounceShader_constants;
  AMUabiConstsInfo *originShader_constants;
  AMUabiConstsInfo *rasterShader_constants;
  AMUabiConstsInfo *swizzleDisplay_constants;
#endif
  
  //not sure if this belongs in class  AMUcbufPack* cbp;
  GPUDevice() {
    int cardID=(curCard++%numCards);
#ifdef USE_CTM
    char pcie[32];
    
    sprintf(pcie,"/dev/pcie%d",cardID);
    AMmanagedDeviceInfo _info = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    _info.arenaSizeSYS=80000000;
    _info.arenaSizeSYSc=8000000;
    info = _info;
    
    vm=amOpenManagedConnection(pcie,&info);
    //    vm=amOpenManagedConnection("/dev/pcie0",&info);
    printf ("vm is %d\n",(int)vm);
    assert(vm&&"Fatal: no ATI 520 card present\n");
#else
    info.baseAddressCPU=malloc(512*1024*1024);
    info.baseAddressSYS=0;
#endif
	constants=new AMUabiConstsInfo;
	raytracerNoPacket_constants=new AMUabiConstsInfo;
	memset(constants,0x7f,sizeof(AMUabiConstsInfo));
	memset(raytracerNoPacket_constants,0x7f,sizeof(AMUabiConstsInfo));
	copy1_constants=new AMUabiConstsInfo;
	copyF4_constants=new AMUabiConstsInfo;
	copy4F_constants=new AMUabiConstsInfo;
	rayGen_constants=new AMUabiConstsInfo;
	uberShader_constants=new AMUabiConstsInfo;
	bounceShader_constants=new AMUabiConstsInfo;
	originShader_constants=new AMUabiConstsInfo;
	rasterShader_constants=new AMUabiConstsInfo;
	swizzleDisplay_constants=new AMUabiConstsInfo;

    bytecountGPU=0;
    bytecountAGP=0;
    printf ("Arena size %d\n",info.arenaSizeSYS);
    printf ("Cached Arena size %d\n",info.arenaSizeSYSc);
    fflush(stdout);
    cbufAddressGPU        =                    info.baseAddressSYS + 0 * 64 * 1024;
    cbufAddressCPU        = ( unsigned char* ) info.baseAddressCPU + 0 * 64 * 1024;
    cbufRayCopyAddressGPU =                    info.baseAddressSYS + 1 * 64 * 1024;
    cbufRayCopyAddressCPU = ( unsigned char* ) info.baseAddressCPU + 1 * 64 * 1024;
    programAddressGPU     =                    info.baseAddressSYS + 2 * 64 * 1024;
    programAddressCPU     = ( unsigned char* ) info.baseAddressCPU + 2 * 64 * 1024;
    copy1KernelAddressGPU =                    info.baseAddressSYS + 3 * 64 * 1024;
    copy1KernelAddressCPU = ( unsigned char* ) info.baseAddressCPU + 3 * 64 * 1024;
    copyF4KernelAddressGPU =                    info.baseAddressSYS + 4 * 64 * 1024;
    copyF4KernelAddressCPU = ( unsigned char* ) info.baseAddressCPU + 4 * 64 * 1024;
    fconstAddressGPU      =                    info.baseAddressSYS + 5 * 64 * 1024;
    fconstAddressCPU      = ( unsigned char* ) info.baseAddressCPU + 5 * 64 * 1024;
    iconstAddressGPU      =                    info.baseAddressSYS + 6 * 64 * 1024;
    iconstAddressCPU      = ( unsigned char* ) info.baseAddressCPU + 6 * 64 * 1024;
    fconstF4AddressGPU     =                    info.baseAddressSYS + 7 * 64 * 1024;
    fconstF4AddressCPU     = ( unsigned char* ) info.baseAddressCPU + 7 * 64 * 1024;
    iconstF4AddressGPU     =                    info.baseAddressSYS + 8 * 64 * 1024;
    iconstF4AddressCPU     = ( unsigned char* ) info.baseAddressCPU + 8 * 64 * 1024;
    fconst1AddressGPU     =                    info.baseAddressSYS + 9 * 64 * 1024;
    fconst1AddressCPU     = ( unsigned char* ) info.baseAddressCPU + 9 * 64 * 1024;
    iconst1AddressGPU     =                    info.baseAddressSYS + 10 * 64 * 1024;
    iconst1AddressCPU     = ( unsigned char* ) info.baseAddressCPU + 10 * 64 * 1024;
    rayGenKernelAddressGPU=                    info.baseAddressSYS + 11 * 64 * 1024;
    rayGenKernelAddressCPU= ( unsigned char* ) info.baseAddressCPU + 11 * 64 * 1024;
    fconstRayGenAddressGPU=                    info.baseAddressSYS + 12 * 64 * 1024;
    fconstRayGenAddressCPU= ( unsigned char* ) info.baseAddressCPU + 12 * 64 * 1024;
    iconstRayGenAddressGPU=                    info.baseAddressSYS + 13 * 64 * 1024;
    iconstRayGenAddressCPU= ( unsigned char* ) info.baseAddressCPU + 13 * 64 * 1024;
    uberShaderKernelAddressGPU=                    info.baseAddressSYS + 14 * 64 * 1024;
    uberShaderKernelAddressCPU= ( unsigned char* ) info.baseAddressCPU + 14 * 64 * 1024;
    fconstUberShaderAddressGPU=                    info.baseAddressSYS + 15 * 64 * 1024;
    fconstUberShaderAddressCPU= ( unsigned char* ) info.baseAddressCPU + 15 * 64 * 1024;
    iconstUberShaderAddressGPU=                    info.baseAddressSYS + 16 * 64 * 1024;
    iconstUberShaderAddressCPU= ( unsigned char* ) info.baseAddressCPU + 16 * 64 * 1024;
    bounceShaderKernelAddressGPU=                    info.baseAddressSYS + 17 * 64 * 1024;
    bounceShaderKernelAddressCPU= ( unsigned char* ) info.baseAddressCPU + 17 * 64 * 1024;
    fconstBounceShaderAddressGPU=                    info.baseAddressSYS + 18 * 64 * 1024;
    fconstBounceShaderAddressCPU= ( unsigned char* ) info.baseAddressCPU + 18 * 64 * 1024;
    iconstBounceShaderAddressGPU=                    info.baseAddressSYS + 19 * 64 * 1024;
    iconstBounceShaderAddressCPU= ( unsigned char* ) info.baseAddressCPU + 19 * 64 * 1024;
    originShaderKernelAddressGPU=                    info.baseAddressSYS + 20 * 64 * 1024;
    originShaderKernelAddressCPU= ( unsigned char* ) info.baseAddressCPU + 20 * 64 * 1024;
    fconstOriginShaderAddressGPU=                    info.baseAddressSYS + 21 * 64 * 1024;
    fconstOriginShaderAddressCPU= ( unsigned char* ) info.baseAddressCPU + 21 * 64 * 1024;
    iconstOriginShaderAddressGPU=                    info.baseAddressSYS + 22 * 64 * 1024;
    iconstOriginShaderAddressCPU= ( unsigned char* ) info.baseAddressCPU + 22 * 64 * 1024;

    rasterShaderKernelAddressGPU=                    info.baseAddressSYS + 23 * 64 * 1024;
    rasterShaderKernelAddressCPU= ( unsigned char* ) info.baseAddressCPU + 23 * 64 * 1024;
    fconstRasterShaderAddressGPU=                    info.baseAddressSYS + 24 * 64 * 1024;
    fconstRasterShaderAddressCPU= ( unsigned char* ) info.baseAddressCPU + 24 * 64 * 1024;
    iconstRasterShaderAddressGPU=                    info.baseAddressSYS + 25 * 64 * 1024;
    iconstRasterShaderAddressCPU= ( unsigned char* ) info.baseAddressCPU + 25 * 64 * 1024;






    swizzleDisplayKernelAddressGPU=                    info.baseAddressSYS + 26 * 64 * 1024;
    swizzleDisplayKernelAddressCPU= ( unsigned char* ) info.baseAddressCPU + 26 * 64 * 1024;
    fconstSwizzleDisplayAddressGPU=                    info.baseAddressSYS + 27 * 64 * 1024;
    fconstSwizzleDisplayAddressCPU= ( unsigned char* ) info.baseAddressCPU + 27 * 64 * 1024;
    iconstSwizzleDisplayAddressGPU=                    info.baseAddressSYS + 28 * 64 * 1024;
    iconstSwizzleDisplayAddressCPU= ( unsigned char* ) info.baseAddressCPU + 28 * 64 * 1024;
    copy4FKernelAddressGPU =                    info.baseAddressSYS + 29 * 64 * 1024;
    copy4FKernelAddressCPU = ( unsigned char* ) info.baseAddressCPU + 29 * 64 * 1024;
    fconst4FAddressGPU     =                    info.baseAddressSYS + 30 * 64 * 1024;
    fconst4FAddressCPU     = ( unsigned char* ) info.baseAddressCPU + 30 * 64 * 1024;
    iconst4FAddressGPU     =                    info.baseAddressSYS + 31 * 64 * 1024;
    iconst4FAddressCPU     = ( unsigned char* ) info.baseAddressCPU + 31 * 64 * 1024;
    perfCountAddressGPU    =                    info.baseAddressSYS + 32 * 64 * 1024;
    perfCountAddressCPU    = (unsigned char *)  info.baseAddressCPU + 32 * 64 * 1024;


    raytracerNoPacketKernelAddressGPU=                    info.baseAddressSYS + 33 * 64 * 1024;
    raytracerNoPacketKernelAddressCPU= ( unsigned char* ) info.baseAddressCPU + 33 * 64 * 1024;
    fconstRaytracerNoPacketAddressGPU=                    info.baseAddressSYS + 34 * 64 * 1024;
    fconstRaytracerNoPacketAddressCPU= ( unsigned char* ) info.baseAddressCPU + 34 * 64 * 1024;
    iconstRaytracerNoPacketAddressGPU=                    info.baseAddressSYS + 35 * 64 * 1024;
    iconstRaytracerNoPacketAddressCPU= ( unsigned char* ) info.baseAddressCPU + 35 * 64 * 1024;


    outputAddressGPU          =                    info.baseAddressSYS + 36 * 64 * 1024;
    outputAddressCPU          = ( unsigned char* ) info.baseAddressCPU + 36 * 64 * 1024;
#ifdef USE_CTM
    
    AMUcompMacro defines[] =
    {
        "AMU_LANG_PS3", "1",
         0,              0
    };
    
    AMuint32 programSize = 0;
    void* programBinary = 0;
    FILE * assembly= fopen ("ctm/raytracer.r5xx","rb");
    FILE * secundo = fopen("ctm/raytracer.const","rb");
    if (secundo!=NULL) fclose(secundo);
    AMUcompCompiler comp;
    if (assembly==NULL||secundo==NULL) {
	comp = amuCompOpenCompiler();
	char * filename="ctm/raytracer.ps";
	FILE * fp = fopen (filename,"rb");
	char * ps3text="";
	std::string ps3strtext="";
	int len=0;
	if (fp){
	    fseek (fp,0,SEEK_END);
	    len=ftell(fp);
	    fseek(fp,0,SEEK_SET);
	    ps3text=(char*)malloc(len+1);
	    fread(ps3text,1,len,fp);
	    ps3text[len]='\0';
	    char * where=ps3text;
	    while ((where=strstr(where,"defi"))!=NULL) {
		where[0]='/';
		where[1]='/';
	    }
	    ps3strtext=ps3text; 
	    int counterlabel=0;
	    if (0){
		std::string::size_type where=0;
		while ((where= ps3strtext.find("rep",where))!=std::string::npos) {
		    if (where==0||(where>0&&ps3strtext[where-1]!='d')) {
			std::string last=            ps3strtext.substr(where);
			ps3strtext=            ps3strtext.substr(0,where);
			where=where+8;
			char tmp[]="rep i7\n";
			tmp[5]='4'+counterlabel++;
			ps3strtext+=tmp;
			ps3strtext+=last;
		    } else where+=1;           
		}where=0;
		while ((where= ps3strtext.find("endrep",where))!=std::string::npos) {
		    std::string last=            ps3strtext.substr(where);
		    ps3strtext=            ps3strtext.substr(0,where);
		    where=where+8;
		    ps3strtext+="endrep\n";
		    ps3strtext+=last;
		}
		/*
		  printf ("%s\n",ps3strtext.c_str());
		  fflush(stdout);
		  exit(0);
		*/
	    }
          
	}else fprintf(stderr,"Unable to open %s\n",filename);
    
	if ( amuCompCompile( comp, ps3strtext.c_str(), len, defines, NULL, "main", &programSize, &programBinary, logFunction ) == 0 ) {
	    
	    assert( !"found error compiling write1" );
	}
	memcpy( programAddressCPU, programBinary, programSize );
	*constants = amuABIExtractConstants( programBinary );
    
    }

    if (!assembly) {
	amuAsmDisassemble(programBinary, printAssemblyFunction);
	FILE * fp = fopen ("ctm/raytracer.const","wb");
	fwrite(constants,sizeof(AMUabiConstsInfo),1,fp);
	fclose(fp);
    }else {
	fseek(assembly,0,SEEK_END);
	size_t strsize=ftell(assembly);
	fseek(assembly,0,SEEK_SET);
	char *str=(char*)malloc(strsize+1);
	programBinary=malloc((strsize+1)*10);
	str[strsize]='\0';
	fread(str,1,strsize,assembly);
	fclose(assembly);
	for (unsigned int i=0;i<strsize;++i) {
	    if (str[i]=='('&&str[i+1]=='!'){
		str[i+1]='(',str[i]='!';
	    }
	}
	FILE * fp = fopen ("ctm/raytracer.const","rb");
	fread(constants,sizeof(AMUabiConstsInfo),1,fp);
	fclose(fp);
	printf ("Assembling...\n");
	fflush(stdout);
	fflush(stderr);
	programSize=0;
	//AMuint32 programSize = 0;
	//	unsigned char programBinary[ 100000 ];
	if (amuAsmAssemble(str,&programSize,programBinary,logFunction)==0) {
	    printf ("FAILED ");
	    
	}
	printf ("Done Assembling...\n");
	fflush(stdout);
	fflush(stderr);
	printf ("program Size %d program binary %d\n",programSize,programBinary);
	fflush(stdout);
	memcpy( programAddressCPU, programBinary, programSize );

    }
    //fclose(fopen ("output.asm","w"));
    //amuAsmDisassemble(programBinary, fileFunction);
    //
    //  extract the symbols and constants from the binary
    //


    //
    //  cleanup and close the compiler
    //
    FILE * elf = fopen (assembly?"raytracer_asm.elf":"raytracer_ps.elf","wb");
    fwrite(programBinary,programSize,1,elf);
    fclose(elf);
    if (!assembly) {
	amuCompFreeBinary( comp, programBinary );
	amuCompCloseCompiler( comp );
    }else free(programBinary);
    comp = amuCompOpenCompiler();

    const char*filename = "ctm/rayGen.ps";
	FILE *fp = fopen (filename, "rb");
	size_t len;
	if (fp) {
		fflush(stderr);
		fseek (fp,0,SEEK_END);
		len=ftell(fp);
		fseek(fp,0,SEEK_SET);
		char *rayGenText = (char*)malloc(len+1);
		fread(rayGenText,1,len,fp);
		rayGenText[len]='\0';
		if ( amuCompCompile( comp, rayGenText, len, defines, NULL, "main", &programSize, &programBinary, logFunction ) == 0 ){
			assert( !"found error compiling rayGen" );
		}
		memcpy( rayGenKernelAddressCPU, programBinary, programSize );
	}else fprintf(stderr,"Unable to open %s\n",filename);
	fflush(stderr);
    *rayGen_constants = amuABIExtractConstants( programBinary );
    amuCompFreeBinary( comp, programBinary );
    amuCompCloseCompiler( comp );
    comp = amuCompOpenCompiler();
	filename = "ctm/uberShader.ps";
	fp = fopen (filename, "rb");
	if (fp) {
		fflush(stderr);
		fseek (fp,0,SEEK_END);
		len=ftell(fp);
		fseek(fp,0,SEEK_SET);
		char *uberShaderText = (char*)malloc(len+1);
		fread(uberShaderText,1,len,fp);
		uberShaderText[len]='\0';
		if ( amuCompCompile( comp, uberShaderText, len, defines, NULL, "main", &programSize, &programBinary, logFunction ) == 0 ){
			assert( !"found error compiling rayGen" );
		}
		memcpy( uberShaderKernelAddressCPU, programBinary, programSize );
	}else fprintf(stderr,"Unable to open %s\n",filename);
	fflush(stderr);
    *uberShader_constants = amuABIExtractConstants( programBinary );
    amuCompFreeBinary( comp, programBinary );
    amuCompCloseCompiler( comp );
      

          comp = amuCompOpenCompiler();
	filename = "ctm/updateRayOrigin.ps";
	fp = fopen (filename, "rb");
	if (fp) {
		fflush(stderr);
		fseek (fp,0,SEEK_END);
		len=ftell(fp);
		fseek(fp,0,SEEK_SET);
		char *originShaderText = (char*)malloc(len+1);
		fread(originShaderText,1,len,fp);
		originShaderText[len]='\0';
		if ( amuCompCompile( comp, originShaderText, len, defines, NULL, "main", &programSize, &programBinary, logFunction ) == 0 ){
			assert( !"found error compiling rayGen" );
		}
		memcpy( originShaderKernelAddressCPU, programBinary, programSize );
	}else fprintf(stderr,"Unable to open %s\n",filename);
	fflush(stderr);
    *originShader_constants = amuABIExtractConstants( programBinary );
    amuCompFreeBinary( comp, programBinary );
    amuCompCloseCompiler( comp );


    comp = amuCompOpenCompiler();
	filename = "ctm/bounceShader.ps";
	fp = fopen (filename, "rb");
	if (fp) {
		fflush(stderr);
		fseek (fp,0,SEEK_END);
		len=ftell(fp);
		fseek(fp,0,SEEK_SET);
		char *bounceShaderText = (char*)malloc(len+1);
		fread(bounceShaderText,1,len,fp);
		bounceShaderText[len]='\0';
		if ( amuCompCompile( comp, bounceShaderText, len, defines, NULL, "main", &programSize, &programBinary, logFunction ) == 0 ){
			assert( !"found error compiling rayGen" );
		}
		memcpy( bounceShaderKernelAddressCPU, programBinary, programSize );
	}else fprintf(stderr,"Unable to open %s\n",filename);
	fflush(stderr);
    *bounceShader_constants = amuABIExtractConstants( programBinary );
    amuCompFreeBinary( comp, programBinary );
    amuCompCloseCompiler( comp );
    assembly= fopen ("ctm/raytracer-single.r5xx","rb");
    secundo = fopen("ctm/raytracer-single.const","rb");
    if (secundo!=NULL) fclose(secundo);
    if (assembly==NULL||secundo==NULL) {
          comp = amuCompOpenCompiler();
	filename = "ctm/raytracer-single.ps";
	fp = fopen (filename, "rb");
	if (fp) {
		fflush(stderr);
		fseek (fp,0,SEEK_END);
		len=ftell(fp);
		fseek(fp,0,SEEK_SET);
		char *raytracerNoPacketText = (char*)malloc(len+1);
		fread(raytracerNoPacketText,1,len,fp);
		raytracerNoPacketText[len]='\0';
		char * where=raytracerNoPacketText;
		while ((where=strstr(where,"defi"))!=NULL) {
		  where[0]='/';
		  where[1]='/';
		}
		
		if ( amuCompCompile( comp, raytracerNoPacketText, len, defines, NULL, "main", &programSize, &programBinary, logFunction ) == 0 ){
			assert( !"found error compiling rayGen" );
		}
		memcpy( raytracerNoPacketKernelAddressCPU, programBinary, programSize );
	}else fprintf(stderr,"Unable to open %s\n",filename);
	fflush(stderr);
	*raytracerNoPacket_constants = amuABIExtractConstants( programBinary );
    }
    if (!assembly) {
	amuAsmDisassemble(programBinary, printNoPacketAssemblyFunction);
	FILE * fp = fopen ("ctm/raytracer-single.const","wb");
	fwrite(raytracerNoPacket_constants,sizeof(AMUabiConstsInfo),1,fp);
	fclose(fp);
    }else {
	fseek(assembly,0,SEEK_END);
	size_t strsize=ftell(assembly);
	fseek(assembly,0,SEEK_SET);
	char *str=(char*)malloc(strsize+1);
	programBinary=malloc((strsize+1)*10);
	str[strsize]='\0';
	fread(str,1,strsize,assembly);
	fclose(assembly);
	for (unsigned int i=0;i<strsize;++i) {
	    if (str[i]=='('&&str[i+1]=='!'){
		str[i+1]='(',str[i]='!';
	    }
	}
	FILE * fp = fopen ("ctm/raytracer-single.const","rb");
	fread(raytracerNoPacket_constants,sizeof(AMUabiConstsInfo),1,fp);
	fclose(fp);
	printf ("Assembling...\n");
	fflush(stdout);
	fflush(stderr);
	programSize=0;
	//AMuint32 programSize = 0;
	//	unsigned char programBinary[ 100000 ];
	if (amuAsmAssemble(str,&programSize,programBinary,logFunction)==0) {
	    printf ("FAILED ");
	    
	}
	printf ("Done Assembling...\n");
	fflush(stdout);
	fflush(stderr);
	printf ("program Size %d program binary %d\n",programSize,programBinary);
	fflush(stdout);
	memcpy( raytracerNoPacketKernelAddressCPU, programBinary, programSize );
	
    }
    if (!assembly) {
	amuCompFreeBinary( comp, programBinary );
	amuCompCloseCompiler( comp );
    }else {
	free(programBinary);
    }
    printf ("Compiling single raytracer:Dane\n");
    fflush(stdout);

    comp = amuCompOpenCompiler();
	filename = "ctm/swizzleDisplay.ps";
	fp = fopen (filename, "rb");
	if (fp) {
		fflush(stderr);
		fseek (fp,0,SEEK_END);
		len=ftell(fp);
		fseek(fp,0,SEEK_SET);
		char *swizzleDisplayText = (char*)malloc(len+1);
		fread(swizzleDisplayText,1,len,fp);
		swizzleDisplayText[len]='\0';
		if ( amuCompCompile( comp, swizzleDisplayText, len, defines, NULL, "main", &programSize, &programBinary, logFunction ) == 0 ){
			assert( !"found error compiling rayGen" );
		}
		memcpy( swizzleDisplayKernelAddressCPU, programBinary, programSize );
	}else fprintf(stderr,"Unable to open %s\n",filename);
	fflush(stderr);
    *swizzleDisplay_constants = amuABIExtractConstants( programBinary );
    amuCompFreeBinary( comp, programBinary );
    amuCompCloseCompiler( comp );

    comp = amuCompOpenCompiler();
	filename = "ctm/rastercopy.ps";
	fp = fopen (filename, "rb");
	if (fp) {
		fflush(stderr);
		fseek (fp,0,SEEK_END);
		len=ftell(fp);
		fseek(fp,0,SEEK_SET);
		char *rasterShaderText = (char*)malloc(len+1);
		fread(rasterShaderText,1,len,fp);
		rasterShaderText[len]='\0';
		if ( amuCompCompile( comp, rasterShaderText, len, defines, NULL, "main", &programSize, &programBinary, logFunction ) == 0 ){
			assert( !"found error compiling rayGen" );
		}
		memcpy( rasterShaderKernelAddressCPU, programBinary, programSize );
	}else fprintf(stderr,"Unable to open %s\n",filename);
	fflush(stderr);
    *rasterShader_constants = amuABIExtractConstants( programBinary );
    amuCompFreeBinary( comp, programBinary );
    amuCompCloseCompiler( comp );

      
    AMuint32 copy1Size = 0;
    void* copy1Binary = 0;

    comp = amuCompOpenCompiler();

char copy1prg[] =
    "    ps_3_0\n"
    "    def c63 .5,.5,.5,.5\n"
    "    dcl vPos.xy     \n"
    "    dcl_2d s0\n"
    "    add r0, vPos, c63\n"
    "    texld r1, r0, s0\n"
    "    mov oC0.xyzw, r1\n"
    "    end             \n"
    ;
    
    if ( amuCompCompile( comp, copy1prg, strlen(copy1prg), defines, NULL, "main", &copy1Size, &copy1Binary, logFunction ) == 0 )
    {
        assert( !"found error compiling write1" );
    }
    //    amuAsmDisassemble(copyBinary, logFunction);
    memcpy( copy1KernelAddressCPU, copy1Binary, copy1Size );

    //
    //  extract the symbols and constants from the binary
    //
    *copy1_constants = amuABIExtractConstants( copy1Binary );

    //
    //  cleanup and close the compiler
    //
    amuCompFreeBinary( comp, copy1Binary );
    amuCompCloseCompiler( comp );
          
    AMuint32 copyF4Size = 0;
    void* copyF4Binary = 0;

    comp = amuCompOpenCompiler();
    
char copyF4prg[] =
"    ps_3_0\n"
"    def c0, 0.5, 1, 2, 0\n"
"    def c1, -0.5, -1.5, -2.5, 0\n"
"    dcl vPos.xy\n"
"    dcl_2d s0\n"
"    mul r0.xy, vPos.yxzw, c0.x\n"
"    frc r1.xy, r0_abs.yxzw\n"
"    cmp r1.xy, vPos, r1, -r1\n"
"    add r1.xy, r1, r1\n"
"    mul r0.w, r1.y, r1.x\n"
"    add r1.xy, -r1, c0.y\n"
"    mad r0.w, r1.x, r1.y, r0.w\n"
"    mad r0.w, c0.z, r0.w, r1.x\n"
"    frc r2.xy, r0\n"
"    add r1.xyz, r0.w, c1\n"
"    add r0.xy, r0.yxzw, -r2.yxzw\n"
"    texld r0, r0, s0\n"
"    cmp r0.w, r1.z, r0.w, r0.z\n"
"    cmp r0.w, r1.y, r0.w, r0.y\n"
"    cmp oC0, r1.x, r0.w, r0.x\n"
;

    if ( amuCompCompile( comp, copyF4prg, strlen(copyF4prg), defines, NULL, "main", &copyF4Size, &copyF4Binary, logFunction ) == 0 )
    {
        assert( !"found error compiling write4" );
    }

    memcpy( copyF4KernelAddressCPU, copyF4Binary, copyF4Size );

    //
    //  extract the symbols and constants from the binary
    //
    *copyF4_constants = amuABIExtractConstants( copyF4Binary );

    //
    //  cleanup and close the compiler
    //
    amuCompFreeBinary( comp, copyF4Binary );
    amuCompCloseCompiler( comp );



    AMuint32 copy4FSize = 0;
    void* copy4FBinary = 0;

    comp = amuCompOpenCompiler();
    
char copy4Fprg[] =
   "    ps_3_0\n"
    "    def c63 .5,.5,.5,.5\n"
    "    dcl vPos.xy     \n"
    "    dcl_2d s0\n"
    "    add r0, vPos, c63\n"
    "    texld r1, r0, s0\n"
    "    mov oC0.xyzw, c63\n"
    "    end             \n"
    ;

/*"    ps_3_0\n"
"    def c0, 2, 0.5, 0, 0\n"
"    dcl vPos.xy\n"
"    dcl_2d s0\n"
"    mad r0.xy, c0.x, vPos.yxzw, c0.y\n"
"    frc r1.xy, r0\n"
"    add r0.xy, r0.yxzw, -r1.yxzw\n"
"    texld oC0, r0, s0\n"
;*/

    if ( amuCompCompile( comp, copy4Fprg, strlen(copy4Fprg), defines, NULL, "main", &copy4FSize, &copy4FBinary, logFunction ) == 0 )
    {
        assert( !"found error compiling write4" );
    }

    memcpy( copy4FKernelAddressCPU, copy4FBinary, copy4FSize );

    //
    //  extract the symbols and constants from the binary
    //
    *copy4F_constants = amuABIExtractConstants( copy4FBinary );

    //
    //  cleanup and close the compiler
    //
    amuCompFreeBinary( comp, copy4FBinary );
    amuCompCloseCompiler( comp );

    
#endif
  }
  ~GPUDevice() {
#ifdef USE_CTM
        amCloseManagedConnection( vm );
#else
        free(info.baseAddressCPU);
#endif
  }

};
extern GPUDevice * dev;// list of all numCard devices
void setUserConstant(GPUDevice* device, const AMUabiConstsInfo *compOutput, void* addressCPU, const char* name, const void* value, AMUabiDataType type );
void setLiteralConstants(GPUDevice* device, const AMUabiConstsInfo *compOutput, void* floatConstAddressCPU, void* intConstAddressCPU );

template<typename T> T* pointerTrans (T* inp, unsigned int cardNo) {
  if (cardNo==0) return inp;
  char * tmp=(char*)inp;
  char * baseAddressCPU=(char*)dev[0].info.baseAddressCPU;
  char * baseAddressCPUc=(char*)dev[0].info.baseAddressCPUc;
  if (tmp>=baseAddressCPU&&tmp<(baseAddressCPU+dev[0].info.arenaSizeSYS)) {
    return (T*)((char*)dev[cardNo].info.baseAddressCPU+(tmp-baseAddressCPU));
  }
  if (tmp>=baseAddressCPUc&&tmp<(baseAddressCPUc+dev[0].info.arenaSizeSYSc)) {
    return (T*)((char*)dev[cardNo].info.baseAddressCPUc+(tmp-baseAddressCPUc));
  }
  return NULL;// error not in card 0 addy
}
static AMuint32 addrTrans(AMuint32 input, unsigned int cardNo) {
  if (cardNo==0)return input;
  AMmanagedDeviceInfoRec i0=dev[0].info;
  AMmanagedDeviceInfoRec iX=dev[cardNo].info;
  if (input>=i0.baseAddressGPU&&input<=i0.baseAddressGPU+i0.arenaSizeGPU) {
    return iX.baseAddressGPU+(input-i0.baseAddressGPU);
  }
  if (input>=i0.baseAddressSYSc&&input<=i0.baseAddressSYSc+i0.arenaSizeSYSc) {
    return iX.baseAddressSYSc+(input-i0.baseAddressSYSc);
  }
  if (input>=i0.baseAddressSYS&&input<=i0.baseAddressSYS+i0.arenaSizeSYS) {
    return iX.baseAddressSYS+(input-i0.baseAddressSYS);
  }
  if (input>=i0.baseAddressGPUb&&input<=i0.baseAddressGPUb+i0.arenaSizeGPUb) {
    return iX.baseAddressGPUb+(input-i0.baseAddressGPUb);
  }
  return 0xffffffff;
}

static void *memcpyBroadcast(void*  dst, void * src, size_t size) {
  void * retval=NULL;
  for ( int cardNo=0;cardNo<numCards;++cardNo) {
    retval=memcpy(pointerTrans(dst,cardNo),src,size);
  }
  return retval;
}
static void *memsetBroadcast(void*  dst, unsigned int val, size_t size) {
  void * retval=NULL;
  for ( int cardNo=0;cardNo<numCards;++cardNo) {
    retval=memset(pointerTrans(dst,cardNo),val,size);
  }
  return retval;
}
extern AMuint32 dualSubmitCommandBuffer(AMmanagedDevice dev, AMuint32 addr, AMuint32 size);

extern AMuint32 dualCommandBufferConsumed(AMmanagedDevice dev, AMuint32 buf);
class DUALcbufPack
{
  AMUcbufPack ** cbufs;
  unsigned int i0, j0, i1, j1;//last domain set
  bool broadcast;
public:
    DUALcbufPack(unsigned int* cbuf, unsigned int size);
    ~DUALcbufPack(void);
public:
    void reset(void);
    unsigned int getCommandBufferSize(void);
    unsigned int appendInitPerfCounters(unsigned int flags);
    unsigned int appendStartPerfCounters(void);
    unsigned int appendStopPerfCounters(void);
    unsigned int appendReadPerfCounters(unsigned int addr);    
    unsigned int appendSetCondVal(unsigned int val);
    unsigned int appendSetDomainBroadcast(unsigned int i0, unsigned int j0, unsigned int i1, unsigned int j1);
    unsigned int appendSetDomainTiled(unsigned int i0, unsigned int j0, unsigned int i1, unsigned int j1);
    unsigned int appendStartProgram(void);
    unsigned int appendWaitForIdle(void);
    unsigned int appendSetInstFmt(unsigned int addr, unsigned int fmt, unsigned int tiling, unsigned int width);
    unsigned int appendSetInpFmt(unsigned int input, unsigned int addr, unsigned int fmt, unsigned int tiling, unsigned int width, unsigned int height);
    unsigned int appendSetOutFmt(unsigned int output, unsigned int addr, unsigned int fmt, unsigned int tiling, unsigned int width, unsigned int height);
    unsigned int appendSetCondOutFmt(unsigned int addr, unsigned int fmt, unsigned int tiling, unsigned int width, unsigned int height);
    unsigned int appendSetConstbFmt(unsigned int addr, unsigned int fmt, unsigned int tiling, unsigned int width);
   unsigned int appendSetConstfFmt(unsigned int addr, unsigned int fmt, unsigned int tiling, unsigned int width);
    unsigned int appendSetConstiFmt(unsigned int addr, unsigned int fmt, unsigned int tiling, unsigned int width);
    unsigned int appendInvInstCache(void);
    unsigned int appendInvConstfCache(void);
    unsigned int appendInvConstiCache(void);
    unsigned int appendInvConstbCache(void);
    unsigned int appendInvCondOutCache(void);
    unsigned int appendInvInpCache(void);
    unsigned int appendFlushOutCache(void);
    unsigned int appendFlushCondOutCache(void);
/* NOT YET IMPL for DUALGPU
    unsigned int appendSetOutMask(unsigned int c0, unsigned int c1, unsigned int c2, unsigned int c3);
    unsigned int appendSetCondOutMask(unsigned int w);
    unsigned int appendSetCondTest(unsigned int test);
    unsigned int appendSetCondLoc(unsigned int loc);
*/

};
DUALcbufPack* copy1(DUALcbufPack * cbp, GPUDevice* device,
                   unsigned int input,
                   unsigned int output,
                   unsigned int TriWidth, unsigned int TriHeight,
		    bool tiled, _AMUcbufFldFormat components, bool backcopy=false);


extern unsigned int gltilesize;
#endif
