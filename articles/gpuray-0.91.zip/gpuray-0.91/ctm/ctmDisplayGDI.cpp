/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * ctmDisplayGL.cpp --
 *
 *      XX
 */
#include "ctmDisplayGDI.h"

#include <windows.h>
#include <stdio.h>
#include <assert.h>

#include "../renderContextGDI.h"
#ifdef USE_BROOK
#include <brook/brook.hpp>
#endif

/*
 * CheckGL --
 *
 *      Checks for and reports and GL errors that have occurred.
 *
 * Results:
 *      void
 */

PixelDisplayerCtmGdi::PixelDisplayerCtmGdi( RenderContextGDI* inRenderContext )
{
   _renderContext = inRenderContext;

   _renderContext->bind();
}

void
PixelDisplayerCtmGdi::Display( int inWidth, int inHeight,
                               const PixelCTM* inPixels )
{
    HWND hWnd = (HWND)_renderContext->getWindowHandle();

    if(!hWnd)
        return;

    _renderContext->bind();

    PAINTSTRUCT ps;
    HDC hDC = BeginPaint( hWnd, &ps );
#ifdef USE_BROOK
    if (inPixels->stream)
	streamWrite(*inPixels->stream,inPixels->AGPmemory);
#endif
    if ( inWidth && inHeight && inPixels->AGPmemory )
    {
        BITMAPINFO bm;
        bm.bmiColors[ 0 ].rgbBlue = 0;
        bm.bmiColors[ 0 ].rgbGreen = 0;
        bm.bmiColors[ 0 ].rgbRed = 0;
        bm.bmiColors[ 0 ].rgbReserved = 0;

        bm.bmiHeader.biSize = sizeof( BITMAPINFOHEADER );
        bm.bmiHeader.biWidth = inWidth;
        bm.bmiHeader.biHeight = inHeight;
        bm.bmiHeader.biPlanes = 1;
        bm.bmiHeader.biBitCount = 32;
        bm.bmiHeader.biCompression = BI_RGB;
        bm.bmiHeader.biSizeImage = 0;
        bm.bmiHeader.biXPelsPerMeter = 0;
        bm.bmiHeader.biYPelsPerMeter = 0;
        bm.bmiHeader.biClrUsed = 0;
        bm.bmiHeader.biClrImportant = 0;

        int ret = SetDIBitsToDevice( hDC, 0 /* x */, 0 /* _y */, inWidth, inHeight, 0, 0, 0, inHeight, (void*)inPixels->AGPmemory, &bm, DIB_RGB_COLORS );
        assert( ret );
    }

    EndPaint( hWnd, &ps );

   _renderContext->swap();
}
