/*
 * kdtreeCTM.h --
 *
 *      k-D tree / axis-aligned bounding box tree acceleration structure.
 */

#ifndef __CELL_KDTREECTM_H__
#define __CELL_KDTREECTM_H__

#include <math.h>
extern "C" {
    //#include <libspe.h>
}

#include "../scene.h"
#include "../cpu/cpuTypes.h"
#include "../cpu/acceleratorCPU.h"

union CtmKdTreeNode
{
  struct
  {
    float primitiveCount_tag;
    float firstPrimitiveIndex;
    // float pad0, pad1;
  } leaf;
  struct
  {
     float leftChildIndex_splitAxis;
     float splitValue;
    //  float pad0, pad1;
  } split;
};
class KDTreeCTMCPU : public AcceleratorCPU
{
  struct CTMDataCPU *device;
public:
  KDTreeCTMCPU(const Scene& scene, const Opts& options);
  virtual ~KDTreeCTMCPU(void);
  uint32 getBatchGranularity();
  void IntersectRay(const RayCPU &ray, HitCPU *hit);
  void intersect(const RayCPU rays[],
                 uint32 numRays, HitCPU hits[]);
  void intersectPacket(const RayCPU rays[],
                       uint32 numRays, HitCPU hits[]);

  void intersectP(const RayCPU rays[],
                  uint32 numRays, HitCPU hits[]);
  void intersectPacketP(const RayCPU rays[],
                        uint32 numRays, HitCPU hits[]);

protected:
    unsigned int bytecount;
    unsigned int TriWidth;
    unsigned int TriHeight;
    float * triangles[3];
    unsigned int trianglesAGP[3];
    unsigned int kdtreeAGP;
    float * kdtree;
    unsigned int kdtreeWidth;

    unsigned int kdtreeHeight;
    bool _dotrace;
  unsigned int _offsetAlign;
  unsigned int _offsetRay;
  unsigned int _offsetTriangle;
  unsigned int _offsetKdtree;
  unsigned int _offsetTT;
  unsigned int _offsetUU;
  unsigned int _offsetVV;
  unsigned int _offsetID;

  enum { kMaximumThreadCount = 16 };
  enum { kAlignment = 128 };

  // number of SPE threads to launch
  // can range from 1-16 for our dual-processor
  // blades, but will scale best in the 1-8 range
  uint32 _threadCount;
    //speid_t _speThreadIDs[kMaximumThreadCount];

  // control for how many times to re-submit the same frame
  // (when testing throughput rather than end-to-end latency)
  uint32 _repeatFrameSubmitCount;
  F3 _rayOffset;
  F3 _bboxMin;
  F3 _bboxMax;
  F3 *_v0;//will go away with kdtree impl
  F3 *_v1;//will go away with kdtree impl
  F3 *_v2;//will go away with kdtree impl
  uint32 _nodeCount;
  CtmKdTreeNode* _nodes;
  uint32 _bruteForceTriCount;
  uint32 _triangleCount;
  uint32* _triangleIDs;
  float *_triangleDataA;
  float *_triangleDataB;
  float *_triangleDataC;
};

#endif
