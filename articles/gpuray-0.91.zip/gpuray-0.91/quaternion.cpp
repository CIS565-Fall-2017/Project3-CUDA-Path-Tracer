/*
 * quaternion.cpp --
 *
 *      Implementation of quaternion type
 */

#include "quaternion.h"


quaternion::quaternion()
   : x(0), y(0), z(0), w(1)
{
}

quaternion::quaternion( float inX, float inY, float inZ, float inW )
   : x(inX), y(inY), z(inZ), w(inW)
{
}

quaternion quaternion::identity()
{
   return quaternion( 0, 0, 0, 1 );
}

quaternion quaternion::fromAxisAngle( const Vec3f& inAxis, float inAngle )
{
   float angle = inAngle * 0.5f;
   float cosAngle = cosf( angle );
   float sinAngle = sinf( angle );

   // normalize the axis
   Vec3f axis = inAxis;
   float axisLengthSquared = axis.x*axis.x + axis.y*axis.y + axis.z*axis.z;
   float inverseAxisLength = 1.0f / sqrtf( axisLengthSquared );
   axis.x *= inverseAxisLength;
   axis.y *= inverseAxisLength;
   axis.z *= inverseAxisLength;
   
   quaternion result;

   result.x = sinAngle * axis.x;
   result.y = sinAngle * axis.y;
   result.z = sinAngle * axis.z;
   result.w = cosAngle;

   return result;
}

Vec3f quaternion::transformVector( const Vec3f& v ) const
{
   quaternion vector( v.x, v.y, v.z, 0 );

   quaternion forward = *this;
   quaternion backward = inverse( forward );
   quaternion transformed = forward * vector * backward;

   return Vec3f( transformed.x, transformed.y, transformed.z );
}

float magnitude( const quaternion& q )
{
   return sqrtf( magnitudeSquared( q ) );
}

float magnitudeSquared( const quaternion& q )
{
   return q.x*q.x + q.y*q.y + q.z*q.z + q.w*q.w;
}

quaternion normalize( const quaternion& q )
{
   return q / magnitude( q );
}

quaternion conjugate( const quaternion& q )
{
   return quaternion( -q.x, -q.y, -q.z, q.w );
}

quaternion inverse( const quaternion& q )
{
   return conjugate( q ) / magnitudeSquared( q );
}

quaternion operator*( float left, const quaternion& right )
{
   return quaternion( left*right.x, left*right.y, left*right.z, left*right.w );
}

quaternion operator*( const quaternion& left, float right )
{
   return right * left;
}

quaternion operator/( const quaternion& left, float right )
{
   return left * (1.0f / right);
}

quaternion operator*( const quaternion& left, const quaternion& right )
{
   quaternion result;

   result.x = left.w*right.x + left.x*right.w + left.y*right.z - left.z*right.y;
   result.y = left.w*right.y + left.y*right.w + left.z*right.x - left.x*right.z;
   result.z = left.w*right.z + left.z*right.w + left.x*right.y - left.y*right.x;
   result.w = left.w*right.w - left.x*right.x - left.y*right.y - left.z*right.z;

   return result;
}

quaternion& quaternion::operator*=( const quaternion& right )
{
   *this = (*this) * right;
   return *this;
}
