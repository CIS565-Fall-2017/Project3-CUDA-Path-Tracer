/*
 * voxelgrid.cpp --
 *
 *      Implementation of voxel grid accelerator
 *      and associated raytracing implementation.
 */
#include "voxelgrid.h"

#include "../timer.h"
#include "../log.h"
#include "brookTracer.h"
#include "voxelkernels.hpp"

/*
 * The following static arrays are only used as temporaries when
 * initializing stream contents.
 *
 * However, they've visible at global scope so that the CPU side
 * verification routines can also use them.
 */

static Vertex vertexDat[4096 * 100 * 4];
static GridTrilistOffset listOffsetDat[4096 * 100 * 4];
static GridTrilist trilistDat[4096 * 100 * 4];


/*
 * DensestVoxelSize --
 *
 *      Helper routine that computes the number of triangles in the most
 *      densely packed voxel in the grid.
 *
 * Returns:
 *      Maximum number of triangles in any grid cell.
 */

static const int kTriangleStreamWidth = 1024;
static const int kIndexStreamWidth = 1024;
static const int kVoxelStreamX = 1024;

static inline int divideRoundUp( int n, int d )
{
	return (n + (d-1)) / d;
}

static int
DensestVoxelSize(const Grid& grid)
{
   int numVoxels = grid.dim.x * grid.dim.y * grid.dim.z;
   int maxTris = 0, ii, last;

   for (last = grid.trilistOffset[0], ii=1; ii < numVoxels; ii++) {
      int length;

      /* Subtract off 1 for the space occupied by the sentinel */
      length = grid.trilistOffset[ii] - last - 1;
      last = grid.trilistOffset[ii];
      if (length > maxTris) {
      maxTris = length;
      }
   }
   /* Don't forget the triangles in the final voxel! */
   if (grid.trilistSize - last - 1 > maxTris) {
      maxTris = grid.trilistSize - last - 1;
   }
   return maxTris;
}


/*
 * CPUFindInitialPositions --
 *
 *      Debugging / Helper function.  It reads back the rays and computes
 *      the time and voxel where they should hit the grid.
 *
 * Returns:
 *      void.
 */

static void
CPUFindInitialPositions(brook::stream rayStream,
                        const Grid& grid, int imageW, int imageH)
{
   Ray *rays;
   int ii;

   rays = new Ray[imageW * imageH];
   rayStream.write(rays);

   for (ii = 0; ii < imageW * imageH; ii++) {
      float3 t1, t2, tMax, tMin, curPos, voxNo;
      float tNear, tFar, tHit;

      t1 = float3((grid.min.x - rays[ii].o.x) / rays[ii].d.x,
                  (grid.min.y - rays[ii].o.y) / rays[ii].d.y,
                  (grid.min.z - rays[ii].o.z) / rays[ii].d.z);
      t2 = float3((grid.max.x - rays[ii].o.x) / rays[ii].d.x,
                  (grid.max.y - rays[ii].o.y) / rays[ii].d.y,
                  (grid.max.z - rays[ii].o.z) / rays[ii].d.z);

      tMax = float3(max(t1.x, t2.x), max(t1.y, t2.y), max(t1.z, t2.z));
      tMin = float3(min(t1.x, t2.x), min(t1.y, t2.y), min(t1.z, t2.z));

      tNear = max(tMin.x, max(tMin.y, tMin.z));
      tFar = min(tMax.x, min(tMax.y, tMax.z));

      tHit = (tNear > tFar || tFar < 0) ? -1 : (tNear < 0) ? 0 : tNear;

      curPos = float3(rays[ii].o.x + rays[ii].d.x * tHit,
                      rays[ii].o.y + rays[ii].d.y * tHit,
                      rays[ii].o.z + rays[ii].d.z * tHit);
      voxNo = float3((curPos.x - grid.min.x) / grid.vsize.x,
                     (curPos.y - grid.min.y) / grid.vsize.y,
                     (curPos.z - grid.min.z) / grid.vsize.z);


      PRINT(("tHit[%d]: %.2f (tNear %.2f, tFar %.2f) voxNo(%f, %f, %f)\n",
             ii, tHit, tNear, tFar, voxNo.x, voxNo.y, voxNo.z));
   }
   delete [] rays;
}


/*
 * CPUTryHitTriangle --
 *
 *      Debugging / Helper function.  Determines whether the given ray hits
 *      any triangles in the current voxel.
 *
 * Returns:
 *      void.
 */

static void
CPUTryHitTriangle(const Ray& ray,
                  const TraversalDataDyn& dyn, const Grid& grid)
{
   GridTrilistOffset triListPos;
   GridTrilist triNum;
   Vertex *vertex;
   int offsetAddr;

   offsetAddr = (int) (dyn.voxNo.z +
                       grid.dim.z * (dyn.voxNo.y + dyn.voxNo.x * grid.dim.y));
   triListPos = listOffsetDat[offsetAddr++];

   while (triListPos.x >= 0) {
      PRINT(("Intersecting index %.2f (%.2f, %.2f).\n",
             triListPos.x + kIndexStreamWidth * triListPos.y,
             triListPos.x, triListPos.y));

      triNum = trilistDat[(int) (triListPos.x + kIndexStreamWidth * triListPos.y)];
      vertex = &vertexDat[(int) (triNum.x + kTriangleStreamWidth * triNum.y)];

      /*
       * XXX We don't actually do the intersection yet.  It should go right
       * here before incrementing offsetAddr and triListPos...
       */

      triListPos = listOffsetDat[offsetAddr++];
   }

   return;
}


/*
 * CPUTraverseRay --
 *
 *      Debugging / Helper function.  Takes a ray and walks it through the
 *      grid, printing its locations.
 *
 * Returns:
 *      void.
 */

static void
CPUTraverseRay(const Ray& ray, const TraversalDataStatic& datStat,
               const TraversalDataDyn& datDyn, const Grid& grid)
{
   TraversalDataDyn cur = datDyn;

   PRINT(("Ray is (%5.2f, %5.2f, %5.2f) --> (%5.2f, %5.2f, %5.2f)\n",
          ray.o.x, ray.o.y, ray.o.z, ray.d.x, ray.d.y, ray.d.z));
   PRINT(("tDelta: (%.2f, %.2f, %.2f) step: (%.f, %.f, %.f)\n",
          datStat.tDelta.x, datStat.tDelta.y, datStat.tDelta.z,
          datStat.step.x, datStat.step.y, datStat.step.z));
   PRINT(("Starting in voxel %.f %.f %.f\t(tMax: %.2f %.2f %.2f)\n",
          cur.voxNo.x, cur.voxNo.y, cur.voxNo.z,
          cur.tMax.x, cur.tMax.y, cur.tMax.z));

   while (cur.voxNo.x <= grid.dim.x &&
          cur.voxNo.y <= grid.dim.y && cur.voxNo.z <= grid.dim.z &&
          cur.voxNo.x >= 0 && cur.voxNo.y >= 0 && cur.voxNo.z >= 0) {
      float minVal;

      minVal = min(cur.tMax.x, min(cur.tMax.y, cur.tMax.z));
      if (minVal == cur.tMax.x) {
         cur.voxNo.x += datStat.step.x;
         cur.tMax.x += datStat.tDelta.x;
      } else if (minVal == cur.tMax.y) {
         cur.voxNo.y += datStat.step.y;
         cur.tMax.y += datStat.tDelta.y;
      } else {
         cur.voxNo.z += datStat.step.z;
         cur.tMax.z += datStat.tDelta.z;
      }

      printf("Moving to voxel %.f %.f %.f\t(tMax: %.2f %.2f %.2f)\n",
             cur.voxNo.x, cur.voxNo.y, cur.voxNo.z,
             cur.tMax.x, cur.tMax.y, cur.tMax.z);

      CPUTryHitTriangle(ray, cur, grid);
   }
}


/*
 * VoxelGridAccelerator::DumpLiveRays --
 *
 *      Trivial helper to print out the ray states and, if provided, the
 *      static and dynamic traversal data.
 *
 * Returns:
 *     void
 */

void
VoxelGridAccelerator::DumpLiveRays(RayState *states,
                                   brook::stream *travDatStat,
                                   brook::stream *travDatDyn,
                                   int imageW, int imageH) const
{
   static bool *deadRays;
   TraversalDataDyn *dyn = NULL;
   TraversalDataStatic *travStat = NULL;
   int jj;

   if (deadRays == NULL) {
      deadRays = new bool[imageW * imageH];
      memset(deadRays, 0, imageW * imageH * sizeof *deadRays);
   }

   if (travDatDyn != NULL) {
      dyn = new TraversalDataDyn[imageW * imageH];
      travDatDyn->write(dyn);
   }
   if (travDatStat != NULL) {
      travStat = new TraversalDataStatic[imageW * imageH];
      travDatStat->write(travStat);
   }

   for (jj = 0; jj < imageW * imageH; jj++) {
      if (states[jj].z == 0.0f) {
         if (states[jj].w > 0) {
            LOG(("Ray[%d] is traversing.\n", jj));
         } else {
            LOG(("Ray[%d] is intersecting index %.2f (%.2f, %.2f).\n",
                 jj,
                 states[jj].x + kIndexStreamWidth * states[jj].y,
                 states[jj].x, states[jj].y));
         }
         if (travStat) {
            LOG(("[%d] tDelta: (%.2f, %.2f, %.2f) step: (%.f, %.f, %.f)\n",
                jj, travStat[jj].tDelta.x,
                travStat[jj].tDelta.y, travStat[jj].tDelta.z,
                travStat[jj].step.x, travStat[jj].step.y,
                travStat[jj].step.z));
         }
         if (dyn) {
            LOG(("[%d] tMax: (%.2f, %.2f, %.2f) voxNo: (%.1f, %.1f, %.1f),"
                     " voxToUse: (%.1f, %.1f, %.1f)\n",
                jj, dyn[jj].tMax.x, dyn[jj].tMax.y, dyn[jj].tMax.z,
                dyn[jj].voxNo.x, dyn[jj].voxNo.y,
                dyn[jj].voxNo.z, dyn[jj].voxToUse.x,
                dyn[jj].voxToUse.y, dyn[jj].voxToUse.z));
         }
      } else {
         if (!deadRays[jj]) {
            LOG(("Ray[%d] is %s.\n", jj, states[jj].z < 0 ? "dead" : "shading"));
            deadRays[jj] = true;
         }
      }
   }
   delete [] dyn;
   delete [] travStat;
}

/*
* VoxelGridAccelerator::initialize --
*
*     Initialize a voxel grid acceleration structure
*     from an input grid and triangle data.
*
* Returns:
*     void
*/

void
VoxelGridAccelerator::initialize( const AcceleratorOptions& inOptions )
{
   using namespace brook;

   const Grid& grid = inOptions.scene->getGrid();

   float3 gridDim((float) grid.dim.x, (float) grid.dim.y, (float) grid.dim.z);
   int numVoxels = grid.dim.x * grid.dim.y * grid.dim.z;
   int ii;

   _grid = grid;
   _gridDim = gridDim;

   int indexStreamW = kIndexStreamWidth;
   int indexStreamH = divideRoundUp( grid.trilistSize, indexStreamW );

   int vertexStreamW = inOptions.vertexStreamX;
   int vertexStreamH = inOptions.vertexStreamY;

   _voxelStreamX = kVoxelStreamX;
   _voxelStreamY = divideRoundUp( numVoxels, _voxelStreamX );
   _voxelStreamConstant.x = (float) _voxelStreamX;
   _voxelStreamConstant.y = 1.0f / (float) _voxelStreamX;

   // Vertex info (3 float3's) for a triangle
   _vertexPositionStream = inOptions.positionStream;

   // trilist is index list of triangles present in each grid voxel.
   // lists for each voxel are dilimited by a negative index value
   _trilist = stream::create<GridTrilist>( indexStreamH, indexStreamW );

   // starting position of each voxel's triangle list in trilist
   // stream is stored here
   _listOffset = stream::create<GridTrilistOffset>( _voxelStreamY, _voxelStreamX );

   assert(_voxelStreamX*_voxelStreamY <= sizeof listOffsetDat / sizeof listOffsetDat[0]);
   for (ii = 0; ii < numVoxels; ii++) {
      int offset = grid.trilistOffset[ii];
      float2 triangleIndexIndex;
      if (offset < 0) {
         triangleIndexIndex.x = triangleIndexIndex.y = -1;
      } else {
         triangleIndexIndex.x = (float) (offset % indexStreamW);
         triangleIndexIndex.y = (float) (offset / indexStreamW);
      }
      listOffsetDat[ii] = triangleIndexIndex;
   }
   // pad out to the stream size we allocated
   for (; ii < _voxelStreamX*_voxelStreamY; ii++) {
      float2 triangleIndexIndex;
      triangleIndexIndex.x = triangleIndexIndex.y = -1;
      listOffsetDat[ii] = triangleIndexIndex;
   }
   _listOffset.read(listOffsetDat);

   assert(grid.trilistSize <= sizeof trilistDat / sizeof trilistDat[0]);
   for (ii = 0; ii < grid.trilistSize; ii++) {
      int offset = grid.trilist[ii];
      float2 triangleIndex;
      if (offset < 0) {
         triangleIndex.x = triangleIndex.y = -1;
      } else {
         triangleIndex.x = (float) (offset % vertexStreamW);
         triangleIndex.y = (float) (offset / vertexStreamW);
      }
      trilistDat[ii] = triangleIndex;
   }
   _trilist.read(trilistDat);

   /*
    * In the worst case we step through the maximal number of voxels
    * (which is the sum of the dimensions) and each cell is also the most
    * densely filled cell.
    */

   _maxIters = DensestVoxelSize(grid) * (grid.dim.x + grid.dim.y + grid.dim.z);
}

/*
* VoxelGridAccelerator::intersect --
*
*     Intersects the rays given in rayStream (with elements
*     of type Ray) against the triangles stored in this
*     accelerator, storing the results in the hitStream
*     (with elements of type Hit).
*
* Returns:
*     A stream of Hits which detail the first hit
*     if any for each input ray.
*/

void
VoxelGridAccelerator::intersect(brook::stream& rayStream,
                                brook::stream& hitStream ) const
{
   using namespace brook;

   int imageW, imageH;

   int lastLive, ii, aa, bb;
   float now, t, iterTime, iterTimeSquare;
   float cpuTot, queryTot;
   RayState *states;

   imageW = rayStream->getExtents()[1];
   imageH = rayStream->getExtents()[0];

   stream rays = rayStream;
   stream travDatStatic = stream::create<TraversalDataStatic>(imageH, imageW);

   /*
   * The lack of read-modify-write means we have to ping pong writing
   * between two copies of our dynamic state, which is a big waste of space.
   */
   stream rayStates[] = {
      stream::create<RayState>(imageH, imageW),
      stream::create<RayState>(imageH, imageW),
   };

   stream hits[] = {
      stream::create<Hit>(imageH, imageW),
      stream::create<Hit>(imageH, imageW),
   };

   stream candidateHits = stream::create<Hit>(imageH, imageW);
   stream travDatDyn[] = {
      stream::create<TraversalDataDyn>(imageH, imageW),
      stream::create<TraversalDataDyn>(imageH, imageW),
   };

   /*
    * The unused stream is a placeholder output for the occlusion driven
    * fast reduction.
    *
    * XXX Could this even be fixed point to reduce bandwidth still further?
    */
   stream unused = stream::create<float4>(imageH, imageW);
   write_query query = write_query::create();

   //unused.setAccess(false, true);
   Timer_Reset();

   /*
   * Set .x (which is ray t) to HUGE so that any true hits will have a lower
   * t (i.e. happen closer to the eye position).
   */
   krnVoxel_Float4Set(float4(999999, -1, -1, -1), hits[0]);

   /*
   * The actual ray tracing loop:
   */

   PRINT(("   Initializing traversal data and ray states\n"));
   krnVoxel_SetupTraversal(rays, toFloat3( _grid.min ), toFloat3( _grid.max ), toFloat3( _grid.vsize ), _gridDim,
                           travDatDyn[0], travDatStatic, rayStates[0]);

   PRINT(("   Traversing and intersecting (up to %d iterations)\n", _maxIters));
   states = new RayState [imageW * imageH];
   lastLive = imageW * imageH;

#if 0
   Ray *raysCPU;
   TraversalDataDyn *travDyn;
   TraversalDataStatic *travStat;

   raysCPU = new Ray[imageW * imageH];
   rays.write(raysCPU);
   travDyn = new TraversalDataDyn[imageW * imageH];
   travDatDyn[0].write(travDyn);
   travStat = new TraversalDataStatic[imageW * imageH];
   travDatStatic.write(travStat);

   CPUTraverseRay(raysCPU[53], travStat[53], travDyn[53], _grid);
#endif
#if 0
   rayStates[0].write(states);
   LOG(("Initial ray state:\n"));
   //CPUFindInitialPositions(rays, _grid, imageW, imageH);
   DumpLiveRays(states, &travDatStatic, &travDatDyn[0], imageW, imageH);
#endif

   PRINT(("   %6d Live rays.", lastLive));
   iterTime = iterTimeSquare = 0;
   now = Timer_GetMS();
   queryTot = cpuTot = 0;
   for (aa = 0, bb = 1, ii = 0; ii < _maxIters; ii++) {
      int jj, live, qLive;
      float cpuT, queryT;

      t = Timer_GetMS();
      krnVoxel_TraverseVoxel(travDatStatic, travDatDyn[aa], rayStates[0],
                             _listOffset, _gridDim, travDatDyn[bb],
                             rayStates[1], _voxelStreamConstant );

#if 0
      LOG(("\nAfter Traversal %d:\n", ii));
      rayStates[1].write(states);
      DumpLiveRays(states, NULL, NULL, imageW, imageH);
#endif

      krnVoxel_Intersect(rays, _vertexPositionStream,
                         toFloat3(_grid.min), toFloat3(_grid.vsize),
                         hits[aa], travDatDyn[bb], rayStates[1], _trilist,
                         hits[bb], rayStates[0]);
      aa = bb;
      bb = 1 - bb;

      /*
       * Early termination: determine how many rays are actually still live
       * and bail when all have either left the grid or hit something.
       */

      cpuT = Timer_GetMS();
      rayStates[0].write(states);
      for (live = 0, jj = 0; jj < imageW * imageH; jj++) {
         if (states[jj].z == 0.0f) {
            live++;
         }
      }
      cpuTot += Timer_GetMS() - cpuT;

      if (live != lastLive) {
#ifndef SILENT
         printf("\r   %6d Live rays.", live);
         LOG(("\n   %6d Live rays.", live));
#endif
         lastLive = live;

         if (live == 0) break;
      }

      queryT = Timer_GetMS();
      query.begin();
      krnVoxel_FastLiveCount(rayStates[0], unused);
      query.end();
      qLive = query.count();
      queryTot += Timer_GetMS() - queryT;

      if (live != qLive) {
         PRINT(("\nQuery found %d live rays instead of %d!\n", qLive, live));
         //assert(false);
      }

#if 0
      LOG(("\nAfter Intersection %d:\n", ii));
      DumpLiveRays(states, NULL, &travDatDyn[aa], imageW, imageH);
#endif

      if (ii + 1 == _maxIters && live > 0) {
         PRINT(("\n%d Bogus live rays in interation %d!\n", live, ii));
         DumpLiveRays(states, NULL, &travDatDyn[aa], imageW, imageH);
      }

      t = Timer_GetMS() - t;
      iterTime += t; iterTimeSquare += t * t;
   }
   t = Timer_GetMS();
   delete [] states;
   PRINT(("\n   Finished in %d iterations: "
          "%3.2f secs, %3.2f msecs mean, %3.2f msecs std. dev.\n",
          ii, (t - now) / 1000.0f, iterTime / ii,
          sqrt(iterTimeSquare) / ii));
   PRINT(("   CPU counting: %5.2f msecs avg, Query: %5.2f msecs avg\n",
          cpuTot / ii, queryTot / ii));
   now = t;

   // put the result data into the buffer provided
   hitStream = hits[aa];
}


/*
 * VoxelGridAccelerator::timeKernels --
 *
 *      Very simple timings for the core voxelgrid kernels.
 *
 * Returns:
 *      void
 */

void
VoxelGridAccelerator::timeKernels(brook::stream& rayStream) const
{
   using namespace brook;

   static const int numPasses = 500;
   float tTrav, tIsect;
   int imageW = rayStream->getExtents()[1];
   int imageH = rayStream->getExtents()[0];
   int i, aa, bb;

   stream travDatStatic = stream::create<TraversalDataStatic>(imageH, imageW);
   stream rayStates[] = {
      stream::create<RayState>(imageH, imageW),
      stream::create<RayState>(imageH, imageW),
   };
   stream hits[] = {
      stream::create<Hit>(imageH, imageW),
      stream::create<Hit>(imageH, imageW),
   };
   stream travDatDyn[] = {
      stream::create<TraversalDataDyn>(imageH, imageW),
      stream::create<TraversalDataDyn>(imageH, imageW),
   };
   write_query timingQuery = write_query::create();

   Timer_Reset();

   krnVoxel_Float4Set(float4(999999, -1, -1, -1), hits[0]);
   krnVoxel_SetupTraversal(rayStream, toFloat3(_grid.min), toFloat3(_grid.max), toFloat3(_grid.vsize), _gridDim,
                           travDatDyn[0], travDatStatic, rayStates[0]);

   timingQuery.begin();
   krnVoxel_TraverseVoxel(travDatStatic, travDatDyn[0],
                          rayStates[0], _listOffset, _gridDim, travDatDyn[1],
                          rayStates[1], _voxelStreamConstant);
   timingQuery.end();
   timingQuery.wait();

   timingQuery.begin();
   tTrav = Timer_GetMS();
   for (i = 0; i < numPasses; i++) {
      krnVoxel_TraverseVoxel(travDatStatic, travDatDyn[0],
                             rayStates[0], _listOffset, _gridDim, travDatDyn[1],
                             rayStates[1], _voxelStreamConstant);
   }
   timingQuery.end();
   timingQuery.wait();
   tTrav = Timer_GetMS() - tTrav;

   for (i = 0, aa = 0, bb = 1; i < numPasses; i++) {
      krnVoxel_TraverseVoxel(travDatStatic, travDatDyn[aa],
                             rayStates[aa], _listOffset, _gridDim,
                             travDatDyn[bb],
                             rayStates[bb], _voxelStreamConstant);
      aa = bb;
      bb = 1 - bb;
   }
   timingQuery.begin();
   krnVoxel_Intersect(rayStream, _vertexPositionStream,
                      toFloat3(_grid.min), toFloat3(_grid.vsize),
                      hits[0], travDatDyn[1], rayStates[1], _trilist,
                      hits[1], rayStates[0]);
   timingQuery.end();
   timingQuery.wait();

   timingQuery.begin();
   tIsect = Timer_GetMS();
   for (i = 0; i < numPasses; i++) {
      krnVoxel_Intersect(rayStream, _vertexPositionStream,
                         toFloat3(_grid.min), toFloat3(_grid.vsize),
                         hits[0], travDatDyn[1], rayStates[1], _trilist,
                         hits[1], rayStates[0]);
   }
   timingQuery.end();
   timingQuery.wait();
   tIsect = Timer_GetMS() - tIsect;

   printf("\n#vox# # passes: %d, fragments per pass: %d\n",
          numPasses, imageH * imageW);
   printf("#vox# Traverse time: %fms, Intersect time: %fms\n",
          tTrav, tIsect);
   printf("#vox# Traversal GB/s: %f, Intersect GB/s: %f\n\n",
          (float) numPasses / tTrav * imageH * imageW * 42 * 4 *
                  1000.0 / 1024.0 / 1024.0 / 1024.0,
          (float) numPasses / tIsect * imageH * imageW * 44 * 4 *
                  1000.0 / 1024.0 / 1024.0 / 1024.0);
}
