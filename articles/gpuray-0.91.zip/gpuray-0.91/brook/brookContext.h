/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * brookContext.h --
 *
 *      XXX
 */

#ifndef __BROOK_BROOKCONTEXT_H__
#define __BROOK_BROOKCONTEXT_H__

#include <brook/brook.hpp>

class IRenderSystem;
class IRenderContext;

class BrookContext {
public:
   BrookContext( IRenderSystem* inSystem );
   BrookContext( IRenderContext* inContext );
};

#endif
