/*
 * simpleshader.h --
 *
 *      Shader that draws the scene with unshadowed diffuse lighting
 */

#ifndef __SIMPLESHADER_H__
#define __SIMPLESHADER_H__

#include <brook/brook.hpp>
#include "../fileIO/fileIO.h"
#include "shader.h"

class SimpleShader : public Shader
{
public:
   void shade(brook::stream& inputPixelStream,
              brook::stream& shadingHitStream,
              const float3& lightPosition,
              const float3& attenConsts,
              const float3& diffColor,
              //brook::stream& specularColor,
              //brook::stream& specularExp, 
              const float3& eyePos,
              brook::stream& pixelStream) const;
};

#endif
