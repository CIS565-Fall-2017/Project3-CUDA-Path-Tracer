/*
* bvh.h --
*
*
*/

#ifndef __BVH_H__
#define __BVH_H__

#include <brook/brook.hpp>

#include "accelerator.h"
#include "../fileIO/fileIO.h"
#include "../common/commonTypes.h"

class BVNode;

struct BVSplitStreamItem {
   Vec3f bboxMin;
   Vec3f bboxMax;
   Vec2f successIndex;
   Vec2f failureIndex;
};

struct BVLeafStreamItem {
   Vec2f firstTriangleIndex;
   float triangleCount;
   Vec2f successorIndex;
};

struct BVTriangleStreamItem {
   Vec3f vertices[3];
};

struct BVRayStreamItem {
   Vec3f origin;
   Vec3f direction;
};

struct BVTraversalStreamItem {
   Vec2f nodeIndex;
   float tmin;
   float tmax;
};

struct BVIntersectStreamItem {
   float2 bestHitTriangle;
   float triangleCount;
   float unused;
};

class BVTreeAccelerator :
   public Accelerator
{
public:
   BVTreeAccelerator();

   void
   initialize( const AcceleratorOptions& inOptions );

   void
   intersect( brook::stream& rayStream, brook::stream& hitStream ) const;

   void
   timeKernels( brook::stream& rayStream ) const;

protected:
   Vec2f BVTreeAccelerator::addNode( BVNode* inNode, const Vec2f& inSuccessorID,
      std::vector<BVTriangleStreamItem>& ioTriangles,
      std::vector<float2>& ioTriangleRemaps,
      std::vector<BVSplitStreamItem>& ioSplits,
      std::vector<BVLeafStreamItem>& ioLeaves );
   void createStateStreams( const brook::stream& inExampleStream ) const;
   void allocateStateStreams() const;
   void debugState() const;

   Vec2f _rootNodeIndex;

   int _vertexStreamX;

   int _triangleStreamX, _triangleStreamY;
   brook::stream _triangleStream;
   brook::stream _triangleRemapStream;

   int _splitStreamX, _splitStreamY;
   brook::stream _splitStream;

   int _leafStreamX, _leafStreamY;
   brook::stream _leafStream;

   mutable int _stateStreamX, _stateStreamY;
   mutable brook::stream _traversalStream;
   mutable brook::stream _intersectStream;

   mutable brook::stream _rayStream;
   mutable brook::stream _hitStream;

   mutable brook::write_mask _mask;
   mutable brook::stream _maskStream;
   mutable brook::write_query _query;
};

#endif
