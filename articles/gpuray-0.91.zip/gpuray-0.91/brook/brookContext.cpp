/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * brookContext.cpp --
 *
 *      XXX
 */
#include "brookContext.h"

#include "../renderContext.h"

BrookContext::BrookContext( IRenderSystem* inSystem )
{
   brook::initialize( inSystem->getRenderSystemID() );
}

BrookContext::BrookContext( IRenderContext* inContext )
{
   brook::initialize(
      inContext->getRenderSystem()->getRenderSystemID(),
      inContext->getContextHandle() );
}
