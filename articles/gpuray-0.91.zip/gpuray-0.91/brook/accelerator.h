/*
 * accelerator.h --
 *
 *      Abstract class for wrapping whatever acceleration structure is used
 *      for tracing the rays through the scene and determining which
 *      triangles to intersect.
 */

#ifndef ACCELERATOR_H
#define ACCELERATOR_H

#include <brook/brook.hpp>
#include "../scene.h"

class AcceleratorOptions
{
public:
   const Opts *opts;
   const Scene *scene;
   int vertexStreamX, vertexStreamY;
   brook::stream positionStream;
};

class Accelerator
{
public:
   virtual void initialize( const AcceleratorOptions& inOptions ) = 0;

   virtual void intersect(brook::stream& rayStream,
                          brook::stream& hitStream) const = 0;
   virtual void timeKernels(brook::stream& rayStream) const = 0;
};

#endif
