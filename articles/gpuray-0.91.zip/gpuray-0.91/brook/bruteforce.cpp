/*
 * bruteforce.cpp --
 *
 *      Implementation of brute force
 *      "accelerator" for ray-triangle tests.
 */
#include "bruteforce.h"

#include "../timer.h"
#include "../log.h"
#include "bruteforcekernels.hpp"

/*
* BruteForceAccelerator::initialize --
*
*     Initialize a brute force accelerator
*     with input triangle data.
*
* Returns:
*     void
*/

void
BruteForceAccelerator::initialize( const AcceleratorOptions& inOptions )
{
   float3* triv0 = (float3*) inOptions.scene->vertices(0);
   float3* triv1 = (float3*) inOptions.scene->vertices(1);
   float3* triv2 = (float3*) inOptions.scene->vertices(2);

   int ii;

   _triangleCount = inOptions.scene->nTris();
   _vertexStreamX = inOptions.vertexStreamX;

   _v0 = new float3[ _triangleCount ];
   _v1 = new float3[ _triangleCount ];
   _v2 = new float3[ _triangleCount ];

   for( ii = 0; ii < _triangleCount; ii++ )
   {
      _v0[ ii ] = triv0[ii];
      _v1[ ii ] = triv1[ii];
      _v2[ ii ] = triv2[ii];
   }
}


/*
 * BruteForceAccelerator::intersect --
 *
 *     Intersects the rays given in rayStream (with elements
 *     of type Ray) against the triangles stored in this
 *     accelerator, storing the results in the hitStream
 *     (with elements of type Hit).
 *
 * Returns:
 *     A stream of Hits which detail the first hit
 *     if any for each input ray.
 */

void
BruteForceAccelerator::intersect(brook::stream& rayStream,
                                 brook::stream& hitStream) const
{
   int percent;
   int ii;
   int imageW = rayStream->getExtents()[1];
   int imageH = rayStream->getExtents()[0];

   static brook::write_query timingQuery = brook::write_query::create();


   /*
    *	This code assumes that we can read-modify-write using the
    * hitStream stream. Since the intersection kernel has
    * only a single output, I think that this is safe.
    */

   float startTime = Timer_GetMS();
   timingQuery.begin();

   krnBrute_InitializeHits( hitStream );

   PRINT(("   %6d Triangles left", _triangleCount));
   percent = _triangleCount / 100;
   if( percent == 0 )
      percent = 1;
   float startIntersectTime = Timer_GetMS();
   for( ii = 0; ii < _triangleCount; ii++ ) {
      krnBrute_IntersectTriangle(rayStream, hitStream,
                                 _v0[ii], _v1[ii], _v2[ii],
                                 (float) ii, hitStream);

#ifndef SILENT
      if (ii % percent == 0) {
         printf("\r   %6d Triangles left", _triangleCount - ii);
         LOG(("\n   %6d Triangles left", _triangleCount - ii));
      }
#endif
   }
   timingQuery.end();
   timingQuery.wait();
   float endTime = Timer_GetMS();
   PRINT(("\r   %6d Triangles left\n", _triangleCount - ii));

   float totalTime = (endTime - startTime);
   float totalIntersectTime = (endTime - startTime);
   int intersectIterations = ii;
   int intersectItems = intersectIterations*imageW*imageH;

   PRINT(("\n#brute# intersect iterations: %d\n", intersectIterations));
   PRINT(("#brute# intersect items: %d\n", intersectItems));
   PRINT(("#brute# time: %fms\n", totalTime));
   PRINT(("#brute# intersect time: %fms (%fms/iteration, %fns/item)\n",
          totalIntersectTime, totalIntersectTime/intersectIterations,
          1000*1000*totalIntersectTime/intersectItems));
}



/*
 * BruteForceAccelerator::timeKernels --
 *
 *      Simple timing of the bruteforce kernel.
 *
 * Returns:
 *      void
 */

void
BruteForceAccelerator::timeKernels(brook::stream& rayStream) const
{
   int imageW = rayStream->getExtents()[1];
   int imageH = rayStream->getExtents()[0];
   float t;
   int ii;

   brook::stream hitStream = brook::stream::create<Hit>(imageH, imageW);
   brook::write_query timingQuery = brook::write_query::create();

   Timer_Reset();
   krnBrute_InitializeHits(hitStream);
   timingQuery.begin();
   krnBrute_IntersectTriangle(rayStream, hitStream, _v0[0], _v1[0], _v2[0],
                              (float) 0, hitStream);
   timingQuery.end();
   timingQuery.wait();

   timingQuery.begin();
   t = Timer_GetMS();
   for( ii = 0; ii < _triangleCount; ii++ ) {
      krnBrute_IntersectTriangle(rayStream, hitStream,
                                 _v0[ii], _v1[ii], _v2[ii],
                                 (float) ii, hitStream);
   }
   timingQuery.end();
   timingQuery.wait();
   t = Timer_GetMS() - t;

   printf("#brute# # passes: %d, fragments per pass: %d\n",
          ii, imageW * imageH);
   printf("#brute# Intersect time: %fms\n", t);
   printf("#brute# Intersect GB/sec: %f\n\n",
          (float) ii / t * imageH * imageW * 16 * 4 *
                  1000.0 / 1024.0 / 1024.0 / 1024.0);
}

