/*
 * voxelgrid_conditional.h --
 *
 */

#ifndef __VOXELGRIDCONDITIONAL_H__
#define __VOXELGRIDCONDITIONAL_H__

#include <brook/brook.hpp>

#include "voxelgrid.h"


class VoxelGridConditionalAccelerator :
   public VoxelGridAccelerator
{
public:
   VoxelGridConditionalAccelerator();

   void intersect(brook::stream& rayStream, brook::stream& hitStream) const;

protected:
   void createRayStreams( const brook::stream& inRayStream ) const;

   mutable int _rayStreamX, _rayStreamY;
   mutable brook::stream _travDatStatic;
   mutable brook::stream _rayStates;
   mutable brook::stream _maskStream;
   mutable brook::stream _candidateHits;
   mutable brook::stream _travDatDyn;

   enum{ kQueryCount = 1 };
   mutable brook::write_mask _mask;
   mutable brook::write_query _queries[kQueryCount];
};

#endif
