/*
 * buildbvh.h --
 *
 */

#ifndef __BUILDBVH_H__
#define __BUILDBVH_H__

#include <brook/brook.hpp>
#include "../common/commonTypes.h"

struct BVTreeOptions {
   BVTreeOptions()
   {
      maximumLeafPrimitives = 2;
   }

   int maximumLeafPrimitives;
};

struct BVTriangle
{
   Vec3f vertices[3];

   int originalTriangleIndex;
   Vec3f centroid;
};

class BVNode {
public:
   bool isLeaf() { return _isLeaf; }

protected:
   BVNode( bool inIsLeaf ) {
      _isLeaf = inIsLeaf;
   }

private:
   bool _isLeaf;
};


class BVLeafNode : public BVNode {
public:
   BVLeafNode( const std::vector<BVTriangle>& inTriangles );

   uint32 getTriangleCount() { return _triangles.size(); }
   const BVTriangle getIndexedTriangle( uint32 inIndex ) {
      return _triangles[inIndex];
   }

   int getLeafIndex() { return _leafIndex; }
   void setLeafIndex( int inIndex ) {
      _leafIndex = inIndex;
   }

private:
   std::vector<BVTriangle> _triangles;

   int _leafIndex;
};


class BVSplitNode : public BVNode {
public:
   BVSplitNode( const BoundingBox& inBounds, const std::vector<BVNode*> inChildren );

   BoundingBox getBounds() { return _bounds; }

   int getChildCount() { return (int) _children.size(); }
   BVNode* getIndexedChild( int inIndex ) {
      return _children[ inIndex ];
   }

   int getSpitIndex() { return _splitIndex; }
   void setSplitIndex( int inIndex ) {
      _splitIndex = inIndex;
   }

private:
   BoundingBox _bounds;
   std::vector<BVNode*> _children;

   int _splitIndex;
};


class BVTreeBuilder {
public:
   BVTreeBuilder( const BVTreeOptions& inOptions,
                  int inTriangleCount, const BVTriangle *inTriangles );

   BVNode* getRootNode() { return _rootNode; }

private:
   BVNode* createNode( std::vector<BVTriangle>& inTriangles );
   BVNode* createSplit( std::vector<BVTriangle>& inTriangles );
   BVNode* createLeaf( std::vector<BVTriangle>& inTriangles );

   BVTreeOptions _options;

   BVNode* _rootNode;
};

#endif
