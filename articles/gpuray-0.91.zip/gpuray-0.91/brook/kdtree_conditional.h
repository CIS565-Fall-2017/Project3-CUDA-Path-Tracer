/*
* kdtree_conditional.h --
*
*
*/

#ifndef __KDTREE_CONDITIONAL_H__
#define __KDTREE_CONDITIONAL_H__

#include <brook/brook.hpp>

#include "kdtree.h"

class KdTreeConditionalAccelerator :
   public KdTreeAccelerator
{
public:
   KdTreeConditionalAccelerator();

   void
   intersect( brook::stream& rayStream, brook::stream& hitStream ) const;

protected:
   void allocateStateStreams() const;
   void debugState() const;

   enum{ kQueryCount = 1 };

   enum QueryType
   {
      kQueryType_None = -1,
      kQueryType_Down = 0,
      kQueryType_Leaf,
      kQueryType_Intersect,
      kQueryType_PostIntersect,
      kQueryType_Up,
      kQueryTypeCount
   };

	mutable brook::write_mask _mask;
   mutable brook::write_query _queries[kQueryCount];
   mutable QueryType _queryTypes[kQueryCount];
   mutable int _queryIndex;

   mutable uint32 _approximateCounts[kQueryTypeCount];
   mutable uint32 _iterationCounts[kQueryTypeCount];
   mutable uint32 _processedItemCounts[kQueryTypeCount];
   mutable float _totalTimes[kQueryTypeCount];

   typedef void (KdTreeConditionalAccelerator::*ModeFunction)() const;

   void executeMode(
      QueryType inType,
      ModeFunction inMaskFunction,
      ModeFunction inKernelFunction ) const;

   bool iterateMode(
      QueryType inType,
      QueryType inNextType,
      int inSwitchFactor,
      ModeFunction inMaskFunction,
      ModeFunction inKernelFunction ) const;

   void processOneQuery() const;
   void printStats( const char* inName, QueryType inType ) const;

   void buildDownMask() const;
   void buildLeafMask() const;
   void buildIntersectMask() const;
   void buildPostIntersectMask() const;
   void buildUpMask() const;

   void executeDownPass() const;
   void executeLeafPass() const;
   void executeIntersectPass() const;
   void executePostIntersectPass() const;
   void executeUpPass() const;
};

#endif
