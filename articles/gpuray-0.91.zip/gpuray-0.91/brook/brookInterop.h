/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * brookInterop.h --
 *
 *      Helper classes for using both brook and CPU together for ray tracing
 */

#ifndef __BROOK_BROOKINTEROP_H__
#define __BROOK_BROOKINTEROP_H__

#include "brookContext.h"
#include "brookTracer.h"
#include "../cpu/cpuTracer.h"

/*
 * TIM: Trying to maintain the brook-CPU interop
 * path will potentially disadvantage progress
 * on the CPU and Cell tracers. As such, it is
 * probably safe to disable this code for now,
 * with the possibility of fixing it up later.
 */

#if 0

class HitShaderCPU2Brook : public IHitShaderCPU
{
public:
   HitShaderCPU2Brook( IHitShaderBrook* inInner );

   void Shade(
      int inWidth, int inHeight,
      const RayCPU* inRays,
      const HitCPU* inHits );

private:
   IHitShaderBrook* _inner;

   int _currentStreamX, _currentStreamY;
   brook::stream _rayStream;
   brook::stream _hitStream;
};

class BaseRayIntersectorBrook2CPU : public IBaseRayIntersectorBrook
{
public:
   BaseRayIntersectorBrook2CPU( IBaseRayIntersectorCPU* inInner );

   void Intersect( brook::stream& inRayStream, IHitShaderBrook* inContinuation );

private:
   IBaseRayIntersectorCPU* _inner;
};

#endif

#endif
