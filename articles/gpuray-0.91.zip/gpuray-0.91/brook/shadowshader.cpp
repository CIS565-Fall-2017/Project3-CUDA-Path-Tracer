/*
 * shadowshader.cpp --
 *
 *      Shader that draws the scene with point-lit shadows
 */
#include "shadowshader.h"

#include "tracerays.hpp"
#include "brookTracer.h"

/*
 * ShadowShaderCallback --
 *
 *      A wrapper object to allow the callback-oriented
 *      style of tracing to work with the shadow shader.
 *
 */


class ShadowShaderCallback : public IHitShaderBrook
{
public:
   brook::stream shadingHitStream;
   brook::stream inputPixelStream;
   brook::stream outputPixelStream;

   float3 lightPosition;
   float3 lightAttenuation;
   float3 eyePosition;

   void Shade( brook::stream& inRayStream, brook::stream& inHitStream )
   {
      krnShading_ShadeShadowedHits( shadingHitStream, inHitStream, lightPosition, lightAttenuation,
         eyePosition, inputPixelStream, outputPixelStream );
   }
};

void ShadowShader::shade(brook::stream& inputPixelStream,
                         brook::stream& shadingHitStream,
                         const float3& lightInfo,
                         const float3& attenConsts,
                         const float3& diffColor,
                         const float3& eyePos,
                         brook::stream& pixelStream) const
{
   float3 lightPosition = lightInfo;

   int pixelStreamX = pixelStream->getExtents()[1];
   int pixelStreamY = pixelStream->getExtents()[0];
   if( pixelStreamX != _rayStreamX || pixelStreamY != _rayStreamY )
   {
      _rayStreamX = pixelStreamX;
      _rayStreamY = pixelStreamY;

      _shadowRayStream = brook::stream::create<Ray>( _rayStreamX, _rayStreamY );
   }

   // create an object for the shadow ray case to use when "shading"
   // its hits.
   ShadowShaderCallback callback;

   callback.shadingHitStream = shadingHitStream;
   callback.inputPixelStream = inputPixelStream;
   callback.outputPixelStream = pixelStream;

   callback.lightPosition = lightPosition;
   callback.lightAttenuation = attenConsts;
   callback.eyePosition = eyePos;

   krnShading_GenerateShadowRays( shadingHitStream, lightPosition, _shadowRayStream );
   _intersector->Intersect( _shadowRayStream, &callback );
}


