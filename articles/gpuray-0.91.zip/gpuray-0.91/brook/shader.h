/*
 * shader.h --
 *
 *      Abstract class for wraping a lighting and shading implementation.
 */

#ifndef __SHADER_H__
#define __SHADER_H__

#include <brook/brook.hpp>


class Shader
{
public:
   virtual void shade(brook::stream& inputPixelStream,
                      brook::stream& shadingHitStream,
                      const float3& lightPosition_atten, 
                      const float3& attenConsts,
                      const float3& diffColor,
                      const float3& eyePos,
                      brook::stream& pixelStream) const = 0;
};

#endif
