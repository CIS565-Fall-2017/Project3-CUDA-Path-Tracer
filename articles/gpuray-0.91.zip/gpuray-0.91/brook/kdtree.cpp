/*
 * kdtree.cpp --
 *
 *      Implementation of k-d tree accelerator
 */
#include "kdtree.h"

#include "../timer.h"
#include "../log.h"
#include "brookTracer.h"
#include "buildkdtree.h"
#include "kdtreekernels.hpp"

//#define DEBUG_KDTREE_STATE
#ifdef DEBUG_KDTREE_STATE
#define DEBUG_ONLY(x)   x
#else
#define DEBUG_ONLY(x)
#endif

#define MAKE_MASK(_m, stmt) do { \
   (_m).enableSet();             \
   (_m).clear();                 \
   stmt;                         \
   (_m).disableSet();            \
} while(0)


static inline int divideRoundUp(int n, int d) {
   return (n + (d-1)) / d;
}

struct BaseSplitStreamItem {
   float splitValue;
   SHORTFIXED2 leftChildIndex;
   SHORTFIXED2 rightChildIndex;
};

struct ExtendedSplitStreamItem {
   Vec3f bboxMin;
   float parentIndexX;

   Vec3f bboxMax;
   float parentIndexY;
};

struct LeafStreamItem {
   float triangleCount;
   SHORTFIXED2 firstTriangleIndex;
   SHORTFIXED2 parentIndex;
};

struct TriangleIndexStreamItem {
   SHORTFIXED2 triangleIndex;
};

struct TriangleStreamItem {
   Vec3f vertices[3];
};

struct RayStreamItem {
   Vec3f origin;
   Vec3f direction;
};

struct CoreStateStreamItem {
   Vec2f nodeIndex;
   float tmin;
   float tmax;
};

struct IntersectStateStreamItem {
   float2 indexIndex;
   float triangleCount;
   float unused;
};


#ifdef DEBUG_KDTREE_STATE
static RayStreamItem* gDebugRays = NULL;
static float4* gDebugHits = NULL;
static SHORTFIXED2* gDebugIndices = NULL;
#endif


/*
 * KdTreeAccelerator::initialize --
 *
 *      The real constructor for the kd-tree.  Builds the kd-tree of the
 *      triangles and allocates and fills all of the static streams (the
 *      triangles, the nodes, etc.).
 *
 * Results:
 *      void.
 */

void
KdTreeAccelerator::initialize(const AcceleratorOptions& inOptions)
{
   _shortConversionSignedOffset = 4096;

   KdTreeOptions options;
   options.intersectCost = 1;
   options.traversalCost = 8;
   options.emptyBonus = 0.1f;
   options.maximumLeafPrimitives = 4;

#if 0
   options.useNewBuilder = true;
   options.newOptions.minNodeExtentRatio = 0.001f;
   options.newOptions.isectCost = 1.0f;
   options.newOptions.splitCost = 1.0f;
#endif

   /*
    * Default options are:
    *   intersectCost = 80;
    *   traversalCost = 1;
    *   emptyBonus = 0.5f;
    *   maximumLeafPrimitives = 1;
    *   maximumDepth = -1;
    */

   uint32 triangleCount = (uint32) inOptions.scene->nTris();
   std::vector<KdTreeTriangle> triangles;
   triangles.resize(triangleCount);

   for(uint32 t = 0; t < triangleCount; t++) {
      triangles[t].vertices[0] = ((Vec3f*) inOptions.scene->vertices(0))[t];
      triangles[t].vertices[1] = ((Vec3f*) inOptions.scene->vertices(1))[t];
      triangles[t].vertices[2] = ((Vec3f*) inOptions.scene->vertices(2))[t];
   }

   KdTreeBuilder builder(*inOptions.opts,
                         options, inOptions.scene, triangleCount, &triangles[0]);

   // TIM: we might be able to "filter" the tree we create
   // before we operate on it to make it more suitable...

   std::vector<TriangleIndexStreamItem> triangleIndices;

   std::vector<BaseSplitStreamItem> baseSplits;
   std::vector<ExtendedSplitStreamItem> extendedSplits;
   std::vector<LeafStreamItem> leaves;

   // TIM: hacky
   _vertexStreamX = inOptions.vertexStreamX;
   _vertexStreamY = inOptions.vertexStreamY;
   _triangleIndexStreamX = 1024;
   _splitStreamX = 1024;
   _leafStreamX = 1024;

   BoundingBox bounds = builder.getIndexedNode(0)->getWorldBounds();
   _boundsMin = toFloat3( bounds.minimum );
   _boundsMax = toFloat3( bounds.maximum );

   uint32 nodeCount = builder.getNodeCount();
   for(uint32 n = 0; n < nodeCount; n++) {
      Node* node = builder.getIndexedNode(n);

      if(node->isLeaf()) {
         LeafNode* leaf = (LeafNode*) node;

         uint32 leafFirstTriangleIndex = triangleIndices.size();

         uint32 leafTriangleIndexCount = leaf->getPrimitiveCount();
         for(uint32 i = 0; i < leafTriangleIndexCount; i++) {
            uint32 triangleIndex = leaf->getIndexedPrimitiveIndex(i);

            TriangleIndexStreamItem indexItem;
            indexItem.triangleIndex.x = (FIXED_VALUE)( triangleIndex % _vertexStreamX );
            indexItem.triangleIndex.y = (FIXED_VALUE)( triangleIndex / _vertexStreamX );

            triangleIndices.push_back(indexItem);
         }

         LeafStreamItem nodeItem;

         nodeItem.triangleCount = (float) leafTriangleIndexCount;
         nodeItem.firstTriangleIndex.x = (FIXED_VALUE)(leafFirstTriangleIndex % _triangleIndexStreamX);
         nodeItem.firstTriangleIndex.y = (FIXED_VALUE)(leafFirstTriangleIndex / _triangleIndexStreamX);

         int parentIndex = node->getParentIndex();
         Node* parentNode = parentIndex < 0 ? NULL : builder.getIndexedNode(parentIndex);

         nodeItem.parentIndex = createLeafParentIndex(parentNode);

         leaves.push_back(nodeItem);
      } else {
         InternalNode* split = (InternalNode*) node;

         BaseSplitStreamItem base;
         ExtendedSplitStreamItem extended;

         extended.bboxMin = node->getWorldBounds().minimum;
         extended.bboxMax = node->getWorldBounds().maximum;

         int splitAxis = split->getSplitAxis();

         // TIM: the sign bit of the y component stores
         // the leaf/split distinction
         // so we use the x components to hold
         // to components of our split axis
         base.leftChildIndex = createChildIndex(
            builder.getIndexedNode(split->getLeftChildIndex()), splitAxis == 0 ? -1 : 1);
         base.rightChildIndex = createChildIndex(
            builder.getIndexedNode(split->getRightChildIndex()), splitAxis == 1 ? -1 : 1 );

         int parentIndex = node->getParentIndex();
         Node* parentNode = parentIndex < 0 ? NULL : builder.getIndexedNode(parentIndex);

         float2 parentIndexXY = createSplitParentIndex(parentNode);
         extended.parentIndexX = parentIndexXY.x;
         extended.parentIndexY = parentIndexXY.y;

         base.splitValue = split->getSplitValue();

         baseSplits.push_back(base);
         extendedSplits.push_back(extended);
      }
   }
   uint32 triangleIndexCount = triangleIndices.size();

   uint32 splitCount = baseSplits.size();
   uint32 leafCount = leaves.size();

   std::cout << "#kdtree# Build: #tris: " << triangleCount << " #triList: "
             << triangleIndexCount << " #splits: " << splitCount
             << " #leaves: " << leafCount << std::endl;

   _vertexStreamX = inOptions.vertexStreamX;
   _vertexStreamY = inOptions.vertexStreamY;

   _triangleIndexStreamX = 1024;
   _triangleIndexStreamY = divideRoundUp((int) triangleIndexCount, _triangleIndexStreamX);

   _splitStreamX = 1024;
   _splitStreamY = divideRoundUp((int) splitCount, _splitStreamX);

   _leafStreamX = 1024;
   _leafStreamY = divideRoundUp((int) leafCount, _leafStreamX);

   triangleIndices.resize(_triangleIndexStreamX * _triangleIndexStreamY);
   baseSplits.resize(_splitStreamX * _splitStreamY);
   extendedSplits.resize(_splitStreamX * _splitStreamY);
   leaves.resize(_leafStreamX * _leafStreamY);

   memset(&triangleIndices[triangleIndexCount], 0,
      (triangleIndices.size() - triangleIndexCount) * sizeof(TriangleIndexStreamItem));
   memset(&baseSplits[splitCount], 0,
      (baseSplits.size() - splitCount) * sizeof(BaseSplitStreamItem));
   memset(&extendedSplits[splitCount], 0,
      (extendedSplits.size() - splitCount) * sizeof(ExtendedSplitStreamItem));
   memset(&leaves[leafCount], 0,
      (leaves.size() - leafCount) * sizeof(LeafStreamItem));

   _vertexStream = inOptions.positionStream;

   _triangleIndexStream = brook::stream::create<KD_TriangleIndex>(_triangleIndexStreamY, _triangleIndexStreamX);
   _triangleIndexStream.read(&triangleIndices[0]);

   _baseSplitStream = brook::stream::create<KD_BaseSplit>(_splitStreamY, _splitStreamX);
   _baseSplitStream.read(&baseSplits[0]);

   _extendedSplitStream = brook::stream::create<KD_ExtendedSplit>(_splitStreamY, _splitStreamX);
   _extendedSplitStream.read(&extendedSplits[0]);

   _leafStream = brook::stream::create<KD_Leaf>(_leafStreamY, _leafStreamX);
   _leafStream.read(&leaves[0]);

   _stateStreamX = _stateStreamY = 0;

   _shortConversionConstant.x = 65535.5f;
   _shortConversionConstant.y = (float) _shortConversionSignedOffset;
}


/*
 * KdTreeAccelerator::createStateStreams --
 *
 *      Helper function to get ready to traverse.  It takes a stream whose
 *      dimensions reflect the traversal and, if necessary, updates its
 *      fields and streams to be the right size.
 *
 * Results:
 *      void.
 */

void
KdTreeAccelerator::createStateStreams(const brook::stream& inExampleStream) const
{
   using namespace brook;

   int imageW = inExampleStream->getExtents()[1];
   int imageH = inExampleStream->getExtents()[0];

   if(_stateStreamX != imageW || _stateStreamY != imageH) {
     _stateStreamX = imageW;
     _stateStreamY = imageH;

     allocateStateStreams();
   }
}


/*
 * KdTreeAccelerator::allocateStateStreams --
 *
 *      Actually allocates the member streams for traversal.  The only
 *      reason this is separate from createStateStreams() is so that the
 *      conditional subclass can override it.
 *
 * Results:
 *      void.
 */

void
KdTreeAccelerator::allocateStateStreams() const
{
   using namespace brook;

   _coreStateStream =
      stream::create<KD_CoreState>(_stateStreamY, _stateStreamX);
   _intersectStateStream =
      stream::create<KD_IntersectState>(_stateStreamY, _stateStreamX);
   _maskStream = stream::create<float>(_stateStreamY, _stateStreamX);
}


/*
 * KdTreeAccelerator::dumpState --
 *
 *      Walks all of the current traversal state and prints the current
 *      state of all of the rays.
 *
 * Results:
 *      void.
 */

void
KdTreeAccelerator::dumpState() const
{
#ifdef DEBUG_KDTREE_STATE
   static CoreStateStreamItem* states = new CoreStateStreamItem[ _stateStreamX * _stateStreamY ];
   static IntersectStateStreamItem* isects = new IntersectStateStreamItem[ _stateStreamX * _stateStreamY ];

   static BaseSplitStreamItem* splits = new BaseSplitStreamItem[ 1024*1024 ];
   static LeafStreamItem* leaves = new LeafStreamItem[ 1024*1024 ];

   _coreStateStream.write(states);
   _intersectStateStream.write(isects);

   _baseSplitStream->Write(splits);
   _leafStream->Write(leaves);

   int s = 0;

   CoreStateStreamItem& state = states[ s ];
   IntersectStateStreamItem& isect = isects[ s ];
   RayStreamItem& ray = gDebugRays[ s ];
   float4 hit = gDebugHits[ s ];

   float nodeX = fabsf(state.nodeIndex.x) - 1;
   float nodeY = fabsf(state.nodeIndex.y) - 1;
   float tmin = state.tmin;
   float tmax = state.tmax;
   float idxX = isect.indexIndex.x;
   float idxY = isect.indexIndex.y;
   float count = isect.triangleCount;
   bool tdelta = tmax != tmin;

   if(state.nodeIndex.x > 0) { // traverse
      std::cerr << "state=" << std::endl;
      std::cerr << (state.tmax > 0 ? "DOWN " : "UP ");

      bool isSplit = state.nodeIndex.y > 0;
      std::cerr << (isSplit ? "split" : "leaf") << nodeX << ", " << nodeY;

      std::cerr << " tmin: " << tmin << " tmax: " << tmax;
      std::cerr << " tdelta: " << tdelta;

      if(isSplit) {
         std::cerr << std::endl << "  ";

         int splitIndex = (int) (nodeY*1024 + nodeX + 0.5);
         BaseSplitStreamItem split = splits[ splitIndex ];

         //std::cerr << " axis: " << split.splitAxisX << "," << split.splitAxisY;
         std::cerr << " value: " << split.splitValue;

         std::cerr << " left: " << (split.leftChildIndex.x-4096)
                   << "," << (split.leftChildIndex.y-4096) ;
         std::cerr << " right: " << (split.rightChildIndex.x-4096)
                   << "," << (split.rightChildIndex.y-4096);

         int axis;
         axis = split.leftChildIndex.x < 4096 ?
                0 : (split.rightChildIndex.x < 4096 ? 1 : 2);

         float thit;
         thit = (split.splitValue - ray.origin[axis]) / ray.direction[axis];

         std::cerr << " thit: " << thit;
      } else {
         int leafIndex = (int) (nodeY*1024 + nodeX + 0.5);
         LeafStreamItem leaf = leaves[ leafIndex ];

         std::cerr << std::endl << "  ";
         std::cerr << " count: " << leaf.triangleCount;
         std::cerr << " first: " << leaf.firstTriangleIndex.x
                   << "," << leaf.firstTriangleIndex.y;
         std::cerr << " parent: " << leaf.parentIndex.x << "," << leaf.parentIndex.y;

      }
   } else if(state.nodeIndex.x < 0) { // isect
      std::cerr << "ISECT";

      std::cerr << " split: " << nodeX << ", " << nodeY;
      std::cerr << " tmin: " << tmin << " tmax: " << tmax;

      std::cerr << " idx: " << idxX << ", " << idxY;
      std::cerr << " count: " << count;

      std::cerr << " tdelta: " << tdelta;

      int indexIndex = (int) (idxX + idxY*1024 + 0.5);
      SHORTFIXED2 triangleIndex = gDebugIndices[ indexIndex ];

      float triX = triangleIndex.x;
      float triY = triangleIndex.y;

      std::cerr << " tri: " << triX << ", " << triY;
   } else { // done
      std::cerr << "done";
   }

   std::cerr << std::endl << "  ";
   std::cerr << " o: " << ray.origin.x << ", "
             << ray.origin.y << ", " << ray.origin.z;
   std::cerr << " d: " << ray.direction.x << ", "
             << ray.direction.y << ", " << ray.direction.z;
   std::cerr << std::endl << "  ";

   std::cerr << " hit: " << hit.x << ", " << hit.y << ", "
             << hit.z << ", " << hit.w;
   std::cerr << std::endl;

//   if(!tdelta)
//      exit(1);
#endif
}


/*
 * KdTreeAccelerator::intersect --
 *
 *      Entry-point to actually do traversal and intersection.  The stream
 *      of rays is passed in and then stream of hits is expected to filled
 *      in on exit.
 *
 * Results:
 *      void.
 */

void
KdTreeAccelerator::intersect(brook::stream& rayStream,
                             brook::stream& hitStream) const
{
   using namespace brook;

   int i;

   _rayStream = rayStream;
   _hitStream = hitStream;
   createStateStreams(rayStream);

   DEBUG_ONLY(std::cerr << "initialize" << std::endl;)

   krnKD_Initialize(_boundsMin, _boundsMax, _rayStream, _hitStream,
                   _coreStateStream, _intersectStateStream);

#ifdef DEBUG_KDTREE_STATE
   if(gDebugRays == NULL) {
      gDebugRays = new RayStreamItem[ _stateStreamX * _stateStreamY ];
   }
   if(gDebugHits == NULL) {
      gDebugHits = new float4[ _stateStreamX * _stateStreamY ];
   }
   if(gDebugIndices == NULL) {
      gDebugIndices = new SHORTFIXED2[ 1024 * 1024 ];
   }
   rayStream.write(gDebugRays);
   _triangleIndexStream->Write(gDebugIndices);
   dumpState();
#endif

   write_mask mask = write_mask::create(_stateStreamY, _stateStreamX);
   stream maskStream = stream::create<float>(_stateStreamY, _stateStreamX);
   write_query query = write_query::create();

   mask.bind();
   mask.enableTest();
   MAKE_MASK(mask, krnKD_GenerateLiveMask(_coreStateStream, maskStream));
   for (i = 0; i < 10000; i++) {
      DEBUG_ONLY(std::cerr << "down" << std::endl;)
      query.begin();
      krnKD_Down(_coreStateStream, rayStream,
                 _baseSplitStream, _coreStateStream, _shortConversionConstant);
      query.end();
      DEBUG_ONLY({hitStream.write(gDebugHits); dumpState();})


      DEBUG_ONLY(std::cerr << "leaf" << std::endl;)
      MAKE_MASK(mask, krnKD_GenerateLeafMask(_coreStateStream, maskStream));
      krnKD_Leaf(_coreStateStream, _intersectStateStream, rayStream, hitStream,
                 _leafStream, _coreStateStream, _intersectStateStream,
                 _shortConversionConstant);
      DEBUG_ONLY({hitStream.write(gDebugHits); dumpState();})


      DEBUG_ONLY(std::cerr << "intersect" << std::endl;)
      MAKE_MASK(mask, krnKD_GenerateIntersectMask(_coreStateStream,
                                                  _intersectStateStream,
                                                  maskStream));
      krnKD_Intersect(_coreStateStream, _intersectStateStream,
                      rayStream, hitStream, _triangleIndexStream,
                      _vertexStream, hitStream, _intersectStateStream,
                      _shortConversionConstant);
      DEBUG_ONLY({hitStream.write(gDebugHits); dumpState();})


      DEBUG_ONLY(std::cerr << "post-intersect" << std::endl;)
      MAKE_MASK(mask, krnKD_GeneratePostIntersectMask(_coreStateStream,
                                                      _intersectStateStream,
                                                      maskStream));
      krnKD_PostIntersect(_coreStateStream, _intersectStateStream,
         hitStream, _coreStateStream, _shortConversionConstant);
      DEBUG_ONLY({hitStream.write(gDebugHits); dumpState();})


      DEBUG_ONLY(std::cerr << "up" << std::endl;)
      MAKE_MASK(mask, krnKD_GenerateUpMask(_coreStateStream, maskStream));
      krnKD_Up(_coreStateStream, rayStream, hitStream, _extendedSplitStream,
               _coreStateStream, _shortConversionConstant);
      DEBUG_ONLY({hitStream.write(gDebugHits); dumpState();})

      MAKE_MASK(mask, krnKD_GenerateLiveMask(_coreStateStream, maskStream));
      if(query.count() == 0) break;
   }
   mask.disableTest();

   krnKD_Finalize(_coreStateStream, hitStream, hitStream);

#ifndef SILENT
   std::cout << "  KDTree done after " << i << " iterations" << std::endl;
#endif
}


/*
 * KdTreeAccelerator::convertSigned16 --
 *
 *      Trivial helper function to turn an integer into a short.
 *
 * Results:
 *      A biased 'short' version of the given integer.
 */

FIXED_VALUE
KdTreeAccelerator::convertSigned16(int value) const
{
   return (FIXED_VALUE)(value + _shortConversionSignedOffset);
}


/*
 * KdTreeAccelerator::createChildIndex --
 *
 *      Helper function for the manual address translation of nodes.  This
 *      routine takes a node and the sign for its .x component (which
 *      encodes a boolean) and produces the packed, 2D, shortfixed2 version.
 *
 * Results:
 *      See description.
 */

SHORTFIXED2
KdTreeAccelerator::createChildIndex(Node* inNode, int inSignForXComponent)
{
   SHORTFIXED2 result;

   if(inNode == NULL) {
      result.x = result.y = convertSigned16(0);
   } else if(inNode->isLeaf()) {
      int leafIndex = ((LeafNode*) inNode)->getLeafIndex();

      int x = leafIndex % _leafStreamX;
      int y = leafIndex / _leafStreamX;

      result.x = convertSigned16(inSignForXComponent * (x + 1));
      result.y = convertSigned16(-(y + 1));
   } else {
      int splitIndex = ((InternalNode*) inNode)->getSplitIndex();

      int x = splitIndex % _splitStreamX;
      int y = splitIndex / _splitStreamX;

      result.x = convertSigned16(inSignForXComponent * (x + 1));
      result.y = convertSigned16(y + 1);
   }
   return result;
}


/*
 * KdTreeAccelerator::createLeafParentIndex --
 *
 *      Helper function for the manual address translation for internal
 *      nodes.  This function takes an internal node and returns the
 *      shortfixed2 packed version of its 2-d address.
 *
 * Results:
 *      See description, or (-1, -1) for leaves.
 */

SHORTFIXED2
KdTreeAccelerator::createLeafParentIndex(Node* inNode)
{
   SHORTFIXED2 result;

   if(inNode == NULL || inNode->isLeaf()) {
      result.x = result.y = convertSigned16(-1);
   } else {
      int splitIndex = ((InternalNode*) inNode)->getSplitIndex();

      result.x = convertSigned16(splitIndex % _splitStreamX);
      result.y = convertSigned16(splitIndex / _splitStreamX);
   }
   return result;
}


/*
 * KdTreeAccelerator::createSplitParentIndex --
 *
 *      Helper function for the manual address translation for internal
 *      nodes.  This function takes an internal node and returns the
 *      float2 packed version of its 2-d address.
 *
 * Results:
 *      See description, or (-1, -1) for leaves.
 */

float2
KdTreeAccelerator::createSplitParentIndex(Node* inNode)
{
   float2 result;

   if(inNode == NULL || inNode->isLeaf()) {
      result.x = result.y = (float) (-1);
   } else {
      int splitIndex = ((InternalNode*) inNode)->getSplitIndex();

      result.x = (float) (splitIndex % _splitStreamX);
      result.y = (float) (splitIndex / _splitStreamX);
   }
   return result;
}


/*
 * KdTreeAccelerator::timeKernels --
 *
 *      Very simple attempt to determine timing for the core kdtree kernels.
 *
 * Returns:
 *      void
 */

void
KdTreeAccelerator::timeKernels(brook::stream& rayStream) const
{
   using namespace brook;

   static const int numPasses = 500;
   int imageW = rayStream->getExtents()[1];
   int imageH = rayStream->getExtents()[0];
   stream hitStream = stream::create<Hit>(imageH, imageW);
   stream bogusCore = stream::create<KD_CoreState>(imageH, imageW);
   write_query timingQ = write_query::create();

   float tDown, tLeaf, tIsect, tPost, tUp;
   int i;

   _rayStream = rayStream;
   _hitStream = hitStream;
   createStateStreams(rayStream);

   krnKD_Initialize(_boundsMin, _boundsMax, _rayStream,
                     _hitStream, _coreStateStream, _intersectStateStream);

   timingQ.begin();
   krnKD_Down(_coreStateStream, rayStream, _baseSplitStream,
               _coreStateStream, _shortConversionConstant);
   timingQ.end();
   timingQ.wait();

   timingQ.begin();
   tDown = Timer_GetMS();
   for(i = 0; i < numPasses; i++) {
      krnKD_Down(_coreStateStream, rayStream, _baseSplitStream,
                  _coreStateStream, _shortConversionConstant);
   }
   timingQ.end();
   timingQ.wait();
   tDown = Timer_GetMS() - tDown;


#if 1
   /*
    * Now actually traverse the tree so we have useful rays for the Leaf
    * state. (For when using bogusCore to sink the Down()'s above)
    */
   for(i = 0; i < 20; i++) {
      krnKD_Down(_coreStateStream, rayStream, _baseSplitStream,
                  _coreStateStream, _shortConversionConstant);
   }
#endif


   timingQ.begin();
   krnKD_Leaf(_coreStateStream, _intersectStateStream, rayStream,
               hitStream, _leafStream, _coreStateStream,
               _intersectStateStream, _shortConversionConstant);
   timingQ.end();
   timingQ.wait();
   timingQ.begin();
   tLeaf = Timer_GetMS();
   for(i = 0; i < numPasses; i++) {
      krnKD_Leaf(_coreStateStream, _intersectStateStream, rayStream,
                  hitStream, _leafStream, _coreStateStream,
                  _intersectStateStream, _shortConversionConstant);
   }
   timingQ.end();
   timingQ.wait();
   tLeaf = Timer_GetMS() - tLeaf;

   timingQ.begin();
   krnKD_Intersect(_coreStateStream, _intersectStateStream, rayStream,
                    hitStream, _triangleIndexStream, _vertexStream,
                    hitStream, _intersectStateStream,
                    _shortConversionConstant);
   timingQ.end();
   timingQ.wait();
   timingQ.begin();
   tIsect = Timer_GetMS();
   for(i = 0; i < numPasses; i++) {
      krnKD_Intersect(_coreStateStream, _intersectStateStream, rayStream,
                       hitStream, _triangleIndexStream, _vertexStream,
                       hitStream, _intersectStateStream,
                       _shortConversionConstant);
   }
   timingQ.end();
   timingQ.wait();
   tIsect = Timer_GetMS() - tIsect;

   timingQ.begin();
   krnKD_PostIntersect(_coreStateStream, _intersectStateStream, hitStream,
                        _coreStateStream, _shortConversionConstant);
   timingQ.end();
   timingQ.wait();
   timingQ.begin();
   tPost = Timer_GetMS();
   for(i = 0; i < numPasses; i++) {
      krnKD_PostIntersect(_coreStateStream, _intersectStateStream, hitStream,
                           _coreStateStream, _shortConversionConstant);
   }
   timingQ.end();
   timingQ.wait();
   tPost = Timer_GetMS() - tPost;

   timingQ.begin();
   krnKD_Up(_coreStateStream, rayStream, hitStream,
             _extendedSplitStream, bogusCore,
             _shortConversionConstant);
   timingQ.end();
   timingQ.wait();
   timingQ.begin();
   tUp = Timer_GetMS();
   for(i = 0; i < numPasses; i++) {
      krnKD_Up(_coreStateStream, rayStream, hitStream,
                _extendedSplitStream, bogusCore,
                _shortConversionConstant);
   }
   timingQ.end();
   timingQ.wait();
   tUp = Timer_GetMS() - tUp;

   printf("\n#kd# # passes: %d, fragments per pass: %d\n",
          numPasses, imageH * imageW);
   printf("#kd# Down time: %fms, Up time: %fms, Leaf time: %fms\n",
          tDown, tUp, tLeaf);
   printf("#kd# Intersect time: %fms, Post Intersect time: %fms\n",
          tIsect, tPost);
   printf("#kd# Down GB/sec: %f, Up GB/sec: %f, Leaf GB/sec: %f\n",
         (float) numPasses / tDown * imageH * imageW * 19 * 4 *
                 1000.0 / 1024.0 / 1024.0 / 1024.0,
         (float) numPasses / tUp * imageH * imageW * 24 * 4 *
                 1000.0 / 1024.0 / 1024.0 / 1024.0,
         (float) numPasses / tLeaf * imageH * imageW * 19 * 4 *
                 1000.0 / 1024.0 / 1024.0 / 1024.0);
   printf("#kd# Intersect GB/sec: %f, Post Intersect GB/sec: %f\n\n",
         (float) numPasses / tIsect * imageH * imageW * 41 * 4 *
                 1000.0 / 1024.0 / 1024.0 / 1024.0,
         (float) numPasses / tPost * imageH * imageW * 16 * 4 *
                 1000.0 / 1024.0 / 1024.0 / 1024.0);
}
