/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * brookDisplayDX.cpp --
 *
 *      XXX
 */
#include "brookDisplayDX.h"

#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>
#include "../timer.h"
#include "../renderContextDX.h"

static const char* kPassthroughVertexShader =
"vs.1.1\n"
"dcl_position v0\n"
"dcl_texcoord0 v1\n"
"mov oPos, v0\n"
"mov oT0, v1\n"
;

static const char* kPassthroughPixelShader =
"ps_2_0\n"
"dcl t0.xy\n"
"dcl_2d s0\n"
"texld r0, t0, s0\n"
"mov oC0, r0\n"
;

static const D3DVERTEXELEMENT9 kVertexFormat[] =
{
   { 0, 0, D3DDECLTYPE_FLOAT4, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0 },
   { 0, 4*sizeof(float), D3DDECLTYPE_FLOAT4, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0 },
   D3DDECL_END()
};

IDirect3DVertexShader9* createVertexShader(
   IDirect3DDevice9* inDevice,
   const std::string& inSource )
{
   IDirect3DDevice9* device = inDevice;
   IDirect3DVertexShader9* resultShader;

   // assemble the shader
   HRESULT result;
   LPD3DXBUFFER codeBuffer;
   LPD3DXBUFFER errorBuffer;

   result = D3DXAssembleShader( inSource.c_str(), inSource.size(), NULL, NULL, 0, &codeBuffer, &errorBuffer );
   if( errorBuffer != NULL )
   {
      const char* errorMessage = (const char*)errorBuffer->GetBufferPointer();
      DX9Warn( "Vertex shader failed to compile:\n%s", errorMessage );
      throw -1;
   }
   else if( FAILED(result) )
   {
      DX9Warn( "Vertex shader failed to compile." );
      throw -1;
   }

   result = device->CreateVertexShader( (DWORD*)codeBuffer->GetBufferPointer(), &resultShader );
   codeBuffer->Release();

   if( FAILED(result) )
   {
      DX9Warn( "Failed to allocate vertex shader." );
      throw -1;
   }

   return resultShader;
}

IDirect3DPixelShader9* createPixelShader(
   IDirect3DDevice9* inDevice,
   const std::string& inSource )
{
   IDirect3DDevice9* device = inDevice;
   IDirect3DPixelShader9* resultShader;

   // assemble the shader
   HRESULT result;
   LPD3DXBUFFER codeBuffer;
   LPD3DXBUFFER errorBuffer;

   result = D3DXAssembleShader( inSource.c_str(), inSource.size(), NULL, NULL, 0, &codeBuffer, &errorBuffer );
   if( errorBuffer != NULL )
   {
      const char* errorMessage = (const char*)errorBuffer->GetBufferPointer();
      DX9Warn( "Pixel shader failed to compile:\n%s", errorMessage );
      throw -1;
   }
   else if( FAILED(result) )
   {
      DX9Warn( "Pixel shader failed to compile." );
      throw -1;
   }

   result = device->CreatePixelShader( (DWORD*)codeBuffer->GetBufferPointer(), &resultShader );
   codeBuffer->Release();

   if( FAILED(result) )
   {
      DX9Warn( "Failed to allocate vertex shader." );
      throw -1;
   }

   return resultShader;
}


PixelDisplayerBrookDX9::PixelDisplayerBrookDX9( RenderContextDX9* inRenderContext, BrookContext* inBrookContext )
{
   HRESULT result;

   _renderContext = inRenderContext;

   IDirect3DDevice9* device = _renderContext->getDevice();

   result = device->CreateVertexBuffer(
      4*sizeof(DXVertex), D3DUSAGE_DYNAMIC | D3DUSAGE_WRITEONLY, 0, D3DPOOL_DEFAULT, &_vertexBuffer, NULL );
   if( FAILED(result) ) throw -1;

   result = device->CreateVertexDeclaration( kVertexFormat, &_vertexDecl );
   if( FAILED(result) ) throw -1;

   _vertexShader = createVertexShader( device, kPassthroughVertexShader );
   _pixelShader = createPixelShader( device, kPassthroughPixelShader );
}

void PixelDisplayerBrookDX9::Display( brook::stream& inPixelStream )
{


   HRESULT result;

   IDirect3DDevice9* device = _renderContext->getDevice();
   IDirect3DTexture9* imageTexture = (IDirect3DTexture9*) (inPixelStream->getIndexedFieldRenderData(0));

   result = device->SetTexture( 0, imageTexture );
   if( FAILED(result) ) throw -1;

   result = device->SetRenderTarget( 0, _renderContext->getDefaultRenderTarget() );
   if( FAILED(result) ) throw -1;
   static ID3DXFont *g_font=NULL;
   if (!g_font) 
     D3DXCreateFont(device,     //D3D Device
                     22,               //Font height
                     0,                //Font width
                     FW_NORMAL,        //Font Weight
                     1,                //MipLevels
                     false,            //Italic
                     DEFAULT_CHARSET,  //CharSet
                     OUT_DEFAULT_PRECIS, //OutputPrecision
                     ANTIALIASED_QUALITY, //Quality
                     DEFAULT_PITCH|FF_DONTCARE,//PitchAndFamily
                     "Arial",          //pFacename,
                     &g_font);         //ppFont
   // render

   result = device->Clear( 0, NULL, D3DCLEAR_TARGET, 0x00000000, 1.0f, 0 );
   DX9AssertResult( result, "Clear Failed" );

   result = device->BeginScene();
   if( FAILED(result) ) throw -1;

   result = device->SetVertexShader( _vertexShader );
   if( FAILED(result) ) throw -1;

   result = device->SetPixelShader( _pixelShader );
   if( FAILED(result) ) throw -1;

   DXVertex* vertices;
   result = _vertexBuffer->Lock( 0, 0, (void**)&vertices, D3DLOCK_DISCARD );
   if( FAILED(result) ) throw -1;

   DXVertex vertex;

   float left = -1.0f, right = 1.0f, top = 1.0f, bottom = -1.0f;
   float texleft = 0.0f, texright = 1.0f, textop = 0.0f, texbottom = 1.0f;

   for( int i = 0; i < 4; i++ )
   {
      vertex.x = (i & 1) ? right : left;
      vertex.y = (i & 2) ? bottom : top;
      vertex.z = 0.5f;
      vertex.w = 1.0f;

      vertex.tx = (i & 1) ? texright : texleft;
      vertex.ty = (i & 2) ? texbottom : textop;
      vertex.tz = 0.5f;
      vertex.tw = 1.0f;

      *vertices++ = vertex;
   }
   result = _vertexBuffer->Unlock();
   if( FAILED(result) ) throw -1;

   result = device->SetVertexDeclaration( _vertexDecl );
   if( FAILED(result) ) throw -1;

   result = device->SetStreamSource( 0, _vertexBuffer, 0, sizeof(DXVertex) );
   if( FAILED(result) ) throw -1;
   static float tt;
   
   result = device->DrawPrimitive( D3DPT_TRIANGLESTRIP, 0, 2 );
   if( FAILED(result) ) throw -1;
    RECT font_rect;   
   SetRect(&font_rect,0,0,256,256);
     char fps[128];
   sprintf (fps,"FPS: %.2f",1000./tt);
   double font_height=g_font->DrawText(NULL,        //pSprite
                                fps,  //pString
                                -1,          //Count
                                &font_rect,  //pRect
                                DT_LEFT|DT_NOCLIP,//Format,
                                0xFFFFFFFF); //Color

   float tmp[16];
   streamWrite(inPixelStream.domain(int2(0,0),int2(1,1)),tmp);

   tt = Timer_GetMS();
   result = device->EndScene();
   if( FAILED(result) ) throw -1;
   result = device->Present( NULL, NULL, NULL, NULL );
   DX9AssertResult( result, "Present Failed" );
}
