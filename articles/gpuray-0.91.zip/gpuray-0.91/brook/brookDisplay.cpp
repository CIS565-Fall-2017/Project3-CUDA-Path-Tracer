/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * brookDisplay.cpp --
 *
 *      XX
 */
#include "brookDisplay.h"

#include "brookDisplayGL.h"
#include "brookDisplayDX.h"
#include "../fileIO/ppmImage.h"

WriteImagePixelDisplayerBrook::WriteImagePixelDisplayerBrook(
   ppmImage* inOutputImage )
{
   _outputImage = inOutputImage;
}

void WriteImagePixelDisplayerBrook::Display( brook::stream& inPixelStream )
{
   int width = inPixelStream->getExtents()[1];
   int height = inPixelStream->getExtents()[0];

   assert( _outputImage->Width() == width );
   assert( _outputImage->Height() == height );

   inPixelStream.write( _outputImage->Data() );
}

CachedPixelDisplayerBrook::CachedPixelDisplayerBrook(
   IPixelDisplayerBrook* inContinuation )
{
   _continuation = inContinuation;
}

void CachedPixelDisplayerBrook::Display( brook::stream& inPixelStream )
{
   _pixelStream = inPixelStream;
}

void CachedPixelDisplayerBrook::Display()
{
   _continuation->Display( _pixelStream );
}

/*
* CreatePixelDisplayerBrook --
*
*      Creates an object capable of displaying
*      pixels from the appropriate brook runtime.
*
* Results:
*      The created object.
*/

IPixelDisplayerBrook*
CreatePixelDisplayerBrook( IRenderContext* inRenderContext, BrookContext* inBrookContext )
{
   const char* renderSystemID = inRenderContext->getRenderSystem()->getRenderSystemID();

   if( strcmp( renderSystemID, "dx9" ) == 0 )
      return new PixelDisplayerBrookDX9( (RenderContextDX9*) inRenderContext, inBrookContext );
   else if( strcmp( renderSystemID, "ogl" ) == 0 )
      return new PixelDisplayerBrookOGL( (RenderContextOGL*) inRenderContext, inBrookContext );
   else
   {
      assert( false );
      throw -1;
   }
}