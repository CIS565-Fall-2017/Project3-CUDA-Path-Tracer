/*
 * bvh.cpp --
 *
 *      Implementation of BV tree accelerator
 */
#include "bvh.h"

#include "../timer.h"
#include "../log.h"
#include "brookTracer.h"
#include "buildbvh.h"
#include "bvhkernels.hpp"

#define MAKE_MASK(_m, stmt) do { \
   (_m).enableSet();             \
   (_m).clear();                 \
   stmt;                         \
   (_m).disableSet();            \
} while(0)


static inline int divideRoundUp(int n, int d) {
   return (n + (d-1)) / d;
}

Vec2f BVTreeAccelerator::addNode( BVNode* inNode, const Vec2f& inSuccessorID,
   std::vector<BVTriangleStreamItem>& ioTriangles,
   std::vector<float2>& ioTriangleRemaps,
   std::vector<BVSplitStreamItem>& ioSplits,
   std::vector<BVLeafStreamItem>& ioLeaves )
{
   if( inNode->isLeaf() )
   {
      BVLeafNode* leaf = (BVLeafNode*) inNode;

      int leafIndex = (int) ioLeaves.size();
      ioLeaves.push_back( BVLeafStreamItem() );

      int firstTriangleIndex = (int) ioTriangles.size();
      int triangleCount = leaf->getTriangleCount();

      for( int t = 0; t < triangleCount; t++ )
      {
         BVTriangle triangle = leaf->getIndexedTriangle(t);
         BVTriangleStreamItem item;
         for( int v = 0; v < 3; v++ )
            item.vertices[v] = triangle.vertices[v];

         int remapValue = triangle.originalTriangleIndex;
         float2 remap;
         remap.x = (float) (remapValue % _vertexStreamX);
         remap.y = (float) (remapValue / _vertexStreamX);

         ioTriangles.push_back(item);
         ioTriangleRemaps.push_back(remap);
      }

      int firstTriangleIndexX = firstTriangleIndex % _triangleStreamX;
      int firstTriangleIndexY = firstTriangleIndex / _triangleStreamX;

      BVLeafStreamItem item;
      item.firstTriangleIndex.x = (float) firstTriangleIndexX;
      item.firstTriangleIndex.y = (float) firstTriangleIndexY;
      item.triangleCount = (float) triangleCount;
      item.successorIndex.x = inSuccessorID.x;
      item.successorIndex.y = - inSuccessorID.y;
      ioLeaves[leafIndex ] = item;

      int leafX = leafIndex % _leafStreamX;
      int leafY = leafIndex / _leafStreamX;

      Vec2f leafID;
      leafID.x = (float) -( leafX + 1 );
      leafID.y = (float) ( leafY + 1 );
      return leafID;
   }
   else
   {
      BVSplitNode* split = (BVSplitNode*) inNode;

      int splitIndex = (int) ioSplits.size();
      ioSplits.push_back( BVSplitStreamItem() );

      BoundingBox bounds = split->getBounds();
      int childCount = split->getChildCount();

      Vec2f childSuccessor = inSuccessorID;
      for( int c = 0; c < childCount; c++ )
      {
         BVNode* child = split->getIndexedChild(c);

         Vec2f childIndex = addNode( child, childSuccessor,
            ioTriangles, ioTriangleRemaps, ioSplits, ioLeaves );
         childSuccessor = childIndex;
      }

      BVSplitStreamItem item;
      item.bboxMin = bounds.minimum;
      item.bboxMax = bounds.maximum;
      item.successIndex = childSuccessor;
      item.failureIndex = inSuccessorID;
      ioSplits[splitIndex] = item;

      int splitX = splitIndex % _splitStreamX;
      int splitY = splitIndex / _splitStreamX;

      Vec2f splitID;
      splitID.x = (float) (splitX + 1);
      splitID.y = (float) (splitY + 1);
      return splitID;
   }
}

BVTreeAccelerator::BVTreeAccelerator()
{
   _query = brook::write_query::create();
}

void
BVTreeAccelerator::initialize(const AcceleratorOptions& inOptions)
{
   BVTreeOptions options;
   options.maximumLeafPrimitives = 8;

   uint32 triangleCount = (uint32) inOptions.scene->nTris();
   std::vector<BVTriangle> inputTris;
   inputTris.resize(triangleCount);

   for(uint32 t = 0; t < triangleCount; t++) {
      inputTris[t].vertices[0] = ((Vec3f*) inOptions.scene->vertices(0))[t];
      inputTris[t].vertices[1] = ((Vec3f*) inOptions.scene->vertices(1))[t];
      inputTris[t].vertices[2] = ((Vec3f*) inOptions.scene->vertices(2))[t];
   }

   BVTreeBuilder builder(options, triangleCount, &inputTris[0]);

   std::vector<BVTriangleStreamItem> triangles;
   std::vector<float2> triangleRemaps;
   std::vector<BVSplitStreamItem> splits;
   std::vector<BVLeafStreamItem> leaves;

   _vertexStreamX = inOptions.vertexStreamX;

   _triangleStreamX = 1024;
   _splitStreamX = 1024;
   _leafStreamX = 1024;

   BVNode* root = builder.getRootNode();

   _rootNodeIndex = addNode( root, Vec2f(0,0), triangles, triangleRemaps, splits, leaves );

   triangleCount = (int) triangles.size();
   int splitCount = (int) splits.size();
   int leafCount = (int) leaves.size();

   std::cout << "#bvh# Build:"
             << " #tris: " << triangleCount
             << " #splits: " << splitCount
             << " #leaves: " << leafCount
             << std::endl;

   _triangleStreamY = divideRoundUp( triangleCount, _triangleStreamX);
   _splitStreamY = divideRoundUp( splitCount, _splitStreamX);
   _leafStreamY = divideRoundUp( leafCount, _leafStreamX);

   triangles.resize(_triangleStreamX * _triangleStreamY);
   triangleRemaps.resize(_triangleStreamX * _triangleStreamY);
   splits.resize(_splitStreamX * _splitStreamY);
   leaves.resize(_leafStreamX * _leafStreamY);

   memset(&triangleRemaps[triangleCount], 0,
      (triangleRemaps.size() - triangleCount) * sizeof(float2));
   memset(&triangles[triangleCount], 0,
      (triangles.size() - triangleCount) * sizeof(BVTriangleStreamItem));
   memset(&splits[splitCount], 0,
      (splits.size() - splitCount) * sizeof(BVSplitStreamItem));
   memset(&leaves[leafCount], 0,
      (leaves.size() - leafCount) * sizeof(BVLeafStreamItem));

   _triangleStream = brook::stream::create<BV_Triangle>(_triangleStreamY, _triangleStreamX);
   _triangleStream.read(&triangles[0]);

   _triangleRemapStream = brook::stream::create<float2>(_triangleStreamY, _triangleStreamX);
   _triangleRemapStream.read(&triangleRemaps[0]);

   _splitStream = brook::stream::create<BV_Split>(_splitStreamY, _splitStreamX);
   _splitStream.read(&splits[0]);

   _leafStream = brook::stream::create<BV_Leaf>(_leafStreamY, _leafStreamX);
   _leafStream.read(&leaves[0]);

   _stateStreamX = _stateStreamY = 0;
}




/*
 * BVTreeAccelerator::createStateStreams --
 *
 *
 * Results:
 *      void.
 */

void
BVTreeAccelerator::createStateStreams(const brook::stream& inExampleStream) const
{
   using namespace brook;

   int imageW = inExampleStream->getExtents()[1];
   int imageH = inExampleStream->getExtents()[0];

   if(_stateStreamX != imageW || _stateStreamY != imageH) {
     _stateStreamX = imageW;
     _stateStreamY = imageH;

     allocateStateStreams();
   }
}


/*
 * BVTreeAccelerator::allocateStateStreams --
 *
 *      Actually allocates the member streams for traversal.  The only
 *      reason this is separate from createStateStreams() is so that the
 *      conditional subclass can override it.
 *
 * Results:
 *      void.
 */

void
BVTreeAccelerator::allocateStateStreams() const
{
   using namespace brook;

   _traversalStream =
      stream::create<BV_TraversalState>(_stateStreamY, _stateStreamX);
   _intersectStream =
      stream::create<BV_IntersectState>(_stateStreamY, _stateStreamX);

   _mask = write_mask::create(_stateStreamY, _stateStreamX);
   _maskStream = stream::create<float>(_stateStreamY, _stateStreamX);
}

/*
 * BVTreeAccelerator::intersect --
 *
 *      Entry-point to actually do traversal and intersection.  The stream
 *      of rays is passed in and then stream of hits is expected to filled
 *      in on exit.
 *
 * Results:
 *      void.
 */

void
BVTreeAccelerator::intersect(brook::stream& rayStream,
                             brook::stream& hitStream) const
{
   using namespace brook;

   _rayStream = rayStream;
   _hitStream = hitStream;
   createStateStreams(rayStream);

   static brook::write_query timingQuery = brook::write_query::create();
   timingQuery.begin();

   float startTime = Timer_GetMS();

   krnBV_Initialize( toFloat2( _rootNodeIndex ), _traversalStream, _intersectStream, _hitStream );


   int approximateTraverseCount = _stateStreamX * _stateStreamY;
   int approximateIntersectCount = 0;

   _mask.bind();
   _mask.enableTest();
   MAKE_MASK(_mask, krnBV_GenerateLiveMask(_traversalStream, _maskStream));
   for( int i = 0; ; i++ )
   {
      _mask.enableSet();
      _mask.clear();
      krnBV_GenerateSplitMask(_traversalStream, _maskStream);
      _mask.disableSet();

      for( int j = 0; j < 16; j++ )
      {
         krnBV_Split(
            _rayStream,
            _traversalStream, _hitStream,
            _splitStream,
            _traversalStream );
      }

      _mask.enableSet();
      _mask.clear();
      krnBV_GenerateLeafMask(_traversalStream, _maskStream);
      _mask.disableSet();

      krnBV_Leaf(
         _traversalStream, _intersectStream,
         _leafStream,
         _traversalStream, _intersectStream );

      _mask.enableSet();
      _mask.clear();
      krnBV_GenerateIntersectMask(_traversalStream, _intersectStream, _maskStream);
      _mask.disableSet();

      for( int j = 0; j < 16; j++ )
      {
         krnBV_Intersect(
            _rayStream,
            _intersectStream, _hitStream,
            _triangleStream,
            _intersectStream, _hitStream );
      }

      _mask.enableSet();
      _mask.clear();
      krnBV_GeneratePostIntersectMask(_traversalStream, _intersectStream, _maskStream);
      _mask.disableSet();

      krnBV_PostIntersect(
         _traversalStream, _intersectStream,
         _traversalStream, _intersectStream );

      MAKE_MASK(_mask, krnBV_GenerateLiveMask(_traversalStream, _maskStream));

      _query.begin();
      krnBV_GenerateLiveMask(_traversalStream, _maskStream);
      _query.end();

      if(_query.count() == 0) break;
   }
   _mask.disableTest();

   krnBV_Finalize(
      _traversalStream, _hitStream,
      _triangleRemapStream,
      _hitStream );

   timingQuery.end();
   timingQuery.wait();
   float endTime = Timer_GetMS();

   float totalTime = (endTime - startTime);
   PRINT(("#bvh# time: %fms\n", totalTime));
   PRINT(("#bvh# krays/s: %f\n", (_stateStreamX*_stateStreamY) / (totalTime)));
}

void BVTreeAccelerator::debugState() const
{
   static BV_TraversalState* traversalState = new BV_TraversalState[ _stateStreamX * _stateStreamY ];
   static BV_IntersectState* intersectState = new BV_IntersectState[ _stateStreamX * _stateStreamY ];
   static float4* hitState = new float4[ _stateStreamX * _stateStreamY ];

   _traversalStream.write( traversalState );
   _intersectStream.write( intersectState );
   _hitStream.write( hitState );

   std::cerr << "traverse: "
      << traversalState[0].x << ", "
      << traversalState[0].y << std::endl;
   std::cerr << "intersect: "
      << intersectState[0].x << ", "
      << intersectState[0].y << std::endl;
}

void
BVTreeAccelerator::timeKernels( brook::stream& rayStream ) const
{
}
