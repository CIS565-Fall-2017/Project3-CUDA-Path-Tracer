/* *************************************************************************
 * Copyright (C) 2004 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * streamTypes.h --
 *
 *      The structs / typedefs for kernel stream arguments.
 *
 *      Note: These can't just be dumped in a .brh file because they need to
 *      be included in both .br and C / C++ files.  That means they can't be
 *      in the same file as kernel declarations since those have to expand
 *      differently in each place.
 */

#ifndef __STREAMTYPES_H__
#define __STREAMTYPES_H__

//typedef float4 Hit;             // Packed as tHit, unused, 2D triangle idx
//typedef float4 Pixel;           // Really just RGBA
//typedef float3 Vertex;
//typedef float2 TriangleIndexIndex;
//typedef float2 TriangleIndex;
//#define KDTREE_USE_SHORTFIXED 1

#define POUND #
POUND define Hit float4
POUND define Pixel float4
POUND define Vertex float3
POUND define TriangleIndexIndex float2
POUND define TriangleIndex float2
POUND define RayState float4
POUND define GridTrilistOffset float2
POUND define GridTrilist float2
#ifdef KDTREE_USE_SHORTFIXED
POUND define KD_NodeIndex shortfixed2
#else
POUND define KD_NodeIndex float2
#endif
POUND define KD_TriangleIndex float2
POUND define KD_TriangleIndexIndex float2
POUND define BV_TraversalState float4

POUND define BV_IntersectState float4

#ifndef __cplusplus
#define Hit float4
#define Pixel float4
#define Vertex float3
#define TriangleIndexIndex float2
#define TriangleIndex float2
#define RayState float4
#define GridTrilistOffset float2
#define GridTrilist float2
#ifdef KDTREE_USE_SHORTFIXED
#define KD_NodeIndex shortfixed2
#else
#define KD_NodeIndex float2
#endif
#define KD_TriangleIndex float2
#define KD_TriangleIndexIndex float2
#define BV_TraversalState float4

#define BV_IntersectState float4


#endif
/*
 * RayState encodes whether a ray is traversing, intersecting, shading, or
 * dead (missed all scene geometry).  For an intersecting ray, it encodes
 * the index of the next triangle to test in the current voxel / cell.  See
 * the relevant #defines in the various .bri files for how each accelerator
 * interprets / encodes values.
 */


typedef struct ray_t {
  float3 o;
  float3 d;
} Ray;

typedef struct FloatTriangle_t {
   float v0;
   float v1;
   float v2;
} FloatTriangle;

typedef struct Float3Triangle_t {
   float3 v0;
   float3 v1;
   float3 v2;
} Float3Triangle;

/*
 * A ShadingHit stores 4 pieces of information:
 *
 *      position:       (x,y,z) where the ray hits a triangle
 *      time:           t value at which the ray hits
 *      normal:         The triangle normal interpolated to the hit point
 *      color:          The triangle color interpolated to the hit point
 *
 * The time is only used to indicate whether the ray hit the scene at all
 * and to encode certain error conditions.  If we were willing to shade all
 * misses as black, it wouldn't be necessary, but a float4's not any worse
 * than a float3 anyhow.
 */

typedef struct shadinghit_t {
  float4 position3_time1;
  float3 normal;
  float3 color;
  float4 specular3_exp;
} ShadingHit;


typedef struct traversaldatadyn_t {
  float3 tMax;     // t when exiting current voxel
  float3 voxNo;    //actually ints (current voxel for grid traversal)
  float3 voxToUse; //ints   (current voxel when intersecting tris)
} TraversalDataDyn;

typedef struct traversaldatastatic_t {
  float3 tDelta; // change in t from voxel to voxel
  float3 step;   // +/-1 only, change in voxel index
} TraversalDataStatic;


#endif
