/*
 * shadowshader.h --
 *
 *      Shader that draws the scene with point-lit shadows
 */

#ifndef __SHADOWSHADER_H__
#define __SHADOWSHADER_H__

#include <brook/brook.hpp>
#include "../fileIO/fileIO.h"
#include "shader.h"
#include "accelerator.h"

class IBaseRayIntersectorBrook;

class ShadowShader : public Shader
{
public:
   ShadowShader(IBaseRayIntersectorBrook *inIntersector) {
      _rayStreamX = _rayStreamY = 0;
      _intersector = inIntersector;
   }

   void shade(brook::stream& inputPixelStream, 
              brook::stream& shadingHitStream,
              const float3& lightPosition,
              const float3& attenConsts,
              const float3& diffColor,
              const float3& eyePos,
              brook::stream& pixelStream) const;

private:
   IBaseRayIntersectorBrook* _intersector;

   mutable int _rayStreamX, _rayStreamY;
   mutable brook::stream _shadowRayStream;
};

#endif
