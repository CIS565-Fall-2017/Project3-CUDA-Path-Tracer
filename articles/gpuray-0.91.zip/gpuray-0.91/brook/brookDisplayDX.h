/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * brookDisplayDX.h --
 *
 *      XXX
 */

#ifndef __BROOK_BROOKDISPLAYDX_H__
#define __BROOK_BROOKDISPLAYDX_H__

#include "brookDisplay.h"
#include "../renderContextDX.h"
class PixelDisplayerBrookDX9 : public IPixelDisplayerBrook
{
public:
   PixelDisplayerBrookDX9( RenderContextDX9* inRenderContext, BrookContext* inBrookContext );

   void Display( brook::stream& inPixelStream );
    
private:
   RenderContextDX9* _renderContext;

   IDirect3DVertexBuffer9* _vertexBuffer;
   IDirect3DVertexDeclaration9* _vertexDecl;
   IDirect3DVertexShader9* _vertexShader;
   IDirect3DPixelShader9* _pixelShader;
};
IDirect3DVertexShader9* createVertexShader(
   IDirect3DDevice9* inDevice,
   const std::string& inSource );
IDirect3DPixelShader9* createPixelShader(
   IDirect3DDevice9* inDevice,
   const std::string& inSource );
#endif
