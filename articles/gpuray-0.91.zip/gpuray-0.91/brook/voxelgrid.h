/*
 * voxelgrid.h --
 *
 *      The first actual acceleration structure used with the GPU based
 *      raytracer.  The voxel grid is just a rectangular uniform grid of the
 *      triangles in the scene.  Rays march through grid cells and only
 *      intersect whatever triangles are in a cell through which a live ray
 *      passes.
 */

#ifndef VOXELGRID_H
#define VOXELGRID_H

#include <brook/brook.hpp>

#include "accelerator.h"
#include "../fileIO/fileIO.h"
#include "tracerays.hpp"

class VoxelGridAccelerator :
   public Accelerator
{
public:
  void initialize( const AcceleratorOptions& inOptions );

  void intersect(brook::stream& rayStream, brook::stream& hitStream) const;
  void timeKernels(brook::stream& rayStream) const;

protected:
  void DumpLiveRays(RayState *states, brook::stream *travDatStat,
                    brook::stream *travDatDyn, int imageW, int imageH) const;
  Grid _grid;
  float3 _gridDim;
  int _maxIters;

  brook::stream _vertexPositionStream;
  brook::stream _trilist;
  brook::stream _listOffset;
  int _voxelStreamX, _voxelStreamY;
  float2 _voxelStreamConstant;
};

#endif
