/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * brookTracer.cpp --
 *
 *      Helper classes for ray-tracing with Brook
 */
#include "brookTracer.h"

#include "../log.h"
#include "bruteforce.h"
#include "voxelgrid.h"
#include "voxelgrid_conditional.h"
#include "kdtree.h"
#include "kdtree_conditional.h"
#include "bvh.h"
#include "../timer.h"
#include "simpleshader.h"
#include "shadowshader.h"
#include "tracerays.hpp"
#include "../cameraManager.h"
#include "brookDisplay.h"

VertexDataBrook::VertexDataBrook( Scene* inScene )
{
   _scene = inScene;

   // TIM: the triangle stream is 3x as wide as tall
   // since we linearize our triangles into it...
   int triCount = _scene->nTris();

   _vertexStreamX = 1024;
   _vertexStreamY = (triCount + (_vertexStreamX-1)) / _vertexStreamX;

   _positionStream =
      brook::stream::create<Float3Triangle>(_vertexStreamY, _vertexStreamX);
   _normalStream =
      brook::stream::create<Float3Triangle>(_vertexStreamY, _vertexStreamX);
   _colorStream =
      brook::stream::create<Float3Triangle>(_vertexStreamY, _vertexStreamX);

   std::vector<Float3Triangle> vertexStreamData;
   std::vector<Float3Triangle> normalStreamData;
   std::vector<Float3Triangle> colorStreamData;

   vertexStreamData.resize(_vertexStreamX * _vertexStreamY);
   normalStreamData.resize(_vertexStreamX * _vertexStreamY);
   colorStreamData.resize(_vertexStreamX * _vertexStreamY);

   memset(&vertexStreamData[0], 0, vertexStreamData.size() * sizeof(Float3Triangle));
   memset(&normalStreamData[0], 0, normalStreamData.size() * sizeof(Float3Triangle));
   memset(&colorStreamData[0], 0, colorStreamData.size() * sizeof(Float3Triangle));

   for( int tt = 0; tt < triCount; tt++ ) {
      vertexStreamData[tt].v0 = ((float3*) _scene->vertices(0))[ tt ];
      vertexStreamData[tt].v1 = ((float3*) _scene->vertices(1))[ tt ];
      vertexStreamData[tt].v2 = ((float3*) _scene->vertices(2))[ tt ];

      normalStreamData[tt].v0 = ((float3*) _scene->normals(0))[ tt ];
      normalStreamData[tt].v1 = ((float3*) _scene->normals(1))[ tt ];
      normalStreamData[tt].v2 = ((float3*) _scene->normals(2))[ tt ];

      colorStreamData[tt].v0 = ((float3*) _scene->colours(0))[ tt ];
      colorStreamData[tt].v1 = ((float3*) _scene->colours(1))[ tt ];
      colorStreamData[tt].v2 = ((float3*) _scene->colours(2))[ tt ];
   }
   _positionStream.read(&vertexStreamData[0]);
   _normalStream.read(&normalStreamData[0]);
   _colorStream.read(&colorStreamData[0]);

   if (_scene->specColours() != NULL) {
      _specularStream =
         brook::stream::create<Float3Triangle>(_vertexStreamY, _vertexStreamX);
      _specularExpStream =
         brook::stream::create<FloatTriangle>(_vertexStreamY, _vertexStreamX);

      std::vector<Float3Triangle> specData;
      std::vector<FloatTriangle> specExpData;

      specData.resize(_vertexStreamX * _vertexStreamY);
      specExpData.resize(_vertexStreamX * _vertexStreamY);

      memcpy(&specData[0], _scene->specColours(), triCount * sizeof(Float3Triangle));
      memcpy(&specExpData[0], _scene->specExps(), triCount * sizeof(FloatTriangle));

      _specularStream.read(&specData[0]);
      _specularExpStream.read(&specExpData[0]);
   } else {
      float filler[] = { -1.0f, -1.0f, -1.0f };

      _specularStream = brook::stream::create<Float3Triangle>(0,0);
      _specularExpStream = brook::stream::create<FloatTriangle>(1,1);
      _specularExpStream.read(&filler);
   }
}

RayGeneratorBrook::RayGeneratorBrook( CameraManager* inCameraManager, Scene* inScene,
                                     IBoundRayIntersectorBrook* inContinuation )
{
   _cameraManager = inCameraManager;
   _scene = inScene;
   _continuation = inContinuation;

   _currentStreamX = _currentStreamY = 0;
}

void RayGeneratorBrook::Generate( int inWidth, int inHeight )
{
   if( inWidth <= 0 || inHeight <= 0 )
      return;

   brook::bind();

   if( _currentStreamX != inWidth || _currentStreamY != inHeight )
   {
      _currentStreamX = inWidth;
      _currentStreamY = inHeight;

      _rayStream = brook::stream::create<Ray>( _currentStreamY, _currentStreamX );
   }

   brook::iter filmPosition(::brook::__BRTFLOAT2,
      inWidth, inHeight, -1, 1.0f, 1.0f, -1.0f, -1.0f, -1 );

   CameraInfo cameraInfo = _cameraManager->getSceneSpaceCameraInfo();

   PRINT(("Generating eye rays...\n"));
   krnGenEyeRays(
      toFloat3( cameraInfo.from ),
      toFloat3( cameraInfo.u ),
      toFloat3( cameraInfo.v ),
      toFloat3( cameraInfo.w ),
      float2(cameraInfo.tx, cameraInfo.ty),
      toFloat3( _scene->bboxMin() ),
      toFloat3( _scene->bboxMax() ),
      filmPosition,
      _rayStream );
   LOG_ONLY(DumpRays(_rayStream););

   _continuation->Intersect( _rayStream );

   brook::unbind();
}

/*
* RayGeneratorBrook::DumpRays --
*
*      Helper function to pretty print all the rays in a stream
*
* Returns:
*      void
*/

void
RayGeneratorBrook::DumpRays(brook::stream& rayStream)
{
   Ray *rays;
   int ii;

   int width = rayStream->getExtents()[1];
   int height = rayStream->getExtents()[0];

   rays = new Ray[height * width];
   rayStream.write(rays);
   for (ii = 0; ii < height * width; ii++) {
      LOG(("Ray[%d]: o(%5.2f, %5.2f, %5.2f)  d(%5.2f, %5.2f, %5.2f)\n", ii,
         rays[ii].o.x, rays[ii].o.y, rays[ii].o.z,
         rays[ii].d.x, rays[ii].d.y, rays[ii].d.z));
   }
   delete [] rays;
}

DefaultHitShaderBrook::DefaultHitShaderBrook(
                                 const Opts& inOptions,
                                 Scene* inScene,
                                 VertexDataBrook* inVertexData,
                                 CameraManager* inCameraManager,
                                 IBaseRayIntersectorBrook* inIntersector,
                                 IPixelDisplayerBrook* inContinuation )
{
   _scene = inScene;
   _vertexData = inVertexData;
   _cameraManager = inCameraManager;
   _continuation = inContinuation;

   _currentStreamX = _currentStreamY = 0;

   if (inOptions.shaderName == NULL ||
       strcmp(inOptions.shaderName, "simple") == 0) {
      _shader = new SimpleShader();
   } else if (strcmp(inOptions.shaderName, "shadow") == 0) {
      _shader = new ShadowShader( inIntersector );
   } else {
      fprintf(stderr, "Unknown shader: %s\n", inOptions.shaderName);
      Usage(inOptions.progName);
   }
}

void DefaultHitShaderBrook::Shade( brook::stream& inRayStream, brook::stream& inHitStream )
{
   int imageW = inRayStream->getExtents()[1];
   int imageH = inRayStream->getExtents()[0];

   if( _currentStreamX != imageW || _currentStreamY != imageH )
   {
      _currentStreamX = imageW;
      _currentStreamY = imageH;

      _shadingHitStream = brook::stream::create<ShadingHit>( _currentStreamY, _currentStreamX );
      _pixelStream = brook::stream::create<float4>( _currentStreamY, _currentStreamX );
   }

   PRINT(("Converting visibility hits to shading hits...\n"));
   float t = Timer_GetMS();
   krnShading_Hit2ShadingHit(
      inRayStream, inHitStream,
      _vertexData->getNormalStream(),
      _vertexData->getColorStream(),
      _vertexData->getSpecularStream(),
      _vertexData->getSpecularExponentStream(),
      _shadingHitStream );
   ::brook::finish();
   t = Timer_GetMS() - t;
   PRINT(("Conversion took %5.2f msecs.\n", t));


   PRINT(("Shading hits...\n"));
   t = Timer_GetMS();

   krnClearStream(_pixelStream);

   unsigned int lightCount = _scene->numLights();
   for( unsigned int ii = 0; ii < lightCount; ii++ )
   {
      LightInfo light = _scene->pointLight(ii);
      float3 lightPos = toFloat3( _cameraManager->getSceneTransformation().transformPoint(light.position) );
      float3 attenuation;
      attenuation.x = light.distAtten;

      LOG(("light pos: %3f %3f %3f\n", lightPos.x, lightPos.y, lightPos.z));
      LOG(("attenuation: %3f\n", attenuation.x));

      _shader->shade(_pixelStream, _shadingHitStream, lightPos, attenuation,
         toFloat3( light.diffIntensity ),
         toFloat3( _cameraManager->getSceneSpaceCameraInfo().from ), _pixelStream);
   }
   _pixelStream->synchronizeRenderData();

   t = Timer_GetMS() - t;
   PRINT(("Shading took %5.2f msecs.\n", t));

   _continuation->Display( _pixelStream );
}

DefaultBaseRayIntersectorBrook::DefaultBaseRayIntersectorBrook(
   const Opts& inOptions, Scene* inScene, VertexDataBrook* inVertexData )
{
   _currentStreamX = _currentStreamY = 0;

   const char* acceleratorName = inOptions.accelName;
   if (acceleratorName == NULL || strcmp(acceleratorName, "voxelgrid") == 0) {
      _rayIntersector = new VoxelGridAccelerator();
   } else if (strcmp(acceleratorName, "voxelgrid_conditional") == 0) {
      _rayIntersector = new VoxelGridConditionalAccelerator();
   } else if (strcmp(acceleratorName, "bruteforce") == 0) {
      _rayIntersector = new BruteForceAccelerator();
   } else if (strcmp(acceleratorName, "kdtree") == 0) {
      _rayIntersector = new KdTreeAccelerator();
   } else if (strcmp(acceleratorName, "kdtree_conditional") == 0) {
      _rayIntersector = new KdTreeConditionalAccelerator();
   } else if (strcmp(acceleratorName, "bvh") == 0) {
      _rayIntersector = new BVTreeAccelerator();
   } else {
      fprintf(stderr, "Unknown accelerator: %s\n", inOptions.accelName);
      Usage(inOptions.progName);
   }

   AcceleratorOptions acceleratorOptions;
   acceleratorOptions.opts = &inOptions;
   acceleratorOptions.scene = inScene;
   acceleratorOptions.vertexStreamX = inVertexData->getVertexStreamX();
   acceleratorOptions.vertexStreamY = inVertexData->getVertexStreamY();
   acceleratorOptions.positionStream = inVertexData->getPositionStream();
   _rayIntersector->initialize( acceleratorOptions );

   _triangleCount = inScene->nTris();
}

void DefaultBaseRayIntersectorBrook::Intersect( brook::stream& inRayStream, IHitShaderBrook* inContinuation )
{
   int imageW = inRayStream->getExtents()[1];
   int imageH = inRayStream->getExtents()[0];

   if( _currentStreamX != imageW || _currentStreamY != imageH )
   {
      _currentStreamX = imageW;
      _currentStreamY = imageH;

      _hitStream = brook::stream::create<Hit>( _currentStreamY, _currentStreamX );
   }

   PRINT(("Casting the rays (gpu)...\n"));
   float t = Timer_GetMS();
   _rayIntersector->intersect( inRayStream, _hitStream );
   brook::finish();
   t = Timer_GetMS() - t;
   LOG_ONLY(DumpHits(_hitStream););
   PRINT(("Raycasting took %5.2f msecs (%5.2f fps) for %d rays and %d triangles.\n",
      t, 1000.0f / t, imageW * imageH, _triangleCount));
   PRINT(("%5.f rays per second (%.2f usecs per ray).\n",
      1000.0 * imageW * imageH / t,
      t * 1000.0 / imageW / imageH));

   inContinuation->Shade( inRayStream, _hitStream );
}

/*
* DefaultBaseRayIntersectorBrook::DumpHits --
*
*      Helper function that prints out all rays that hit.
*
* Returns:
*      void
*/

void
DefaultBaseRayIntersectorBrook::DumpHits(brook::stream& hitStream)
{
   Hit *hits;
   int ii;

   int width = hitStream->getExtents()[1];
   int height = hitStream->getExtents()[0];

   hits = new Hit[ height * width ];
   hitStream.write(hits);
   for (ii = 0; ii < height * width; ii++) {
      if (hits[ii].w >= 0) {
         LOG(("Ray[%d] hit triangle %.f at uv <%f, %f> at time %f\n",
            ii, hits[ii].w, hits[ii].y, hits[ii].z, hits[ii].x ));
      }
   }
}

BoundRayIntersectorBrook::BoundRayIntersectorBrook(
   IBaseRayIntersectorBrook* inIntersector, IHitShaderBrook* inContinuation )
{
   _intersector = inIntersector;
   _continuation = inContinuation;
}

void BoundRayIntersectorBrook::Intersect( brook::stream& inRayStream )
{
   _intersector->Intersect( inRayStream, _continuation );
}

TracerBrook::TracerBrook(
   ITracer* inInnerTracer, 
   CachedPixelDisplayerBrook* inDisplayContinuation )
{
   _innerTracer = inInnerTracer;
   _displayContinuation = inDisplayContinuation;
}

void TracerBrook::Resize( int inWidth, int inHeight ) {
   _innerTracer->Resize( inWidth, inHeight );
}

void TracerBrook::TraceRays()
{
   _innerTracer->TraceRays();
}

void TracerBrook::Display()
{
   _displayContinuation->Display();
}
