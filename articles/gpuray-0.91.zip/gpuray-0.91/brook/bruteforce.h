/*
 * bruteforce.h --
 *
 *      The simplest 'acceleration' structure: none.  The bruteforce
 *      approach just intersects every ray with every triangle and finds the
 *      first hit.
 */

#ifndef BRUTEFORCE_H
#define BRUTEFORCE_H

#include <brook/brook.hpp>
#include "accelerator.h"
#include "../fileIO/fileIO.h"

class BruteForceAccelerator : public Accelerator
{
public:
   void initialize( const AcceleratorOptions& inOptions );

   void intersect(brook::stream& rayStream, brook::stream& hitStream) const;
   void timeKernels(brook::stream& rayStream) const;

private:
   int _triangleCount;
   int _vertexStreamX;
   float3* _v0;
   float3* _v1;
   float3* _v2;
};

#endif
