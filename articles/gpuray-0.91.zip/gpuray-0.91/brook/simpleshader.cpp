/*
 * simpleshader.cpp --
 *
 *      Shader that draws the scene with unshadowed diffuse lighting
 */

#include "simpleshader.h"
#include "tracerays.hpp"

void SimpleShader::shade(brook::stream& inputPixelStream,
                         brook::stream& shadingHits,
                         const float3& lightPos,
                         const float3& attenConsts,
                         const float3& diffColor,
                         const float3& eyePos,
                         brook::stream& pixels) const
{
   krnShading_ShadeSimpleHits(inputPixelStream, shadingHits, lightPos, 
      attenConsts, diffColor, eyePos, pixels);
}
