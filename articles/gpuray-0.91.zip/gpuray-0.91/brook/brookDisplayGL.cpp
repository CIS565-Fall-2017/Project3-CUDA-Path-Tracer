/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * brookDisplayGL.cpp --
 *
 *      XX
 */
#include "brookDisplayGL.h"

#include <windows.h>
#include <GL/gl.h>

#include "../nv-glext.h"
#include "../renderContextGL.h"

#define CHECK_GL()      (CheckGL(__FILE__, __LINE__))

#define GETPROCADDR(type, name) do { \
   if ((name = (type) wglGetProcAddress(#name)) == NULL) { \
   fprintf(stderr, "Unable to find symbol %s\n", name); \
   } } while(0)

/*
* A fragment program of some sort appears to be mandatory with NV hardware
* and float textures.  This extremely simple shader just fetches from
* texture[0] using texCoord[0].  Not rocket science.
*/

static char fp_tex[] = "!!ARBfp1.0\n"
"TEX result.color,"
"    fragment.texcoord[0], texture[0], RECT;\n"
"END\n";

PixelDisplayerBrookOGL::PixelDisplayerBrookOGL( RenderContextOGL* inRenderContext, BrookContext* inBrookContext )
{
   _renderContext = inRenderContext;

   _renderContext->bind();

   GETPROCADDR(PFNGLGENPROGRAMSARBPROC, glGenProgramsARB);
   GETPROCADDR(PFNGLPROGRAMSTRINGARBPROC, glProgramStringARB);
   GETPROCADDR(PFNGLBINDPROGRAMARBPROC, glBindProgramARB);
   GETPROCADDR(PFNGLDELETEPROGRAMSARBPROC, glDeleteProgramsARB);
   GETPROCADDR(PFNGLISPROGRAMARBPROC, glIsProgramARB);

   /*
   * We create the fp here, *after* brook is initialized.
   * Otherwise, our program gets clobbered.
   */
   glGenProgramsARB(1, &_fpID);
   glBindProgramARB(GL_FRAGMENT_PROGRAM_ARB, _fpID);
   glProgramStringARB(GL_FRAGMENT_PROGRAM_ARB, GL_PROGRAM_FORMAT_ASCII_ARB,
      strlen(fp_tex), fp_tex);
}

void PixelDisplayerBrookOGL::Display( brook::stream& inPixelStream )
{
   int width = inPixelStream->getExtents()[1];
   int height = inPixelStream->getExtents()[0];

   GLuint imageTex = (GLuint) (inPixelStream->getIndexedFieldRenderData(0));

   _renderContext->bind();

   glDrawBuffer(GL_BACK);
   glBindTexture(GL_TEXTURE_RECTANGLE_EXT, imageTex);
   glEnable(GL_TEXTURE_RECTANGLE_EXT);

   glBindProgramARB(GL_FRAGMENT_PROGRAM_ARB, _fpID);
   glEnable(GL_FRAGMENT_PROGRAM_ARB);

   glColor3f(1, 1, 1);
   glClearColor( 1.0, 1.0, 0.0, 0.0 );
   glClear(GL_COLOR_BUFFER_BIT);
   //   CHECK_GL();

   glBegin(GL_QUADS);
   glTexCoord2d(0, height);
   glVertex2f(-1.0f, -1.0f);

   glTexCoord2d(width, height);
   glVertex2f(1.0f, -1.0f);

   glTexCoord2d(width, 0);
   glVertex2f(1.0f, 1.0f);

   glTexCoord2d(0, 0);
   glVertex2f(-1.0f, 1.0f);
   glEnd();

   _renderContext->swap();
}
