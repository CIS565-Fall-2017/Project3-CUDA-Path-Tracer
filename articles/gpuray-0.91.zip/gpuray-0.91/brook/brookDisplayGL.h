/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * brookDisplayGL.h --
 *
 *      XXX
 */

#ifndef __BROOK_BROOKDISPLAYGL_H__
#define __BROOK_BROOKDISPLAYGL_H__

#include <windows.h>
#include <GL/gl.h>

#include "brookDisplay.h"
#include "../renderContextGL.h"
#include "../nv-glext.h"

class PixelDisplayerBrookOGL : public IPixelDisplayerBrook
{
public:
   PixelDisplayerBrookOGL( RenderContextOGL* inRenderContext, BrookContext* inBrookContext );

   void Display( brook::stream& inPixelStream );

private:
   RenderContextOGL* _renderContext;

   unsigned int _fpID;

   PFNGLGENPROGRAMSARBPROC glGenProgramsARB;
   PFNGLPROGRAMSTRINGARBPROC glProgramStringARB;
   PFNGLBINDPROGRAMARBPROC glBindProgramARB;
   PFNGLDELETEPROGRAMSARBPROC glDeleteProgramsARB;
   PFNGLISPROGRAMARBPROC glIsProgramARB;
};

#endif
