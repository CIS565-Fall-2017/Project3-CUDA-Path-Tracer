/*
 * voxelgrid_conditional.cpp --
 *
 */
#include "voxelgrid_conditional.h"

#include "../timer.h"
#include "../log.h"
#include "brookTracer.h"
#include "voxelkernels.hpp"

enum VoxelQueryType
{
   kVoxelQueryType_None = -1,
   kVoxelQueryType_Traverse = 0,
   kVoxelQueryType_Intersect,
   kVoxelQueryTypeCount
};


/*
* VoxelGridConditionalAccelerator::VoxelGridConditionalAccelerator --
*
*     Initializes member variables of the accelerator
*     that can be set before the initialize() method is called.
*
*/

VoxelGridConditionalAccelerator::VoxelGridConditionalAccelerator()
{
   _rayStreamX = _rayStreamY = 0;

   using namespace brook;

   for( int i = 0; i < kQueryCount; i++ )
      _queries[i] = write_query::create();
}

/*
* VoxelGridConditionalAccelerator::intersect --
*
*     Intersects the rays given in rayStream (with elements
*     of type Ray) against the triangles stored in this
*     accelerator, storing the results in the hitStream
*     (with elements of type Hit).
*
* Returns:
*     A stream of Hits which detail the first hit
*     if any for each input ray.
*/

void
VoxelGridConditionalAccelerator::intersect(brook::stream& rayStream,
                                           brook::stream& hitStream ) const
{
   using namespace brook;

   int ii;

   createRayStreams( rayStream );

   static brook::write_query timingQuery = brook::write_query::create();
   timingQuery.begin();
   float startTime = Timer_GetMS();
   float traverseTime = 0;
   float intersectTime = 0;

   stream rays = rayStream;
   stream travDatStatic = _travDatStatic;

   stream rayStates = _rayStates;
   stream maskStream = _maskStream;

   stream hits = hitStream;

   stream candidateHits = _candidateHits;
   stream travDatDyn = _travDatDyn;

   VoxelQueryType queryTypes[kQueryCount];
   for( ii = 0; ii < kQueryCount; ii++ )
      queryTypes[ii] = kVoxelQueryType_None;

   uint32 queryTotals[ kVoxelQueryTypeCount ];
   for( ii = 0; ii < kVoxelQueryTypeCount; ii++ )
      queryTotals[ii] = 0;


   /*
   * Set .x (which is ray t) to HUGE so that any true hits will have a lower
   * t (i.e. happen closer to the eye position).
   */
   krnVoxel_Float4Set(float4(999999, -1, -1, -1), hits);

   /*
   * The actual ray tracing loop:
   */

   krnVoxel_SetupTraversal(rays,
                           toFloat3(_grid.min), toFloat3(_grid.max),
                           toFloat3(_grid.vsize), _gridDim,
                           travDatDyn, travDatStatic, rayStates);

   _mask.bind();
   _mask.enableTest();

   uint32 approximateItemCounts[ kVoxelQueryTypeCount ];
   for( ii = 0; ii < kVoxelQueryTypeCount; ii++ )
      approximateItemCounts[ii] = 0;
   approximateItemCounts[kVoxelQueryType_Traverse] = _rayStreamX*_rayStreamY;

   uint32 switchTraverseToIntersectFactor = 2;
   uint32 switchIntersectToTraverseFactor = 2;

   uint32 traverseIterations = 0;
   uint32 intersectIterations = 0;

   int queryIndex = 0;
   for (ii = 0; ii < _maxIters; ii++) {
      bool firstQuery;
      bool traverseWorkDone = false;
      bool intersectWorkDone = false;

      float startTraverseTime = Timer_GetMS();

      _mask.enableSet();
      _mask.clear();
      krnVoxel_GenerateTraverseMask( rayStates, _maskStream );
      _mask.disableSet();

      firstQuery = true;
      while( true )
      {
         if( queryTypes[queryIndex] == kVoxelQueryType_Traverse )
         {
            uint32 count = _queries[queryIndex].count();

            if( firstQuery )
            {
               firstQuery = false;
               if( count != 0 )
                  traverseWorkDone = true;
            }
            else
            {
               approximateItemCounts[ kVoxelQueryType_Intersect ] += approximateItemCounts[ kVoxelQueryType_Traverse ] - count;
            }
         }
         if( queryTypes[queryIndex] != kVoxelQueryType_None )
         {
            uint32 count = _queries[queryIndex].count();
            approximateItemCounts[queryTypes[queryIndex]] = count;
            queryTotals[queryTypes[queryIndex]] += count;
            queryTypes[queryIndex] = kVoxelQueryType_None;
         }
         if( approximateItemCounts[ kVoxelQueryType_Traverse ]*switchTraverseToIntersectFactor
            <= approximateItemCounts[ kVoxelQueryType_Intersect ] )
         {
            break;
         }

         _queries[queryIndex].begin();
         krnVoxel_TraverseVoxel(travDatStatic, travDatDyn, rayStates,
                                _listOffset, _gridDim, travDatDyn,
                                rayStates, _voxelStreamConstant );
         _queries[queryIndex].end();
         queryTypes[queryIndex] = kVoxelQueryType_Traverse;
         queryIndex = (queryIndex + 1) % kQueryCount;
         traverseIterations++;

         _mask.enableSet();
         krnVoxel_GenerateTraverseMask( rayStates, _maskStream );
         _mask.disableSet();
      }

      traverseTime += Timer_GetMS() - startTraverseTime;

      float startIntersectTime = Timer_GetMS();

      _mask.enableSet();
      _mask.clear();
      krnVoxel_GenerateIntersectMask( rayStates, _maskStream );
      _mask.disableSet();

      krnVoxel_Intersect(rays, _vertexPositionStream,
                         toFloat3(_grid.min), toFloat3(_grid.vsize),
                         hits, travDatDyn, rayStates, _trilist,
                         hits, rayStates);

      firstQuery = true;
      while( true )
      {
         if( queryTypes[queryIndex] == kVoxelQueryType_Intersect )
         {
            uint32 count = _queries[queryIndex].count();

            if( firstQuery )
            {
               firstQuery = false;
               if( count != 0 )
                  intersectWorkDone = true;
            }
            else
            {
               approximateItemCounts[ kVoxelQueryType_Traverse ] += approximateItemCounts[ kVoxelQueryType_Intersect ] - count;
            }

         }
         if( queryTypes[queryIndex] != kVoxelQueryType_None )
         {
            uint32 count = _queries[queryIndex].count();
            approximateItemCounts[queryTypes[queryIndex]] = count;
            queryTotals[queryTypes[queryIndex]] += count;
            queryTypes[queryIndex] = kVoxelQueryType_None;
         }
         if( approximateItemCounts[ kVoxelQueryType_Intersect ]*switchIntersectToTraverseFactor
            <= approximateItemCounts[ kVoxelQueryType_Traverse ] )
         {
            break;
         }

         _queries[queryIndex].begin();
         krnVoxel_Intersect(rays, _vertexPositionStream,
                            toFloat3(_grid.min), toFloat3(_grid.vsize),
                            hits, travDatDyn, rayStates, _trilist,
                            hits, rayStates);
         _queries[queryIndex].end();
         queryTypes[queryIndex] = kVoxelQueryType_Intersect;
         queryIndex = (queryIndex + 1) % kQueryCount;
         intersectIterations++;

         _mask.enableSet();
         krnVoxel_GenerateIntersectMask( rayStates, _maskStream );
         _mask.disableSet();
      }

      intersectTime += Timer_GetMS() - startIntersectTime;

      if( !traverseWorkDone && !intersectWorkDone )
         break;
   }
   _mask.disableTest();

   while( queryTypes[queryIndex] != kVoxelQueryType_None )
   {
      queryTotals[queryTypes[queryIndex]] += _queries[queryIndex].count();
      queryTypes[queryIndex] = kVoxelQueryType_None;
      queryIndex = (queryIndex + 1) % kQueryCount;
   }

   // put the result data into the buffer provided
   hitStream = hits;

   timingQuery.end();
   timingQuery.wait();
   float endTime = Timer_GetMS();

   float totalTime = (endTime - startTime);
   int traverseItems = (int) queryTotals[ kVoxelQueryType_Traverse ];
   int intersectItems = (int) queryTotals[ kVoxelQueryType_Intersect ];

   PRINT(("#voxel# time: %fms\n", totalTime));
   PRINT(("#voxel# krays/s: %f\n", (_rayStreamX*_rayStreamY) / (totalTime)));

   PRINT(("#voxel# traverse iterations: %d\n", (int) traverseIterations));
   PRINT(("#voxel# intersect iterations: %d\n", (int) intersectIterations));
   PRINT(("#voxel# traverse items: %d\n", (int) traverseItems));
   PRINT(("#voxel# intersect items: %d\n", (int) intersectItems));
   PRINT(("#voxel# traverse time: %fms (%fms/iteration, %fns/item)\n",
      traverseTime, traverseTime/traverseIterations, 1000*1000*traverseTime/traverseItems));
   PRINT(("#voxel# intersect time: %fms (%fms/iteration, %fns/item)\n",
      intersectTime, intersectTime/intersectIterations, 1000*1000*intersectTime/intersectItems));
}

/*
* VoxelGridConditionalAccelerator::createRayStreams --
*
*     Updates all internally-cached streams of
*     this accelerator to match the shape of
*     the supplied template stream. This operation
*     is logically const even though it modififes
*     the cached stream members.
*/

void
VoxelGridConditionalAccelerator::createRayStreams( const brook::stream& inRayStream ) const
{
   using namespace brook;

   int imageW, imageH;

   imageW = inRayStream->getExtents()[1];
   imageH = inRayStream->getExtents()[0];

   if( imageW != _rayStreamX || imageH != _rayStreamY )
   {
      _rayStreamX = imageW;
      _rayStreamY = imageH;

      _travDatStatic = stream::create<TraversalDataStatic>(imageH, imageW);
      _rayStates = stream::create<RayState>(imageH, imageW);
      _maskStream = stream::create<float>(imageH, imageW);
      _candidateHits = stream::create<Hit>(imageH, imageW);
      _travDatDyn = stream::create<TraversalDataDyn>(imageH, imageW);

      _mask = write_mask::create( imageH, imageW );
   }
}

