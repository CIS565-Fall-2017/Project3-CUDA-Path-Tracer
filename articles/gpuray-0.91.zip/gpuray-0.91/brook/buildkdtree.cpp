/*
 * buildkdtree.cpp --
 *
 *      Implementation of k-d tree construction
 */

#include "buildkdtree.h"

#include <assert.h>
#include <algorithm>

#include "../common/commonTypes.h"
#include "../timer.h"
#include "../log.h"
#include "../builder/trianglePrimitives.h"

inline int Round2Int( double inValue ) {
  return (int) (inValue+(.5-1.4e-11));
}

inline int Log2Int(float v) {
   return ((*(int *) &v) >> 23) - 127;
}

struct BoundEdge {
   BoundEdge() {}

   BoundEdge( float inTime, int inPrimitiveIndex, bool inIsStart ) {
      time = inTime;
      primitiveIndex = inPrimitiveIndex;
      type = inIsStart ? START : END;
   }

   bool operator<( const BoundEdge& inEdge ) const {
      if( time == inEdge.time )
         return (int) type < (int) inEdge.type;
      else return time < inEdge.time;
   }

   float time;
   int primitiveIndex;
   enum { START, END } type;
};



float KdTreeTriangle::getSurfaceArea() const
{
   // Get triangle vertices in _p1_, _p2_, and _p3_
   const Vec3f &p1 = vertices[0];
   const Vec3f &p2 = vertices[1];
   const Vec3f &p3 = vertices[2];
   return 0.5f * length( cross(p2-p1, p3-p1) );
}


Vec3f KdTreeTriangle::getNormal() const
{
   const Vec3f &p1 = vertices[0];
   const Vec3f &p2 = vertices[1];
   const Vec3f &p3 = vertices[2];
   return normalize( cross(p2-p1, p3-p1) );
}


BoundingBox KdTreeTriangle::getBounds() const
{
   return join(BoundingBox(vertices[0], vertices[1]), vertices[2]);
}


KdTreeOptions::KdTreeOptions()
{
   intersectCost = 80;
   traversalCost = 1;
   emptyBonus = 0.5f;
   maximumLeafPrimitives = 1;
   maximumDepth = -1;

   useNewBuilder = false;
}


LeafNode::LeafNode( const BoundingBox& inBounds, const KdTreeTriangle* inPrimitives, const int* inPrimitiveIndices, int inPrimitiveCount )
{
  setIsLeaf( true );


  BoundingBox contentBounds;

  _primitives.reserve( inPrimitiveCount );
  _primitiveIndices.reserve( inPrimitiveCount );
  for( int i = 0; i < inPrimitiveCount; i++ )
  {
    int index = inPrimitiveIndices[i];
    const KdTreeTriangle* primitive = inPrimitives + index;

    _primitiveIndices.push_back( index );
    _primitives.push_back( primitive );

    contentBounds = join( contentBounds, primitive->getBounds() );
  }

  BoundingBox bounds = inBounds;
  setWorldBounds( bounds );
}


float LeafNode::getPrimitiveSurfaceArea()
{
  float result = 0.0f;

  uint32 primitiveCount = getPrimitiveCount();
  for( uint32 p = 0; p < primitiveCount; p++ )
  {
    const KdTreeTriangle* primitive = getIndexedPrimitive( p );
    result += primitive->getSurfaceArea();
  }

  return result;
}


Vec3f LeafNode::getPrimitiveDirectedSurfaceArea()
{
  Vec3f result( 0, 0, 0 );

  uint32 primitiveCount = getPrimitiveCount();
  for( uint32 p = 0; p < primitiveCount; p++ )
  {
    const KdTreeTriangle* primitive = getIndexedPrimitive( p );

    float surfaceArea = primitive->getSurfaceArea();
    Vec3f surfaceNormal = primitive->getNormal();

    for( int i = 0; i < 3; i++ )
      surfaceNormal[i] = fabsf( surfaceNormal[i] );

    result += surfaceArea * surfaceNormal;
  }

  return result;

}


InternalNode::InternalNode(
  const BoundingBox& inBounds, int inSplitAxis, float inSplitValue, int inLeftChildIndex, int inRightChildIndex )
{
  setIsLeaf( false );
  setWorldBounds( inBounds );

  _splitAxis = inSplitAxis;
  _splitValue = inSplitValue;
  _leftChildIndex = inLeftChildIndex;
  _rightChildIndex = inRightChildIndex;
}


KdTreeBuilder::KdTreeBuilder( const Opts& cmdLine, const KdTreeOptions& inOptions, const Scene *scene, uint32 inTriangleCount, const KdTreeTriangle* inTriangles )
{
   _options = inOptions;

   _triangleCount = inTriangleCount;
   _triangles = new KdTreeTriangle[ _triangleCount ];
   for( uint32 t = 0; t < _triangleCount; t++ )
      _triangles[t] = inTriangles[t];

   if( _options.useNewBuilder )
   {
      constructFromNewBuilder( cmdLine, scene );
   }
   else
   {
      if( _options.maximumDepth <= 0 )
         _options.maximumDepth = Round2Int( 8 + 1.3f * Log2Int( (float) _triangleCount ) );
      int maximumDepth = _options.maximumDepth;

      std::vector< BoundingBox > triangleBounds;
      triangleBounds.reserve( _triangleCount );
      for( uint32 i = 0; i < _triangleCount; i++ )
      {
         BoundingBox bounds = _triangles[i].getBounds();
         triangleBounds.push_back( bounds );
      }

      _worldBounds = triangleBounds[0];
      for( uint32 i = 1; i < _triangleCount; i++ )
      {
         _worldBounds = join( _worldBounds, triangleBounds[i] );
      }

      BoundEdge* edges[3];
      for( int i = 0; i < 3; i++ )
         edges[i] = new BoundEdge[ 2 * _triangleCount ];
      int* triangles0 = new int[ _triangleCount ];
      int* triangles1 = new int[ (maximumDepth+1) * _triangleCount ];

      int* triangleIndices = new int[ _triangleCount ];
      for( uint32 i = 0; i < _triangleCount; i++ )
         triangleIndices[i] = i;

      buildNode( _worldBounds, triangleBounds, triangleIndices,
         _triangleCount, maximumDepth, edges, triangles0, triangles1 );

      delete[] triangleIndices;
      for( int i = 0; i < 3; i++ )
         delete[] edges[i];
      delete[] triangles0;
      delete[] triangles1;
   }

   int nodeCounter = 0;
   int leafCounter = 0;
   int splitCounter = 0;

   uint32 nodeCount = getNodeCount();
   for( uint32 n = 0; n < nodeCount; n++ )
   {
      Node* node = getIndexedNode(n);
      int nodeIndex = nodeCounter++;
      node->setNodeIndex( nodeIndex );
      if( node->isLeaf() )
      {
         ((LeafNode*) node)->setLeafIndex( leafCounter++ );
      }
      else
      {
         InternalNode* split = ((InternalNode*) node);

         split->setSplitIndex( splitCounter++ );
         getIndexedNode(split->getLeftChildIndex())->setParentIndex( nodeIndex, kChildType_Left);
         getIndexedNode(split->getRightChildIndex())->setParentIndex( nodeIndex, kChildType_Right);
      }
   }
   getIndexedNode(0)->setParentIndex(-1,kChildType_None);
}


uint32 KdTreeBuilder::getNodeCount()
{
   return _nodes.size();
}


Node* KdTreeBuilder::getIndexedNode( uint32 inIndex )
{
   return _nodes[ inIndex ];
}

void KdTreeBuilder::constructFromNewBuilder( const Opts& cmdLine, const Scene *scene )
{
   std::vector<TrianglePrimitive> triangles;
   for( uint32 t = 0; t < _triangleCount; t++ )
   {
      TrianglePrimitive triangle;
      for( int v = 0; v < 3; v++ )
         triangle.vertices[v] = *((Vec3f*) &(_triangles[t].vertices[v]));
      triangles.push_back( triangle );
   }

   TrianglePrimitives primitives( triangles.size(), &triangles[0] );
   //KDTree* newTree = buildKdTree( _options.newOptions, &primitives );
   KDTree* newTree = KDTree_Create( cmdLine, *scene, _options.newOptions );

   BoundingBox bounds = newTree->getBounds();
   _worldBounds = bounds;

   int nodeCount = newTree->getNodeCount();
   _nodes.resize( nodeCount );

   for( int n = 0; n < nodeCount; n++ )
   {
      KDTreeNode node = newTree->getNodes()[ n ];

      if( (node.leaf.numPrimitives & 0x3) == 0x3 )
      {
         // leaf
         int numPrimitives = node.leaf.numPrimitives >> 2;
         int firstPrimitive = node.leaf.firstPrimitive;

         _nodes[n] = new LeafNode( _worldBounds, _triangles, newTree->getPrimitiveIndices() + firstPrimitive, numPrimitives );
      }
      else
      {
         // split
         float splitValue = node.split.splitValue;
         int splitAxis = node.split.leftChild & 0x3;
         int leftChild = node.split.leftChild >> 2;
         int rightChild = leftChild + 1;

         _nodes[n] = new InternalNode( _worldBounds, splitAxis, splitValue, leftChild, rightChild );
      }
   }
   buildNodeBounds( _nodes[0], _worldBounds );
}

int KdTreeBuilder::buildNode( const BoundingBox& inNodeBounds,
  const std::vector<BoundingBox>& inPrimitiveBounds,
  int* inPrimitiveIndices, int inPrimitiveCount,
  int inDepth, BoundEdge* ioEdges[3],
  int* ioPrimitives0, int* ioPrimitives1, int inBadRefines )
{
  int nodeIndex = (int) _nodes.size();
  _nodes.push_back( NULL );

  if( inPrimitiveCount <= _options.maximumLeafPrimitives || inDepth == 0 )
  {
    _nodes[nodeIndex] = new LeafNode( inNodeBounds, _triangles, inPrimitiveIndices, inPrimitiveCount );
    return nodeIndex;
  }

  int badRefines = inBadRefines;

  int bestAxis = -1, bestOffset = -1;
  float bestCost = FLT_MAX;

  float oldCost = _options.intersectCost * float(inPrimitiveCount);

  Vec3f d = inNodeBounds.maximum - inNodeBounds.minimum;
  float totalSurfaceArea = (2.0f * (d.x*d.y + d.x*d.z + d.y*d.z));
  float inverseTotalSurfaceArea = 1.0f / totalSurfaceArea;

  // choose axis
  int axis;
  if( d.x > d.y && d.x > d.z ) axis = 0;
  else axis = (d.y > d.z) ? 1 : 2;

  int retries = 0;
retrySplit:
  for( int i = 0; i < inPrimitiveCount; i++ )
  {
    int primitiveIndex = inPrimitiveIndices[i];
    const BoundingBox& bounds = inPrimitiveBounds[ primitiveIndex ];

    ioEdges[axis][2*i] = BoundEdge( bounds.minimum[axis], primitiveIndex, true );
    ioEdges[axis][2*i+1] = BoundEdge( bounds.maximum[axis], primitiveIndex, false );
  }
  std::sort( &ioEdges[axis][0], &ioEdges[axis][2*inPrimitiveCount] );

  int belowCount = 0, aboveCount = inPrimitiveCount;
  for( int i = 0; i < 2*inPrimitiveCount; i++ )
  {
    if( ioEdges[axis][i].type == BoundEdge::END )
      --aboveCount;

    float edgeT = ioEdges[axis][i].time;
    if( edgeT > inNodeBounds.minimum[axis] && edgeT < inNodeBounds.maximum[axis] )
    {
      // compute split cost
      int otherAxis[3][2] = { {1,2}, {0,2}, {0,1} };
      int otherAxis0 = otherAxis[axis][0];
      int otherAxis1 = otherAxis[axis][1];

      float belowSurfaceArea = 2 * (d[otherAxis0] * d[otherAxis1]
        + (edgeT - inNodeBounds.minimum[axis])
        * (d[otherAxis0] + d[otherAxis1]));

      float aboveSurfaceArea = 2 * (d[otherAxis0] * d[otherAxis1]
        + (inNodeBounds.maximum[axis] - edgeT)
        * (d[otherAxis0] + d[otherAxis1]));

      float pBelow = belowSurfaceArea * inverseTotalSurfaceArea;
      float pAbove = aboveSurfaceArea * inverseTotalSurfaceArea;

      float emptyBonus = (aboveCount == 0 || belowCount == 0) ? _options.emptyBonus : 0.0f;
      float cost = _options.traversalCost + _options.intersectCost * (1.0f - emptyBonus)
        * (pBelow * belowCount + pAbove * aboveCount);

      if( cost < bestCost )
      {
        bestCost = cost;
        bestAxis = axis;
        bestOffset = i;
      }
    }

    if( ioEdges[axis][i].type == BoundEdge::START )
      ++belowCount;
  }

  assert( belowCount == inPrimitiveCount && aboveCount == 0 );

  if( bestAxis == -1 && retries < 2 )
  {
    ++retries;
    axis = (axis+1) % 3;
    goto retrySplit;
  }
  if( bestCost > oldCost ) ++badRefines;
  if( (bestCost > 4.0f * oldCost && inPrimitiveCount < 16)
    || bestAxis == -1 || badRefines == 3 )
  {
    _nodes[nodeIndex] = new LeafNode( inNodeBounds, _triangles, inPrimitiveIndices, inPrimitiveCount );
    return nodeIndex;
  }

  int n0 = 0, n1 = 0;
  for( int i = 0; i < bestOffset; i++ )
    if( ioEdges[bestAxis][i].type == BoundEdge::START )
      ioPrimitives0[n0++] = ioEdges[bestAxis][i].primitiveIndex;
  for( int i = bestOffset+1; i < 2*inPrimitiveCount; i++ )
    if( ioEdges[bestAxis][i].type == BoundEdge::END )
      ioPrimitives1[n1++] = ioEdges[bestAxis][i].primitiveIndex;

  float tsplit = ioEdges[bestAxis][bestOffset].time;

  BoundingBox bounds0 = inNodeBounds;
  BoundingBox bounds1 = inNodeBounds;
  bounds0.maximum[bestAxis] = bounds1.minimum[bestAxis] = tsplit;

  int leftChildIndex = buildNode( bounds0, inPrimitiveBounds, ioPrimitives0, n0, inDepth-1, ioEdges,
    ioPrimitives0, ioPrimitives1 + inPrimitiveCount, badRefines );
  int rightChildIndex = buildNode( bounds1, inPrimitiveBounds, ioPrimitives1, n1, inDepth-1, ioEdges,
    ioPrimitives0, ioPrimitives1 + inPrimitiveCount, badRefines );

  _nodes[nodeIndex] = new InternalNode( inNodeBounds, bestAxis, tsplit, leftChildIndex, rightChildIndex );

  return nodeIndex;
}

void KdTreeBuilder::buildNodeBounds( Node* inNode, const BoundingBox& inNodeBounds )
{
   inNode->setWorldBounds( inNodeBounds );

   if( !inNode->isLeaf() )
   {
      InternalNode* split = ((InternalNode*) inNode);
      int splitAxis = split->getSplitAxis();
      float splitValue = split->getSplitValue();

      BoundingBox leftBounds = inNodeBounds;
      BoundingBox rightBounds = inNodeBounds;

      leftBounds.maximum[ splitAxis ] = splitValue;
      rightBounds.minimum[ splitAxis ] = splitValue;

      buildNodeBounds( getIndexedNode(split->getLeftChildIndex()), leftBounds );
      buildNodeBounds( getIndexedNode(split->getRightChildIndex()), rightBounds );
   }
}
