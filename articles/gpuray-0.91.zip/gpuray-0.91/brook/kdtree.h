/*
* kdtree.h --
*
*
*/

#ifndef __KDTREE_H__
#define __KDTREE_H__

#include <brook/brook.hpp>

#include "accelerator.h"
#include "../fileIO/fileIO.h"

//#define KDTREE_USE_SHORTFIXED 1

#ifdef KDTREE_USE_SHORTFIXED
typedef shortfixed2 SHORTFIXED2;
typedef shortfixed4 SHORTFIXED4;
typedef unsigned short FIXED_VALUE;
#else
typedef float2 SHORTFIXED2;
typedef float4 SHORTFIXED4;
typedef float FIXED_VALUE;
#endif

class Node;

class KdTreeAccelerator :
   public Accelerator
{
public:
   void
   initialize( const AcceleratorOptions& inOptions );

   void
   intersect( brook::stream& rayStream, brook::stream& hitStream ) const;

   void
   timeKernels( brook::stream& rayStream ) const;

protected:
   SHORTFIXED2 createChildIndex( Node* inNode, int inSignForXComponent );
   SHORTFIXED2 createLeafParentIndex( Node* inNode );
   float2 createSplitParentIndex( Node* inNode );
   void createStateStreams( const brook::stream& inExampleStream ) const;
   virtual void allocateStateStreams() const;
   FIXED_VALUE convertSigned16( int value ) const;
   void dumpState() const;

   float3 _boundsMin, _boundsMax;

   int _vertexStreamX, _vertexStreamY;
   int _triangleIndexStreamX, _triangleIndexStreamY;
   int _splitStreamX, _splitStreamY;
   int _leafStreamX, _leafStreamY;

   int _shortConversionSignedOffset;
   float2 _shortConversionConstant;

   brook::stream _vertexStream;
   brook::stream _triangleIndexStream;
   brook::stream _baseSplitStream;
   brook::stream _extendedSplitStream;
   brook::stream _leafStream;

   // these values are mutable, because they are caches
   // to speed up the logically-const "intersect" operation
   mutable int _stateStreamX, _stateStreamY;
   mutable brook::stream _coreStateStream;
   mutable brook::stream _intersectStateStream;
   mutable brook::stream _maskStream;

   mutable brook::stream _rayStream;
   mutable brook::stream _hitStream;
};

#endif
