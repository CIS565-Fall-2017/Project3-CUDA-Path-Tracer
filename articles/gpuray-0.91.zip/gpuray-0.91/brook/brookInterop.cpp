/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * brookInterop.cpp --
 *
 *      Helper classes for using both brook and CPU together for ray tracing
 */
#include "brookInterop.h"
