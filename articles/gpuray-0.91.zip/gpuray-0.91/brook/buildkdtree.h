/*
 * buildkdtree.h --
 *
 *      I believe this is glue code Tim put together so that he could call
 *      use the pbrt kd-tree code from our code.  --Jeremy.
 */

#ifndef __BUILDKDTREE_H__
#define __BUILDKDTREE_H__

#include <brook/brook.hpp>
#include <vector>
#include "../common/commonTypes.h"
#include "../builder/kdtree.h"

struct BoundEdge;

enum ChildType {
   kChildType_Left,
   kChildType_Right,
   kChildType_None
};

struct KdTreeTriangle {
   Vec3f vertices[3];

   float getSurfaceArea() const;
   Vec3f getNormal() const;
   BoundingBox getBounds() const;
};
typedef std::vector<const KdTreeTriangle*> TriangleList;


struct KdTreeOptions {
   KdTreeOptions();

   int intersectCost;
   int traversalCost;
   float emptyBonus;
   int maximumLeafPrimitives;
   int maximumDepth;

   bool useNewBuilder;
   KDTreeBuildOptions newOptions;
};


class Node {
public:
   bool isLeaf() { return _isLeaf; }

   const BoundingBox& getWorldBounds() { return _worldBounds; }
   void setWorldBounds( const BoundingBox& inBounds ) {
      _worldBounds = inBounds;
   }

   int getSuccessor() { return _successor; }

   void setSuccessor( int inSuccessor ) {
      _successor = inSuccessor;
   }

   float getDensity() { return _density; }

   void setDensity( float inDensity ) {
      _density = inDensity;
   }

   Vec3f getDirectedDensity() { return _directedDensity; }

   void setDirectedDensity( const Vec3f& inDirectedDensity ) {
      _directedDensity = inDirectedDensity;
   }

   float getSurfaceArea() { return _surfaceArea; }

   void setSurfaceArea( float inArea ) {
      _surfaceArea = inArea;
   }

   Vec3f getDirectedSurfaceArea() { return _directedSurfaceArea; }

   void setDirectedSurfaceArea( const Vec3f& inDirectedSurfaceArea ) {
      _directedSurfaceArea = inDirectedSurfaceArea;
   }

   float getApproximateRadius() { return _approximateRadius; }
   void setApproximateRadius( float inRadius ) {
      _approximateRadius = inRadius;
   }

   int getNodeIndex() { return _nodeIndex; }
   void setNodeIndex( int inIndex ) {
      _nodeIndex = inIndex;
   }

   int getParentIndex() { return _parentIndex; }
   void setParentIndex( int inIndex ) {
      _parentIndex = inIndex;
   }

   ChildType getChildType() { return _childType; }
   void setChildType( ChildType inChildType ) {
      _childType = inChildType;
   }

   void setParentIndex( int inIndex, ChildType inChildType ) {
      setParentIndex( inIndex );
      setChildType( inChildType );
   }

protected:
   Node() {
      _isLeaf = false;
      _density = 0.0f;
      _surfaceArea = 0.0f;
   }

   void setIsLeaf( bool inIsLeaf ) {
      _isLeaf = inIsLeaf;
   }

private:
   bool _isLeaf;
   int _successor;
   float _density;
   Vec3f _directedDensity;
   float _surfaceArea;
   Vec3f _directedSurfaceArea;
   float _approximateRadius;

   BoundingBox _worldBounds;

   int _parentIndex;
   ChildType _childType;

   int _nodeIndex;
};


class LeafNode : public Node {
public:
   LeafNode( const BoundingBox& inBounds, const KdTreeTriangle *inPrimitives,
             const int *inPrimitiveIndices, int inPrimitiveCount );

   uint32 getPrimitiveCount() { return _primitives.size(); }
   const KdTreeTriangle *getIndexedPrimitive( uint32 inIndex ) {
      return _primitives[inIndex];
   }
   uint32 getIndexedPrimitiveIndex( uint32 inIndex ) {
      return (uint32) _primitiveIndices[ inIndex ];
   }

   float getPrimitiveSurfaceArea();
   Vec3f getPrimitiveDirectedSurfaceArea();

   int getLeafIndex() { return _leafIndex; }
   void setLeafIndex( int inIndex ) {
      _leafIndex = inIndex;
   }

private:
   std::vector<int> _primitiveIndices;
   TriangleList _primitives;

   int _leafIndex;
};


class InternalNode : public Node {
public:
   InternalNode( const BoundingBox& inBounds, int inSplitAxis, float inSplitValue,
                 int inLeftChildIndex, int inRightChildIndex );

   int getSplitAxis() { return _splitAxis; }
   float getSplitValue() { return _splitValue; }

   int getLeftChildIndex() { return _leftChildIndex; }
   int getRightChildIndex() { return _rightChildIndex; }

   int getSplitIndex() { return _splitIndex; }
   void setSplitIndex( int inIndex ) { _splitIndex = inIndex; }

private:
   int _splitAxis;
   float _splitValue;
   int _leftChildIndex;
   int _rightChildIndex;

   int _splitIndex;
};


class KdTreeBuilder {
public:
   KdTreeBuilder( const Opts& cmdLineOpts,
                  const KdTreeOptions& inOptions, const Scene *inScene,
                  uint32 inTriangleCount, const KdTreeTriangle *inTriangles );

   uint32 getNodeCount();
   Node *getIndexedNode( uint32 inIndex );

private:
   void constructFromNewBuilder( const Opts& cmdLineOpts, const Scene *inScene );
   int buildNode( const BoundingBox& inNodeBounds,
                  const std::vector<BoundingBox>& inPrimitiveBounds,
                  int *inPrimitiveIndices, int inPrimitiveCount,
                  int inDepth, BoundEdge *ioEdges[3], int *ioPrimitives0,
                  int *ioPrimitives1, int inBadRefines = 0 );
   void buildNodeBounds( Node* inNode, const BoundingBox& inNodeBounds );

   KdTreeOptions _options;
   BoundingBox _worldBounds;

   typedef std::vector<Node *> NodeList;
   NodeList _nodes;

   uint32 _triangleCount;
   KdTreeTriangle *_triangles;
};
#endif
