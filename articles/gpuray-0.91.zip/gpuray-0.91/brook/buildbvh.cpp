/*
 * buildbvh.cpp --
 *
 *      Implementation of bv tree construction
 */

#include "buildbvh.h"

#include <vector>
#include <algorithm>

#include "../common/commonTypes.h"
#include "../timer.h"
#include "../log.h"

BVLeafNode::BVLeafNode( const std::vector<BVTriangle>& inTriangles )
   : BVNode(true)
{
   _leafIndex = -1;

   _triangles = inTriangles;
}

BVSplitNode::BVSplitNode( const BoundingBox& inBounds, const std::vector<BVNode*> inChildren )
   : BVNode(false)
{
   _splitIndex = -1;

   _bounds = inBounds;
   _children = inChildren;
}

BVTreeBuilder::BVTreeBuilder( const BVTreeOptions& inOptions,
   int inTriangleCount, const BVTriangle *inTriangles )
{
   _options = inOptions;

   std::vector<BVTriangle> triangles;
   for( int t = 0; t < inTriangleCount; t++ )
   {
      triangles.push_back( inTriangles[t] );
      triangles[t].originalTriangleIndex = t;

      Vec3f centroid;
      for( int v = 0; v < 3; v++ )
         centroid += triangles[t].vertices[v];
      triangles[t].centroid = centroid;
   }

   _rootNode = createNode( triangles );
}

BVNode* BVTreeBuilder::createNode( std::vector<BVTriangle>& inTriangles )
{
   int triangleCount = (int) inTriangles.size();

   if( triangleCount <= _options.maximumLeafPrimitives )
      return createLeaf( inTriangles );
   else
      return createSplit( inTriangles );
}

class BVTriangleCompare
{
public:
   BVTriangleCompare( int inAxis )
   {
      _axis = inAxis;
   }

   bool operator()( const BVTriangle& left, const BVTriangle& right )
   {
      return left.centroid[_axis] < right.centroid[_axis];
   }

private:
   int _axis;
};

BVNode* BVTreeBuilder::createSplit( std::vector<BVTriangle>& inTriangles )
{
   int triangleCount = (int) inTriangles.size();

   BoundingBox bounds;

   for( int t = 0; t < triangleCount; t++ )
   {
      for( int v = 0; v < 3; v++ )
      {
         bounds = join( bounds, inTriangles[t].vertices[v] );
      }
   }

   Vec3f extents = bounds.maximum - bounds.minimum;

   int bestAxis = 0;
   float bestExtent = extents.x;

   if( extents.y > bestExtent )
   {
      bestAxis = 1;
      bestExtent = extents.y;
   }

   if( extents.z > bestExtent )
   {
      bestAxis = 2;
      bestExtent = extents.z;
   }

   std::sort( inTriangles.begin(), inTriangles.end(), BVTriangleCompare(bestAxis) );

   std::vector<BVTriangle> firstTriangles;
   std::vector<BVTriangle> secondTriangles;

   int firstCount = triangleCount / 2;
   for( int i = 0; i < firstCount; i++ )
      firstTriangles.push_back( inTriangles[i] );
   for( int j = firstCount; j < triangleCount; j++ )
      secondTriangles.push_back( inTriangles[j] );

   BVNode* firstChild = createNode( firstTriangles );
   BVNode* secondChild = createNode( secondTriangles );

   std::vector<BVNode*> children;
   if( rand() & 1 )
   {
      children.push_back( firstChild );
      children.push_back( secondChild );
   }
   else
   {
      children.push_back( secondChild );
      children.push_back( firstChild );
   }

   return new BVSplitNode( bounds, children );
}

BVNode* BVTreeBuilder::createLeaf( std::vector<BVTriangle>& inTriangles )
{
   return new BVLeafNode( inTriangles );
}
