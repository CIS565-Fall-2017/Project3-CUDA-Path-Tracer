/*
 * kdtree_conditional.cpp --
 *
 *      Implementation of z-cull k-d tree accelerator
 */

#include "kdtree_conditional.h"

#include <iostream>

#include "kdtreekernels.hpp"
#include "../log.h"
#include "../timer.h"

//#define USE_RESTART

KdTreeConditionalAccelerator::KdTreeConditionalAccelerator()
{
   using namespace brook;

   for( int i = 0; i < kQueryCount; i++ )
      _queries[i] = write_query::create();
}

void
KdTreeConditionalAccelerator::allocateStateStreams() const
{
   using namespace brook;

   KdTreeAccelerator::allocateStateStreams();
   _mask = write_mask::create( _stateStreamY, _stateStreamX );
}

static float4* gDebugCoreStates = NULL;
static float4* gDebugIntersectStates = NULL;

void KdTreeConditionalAccelerator::debugState() const
{
   if( gDebugCoreStates == NULL )
   {
      gDebugCoreStates = new float4[ _stateStreamX * _stateStreamY ];
      gDebugIntersectStates = new float4[ _stateStreamX * _stateStreamY ];
   }

   _coreStateStream.write( gDebugCoreStates );
   _intersectStateStream.write( gDebugIntersectStates );
}

void
KdTreeConditionalAccelerator::intersect(
   brook::stream& rayStream, brook::stream& hitStream ) const
{
   using namespace brook;

   _rayStream = rayStream;
   _hitStream = hitStream;
   createStateStreams( rayStream );

   static brook::write_query timingQuery = brook::write_query::create();
   timingQuery.begin();

   float startTime = Timer_GetMS();

   krnKD_Initialize( _boundsMin, _boundsMax, rayStream, hitStream, _coreStateStream, _intersectStateStream );

   for( int i = 0; i < kQueryCount; i++ )
      _queryTypes[i] = kQueryType_None;

   for( int i = 0; i < kQueryTypeCount; i++ )
   {
      _approximateCounts[i] = 0;
      _iterationCounts[i] = 0;
      _processedItemCounts[i] = 0;
      _totalTimes[i] = 0;
   }

   _approximateCounts[kQueryType_Down] = _stateStreamX*_stateStreamY;

   _mask.bind();
   _mask.enableTest();

   int switchFactor = 4;

   _queryIndex = 0;
   while( true )
   {
      bool workDone = false;

      if( iterateMode(
         kQueryType_Down,
         kQueryType_Intersect,
         switchFactor,
         &KdTreeConditionalAccelerator::buildDownMask,
         &KdTreeConditionalAccelerator::executeDownPass ) )
      {
         workDone = true;
      }

      executeMode(
         kQueryType_Leaf,
         &KdTreeConditionalAccelerator::buildLeafMask,
         &KdTreeConditionalAccelerator::executeLeafPass );

#ifdef USE_RESTART
      if( iterateMode(
         kQueryType_Intersect,
         kQueryType_Down,
         switchFactor,
         &KdTreeConditionalAccelerator::buildIntersectMask,
         &KdTreeConditionalAccelerator::executeIntersectPass ) )
      {
         workDone = true;
      }

      executeMode(
         kQueryType_PostIntersect,
         &KdTreeConditionalAccelerator::buildPostIntersectMask,
         &KdTreeConditionalAccelerator::executePostIntersectPass );
#else
      if( iterateMode(
         kQueryType_Intersect,
         kQueryType_Up,
         switchFactor,
         &KdTreeConditionalAccelerator::buildIntersectMask,
         &KdTreeConditionalAccelerator::executeIntersectPass ) )
      {
         workDone = true;
      }

      executeMode(
         kQueryType_PostIntersect,
         &KdTreeConditionalAccelerator::buildPostIntersectMask,
         &KdTreeConditionalAccelerator::executePostIntersectPass );

      if( iterateMode(
         kQueryType_Up,
         kQueryType_Down,
         switchFactor,
         &KdTreeConditionalAccelerator::buildUpMask,
         &KdTreeConditionalAccelerator::executeUpPass ) )
      {
         workDone = true;
      }
#endif
      if( !workDone )
         break;
   }

   _mask.disableTest();
   _mask.unbind();

   krnKD_Finalize( _coreStateStream, _hitStream, _hitStream );

   while( _queryTypes[_queryIndex] != kQueryType_None )
   {
      processOneQuery();
      _queryIndex = (_queryIndex + 1) % kQueryCount;
   }
   timingQuery.end();
   timingQuery.wait();
   float endTime = Timer_GetMS();

   float totalTime = (endTime - startTime);
   PRINT(("#kdtree# time: %fms\n", totalTime));
   PRINT(("#kdtree# krays/s: %f\n", (_stateStreamX*_stateStreamY) / (totalTime)));

   printStats( "down", kQueryType_Down );
   printStats( "leaf", kQueryType_Leaf );
   printStats( "intersect", kQueryType_Intersect );
   printStats( "post-intersect", kQueryType_PostIntersect );
   printStats( "up", kQueryType_Up );

/*
   int totalSplitItems = (int) queryTotals[kQueryType_Split];
   int totalLeafItems = (int) queryTotals[kQueryType_Leaf];
   int totalIntersectItems = (int) queryTotals[kQueryType_Intersect];

   PRINT(("#kdtree# split iterations: %d\n", (int) totalSplitIterations));
   PRINT(("#kdtree# leaf iterations: %d\n", (int) totalLeafIterations));
   PRINT(("#kdtree# intersect iterations: %d\n", (int) totalIntersectIterations));

   PRINT(("#kdtree# split items: %d\n", totalSplitItems));
   PRINT(("#kdtree# leaf items: %d\n", totalLeafItems));
   PRINT(("#kdtree# intersect items: %d\n", totalIntersectItems));

   PRINT(("#kdtree# split time: %fms (%fms/iteration, %fns/item)\n",
      totalSplitTime, totalSplitTime/totalSplitIterations, 1000*1000*totalSplitTime/totalSplitItems));
   PRINT(("#kdtree# leaf time: %fms (%fms/iteration, %fns/item)\n",
      totalLeafTime, totalLeafTime/totalLeafIterations, 1000*1000*totalLeafTime/totalLeafItems));
   PRINT(("#kdtree# intersect time: %fms (%fms/iteration, %fns/item)\n",
      totalIntersectTime, totalIntersectTime/totalIntersectIterations, 1000*1000*totalIntersectTime/totalIntersectItems));*/
}

void KdTreeConditionalAccelerator::executeMode(
      QueryType inType,
      ModeFunction inMaskFunction,
      ModeFunction inKernelFunction ) const
{
   float startTime = Timer_GetMS();

   processOneQuery();

   _mask.enableSet();
   _mask.clear();
   (this->*inMaskFunction)();
   _mask.disableSet();

   _queries[_queryIndex].begin();
   (this->*inKernelFunction)();
   _queries[_queryIndex].end();
   _queryTypes[_queryIndex] = inType;

   _queryIndex = (_queryIndex + 1) % kQueryCount;
   _iterationCounts[ inType ]++;

   _totalTimes[inType] += Timer_GetMS() - startTime;
}

bool KdTreeConditionalAccelerator::iterateMode(
      QueryType inType,
      QueryType inNextType,
      int inSwitchFactor,
      ModeFunction inMaskFunction,
      ModeFunction inKernelFunction ) const
{
   float startTime = Timer_GetMS();

   _mask.enableSet();
   _mask.clear();
   (this->*inMaskFunction)();
   _mask.disableSet();

   bool firstQuery = true;
   bool workDone = false;
   while( true )
   {
      if( _queryTypes[_queryIndex] == inType )
      {
         uint32 count = _queries[_queryIndex].count();

         if( firstQuery )
         {
            firstQuery = false;
            if( count != 0 )
               workDone = true;
         }
         else
         {
            _approximateCounts[ inNextType ] += _approximateCounts[ inType ] - count;
         }
      }
      processOneQuery();
      if( !firstQuery && _approximateCounts[ inType ]*inSwitchFactor
         <= _approximateCounts[ inNextType ] )
      {
         break;
      }

      _queries[_queryIndex].begin();
      (this->*inKernelFunction)();
      _queries[_queryIndex].end();
      _queryTypes[_queryIndex] = inType;

      _queryIndex = (_queryIndex + 1) % kQueryCount;
      _iterationCounts[ inType ]++;

      _mask.enableSet();
      (this->*inMaskFunction)();
      _mask.disableSet();
   }

   _totalTimes[inType] += Timer_GetMS() - startTime;
   return workDone;
}

void KdTreeConditionalAccelerator::processOneQuery() const
{
   QueryType oldQueryType = _queryTypes[_queryIndex];
   if( oldQueryType != kQueryType_None )
   {
      uint32 count = _queries[_queryIndex].count();
      _approximateCounts[oldQueryType] = count;
      _processedItemCounts[oldQueryType] += count;
      _queryTypes[_queryIndex] = kQueryType_None;
   }
}

void KdTreeConditionalAccelerator::printStats( const char* inName, QueryType inType ) const
{
   int totalItems = (int) _processedItemCounts[inType];
   int totalPasses = (int) _iterationCounts[inType];
   float time = _totalTimes[inType];

   PRINT(("#kdtree# %s iterations: %d\n", inName, (int) totalPasses));
   PRINT(("#kdtree# %s items: %d\n", inName, (int) totalItems));
   PRINT(("#kdtree# %s time: %fms (%fms/iter, %fns/item)\n",
      inName, time, time / totalPasses, 1000*1000*time / totalItems));
}

void KdTreeConditionalAccelerator::buildDownMask() const
{
   krnKD_GenerateDownMask( _coreStateStream, _maskStream );
}

void KdTreeConditionalAccelerator::buildLeafMask() const
{
   krnKD_GenerateLeafMask( _coreStateStream, _maskStream );
}

void KdTreeConditionalAccelerator::buildIntersectMask() const
{
   krnKD_GenerateIntersectMask( _coreStateStream, _intersectStateStream, _maskStream );
}

void KdTreeConditionalAccelerator::buildPostIntersectMask() const
{
   krnKD_GeneratePostIntersectMask( _coreStateStream, _intersectStateStream, _maskStream );
}

void KdTreeConditionalAccelerator::buildUpMask() const
{
   krnKD_GenerateUpMask( _coreStateStream, _maskStream );
}

void KdTreeConditionalAccelerator::executeDownPass() const
{
   krnKD_Down( _coreStateStream, _rayStream,
         _baseSplitStream, _coreStateStream,
         _shortConversionConstant );
}

void KdTreeConditionalAccelerator::executeLeafPass() const
{
   krnKD_Leaf( _coreStateStream, _intersectStateStream, _rayStream, _hitStream,
         _leafStream, _coreStateStream, _intersectStateStream,
         _shortConversionConstant );
}

void KdTreeConditionalAccelerator::executeIntersectPass() const
{
   krnKD_Intersect( _coreStateStream, _intersectStateStream, _rayStream, _hitStream,
         _triangleIndexStream, _vertexStream, _hitStream, _intersectStateStream,
         _shortConversionConstant );
}

void KdTreeConditionalAccelerator::executePostIntersectPass() const
{
   krnKD_PostIntersect( _coreStateStream, _intersectStateStream,
         _hitStream, _coreStateStream, _shortConversionConstant );
}

void KdTreeConditionalAccelerator::executeUpPass() const
{
   krnKD_Up( _coreStateStream, _rayStream, _hitStream,
         _extendedSplitStream, _coreStateStream,
         _shortConversionConstant );
}
