/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * brookDisplay.h --
 *
 *      XXX
 */

#ifndef __BROOK_BROOKDISPLAY_H__
#define __BROOK_BROOKDISPLAY_H__

#include "brookContext.h"
#include "../renderContext.h"

class ppmImage;

/*
 * IPixelDisplayerBrook --
 *
 *      Interface for components that can take a brook stream
 *      of pixels and display it to the user (or otherwise
 *      consume the pixel data).
 *
 */

class IPixelDisplayerBrook
{
public:
   virtual void Display( brook::stream& inPixelStream ) = 0;
};

/*
 * WriteImagePixelDisplayerBrook --
 *
 *      An implementation of IPixelDisplayer that
 *      writes the result pixels out to a memory-resident
 *      image.
 *
 */

class WriteImagePixelDisplayerBrook : public IPixelDisplayerBrook
{
public:
   WriteImagePixelDisplayerBrook(
      ppmImage* inOutputImage );

   void Display( brook::stream& inPixelStream );

private:
   ppmImage* _outputImage;
};

/*
 * CachedPixelDisplayerBrook --
 *
 *      An implementation of IPixelDisplayerBrook that stores
 *      the last generated pixel stream in an instance variable,
 *      so that it can easily be retrieved later.
 *
 */

class CachedPixelDisplayerBrook : public IPixelDisplayerBrook
{
public:
   CachedPixelDisplayerBrook(
      IPixelDisplayerBrook* inContinuation );

   void Display( brook::stream& inPixelStream );
   void Display();

private:
   IPixelDisplayerBrook* _continuation;

   brook::stream _pixelStream;
};


/*
* CreatePixelDisplayerBrook --
*
*      Creates an object capable of displaying
*      pixels from the appropriate brook runtime.
*
* Results:
*      The created object.
*/

IPixelDisplayerBrook* CreatePixelDisplayerBrook( IRenderContext* inRenderContext, BrookContext* inBrookContext );

#endif
