/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * brookTracer.h --
 *
 *      Helper classes for ray-tracing with Brook
 */

#ifndef __BROOK_BROOKTRACER_H__
#define __BROOK_BROOKTRACER_H__

#include <brook/brook.hpp>

#include "../main.h"
#include "../scene.h"
#include "../renderContext.h"
#include "../tracer.h"

class Accelerator;
class Shader;
class CameraManager;
class BrookContext;
class IBaseRayIntersectorBrook;
class IBoundRayIntersectorBrook;
class IPixelDisplayerBrook;
class IHitShaderBrook;
class VertexDataBrook;
class CachedPixelDisplayerBrook;

/*
 * VertexDataBrook --
 *
 *      Wrapper to hold all the vertex data for
 *      triangles in the scene, so that it can
 *      be easily shared between multiple clients.
 *
 */

class VertexDataBrook {
public:
   VertexDataBrook( Scene* inScene );

   int getVertexStreamX() { return _vertexStreamX; }
   int getVertexStreamY() { return _vertexStreamY; }
   brook::stream& getPositionStream() { return _positionStream; }
   brook::stream& getNormalStream() { return _normalStream; }
   brook::stream& getColorStream() { return _colorStream; }
   brook::stream& getSpecularStream() { return _specularStream; }
   brook::stream& getSpecularExponentStream() { return _specularExpStream; }

private:
   Scene* _scene;

   int _vertexStreamX, _vertexStreamY;
   brook::stream _positionStream;
   brook::stream _normalStream;
   brook::stream _colorStream;
   brook::stream _specularStream;
   brook::stream _specularExpStream;
};

/*
 * RayGeneratorBrook --
 *
 *      A brook implementation of eye ray generation.
 *
 */

class RayGeneratorBrook : public IRayGenerator {
public:
   RayGeneratorBrook( CameraManager* inCameraManager, Scene* inScene,
      IBoundRayIntersectorBrook* inContinuation );

   void Generate( int inWidth, int inHeight );

private:
   static void DumpRays( brook::stream& rayStream );

   CameraManager *_cameraManager;
   Scene *_scene;
   IBoundRayIntersectorBrook* _continuation;

   int _currentStreamX, _currentStreamY;
   brook::stream _rayStream;
};

/*
 * IHitShaderBrook --
 *
 *      Interface for components that can shade
 *      rays/hits represented as brook streams.
 *
 *      Used as a callback by components that
 *      generate streams of hits.
 *
 */

class IHitShaderBrook {
public:
   virtual void Shade( brook::stream& inRayStream, brook::stream& inHitStream ) = 0;
};

/*
 * DefaultHitShaderBrook --
 *
 *      Default implementation of IHitShaderBrook.
 *      Converts hits to shading hits and then uses
 *      an "old" brook shader to calculate pixel
 *      colors before handing the pixels off to
 *      a display callback.
 *
 */

class DefaultHitShaderBrook : public IHitShaderBrook {
public:
   DefaultHitShaderBrook(
      const Opts& inOptions,
      Scene* inScene,
      VertexDataBrook* inVertexData,
      CameraManager* inCameraManager,
      IBaseRayIntersectorBrook* inIntersector,
      IPixelDisplayerBrook* inContinuation );

   void Shade( brook::stream& inRayStream, brook::stream& inHitStream );
   void Display();

private:
   Scene* _scene;
   VertexDataBrook *_vertexData;
   CameraManager *_cameraManager;
   IPixelDisplayerBrook *_continuation;

   Shader *_shader;

   int _currentStreamX, _currentStreamY;
   brook::stream _shadingHitStream;
   brook::stream _pixelStream;
};

/*
 * IBaseRayIntersectorBrook --
 *
 *      Interface for components that can take
 *      a stream of rays, generate a stream of hits
 *      and then provide both to a user-specified callback.
 *
 */

class IBaseRayIntersectorBrook
{
public:
   virtual void Intersect( brook::stream& inRayStream, IHitShaderBrook* inContinuation ) = 0;
};

/*
 * DefaultBaseRayIntersectorBrook --
 *
 *      Default implementation of IBaseRayIntersectorBrook.
 *      Uses an "old" Accelerator object to do the actual
 *      intersection work before calling the callback.
 *
 */

class DefaultBaseRayIntersectorBrook : public IBaseRayIntersectorBrook {
public:
   DefaultBaseRayIntersectorBrook(
      const Opts& inOptions, Scene* inScene, VertexDataBrook* inVertexData );

   void Intersect( brook::stream& inRayStream, IHitShaderBrook* inContinuation );

private:
   static void DumpHits( brook::stream& hitStream );

   VertexDataBrook *_vertexData;
   Accelerator *_rayIntersector;
   int _triangleCount;

   int _currentStreamX, _currentStreamY;
   brook::stream _hitStream;
};

/*
 * IBoundRayIntersectorBrook --
 *
 *      Interface similar to IBaseRayIntersectorBrook, except
 *      that the callback is bound to the object, rather than
 *      being supplied by the caller.
 *
 */

class IBoundRayIntersectorBrook
{
public:
   virtual void Intersect( brook::stream& inRayStream ) = 0;
};

/*
 * BoundRayIntersectorBrook --
 *
 *      Default implementation of IBoundRayIntersectorBrook. Binds
 *      an instance of IBaseRayIntersectorBrook to a specific
 *      shading callback.
 *
 */

class BoundRayIntersectorBrook : public IBoundRayIntersectorBrook
{
public:
   BoundRayIntersectorBrook(
      IBaseRayIntersectorBrook* inIntersector, IHitShaderBrook* inContinuation );

   void Intersect( brook::stream& inRayStream );

private:
   IBaseRayIntersectorBrook* _intersector;
   IHitShaderBrook* _continuation;
};

/*
 * TracerBrook --
 *
 *      An implementation of ITracer that uses
 *      a ray generator that (through its callbacks)
 *      can generate a pixel stream, and a pixel
 *      displayer that can present those pixels
 *      to the user.
 *
 */

class TracerBrook : public ITracer
{
public:
   TracerBrook(
      ITracer* inInnerTracer, 
      CachedPixelDisplayerBrook* inDisplayContinuation );

   void Resize( int inWidth, int inHeight );
   void TraceRays();
   void Display();

private:
   ITracer* _innerTracer;
   CachedPixelDisplayerBrook* _displayContinuation;
};

/*
 * toFloat2 --
 *
 *      Helper function to convert vector values
 *      to the equivalent brook type.
 *
 */

inline float2 toFloat2( const Vec2f& inValue ) {
   return float2( inValue.x, inValue.y );
}

/*
 * toFloat3 --
 *
 *      Helper function to convert vector values
 *      to the equivalent brook type.
 *
 */

inline float3 toFloat3( const Vec3f& inValue ) {
   return float3( inValue.x, inValue.y, inValue.z );
}


#endif
