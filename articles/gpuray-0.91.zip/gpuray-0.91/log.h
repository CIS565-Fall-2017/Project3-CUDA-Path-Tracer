/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * log.h --
 *
 *      Simple log module.
 */

#ifndef __LOG_H__
#define __LOG_H__

#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SILENT
#define PRINT(msg)
#define LOG(msg)
#define LOG_ONLY(block)
#define PAUSE(msg)
#else
#define PRINTTIME(msg)  do { printf msg; } while(0)
#define PRINT(msg)      do { if (!_quiet) { printf msg; LOG(msg); } } while (0)
#ifdef NDEBUG
#define LOG(msg)
#define LOG_ONLY(block)
#else
#define LOG(msg)        do { if (_logFD) { Log msg; } } while(0)
#define LOG_ONLY(block) do { if (_logFD) { block } } while(0)
#endif
#define PAUSE(msg) \
   do { PRINT(("Paused: %s.  Press <enter>.\n", msg)); getchar(); } while(0)
#endif


extern void Log_Open(const char *filename);
extern void Log_Close(void);
extern void Log(const char *fmt, ...);

extern FILE *_logFD;
extern int _quiet;

#ifdef __cplusplus
}
#endif
#endif
