/* 
 * fileformat.h
 *************************************
 * A new file format for the raytracer
 */

/*
#define DIFFUSE  0x00000001
#define AMBIENT  0x00000010
#define SPECULAR 0x00000100
*/

#ifndef __FILEFORMAT_H__
#define __FILEFORMAT_H__

#include "f3.h"

// We need to break vertices down into batches in order to associate
// different materials with different sets of triangles

struct Batch {
   // right now just do a simple scheme
   int vertexCount;
   int triangleCount;
   
   // require 1 things: position
   F3 *vertices;

   // everything else optional
   F3 *normals;

   // additional materials
   F3 *diffuseColors;

   F3 *ambientColors;  // do we need ambient colors? that's an open gl thing...
   
   // Specular -- NULL means no specular for simplicity
   F3 *specularColors;     // every vertice will have a specular color also
   float *specularExp;     // one float specular exponent per vertice

   // Reflective -- not sure how I will do that yet

   // indeces of triangles -- because triangles can share vertices
   int *triangleIndeces;  // will be 3*triangleCount
};

struct NewScene {
   int batchCount;
   Batch *batches;

   std::vector<LightInfo> pointLights;
};

void ReadSceneFile( char *fname, bool verbose, NewScene *scene);

void WriteOutScene ( char *fname, bool verbose, NewScene *scene);

#endif
