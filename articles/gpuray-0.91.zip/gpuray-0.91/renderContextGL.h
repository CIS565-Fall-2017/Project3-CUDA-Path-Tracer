/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * renderContextGL.h --
 *
 *      OpenGL implementation of the IRenderSystem interface.
 */

#ifndef __RENDERCONTEXTGL_H__
#define __RENDERCONTEXTGL_H__

#include "renderContext.h"

class RenderSystemOGL : public IRenderSystem
{
public:
   const char* getRenderSystemID();
#ifdef _WIN32
   IRenderContext* createRenderContext( HWND inWindowHandle );
#else
   IRenderContext* createRenderContext( Display *display, Window win,
                                        XVisualInfo *visInfo );
#endif
};

class RenderContextOGL : public IRenderContext
{
public:
#ifdef _WIN32
   RenderContextOGL( RenderSystemOGL* inRenderSystem, HWND inWindowHandle );
#else
   RenderContextOGL( RenderSystemOGL* inRenderSystem, Display *display,
                     Window win, XVisualInfo *visInfo );
#endif

   IRenderSystem* getRenderSystem();
   void* getContextHandle();

   void resize( int inWidth, int inHeight );

   void bind();
   void swap();

#ifndef _WIN32
   const XVisualInfo *getVisual(void) const { return _visInfo; }
#endif

private:
   RenderSystemOGL* _renderSystem;

#ifdef _WIN32
   HDC _hdc;
   HGLRC _hglrc;
#else
   Display *_dpy;
   Window _win;
   XVisualInfo *_visInfo;
   GLXContext _ctx;
#endif
};


#endif
