#!/bin/bash
#
# compute-performance.sh --
#
#	Simple shell script to generate a bunch of timing numbers.

scenes=${1:-cbox glassner bunny robots kitchen gally}
shaders=${2:-simple shadow whitted}
accels=${3:-kdtree-spu}
resolution=1024

computePerformance=1
computeCacheStats=0

echo -n "Starting at "
date

if [ $computePerformance -ne 0 ]; then
   echo "*** Computing Performance ***"
   for accel in $accels; do
      for scene in $scenes; do
         for shader in $shaders; do
            echo "** ${accel} ${scene} ${shader} **"
            ./bin/raytracer --cpu -a $accel \
              -s $scene -l $shader --size $resolution \
              -o junk.ppm | grep -E "(rayType\:)|(Raycasting took)|(usecs per ray)";
	         echo -e ""
         done
      done
   done
fi

if [ $computeCacheStats -ne 0 ]; then
   echo "*** Computing Cache Stats ***"
   for accel in $accels; do
      for scene in $scenes; do
         for shader in $shaders; do
            echo "** ${accel} ${scene} ${shader} **"
            ./bin/raytracer --cpu -a $accel \
              -s $scene -l $shader --size $resolution \
	      --accelOpt speCount=1 \
              -o junk.ppm | grep -E "(STAT)|(rayType\:)|( cache)";
	         echo -e ""
         done
      done
   done
fi

echo -n "Done at "
date
