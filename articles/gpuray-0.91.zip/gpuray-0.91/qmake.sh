#!/bin/sh
rm bin/release/raytracer.exe
rm bin/debug/raytracer.exe
#rm ctm/raytracer.r5xx
#rm ctm/raytracer.r5xx
#rm bin/release/ctmAccel.lib
make VERBOSE=1 ENABLE_CTM=1 DXSDK_DIR="c:\\Program Files\Microsoft DirectX SDK" $* 
