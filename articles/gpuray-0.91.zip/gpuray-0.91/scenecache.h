/* *************************************************************************
 * Copyright (C) 2006 Tim Foley
 * All Rights Reserved
 * *************************************************************************/

/*
 * scenecache.h --
 *
 *      A simple cache for created k-d trees, so that
 *      we don't have to suffer from long build times.
 *      This hopefully will be a short-lived module.
 */

#ifndef __SCENECACHE_H__
#define __SCENECACHE_H__

#include "main.h"
#include "scene.h"
#include "builder/kdtree.h"

/*
 * BuildKDTreeCached --
 *
 *      Returns a previously-created k-d tree
 *      from the cache or, if none exists,
 *      creates a tree with the specified options
 *      and inserts it into the cache.
 */

KDTree*
BuildKDTreeCached( const Opts& opts, const Scene* inScene,
                   const KDTreeBuildOptions& inOptions );

#endif
