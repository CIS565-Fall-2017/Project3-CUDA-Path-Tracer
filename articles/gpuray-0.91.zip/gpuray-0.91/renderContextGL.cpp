/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * renderContextGL.h --
 *
 *      OpenGL implementation of the IRenderSystem interface.
 */
#include "renderContextGL.h"

#include <stdio.h>
#include <iostream>
#include <GL/gl.h>

const char* RenderSystemOGL::getRenderSystemID()
{
   return "ogl";
}

#ifdef _WIN32
IRenderContext*
RenderSystemOGL::createRenderContext( HWND inWindowHandle )
{
   return new RenderContextOGL( this, inWindowHandle );
}
#else
IRenderContext*
RenderSystemOGL::createRenderContext(Display *display,
                                     Window win, XVisualInfo *visInfo)
{
   return new RenderContextOGL(this, display, win, visInfo);
}
#endif

#if _WIN32
RenderContextOGL::RenderContextOGL( RenderSystemOGL* inRenderSystem, HWND inWindowHandle )
{
   _renderSystem = inRenderSystem;

   PIXELFORMATDESCRIPTOR pfd = {
      sizeof(PIXELFORMATDESCRIPTOR),  //  size of this pfd
         1,                              // version number
         PFD_DRAW_TO_WINDOW |            // support window
         PFD_SUPPORT_OPENGL |            // support OpenGL
         PFD_DOUBLEBUFFER,               // double buffered
         PFD_TYPE_RGBA,                  // RGBA type
         32,                             // 32-bit color depth
         0, 0, 0, 0, 0, 0,               // color bits ignored
         8,                              // standard 8bit alpha buffer
         0,                              // alpha shift bit ignored
         0,                              // no accumulation buffer
         0, 0, 0, 0,                     // accum bits ignored
         24,                             // set depth buffer
         0,                              // no stencil buffer
         0,                              // no auxiliary buffer
         PFD_MAIN_PLANE,                 // main layer
         0,                              // reserved
         0, 0, 0                         // layer masks ignored
   };
   int pixelformat;

   if ((_hdc = GetDC(inWindowHandle)) == NULL) {
      throw -1;
   }
   if ((pixelformat = ChoosePixelFormat(_hdc, &pfd)) == 0) {
      fprintf(stderr, "ChoosePixelFormat failed");
      throw -1;
   }
   if (!SetPixelFormat(_hdc, pixelformat, &pfd)) {
      fprintf(stderr, "SetPixelFormat failed" );
      throw -1;
   }
   if ((_hglrc = wglCreateContext(_hdc)) == NULL ||
      !wglMakeCurrent(_hdc, _hglrc)) {
      throw -1;
   }
}
#else
RenderContextOGL::RenderContextOGL(RenderSystemOGL* inRenderSystem,
                                   Display *display, Window win,
                                   XVisualInfo *visInfo)
{
   _renderSystem = inRenderSystem;
   _dpy = display;
   _win = win;
   _ctx = glXCreateContext(display, visInfo, NULL, True);
}
#endif

IRenderSystem *
RenderContextOGL::getRenderSystem()
{
   return _renderSystem;
}

void *
RenderContextOGL::getContextHandle()
{
#if _WIN32
   return (void *) _hglrc;
#else
   return (void *) _ctx;
#endif
}

void
RenderContextOGL::resize( int inWidth, int inHeight )
{
   bind();
   glViewport(0, 0, inWidth, inHeight);
}

void
RenderContextOGL::bind()
{
#if _WIN32
   wglMakeCurrent(_hdc, _hglrc);
#else
   glXMakeCurrent(_dpy, _win, _ctx);
#endif
}

void
RenderContextOGL::swap()
{
#if _WIN32
   SwapBuffers(_hdc);
#else
   glXSwapBuffers(_dpy, _win);
#endif
}
