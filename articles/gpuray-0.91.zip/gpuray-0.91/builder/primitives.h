/*
 * primitives.h --
 *
 *      Interface for abstracting a list of
 *      primitives during tree construction.
 */

#ifndef __PRIMITIVES_H__
#define __PRIMITIVES_H__

#include "../common/commonTypes.h"

/*
* IPrimitives --
*
*/

class IPrimitives
{
public:
   // return the number of primitives being represented
   virtual int getPrimitiveCount() const = 0;

   // return a bounding box that encloses all the primitives
   virtual BoundingBox getBounds() const = 0;

   // return a bounding box to enclose the portion of
   // the specified primitive that intersects the passed-in
   // bounding box
   virtual BoundingBox getIndexedPrimitiveClippedBounds( int inIndex, const BoundingBox& inBounds ) const = 0;
};

#endif
