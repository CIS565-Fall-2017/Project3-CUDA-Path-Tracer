/*
 * kdtreeOffline.h --
 *
 *      Class definition for the really slow builder of really good trees.
 */

#ifndef __KDTREEOFFLINE_H__
#define __KDTREEOFFLINE_H__

#include "kdtree.h"
#include "primitives.h"

//#define PROFILE_KDTREE_BUILD 1
#ifdef PROFILE_KDTREE_BUILD
#define PROFILE_ONLY(x) x
#else
#define PROFILE_ONLY(x)
#endif


enum CandidateType {
   /*
    * This order is critical for efficient comparison of splits.  In
    * general, End should sort before Begin so that if one primitive ends in
    * the same place another begins, the first one is terminated before the
    * next starts.  However, a primitive that begins and ends in the same
    * place (projected along a given axis) should sort after any prior
    * primitives end and before any subsequent primitives start.  That way
    * maximizes the way primitives can be separated from each other.
    */

   CANDIDATE_End,
   CANDIDATE_BeginEnd,
   CANDIDATE_Begin,
};

struct Candidate {
   CandidateType kind;
   float value;
   int primitiveIndex;

   bool inline operator<(const Candidate& other) const {
      return value != other.value ? value < other.value : kind < other.kind;
   }
};

struct SplitDesc {
   int splitAxis;
   float splitValue;
   int index;
   double cost;
};

struct KDTreeLazyInfo {
   BoundingBox bbox;
   std::vector<int> primitives;
};


class KDTreeOffline : public KDTree
{
public:
   KDTreeOffline(const Scene &scene, const KDTreeBuildOptions& opts);
   KDTreeOffline(const BoundingBox& bbox,
                 const std::vector<KDTreeNode>& nodes,
                 const std::vector<int>& primitiveIndices);

   virtual void refineLazy(int nodeIndex);
   virtual void printStats(void) const;

protected:
   int allocateNodes(int num);

   double inline estimateLeafCost(const BoundingBox& nodeBBox,
                                  int primitiveCount) const {
      return estimateLeafCost(nodeBBox.getSurfaceArea(), primitiveCount);
   }

   double inline estimateLeafCost(double surfaceArea,
                                  int primitiveCount) const {
      if (primitiveCount == 0) {
         return surfaceArea * _opts.emptyLeafCost;
      }

      return surfaceArea
         * (_opts.leafCost + primitiveCount * _opts.isectCost);
   }

   double inline estimateSplitCost(double cellSurfaceArea,
                                   double leftSurfaceArea, int leftNumPrims,
                                   double rightSurfaceArea, int rightNumPrims) const {
      return cellSurfaceArea * _opts.splitCost
         + estimateLeafCost(leftSurfaceArea, leftNumPrims)
         + estimateLeafCost(rightSurfaceArea, rightNumPrims);
   }


   void buildSplitCandidates(const int *primitiveIndices,
                             int primitiveCount, const BoundingBox& nodeBBox,
                             Candidate *candidates[3], int candidateCounts[3]) const;
   void constructLeaf(int nodeIndex,
                      const std::vector<int> nodePrimitiveIndices);
   void constructLazy(int nodeIndex, const BoundingBox& bbox,
                     const std::vector<int> primitives);
   void refineNode(int nodeIndex, uint32 depth, const BoundingBox& bbox,
                   std::vector<int>& nodePrimitiveIndices);

   SplitDesc chooseEstimatedBestSplit(int primitiveCount,
                                      const BoundingBox& nodeBBox,
                                      Candidate *candidates[3],
                                      int candidateCounts[3]) const;


   const IPrimitives *_primitives;
   int _primitiveCount;
   std::vector<Candidate> _splitCandidates[3];

   float _invTreeSA;    /* Precomputed 1 / _treeBBox.surfaceArea() */

#ifdef PROFILE_KDTREE_BUILD
   void startProfile(void);
   void endProfile(void);

   struct {
      float timeStart;
      float timeEstimateBestSplit;
      float timeSort;
      float timeCreateEvents;
      float timeGetClippedBounds;
   } _profile;
#endif
};
#endif
