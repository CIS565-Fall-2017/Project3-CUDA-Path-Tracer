/*
 * kdtree.cpp --
 *
 *      Logic for building and updating the core k-D tree data structure.
 */

#include "kdtree.h"
#include "kdtreeOffline.h"


/*
 * KDTree_Create --
 *
 *      Wrapper that selects the right kdtree implemenation and invokes it.
 *
 * Results:
 *      Newly allocated kdtree of some sort.
 */

KDTree *
KDTree_Create(const Opts& opts, const Scene& scene,
              const KDTreeBuildOptions& treeOpts)
{
   const char *type = GetKeyValueString("builder", opts.buildOpts, "offline");

   if (type == NULL || strcmp(type, "offline") == 0) {
      return new KDTreeOffline(scene, treeOpts);
   } else {
      fprintf(stderr, "Unknown k-D tree type: %s!\n", type);
      return NULL;
   }
}


/*
 * KDTree_Create --
 *
 *      Wrapper that selects the right kdtree implemenation and invokes it.
 *
 * Results:
 *      Newly allocated kdtree of some sort.
 */

KDTree *
KDTree_Create(const Opts& opts,
              const BoundingBox& box,
              const std::vector<KDTreeNode>& nodes,
              const std::vector<int>& indices)
{
   const char *type = GetKeyValueString("builder", opts.buildOpts, "offline");

   if (type == NULL || strcmp(type, "offline") == 0) {
      return new KDTreeOffline(box, nodes, indices);
   } else {
      fprintf(stderr, "Unknown k-D tree type: %s!\n", type);
      return NULL;
   }
}
