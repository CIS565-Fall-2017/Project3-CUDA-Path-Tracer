/*
 * trianglePrimitives.h --
 *
 *      Implementation of the IPrimitives
 *      interface for a simple list of triangles
 */

#ifndef __TRIANGLEPRIMITIVES_H__
#define __TRIANGLEPRIMITIVES_H__

#include "primitives.h"
#include "../common/commonTypes.h"

#include <vector>

/*
* TrianglePrimitive --
*
*/

class TrianglePrimitive
{
public:
   TrianglePrimitive() {}

   TrianglePrimitive( Vec3f inVertex0, Vec3f inVertex1, Vec3f inVertex2 );

   BoundingBox getBounds() const;

   Vec3f vertices[3];
};

/*
* TrianglePrimitives --
*
*/

class TrianglePrimitives : public IPrimitives
{
public:
   TrianglePrimitives( int inTriangleCount, const TrianglePrimitive* inTriangles );
   virtual ~TrianglePrimitives() {}

   // return the number of triangles being represented
   int getPrimitiveCount() const { return _triangles.size(); }

   // return a bounding box that encloses all the triangles
   BoundingBox getBounds() const { return _bounds; }

   // return a bounding box to enclose the portion of
   // the specified triangle that intersects the passed-in
   // bounding box
   BoundingBox getIndexedPrimitiveClippedBounds( int inIndex, const BoundingBox& inBounds ) const;

protected:
   std::vector<TrianglePrimitive> _triangles;

   BoundingBox _bounds;
};

#endif
