/*
 * kdtreeOffline.cpp --
 *
 *      Logic for building and updating the core k-D tree data structure.
 *      This builder is meant to be the one that tries really really hard to
 *      build an excellent tree even if it takes a *long* time.
 */

#include "kdtreeOffline.h"
#include "../log.h"
#include "../timer.h"
#include "trianglePrimitives.h"

#include <limits>
#include <algorithm>
#include <assert.h>

#define STATS_MODULE   kdtree
#define STATS_COUNTERS \
   DEFN_STAT(Nodes, "Number of kdtree nodes") \
   DEFN_STAT(Splits, "Number of kdtree internal nodes") \
   DEFN_STAT(Leaves, "Number of kdtree leaf nodes") \
   DEFN_STAT(EmptyLeaves, "Number of empty kdtree leaf nodes") \
   DEFN_STAT(TriangleIndices, "Cumulative length of all triangle lists") \
   DEFN_STAT(Lazy, "Number of kdtree lazy nodes built") \
   DEFN_STAT(Refinements, "Number of times a lazy node was refined") \

#define STATS_DEFINE_COUNTERS
#include "../stats.h"


/*
 * ReleaseVectorContents --
 *
 *      This routine forcibly releases the memory associated with a vector.
 *      It swaps the input vector's contents with an empty vector so that
 *      the empty contents are returned and the prior contents are released
 *      when they fall out of scope at the end of the function.
 *
 * Results:
 *      void, but the input vector's contents are all gone and freed.
 */

template<typename T> void
ReleaseVectorContents(std::vector<T>& ioVector)
{
   std::vector<T> empty;
   ioVector.swap(empty);
}


/*
 * KDTreeOffline::allocateNodes --
 *
 *      Grows the _treeNodes vector.  It's here instead of inline in the .h
 *      file so that I can put stat counters into it without twisting C++
 *      around too badly.
 *
 * Results:
 *      The index of the first new node.
 */

int inline
KDTreeOffline::allocateNodes(int num)
{
   int firstNew = (int) _treeNodes.size();

   STAT_INC_BY(Nodes, num);
   _treeNodes.resize(firstNew + num);
   return firstNew;
}


/*
 * KDTreeOffline::KDTree --
 *
 *   Constructor.  Takes in the build options and the primitives and
 *   builds a kdtree organizing them.
 *
 * Results:
 *   Construction (all members initialized)
 */

KDTreeOffline::KDTreeOffline(const Scene &scene,
                             const KDTreeBuildOptions& opts) : KDTree(scene, opts)
{
   int ii;

   if (sizeof(KDTreeNode) != NODE_SIZE) {
      PRINT(("Uh oh, KDTreeNode is %d bytes, not 8!\n", sizeof(KDTreeNode)));
      assert(sizeof(KDTreeNode) == NODE_SIZE);
   }
   if ((opts.triIndexSize % 4) != 0) {
      PRINT(("Uh oh, triangle indicates are %d bytes, not 4n!\n", opts.triIndexSize));
      assert((opts.triIndexSize % 4) == 0);
   }

   const Vec3f *v0 = (const Vec3f *) scene.vertices(0);
   const Vec3f *v1 = (const Vec3f *) scene.vertices(1);
   const Vec3f *v2 = (const Vec3f *) scene.vertices(2);

   _primitiveCount = scene.nTris();

   std::vector<TrianglePrimitive> buildTris;
   buildTris.resize(_primitiveCount);
   for (ii = 0; ii < _primitiveCount; ii++) {
      buildTris[ii].vertices[0] = v0[ii];
      buildTris[ii].vertices[1] = v1[ii];
      buildTris[ii].vertices[2] = v2[ii];
   }
   _primitives = new TrianglePrimitives(buildTris.size(), &buildTris[0]);
   assert(_primitiveCount == _primitives->getPrimitiveCount());

   // compute bounds for entire tree
   _treeBBox = _primitives->getBounds();
   _invTreeSA = 1.0f / _treeBBox.getSurfaceArea();

   // prepare derived values from the options
   _minNodeExtent = (_treeBBox.maximum - _treeBBox.minimum)
      * _opts.minNodeExtentRatio;

   // create data structures shared across build functions
   uint32 maximumAxisEventCount = _primitiveCount * 2;
   for (int i = 0; i < 3; i++) {
      _splitCandidates[i].resize(maximumAxisEventCount);
   }

   // allocate two nodes for the root so child pairs are 16-byte aligned
   int rootNode = allocateNodes(2);
   assert(rootNode == 0);

   // compute a primitive list for the root
   std::vector<int> initialPrimitiveIndices;
   initialPrimitiveIndices.resize(_primitiveCount);
   for (ii = 0; ii < _primitiveCount; ii++) {
      initialPrimitiveIndices[ii] = ii;
   }
   constructLazy(rootNode, _treeBBox, initialPrimitiveIndices);

   PROFILE_ONLY(startProfile();)

   refineLazy(rootNode);

   PROFILE_ONLY(endProfile();)
   printStats();
}


/*
 * KDTreeOffline::KDTree --
 *
 *   Constructor.  Takes a prebuilt tree (presumably read from disk or some
 *   other store) and wraps a KDTree around it.
 *
 *   XXX The build options are fabricated and the construction information
 *   (primitives, split candidates, etc.) is all lost.
 *
 * Results:
 *   Construction (all members initialized)
 */

KDTreeOffline::KDTreeOffline(const BoundingBox& bbox,
                             const std::vector<KDTreeNode>& nodes,
                             const std::vector<int>& indices) : KDTree(bbox, nodes, indices)
{
   _primitives = NULL;
   _primitiveCount = 0;
}


/*
 * KDTreeOffline::constructLeaf --
 *
 *   Once we've decided not to split a node, we need to append its
 *   primitives to the tree's list and fill in the node fields with the
 *   primitive count and offset to first primitive.
 *
 * Results:
 *   void
 */

void inline
KDTreeOffline::constructLeaf(int inNodeIndex,
                             const std::vector<int> inNodePrimitiveIndices)
{
   KDTreeNode node;

   int numPrimitives = (int) inNodePrimitiveIndices.size();
   int firstPrimitive;

   STAT_INC(Leaves);
   STAT_INC_BY(TriangleIndices, numPrimitives);
   if (numPrimitives == 0) {
      // we could use the primitive index to store
      // special flags in this case - for example
      // to be used in creating "solid" nodes
      // that would be occluders in an MLRTA approach
      firstPrimitive = 0;
      STAT_INC(EmptyLeaves);
   } else {
      firstPrimitive = (int) _primitiveIndices.size();

      for (int i = 0; i < numPrimitives; i++) {
         _primitiveIndices.push_back(inNodePrimitiveIndices[i]);
      }
   }
   // the bottom two bits of the primitive count are set to 1
   // to indicate that this is a leaf node
   node.leaf.firstPrimitive = (firstPrimitive * _opts.triIndexSize) | KD_LEAF;
   node.leaf.numPrimitives = numPrimitives;

   _treeNodes[inNodeIndex] = node;
}


/*
 * KDTreeOffline::constructLazy --
 *
 *      Fills in a lazy node (a node where we the builder stops
 *      refining because it hit the limit specified by the caller rather
 *      than because the cost metric terminated).
 *
 *      So that it interoperates as unobtrusively with normal nodes, the
 *      lazy node is encoded as a funky leaf node with a pointer to an
 *      adjunct structure with the needed build information.
 *
 * Results:
 *      void
 */

void inline
KDTreeOffline::constructLazy(int nodeIndex, const BoundingBox& bbox,
                             const std::vector<int> primitives)
{
   KDTreeLazyInfo *info;

   STAT_INC(Lazy);

   info = new KDTreeLazyInfo();
   info->bbox = bbox;
   info->primitives = primitives;

   _treeNodes[nodeIndex].lazy.lazySentinel = (-1 & (~KD_LEAF)) | KD_LEAF;
   _treeNodes[nodeIndex].lazy.buildInfo = info;
}


/*
 * KDTreeOffline::buildSplitCandidates --
 *
 *   Identifies all the potential split plane locations in the current
 *   node.  At the very least, any vertex of a primitive's bounding box
 *   in the node is a candidate.  Potentially, also vertices of the
 *   primitives themselves or of the intersection of the primitive's
 *   bounding box and the node's bounding box.
 *
 * Results:
 *   void
 */

void inline
KDTreeOffline::buildSplitCandidates(const int *primitiveIndices,
                                    int numPrimitives, const BoundingBox& nodeBBox,
                                    Candidate *axisEvents[3],
                                    int axisEventCounts[3]) const
{
   for (int i = 0; i < numPrimitives; i++) {
      int primitiveIndex = primitiveIndices[i];

      PROFILE_ONLY(float tStartGetClippedBounds = Timer_GetMS();)

      BoundingBox primitiveBounds =
         _primitives->getIndexedPrimitiveClippedBounds(primitiveIndex, nodeBBox);

      PROFILE_ONLY(
         _profileTimeGetClippedBounds += Timer_GetMS() - tStartGetClippedBounds;
      )

      // although this should indicate an emtpy intersection with the current
      // node (and hence a triangle that shouldn't have been here), this can
      // also be tripped for degenerate triangles...
//         assert(primitiveBounds.getSurfaceArea() > 0.0f);

      Candidate event;
      for (int j = 0; j < 3; j++) {
         if (primitiveBounds.minimum[j] == primitiveBounds.maximum[j]) {
            event.kind = CANDIDATE_BeginEnd;
            event.value = primitiveBounds.minimum[j];
            event.primitiveIndex = primitiveIndex;
            axisEvents[j][axisEventCounts[j]++] = event;
         } else {
            event.primitiveIndex = primitiveIndex;

            event.kind = CANDIDATE_Begin;
            event.value = primitiveBounds.minimum[j];
            axisEvents[j][axisEventCounts[j]++] = event;

            event.kind = CANDIDATE_End;
            event.value = primitiveBounds.maximum[j];
            axisEvents[j][axisEventCounts[j]++] = event;
         }
      }
   }
}


/*
 * KDTreeOffline::refineLazy --
 *
 *      Entry point for lazy building.  It pulls the specified node out of
 *      the tree and calls the main refine() function with the arguments it
 *      expects.  When things are all done it frees the cached build info.
 *
 * Results:
 *      void.
 */

void
KDTreeOffline::refineLazy(int nodeOffset)
{
   const KDTreeNode *nodes = &_treeNodes[0];
   const int nodeIndex = nodeOffset >> NODE_SHIFT;
   int sentinel;
   KDTreeLazyInfo *info;

   STAT_INC(Refinements);

   sentinel = GET_NODE(nodes, nodeOffset)->lazy.lazySentinel;
   info = (KDTreeLazyInfo *) GET_NODE(nodes, nodeOffset)->lazy.buildInfo;

   assert((sentinel & KD_LEAF) == KD_LEAF);
   assert(sentinel < 0);

   refineNode(nodeIndex, 1, info->bbox, info->primitives);

   delete info;
}


/*
 * KDTreeOffline::refineNode --
 *
 *   The meat of the building process.  This recursive function takes in
 *   the index of the current node under consideration, its bounding box,
 *   and its primitives.  It identifies the best candidate split plane in
 *   each dimension and compares the estimated cost of using each to the
 *   estimated cost of just declaring this node a leaf.  If it decides to
 *   split, it recursively calls itself with each of the new children.
 *
 * Results:
 *   void
 */

void
KDTreeOffline::refineNode(int nodeIndex, uint32 depth, const BoundingBox& nodeBBox,
                          std::vector<int>& inNodePrimitiveIndices)
      {
   int *primitiveIndices = NULL;
   
   if(inNodePrimitiveIndices.size() > 0)
	   primitiveIndices = &inNodePrimitiveIndices[0];
   
   int numPrimitives = (int) inNodePrimitiveIndices.size();

   /*
    * An empty node should obviously not be split.
    */

   if (numPrimitives == 0) {
      constructLeaf(nodeIndex, inNodePrimitiveIndices);
      return;
   }

   /*
    * Any node whose size relative to the entire scene is sufficiently
    * small isn't worth the cost of refining.
    */

   float absoluteProbabilityOfHit = nodeBBox.getSurfaceArea() * _invTreeSA;
   if (absoluteProbabilityOfHit < _opts.minAbsoluteProbability) {
      constructLeaf(nodeIndex, inNodePrimitiveIndices);
      return;
   }

   /*
    * Lazy early-out: Don't refine if the recursion has already gone as deep
    * as specified in the options.  This is intentionally below the checks
    * above because, even if the node is never visited again, it's cheaper to
    * make it a leaf once than make it a lazy node once and possibly a leaf
    * later.
    */

   if (depth > _opts.refineDepth) {
      constructLazy(nodeIndex, nodeBBox, inNodePrimitiveIndices);
      return;
   }

   /*
    * No easy outs, so generate the list of all locations at which to
    * evaluate splitting the node.
    */

   PROFILE_ONLY(float tStartCreateEvents = Timer_GetMS();)
   int axisEventCounts[3] = { 0, 0, 0 };
   Candidate* axisEvents[3];
   for (int i = 0; i < 3; i++) {
      axisEvents[i] = &_splitCandidates[i][0];
   }
   buildSplitCandidates(primitiveIndices, numPrimitives,
                         nodeBBox, axisEvents, axisEventCounts);
   PROFILE_ONLY(_profileTimeCreateEvents += Timer_GetMS() - tStartCreateEvents;)


   /*
    * Sort the split candidates so they can be evaluated simply from left
    * to right in a single pass.
    */

   PROFILE_ONLY(float tStartSort = Timer_GetMS();)
   for (int i = 0; i < 3; i++) {
      std::sort(axisEvents[i], axisEvents[i] + axisEventCounts[i]);
   }
   PROFILE_ONLY(_profileTimeSort += Timer_GetMS() - tStartSort;)


   /*
    * Take a pass over all the split candidates and pick the one that
    * minimizes the estimated cost for the resulting child nodes.
    */

   PROFILE_ONLY(float tStartSplit = Timer_GetMS();)
   SplitDesc bestSplit;
   bestSplit = chooseEstimatedBestSplit(numPrimitives, nodeBBox,
                                         axisEvents, axisEventCounts);
   PROFILE_ONLY(_profileTimeEstimateBestSplit += Timer_GetMS() - tStartSplit;)


   /*
    * One final early exit-- if the estimate for declaring this node a
    * leaf is better than the estimate for continuing to split, mark this
    * node a leaf and stop recurring.
    */

   double leafCost = estimateLeafCost(nodeBBox, numPrimitives);
   if (leafCost < bestSplit.cost) {
      constructLeaf(nodeIndex, inNodePrimitiveIndices);
      return;
   }


   /*
    * From this point forward we're committed to splitting the node
    * at the location encoded in bestSplit.  We're also done with the
    * primitive list since we'll use the split candidates to build up the
    * lists for the children.
    */

   ReleaseVectorContents(inNodePrimitiveIndices);

   KDTreeNode node;
   int leftChild = allocateNodes(2);
   node.split.leftChild = (leftChild << NODE_SHIFT) | bestSplit.splitAxis;
   node.split.splitValue = bestSplit.splitValue;
   _treeNodes[nodeIndex] = node;
   STAT_INC(Splits);

   /*
    * Some of this work may be redundant with work in
    * estimateBestSplitForAxis, but it is a cleaner
    * breakdown to do it here as well.
    */

   BoundingBox leftChildBounds = nodeBBox;
   leftChildBounds.maximum[bestSplit.splitAxis] = bestSplit.splitValue;

   BoundingBox rightChildBounds = nodeBBox;
   rightChildBounds.minimum[bestSplit.splitAxis] = bestSplit.splitValue;


   int eventCount = axisEventCounts[bestSplit.splitAxis];

   std::vector<int> leftChildPrimitiveIndices;
   std::vector<int> rightChildPrimitiveIndices;

   for (int i = 0; i < bestSplit.index; i++) {
      CandidateType kind = axisEvents[bestSplit.splitAxis][i].kind;
      if (kind == CANDIDATE_Begin || kind == CANDIDATE_BeginEnd) {
         leftChildPrimitiveIndices.push_back(
               axisEvents[bestSplit.splitAxis][i].primitiveIndex);
      }
   }

   if (bestSplit.index < eventCount) {
      /*
       * XXX Huh?  Is this to put planar primitives in both children?
       */
      if (axisEvents[bestSplit.splitAxis][bestSplit.index].kind == CANDIDATE_BeginEnd) {
         rightChildPrimitiveIndices.push_back(axisEvents[bestSplit.splitAxis][bestSplit.index].primitiveIndex);
      }
   }

   for (int i = bestSplit.index+1; i < eventCount; i++) {
      CandidateType kind = axisEvents[bestSplit.splitAxis][i].kind;
      if (kind == CANDIDATE_End || kind == CANDIDATE_BeginEnd)
         rightChildPrimitiveIndices.push_back(
               axisEvents[bestSplit.splitAxis][i].primitiveIndex);
   }

   ++depth;
   refineNode(leftChild, depth, leftChildBounds, leftChildPrimitiveIndices);
   ReleaseVectorContents(leftChildPrimitiveIndices);
   refineNode(leftChild + 1, depth, rightChildBounds, rightChildPrimitiveIndices);
}


/*
 * KDTreeOffline::chooseEstimatedBestSplit --
 *
 *   Iterates through the candidate split planes (events), estimates the
 *   cost of the tree resulting from splitting at each, and returns the
 *   split that minimizes costs.
 *
 * Results:
 *   The split that, according to the approximated cost evaluation, is
 *   the best for this node.
 */

SplitDesc
KDTreeOffline::chooseEstimatedBestSplit(int numPrimitives, const BoundingBox& nodeBBox,
                                        Candidate *axisEvents[3],
                                        int axisEventCounts[3]) const
{
   SplitDesc bestSplit;
   bestSplit.cost = FLT_MAX;

   for (int axis0 = 0; axis0 < 3; axis0++) {
      int leftPrimitiveCount = 0;
      int rightPrimitiveCount = numPrimitives;

      Candidate *events = axisEvents[axis0];
      int eventCount = axisEventCounts[axis0];

      int axis1 = (axis0 + 1) % 3;
      int axis2 = (axis1 + 1) % 3;

      float nodeAxisMinimum = nodeBBox.minimum[axis0];
      float nodeAxisMaximum = nodeBBox.maximum[axis0];
      Vec3f nodeExtents = nodeBBox.maximum - nodeBBox.minimum;
      float nodeAxis0Extent = nodeExtents[axis0];
      float nodeAxis1Extent = nodeExtents[axis1];
      float nodeAxis2Extent = nodeExtents[axis2];
      float offAxisExtent = nodeAxis1Extent + nodeAxis2Extent;

      float baseSurfaceArea = nodeAxis1Extent * nodeAxis2Extent;
      float nodeSurfaceArea = 2*(baseSurfaceArea + nodeAxis0Extent * offAxisExtent);

      float minimumExtent = _minNodeExtent[axis0];
      float minSplitPosition = nodeAxisMinimum + minimumExtent;
      float maxSplitPosition = nodeAxisMaximum - minimumExtent;

      int trialEventIndex = 0;
      while((trialEventIndex < eventCount) &&
             (events[trialEventIndex].value < minSplitPosition)) {
         // skip through any events that are before the allowed range
         if (events[trialEventIndex].kind == CANDIDATE_End) {
            rightPrimitiveCount--;
         } else if (events[trialEventIndex].kind == CANDIDATE_BeginEnd) {
            leftPrimitiveCount++;
            rightPrimitiveCount--;
         } else if (events[trialEventIndex].kind == CANDIDATE_Begin) {
            leftPrimitiveCount++;
         }

         trialEventIndex++;
      }

      for (; trialEventIndex < eventCount; trialEventIndex++) {
         float trialSplitValue = events[trialEventIndex].value;

         // once we have left the allowed range, we are done
         if (trialSplitValue > maxSplitPosition) {
            goto doneWithThisAxis;
         }

         if (events[trialEventIndex].kind == CANDIDATE_End) {
            rightPrimitiveCount--;
         }

         float leftSurfaceArea = 2*(baseSurfaceArea + (trialSplitValue - nodeAxisMinimum) * offAxisExtent);
         float rightSurfaceArea = 2*(baseSurfaceArea + (nodeAxisMaximum - trialSplitValue) * offAxisExtent);

         double trialCost = estimateSplitCost(
               nodeSurfaceArea, leftSurfaceArea, leftPrimitiveCount,
               rightSurfaceArea, rightPrimitiveCount);

         if (trialCost < bestSplit.cost) {
            bestSplit.splitAxis = axis0;
            bestSplit.splitValue = trialSplitValue;
            bestSplit.index = trialEventIndex;
            bestSplit.cost = trialCost;
         }

         if (events[trialEventIndex].kind == CANDIDATE_BeginEnd) {
            leftPrimitiveCount++;
            rightPrimitiveCount--;
         }

         if (events[trialEventIndex].kind == CANDIDATE_Begin) {
            leftPrimitiveCount++;
         }
      }

      assert(leftPrimitiveCount == numPrimitives);
      assert(rightPrimitiveCount == 0);

doneWithThisAxis:

      // one last event for when we are all the way to the other side...
      float trialSplitValue = events[eventCount-1].value;

      if( (trialSplitValue >= minSplitPosition)
  && (trialSplitValue <= maxSplitPosition) )
      {

         double leftSurfaceArea = 2*(baseSurfaceArea + (trialSplitValue - nodeAxisMinimum) * offAxisExtent);
         double rightSurfaceArea = 2*(baseSurfaceArea + (nodeAxisMaximum - trialSplitValue) * offAxisExtent);
         double trialCost = estimateSplitCost(nodeSurfaceArea, leftSurfaceArea,
                                            numPrimitives, rightSurfaceArea, 0);

         if (trialCost < bestSplit.cost) {
            bestSplit.splitAxis = axis0;
            bestSplit.splitValue = trialSplitValue;
            bestSplit.index = eventCount;
            bestSplit.cost = trialCost;
         }
      }
   }
   return bestSplit;
}


/*
 * KDTreeOffline::printStats --
 *
 *      Dumps the current contents of the stat counters.
 *
 * Results:
 *      void
 */

void
KDTreeOffline::printStats(void) const
{
   Stats_Print();
}


#ifdef PROFILE_KDTREE_BUILD
/*
 * KDTreeOffline::initializeProfiler --
 *
 *   Zeroes all the of state for the builtin profiler and returns the
 *   start time.
 *
 * Results:
 *   The time at which the profiler was reset.
 */

float
KDTreeOffline::initializeProfiler(void)
{
   memset(&_profile, 0, sizeof _profile);
   _profile.timeStart = Timer_GetMS();
}


/*
 * KDTreeOffline::printProfile --
 *
 *   Stops the profiler and dumps the accumulated timing results.
 *
 * Results:
 *   void
 */

void
KDTreeOffline::printProfile(float totalElapsed)
{
   float total = Timer_GetMS() - _profile.timeStart;

   fprintf(stderr,
         "k-D Tree build profile:\n"
         "  Total refineNode + children: %.2f msecs\n"
         "    Create events: %.2f msecs\n"
         "       Get clipped bounds: %.2f msecs\n"
         "    Sort: %.2f msecs\n"
         "    Estimate best split + children: %.2f msecs\n\n",
         total,
         _profile.timeCreateEvents,
         _profile.timeGetClippedBounds,
         _profile.timeSort,
         _profile.timeEstimateBestSplit);
}
#endif
