/*
 * kdtree.h -
 *
 *      Implements the actually k-D tree data structure, accessors, and
 *      builder.  Does NOT implement any intersection / traversal.
 */

#ifndef __BUILDER_KDTREE_H__
#define __BUILDER_KDTREE_H__

#include "../scene.h"
#include "../main.h"


/*
 * This is a literal 8 instead of sizeof(KDTreeNode) on purpose.  The
 * calculations below rely upon it being at least a multiple of 8 and I want
 * to know if it ever changes (see the assert() in KDTreePU() ctor).
 */
#define NODE_SIZE       8
#define NODE_SHIFT      3
#define GET_NODE(t, n) ((KDTreeNode *) (((uint8 *) (t)) + (n)))


enum KDTreeNodeType {
   KD_SPLIT_X = 0,
   KD_SPLIT_Y = 1,
   KD_SPLIT_Z = 2,
   KD_LEAF = 3,
};


union KDTreeNode {
   struct {
      // index of left child (right child is at this index + 1)
      // bottom two bits store node "kind", so the index is left-shifted
      uint32 leftChild;

      // position of split plane along the axis stored in
      // the node kind
      float splitValue;
   } split;

   struct {
      // index of first primitive index for this leaf
      // bottom two bits store node "kind", so the count is left-shifted
      uint32 firstPrimitive;

      // number of primitives
      uint32 numPrimitives;
   } leaf;

   struct {
      // Top bits are all -1 to indicate lazy node instead of leaf
      // bottom two bits store node "kind", so the count is left-shifted
      int lazySentinel;

      // Pointer to an extension with state to continue building
      void *buildInfo;
   } lazy;
};


struct KDTreeBuildOptions {
   /*
    * Disallow splits unless both sides have an extent greater than the
    * amount specified (relative to the scene bounds).  Setting this to
    * non-zero disallows planar cells, but helps low precision architectures.
    */
   float minNodeExtentRatio;

   /*
    * Extra termination criterion-- The probability that a random ray hits a
    * given cell is a function of that cell's surface area relative to scene
    * size.  Disallow splits once a cell is small enough that its
    * probability of being hit is sufficiently small.
    */
   float minAbsoluteProbability;

   float emptyLeafCost;
   float leafCost;
   float isectCost;
   float splitCost;

   int triIndexSize;    /* Amount by which to scale triangle indices */
   uint32 refineDepth;  /* How deeply to refine each time */

   KDTreeBuildOptions(void) {
      minNodeExtentRatio = 0.0f; /* Allow planar and arbitrarily skinny cells */
      minAbsoluteProbability = 0.0000000001f;

      emptyLeafCost = 0.0f;
      leafCost = 0.0f;

      splitCost = 1.0f;
      isectCost = 40.0f;

      triIndexSize = sizeof(uint32);
      refineDepth = (uint32) -1;
   }

};


class KDTree {
public:
   KDTree(const Scene &scene, const KDTreeBuildOptions& opts) :
      _opts(opts) { ; }
   KDTree(const BoundingBox& bbox,
          const std::vector<KDTreeNode>& nodes,
          const std::vector<int>& indices) :
      _treeBBox(bbox), _treeNodes(nodes), _primitiveIndices(indices) { ; }

   virtual void refineLazy(int nodeIndex) = 0;

   int inline getNodeCount(void) { return _treeNodes.size(); }
   const KDTreeNode *getNodes(void) { return &_treeNodes[0]; }

   inline int getPrimitiveIndexCount() {return _primitiveIndices.size(); }
   inline const int* getPrimitiveIndices() { return &_primitiveIndices[0] ; }

   BoundingBox inline getBounds(void) const { return _treeBBox; }

   virtual void printStats(void) const = 0;

protected:
   KDTreeBuildOptions _opts;
   Vec3f _minNodeExtent;

   BoundingBox _treeBBox;
   std::vector<KDTreeNode> _treeNodes;
   std::vector<int> _primitiveIndices;
};

extern KDTree *KDTree_Create(const Opts& cmdLineOpts,
                             const Scene& scene,
                             const KDTreeBuildOptions& opts);
extern KDTree *KDTree_Create(const Opts& cmdLineOpts,
                             const BoundingBox& box,
                             const std::vector<KDTreeNode>& nodes,
                             const std::vector<int>& indices);
#endif
