/*
 * clippedTrianglePrimitives.h --
 *
 *      Implementation of the IPrimitives
 *      interface for a simple list of triangles
 */

#ifndef __CLIPPEDTRIANGLEPRIMITIVES_H__
#define __CLIPPEDTRIANGLEPRIMITIVES_H__

#include "primitives.h"
#include "trianglePrimitives.h"
#include "../common/commonTypes.h"

#include <vector>

/*
* ClippedTrianglePrimitives --
*
*/

class ClippedTrianglePrimitives : public TrianglePrimitives
{
public:
   ClippedTrianglePrimitives( int inTriangleCount, const TrianglePrimitive* inTriangles );

   // return a bounding box to enclose the portion of
   // the specified triangle that intersects the passed-in
   // bounding box
   BoundingBox getIndexedPrimitiveClippedBounds( int inIndex, const BoundingBox& inBounds ) const;
};

#endif
