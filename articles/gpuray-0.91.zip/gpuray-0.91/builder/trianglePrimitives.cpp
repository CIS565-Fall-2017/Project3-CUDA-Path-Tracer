/*
 * trianglePrimitives.cpp --
 *
 *      Implementation of the IPrimitives
 *      interface for a simple list of triangles
 */

#include "trianglePrimitives.h"

/*
 * TrianglePrimitive::TrianglePrimitive -
 *
 *      Constructor: initialize with given vertices.
 */

TrianglePrimitive::TrianglePrimitive( Vec3f inVertex0, Vec3f inVertex1, Vec3f inVertex2 )
{
   vertices[0] = inVertex0;
   vertices[1] = inVertex1;
   vertices[2] = inVertex2;
}

/*
 * TrianglePrimitive::getBounds -
 *
 *      Computes an AABB for this triangle
 *      Returns: bounding box
 */

BoundingBox TrianglePrimitive::getBounds() const
{
   BoundingBox result;
   result = join( result, vertices[0] );
   result = join( result, vertices[1] );
   result = join( result, vertices[2] );
   return result;
}

/*
 * TrianglePrimitives::TrianglePrimitives -
 *
 *      Constructor: initialize primitive list with given triangles
 */

TrianglePrimitives::TrianglePrimitives( int inTriangleCount, const TrianglePrimitive* inTriangles )
{
   _triangles.resize( inTriangleCount );
   memcpy( &_triangles[0], inTriangles, inTriangleCount*sizeof(TrianglePrimitive) );

   for( int i = 0; i < inTriangleCount; i++ )
      _bounds = join( _bounds, inTriangles[i].getBounds() );
}

/*
 * TrianglePrimitives::getIndexedPrimitiveClippedBounds -
 *
 *      Compute bounds for given triangle, after clipping triangle
 *      to the passed-in rectangle.
 */

BoundingBox TrianglePrimitives::getIndexedPrimitiveClippedBounds( int inIndex, const BoundingBox& inBounds ) const
{
   // TIM: for now:
   return intersect( _triangles[ inIndex ].getBounds(), inBounds );
}
