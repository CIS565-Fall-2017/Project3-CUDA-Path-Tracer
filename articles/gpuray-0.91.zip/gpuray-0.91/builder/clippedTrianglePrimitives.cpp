/*
 * clippedTrianglePrimitives.cpp --
 *
 *      Implementation of the IPrimitives
 *      interface for a simple list of triangles
 */

#include "clippedTrianglePrimitives.h"

/*
 * ClippedTrianglePrimitives::ClippedTrianglePrimitives -
 *
 *      Constructor: initialize primitive list with given triangles
 */

ClippedTrianglePrimitives::ClippedTrianglePrimitives( int inTriangleCount, const TrianglePrimitive* inTriangles )
   : TrianglePrimitives( inTriangleCount, inTriangles )
{
}

/*
 * clipSegment -
 *
 *      Take the segment defined by (inFirst, inSecond) and
 *      generate appropriate vertices for a clipped polygon
 *      in ioVertices. The plane to clip against is defined
 *      by inAxis and inValue, and the side to clip on is
 *      defined by inSense (1 means above == inside and
 *      -1 means below == inside).
 *
 *      The clipping rules are:
 *      1st inside, 2nd inside - emit 2nd
 *      1st inside, 2nd outside - emit lerp( 1st, 2nd )
 *      1st outside, 2nd inside - emit lerp( 1st, 2nd ) and 2nd
 *      1st outside, 2nd outside - emit nothing
 */

static void clipSegment( Vec3f inFirst, Vec3f inSecond, int inAxis, float inValue, float inSense, std::vector<Vec3f>& ioVertices )
{
   bool firstInside = (inFirst[inAxis] - inValue) * inSense >= 0;
   bool secondInside = (inSecond[inAxis] - inValue) * inSense >= 0;

   if( firstInside != secondInside )
   {
      /*
       * We need to emit a vertex at the point where the
       * segment crosses the plane. We compute this
       * as a lerp of the two end points.
       *
       * It is important to note that we compute lerp(A,B,t)
       * as A + (B-A)*t rather than A*(1-t) + B*t.
       * This guarantees that in the case where A[i] == B[i]
       * (as would happen when they are both the result of
       * clipping against a plane in direction i) we generate
       * precisely the same value.
       */

      float tHit = (inValue - inFirst[inAxis]) / (inSecond[inAxis] - inFirst[inAxis]);
      Vec3f pHit = inFirst + (inSecond-inFirst)*tHit;
      pHit[inAxis] = inValue;

      ioVertices.push_back( pHit );
   }

   if( secondInside )
   {
      ioVertices.push_back( inSecond );
   }
}

/*
 * clipSegment -
 *
 *      Take the polygon defined by the vertices in inVertices
 *      (assumed to be a planar convex polygon) and 
 *      generate appropriate vertices for a clipped polygon
 *      as result. The plane to clip against is defined
 *      by inAxis and inValue, and the side to clip on is
 *      defined by inSense (1 means above == inside and
 *      -1 means below == inside).
 *
 *      Returns: the vertices of the clipped polygon as a std::vector
 */

static std::vector<Vec3f> clip( std::vector<Vec3f> inVertices, int inAxis, float inValue, float inSense )
{
   std::vector<Vec3f> result;

   int vertexCount = (int) inVertices.size();
   for( int i = 0; i < vertexCount; i++ )
   {
      clipSegment( inVertices[i], inVertices[(i+1)%vertexCount], inAxis, inValue, inSense, result );
   }

   return result;
}

/*
 * ClippedTrianglePrimitives::getIndexedPrimitiveClippedBounds -
 *
 *      Compute bounds for given triangle, after clipping triangle
 *      to the passed-in rectangle.
 */

BoundingBox ClippedTrianglePrimitives::getIndexedPrimitiveClippedBounds( int inIndex, const BoundingBox& inBounds ) const
{
   std::vector<Vec3f> vertices;
   vertices.resize( 3 );

   for( int i = 0; i < 3; i++ )
      vertices[i] = _triangles[inIndex].vertices[i];

   for( int i = 0; i < 3; i++ )
   {
      vertices = clip( vertices, i, inBounds.minimum[i], 1 );
      vertices = clip( vertices, i, inBounds.maximum[i], -1 );
   }

   if( vertices.size() == 0 )
      return BoundingBox( Vec3f(0), Vec3f(0) );

   BoundingBox result( vertices[0], vertices[0] );
   for( unsigned int i = 1; i < vertices.size(); i++ )
      result = join( result, vertices[i] );

   return result;
}
