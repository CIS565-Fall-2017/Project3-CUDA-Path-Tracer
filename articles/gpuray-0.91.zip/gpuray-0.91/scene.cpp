/* *************************************************************************
 * Copyright (C) 2006 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * scene.cpp --
 *
 *      Wraps all the scene data loading from files and such.
 */

#include <assert.h>
#include <float.h>
#include <string>

#include "scene.h"
#include "log.h"
#include "sceneparser.h"

#define WRITE_TRI_SIMPLE 0
#define FABRICATE_SPEC 0


/*
 * Scene::Scene --
 *
 *      Constructor.  Pulls the filename out of the commandline parameters,
 *      parses the scene description file, and loads the data.
 *
 * Results:
 *      None (other than construction)
 */

Scene::Scene(const Opts& opts)
{
   _specular = NULL;
   _specularExp = NULL;

   bool newFormat = InitializeSceneData(opts);
   if (newFormat) {
      InitializeTriangleDataSimple(opts);
   } else {
      // If enabled, write the data out in the new format
      if (WRITE_TRI_SIMPLE) {
         WriteTriangleDataSimple(opts.sceneName);
      }
   }
   PrintSceneGeometry(opts.verbose);
}


/*
 * Scene::~Scene --
 *
 *      Destructor.  Just frees a bunch of things.
 *
 * Results:
 *      void.
 */

Scene::~Scene(void)
{
   // delete v0, v1, v2?

   delete [] _specular;
   delete [] _specularExp;

   /*
    * XXX Free Grid and Grid data...
    */
   memset(&_params, 0, sizeof _params);
   memset(&_simpleScene, 0, sizeof _simpleScene);
}


/*
 * Scene::InitializeSceneData --
 *
 *      Reads in all the triangles in either voxelized or raw triangle form
 *      and builds the structure recording whole scene parameters (e.g.
 *      bounding box, camera initial positions, etc.)
 *
 * Results:
 *      true if the scene data is in the new format, else false.
 */

bool
Scene::InitializeSceneData(const Opts& opts)
{
   _sceneName = opts.sceneName;

   /*
    * Load scene parameters
    */

   std::string sceneFileName = "scenes/" + std::string(opts.sceneName) + ".xml";
   parseScene(sceneFileName, _params);

   /*
    * Read and intialize scene data.
    */

   memset(&_grid, 0, sizeof _grid);
   switch (_params.sceneType) {
   case kSceneType_Vox:
      ReadVoxFile(_params.fileName, opts.verbose, _grid,
                  *(Point3 **) &_v[0], *(Point3 **) &_v[1], *(Point3 **) &_v[2],
                  *(Normal3 **) &_n[0], *(Normal3 **) &_n[1], *(Normal3 **) &_n[2],
                  *(Spectra **) &_c[0], *(Spectra **) &_c[1], *(Spectra **) &_c[2]);
      break;

   case kSceneType_Triangles:
      memset(&_grid, 0, sizeof _grid);
      ReadTrianglesFile(_params.fileName, _grid,
                  *(Point3 **) &_v[0], *(Point3 **) &_v[1], *(Point3 **) &_v[2],
                  *(Normal3 **) &_n[0], *(Normal3 **) &_n[1], *(Normal3 **) &_n[2],
                  *(Spectra **) &_c[0], *(Spectra **) &_c[1], *(Spectra **) &_c[2]);
      break;
   case kSceneType_Simple:
      ReadSceneFile(_params.fileName, opts.verbose, &_simpleScene);
      break;
   default:
      fprintf(stderr, "Unknown scene type: %d\n", _params.sceneType);
      exit(-1);
      break;
   }

   return _params.sceneType == kSceneType_Simple;
}


/*
 * Scene::InitializeTriangleDataSimple --
 *
 *      The 'Simple' file format is the newer one and includes support for
 *      material properties and various other goodies.
 *
 * Results:
 *      void
 */

void
Scene::InitializeTriangleDataSimple(const Opts& opts)
{
   Batch *batch = &_simpleScene.batches[0];
   assert(_simpleScene.batchCount == 1);

   // Set up the grid
   _grid.nTris = batch->triangleCount;

   _v[0] = new F3[batch->triangleCount];
   _v[1] = new F3[batch->triangleCount];
   _v[2] = new F3[batch->triangleCount];
   _n[0] = new F3[batch->triangleCount];
   _n[1] = new F3[batch->triangleCount];
   _n[2] = new F3[batch->triangleCount];
   _c[0] = new F3[batch->triangleCount];
   _c[1] = new F3[batch->triangleCount];
   _c[2] = new F3[batch->triangleCount];

   Vec3f min, max;
   min.x = min.y = min.z = FLT_MAX;
   max.x = max.y = max.z = 0;

   // This ugly block finds the min and max coords of the scene
   for (int i = 0; i < batch->triangleCount; i++) {
      _v[0][i] = batch->vertices[i * 3];
      _v[1][i] = batch->vertices[i * 3 + 1];
      _v[2][i] = batch->vertices[i * 3 + 2];
      _n[0][i] = batch->normals[i * 3];
      _n[1][i] = batch->normals[i * 3 + 1];
      _n[2][i] = batch->normals[i * 3 + 2];
      _c[0][i] = batch->diffuseColors[i * 3];
      _c[1][i] = batch->diffuseColors[i * 3 + 1];
      _c[2][i] = batch->diffuseColors[i * 3 + 2];

      if (batch->vertices[i*3].x < min.x) min.x = batch->vertices[i*3].x;
      if (batch->vertices[i*3].y < min.y) min.y = batch->vertices[i*3].y;
      if (batch->vertices[i*3].z < min.z) min.z = batch->vertices[i*3].z;

      if (batch->vertices[i*3+1].x < min.x) min.x = batch->vertices[i*3].x;
      if (batch->vertices[i*3+1].y < min.y) min.y = batch->vertices[i*3].y;
      if (batch->vertices[i*3+1].z < min.z) min.z = batch->vertices[i*3].z;

      if (batch->vertices[i*3+2].x < min.x) min.x = batch->vertices[i*3].x;
      if (batch->vertices[i*3+2].y < min.y) min.y = batch->vertices[i*3].y;
      if (batch->vertices[i*3+2].z < min.z) min.z = batch->vertices[i*3].z;

      if (batch->vertices[i*3].x > max.x) max.x = batch->vertices[i*3].x;
      if (batch->vertices[i*3].y > max.y) max.y = batch->vertices[i*3].y;
      if (batch->vertices[i*3].z > max.z) max.z = batch->vertices[i*3].z;

      if (batch->vertices[i*3+1].x > max.x) max.x = batch->vertices[i*3].x;
      if (batch->vertices[i*3+1].y > max.y) max.y = batch->vertices[i*3].y;
      if (batch->vertices[i*3+1].z > max.z) max.z = batch->vertices[i*3].z;

      if (batch->vertices[i*3+2].x > max.x) max.x = batch->vertices[i*3].x;
      if (batch->vertices[i*3+2].y > max.y) max.y = batch->vertices[i*3].y;
      if (batch->vertices[i*3+2].z > max.z) max.z = batch->vertices[i*3].z;
   }
   _grid.max = max;
   _grid.min = min;

   // Do speculars
   if (batch->specularColors != NULL) {
      _specular = new F3[batch->vertexCount];
      _specularExp = new float[batch->vertexCount];

      memset(_specular, 0, batch->vertexCount * sizeof(F3));
      memset(_specularExp, 0, batch->vertexCount * sizeof(float));
      memcpy(_specular,
             &batch->specularColors[0], batch->vertexCount*sizeof(F3));
      memcpy(_specularExp,
             &batch->specularExp[0], batch->vertexCount*sizeof(float));

      /*
       * The code really assumes everything that's per-vertex is actually
       * 3x per-triangle (and vertices are duplicated for each triangle that
       * shares them).
       */
      assert(batch->triangleCount * 3 == batch->vertexCount);
   }
}


/*
 * Scene::WriteTriangleDataSimple --
 *
 *      Writes the triangle, normal, colour, etc. data to file.  This
 *      explicitly doesn't use the fileformat code so that it can write data
 *      read from other fileformats.  Specifically, we write out a single
 *      batch that contains everything.
 *
 *      XXX The proper way to do this would be to convert to the
 *      representation the simple fileformat code expects and use its
 *      routines for writing data.
 *
 * Results:
 *      void, but "sceneName".ss is written to disk.
 */

void
Scene::WriteTriangleDataSimple(const char *sceneName) const
{
   int triCount = _grid.nTris;
   char *fname;
   int count;
   FILE *fp;

   fname = new char[strlen(sceneName)+4];
   strcpy(fname, sceneName);
   strcat(fname, ".ss");

   if ((fp = fopen(fname, "wb")) == NULL) {
      assert(false);
   }
   delete fname;

   // write num batches
   count = 1;
   fwrite (&count, sizeof(int), 1, fp);

   // write num attribs: (e.g. specular, normals, diffuse colours)
   count = FABRICATE_SPEC ? 3 : 2;
   fwrite (&count, sizeof(int), 1, fp);

   // write num vertices
   count = triCount*3;
   fwrite (&count, sizeof(int), 1, fp);

   // write vertices
   for (int i=0; i < triCount; i++) {
      fwrite(&_v[0][i], sizeof(Vec3f), 1, fp);
      fwrite(&_v[1][i], sizeof(Vec3f), 1, fp);
      fwrite(&_v[2][i], sizeof(Vec3f), 1, fp);
   }

   // write normals
   int type = NORMAL;
   fwrite (&type, sizeof(int), 1, fp);
   for (int i=0; i < triCount; i++) {
      fwrite(&_n[0][i], sizeof(Vec3f), 1, fp);
      fwrite(&_n[1][i], sizeof(Vec3f), 1, fp);
      fwrite(&_n[2][i], sizeof(Vec3f), 1, fp);
   }

   // write diffuse colors
   type = DIFFUSE;
   fwrite (&type, sizeof(int), 1, fp);
   for (int i=0; i < triCount; i++) {
      fwrite(&_c[0][i], sizeof(Vec3f), 1, fp);
      fwrite(&_c[1][i], sizeof(Vec3f), 1, fp);
      fwrite(&_c[2][i], sizeof(Vec3f), 1, fp);
   }

   // write out some random specular values
   if (FABRICATE_SPEC) {
      type = SPECULAR;
      fwrite (&type, sizeof(int), 1, fp);
      Vec3f spec;
      spec.x = spec.y = spec.z = 1;  //everything will have spec highlighting!

      for (int i=0; i<count; i++) {
         fwrite(&spec, sizeof(Vec3f), 1, fp);
      }

      float specExp = 64;
      for (int i=0; i<count; i++) {
         fwrite(&specExp, sizeof(float), 1, fp);  //between 0-128 in opengl
      }
   }

   //write out tri count
   fwrite(&triCount, sizeof(int), 1, fp);

   // write out triangle indeces... for now is just flat
   for (int i=0; i<count; i++)
      fwrite(&i, sizeof(int), 1, fp);

   fclose(fp);
}


/*
 * Scene::PrintSceneGeometry --
 *
 *      Dumps a bunch of (perhaps) useful information about the scene
 *      contents.
 *
 * Results:
 *      void.
 */

void
Scene::PrintSceneGeometry(bool verbose) const
{
   PRINT(("   Grid: %i triangles, %ix%ix%i voxels, %i trilist size.\n",
          _grid.nTris, _grid.dim.x, _grid.dim.y, _grid.dim.z,
          _grid.trilistSize));
   PRINT(("   Grid: BBox: Min: (%.2f, %.2f, %.2f) Max: (%.2f, %.2f, %.2f)\n",
          _grid.min.x, _grid.min.y, _grid.min.z,
          _grid.max.x, _grid.max.y, _grid.max.z));
   LOG(("   Grid: VSize %.2fx%.2fx%.2f\n",
        _grid.vsize.x, _grid.vsize.y, _grid.vsize.z));

   if (verbose) {
      int maxLength, length, last, i;

      PRINT(("Triangle List:\n"));
      maxLength = length = 0;
      for(i = 0; i < _grid.trilistSize; i++) {
         PRINT(("%i ", _grid.trilist[i]));
         if (_grid.trilist[i] != -1) {
            length++;
         } else {
            PRINT(("Length: %d\n", length));
            if (length > maxLength) {
               maxLength = length;
            }
            length = 0;
         }
      }
      PRINT(("Max length: %d\n", maxLength));

      PRINT(("Triangle List Offsets:\n"));
      maxLength = 0;
      last = _grid.trilistOffset[0];
      for (i = 1; i < _grid.dim.x * _grid.dim.y * _grid.dim.z; i++) {
         PRINT(("%i ", _grid.trilistOffset[i]));

         /* The -1 subtracts off the space for the sentinel */
         length = _grid.trilistOffset[i] - last - 1;
         last = _grid.trilistOffset[i];
         if (length > maxLength) {
            maxLength = length;
         }
      }
      length = _grid.trilistSize - last - 1;
      if (length > maxLength) {
         maxLength = length;
      }
      PRINT(("\n"));
      PRINT(("Max length: %d\n", maxLength));
   }
}
