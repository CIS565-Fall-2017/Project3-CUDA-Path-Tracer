/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * stats.h --
 *
 *      A module exporting basic counters and some simple manipulations.
 */

#ifndef __STATS_H__
#define __STATS_H__

#include <assert.h>

#ifdef __cplusplus
extern "C" {
#endif


/*
 * For now, define stats iff debug builds
 */

#ifndef NDEBUG
#define STATS   1
#endif


/*
 * Stupid preprocessor.  You need the extra level of indirection to
 * stringify and concatenate #defines with other things reliably.
 */

#define BARECONC(x, y)          x##y
#define CONC(x, y)              BARECONC(x, y)
#define BARESTR(x)              #x
#define STR(x)                  BARESTR(x)

#ifdef STATS
#define STATS_ONLY(block) do { block } while(0)

#define STATNAME(name)    CONC(_stats_, CONC(STATS_MODULE, name))
#define STAT_GET(name)    (&CONC(_stats_, STATS_MODULE)[STATNAME(name)])
#define STAT_SET(name, n) ((*STAT_GET(name)) = (n))
#define STAT_CLEAR(name)  STAT_SET(name, 0)
#define STAT_INC(name)    ((*STAT_GET(name))++)
#define STAT_INC_BY(name, n)    ((*STAT_GET(name)) += (n))


#ifdef STATS_DEFINE_COUNTERS
   #ifndef STATS_COUNTERS
   #error  "STATS_COUNTER must be defined to use stats!"
   #endif

   #define DEFN_STAT(name, purpose)  STATNAME(name),
   enum CONC(_stats_counters_, STATS_MODULE) {
      STATS_COUNTERS
      STATNAME(Last)
   };
   #undef DEFN_STAT
   #define DEFN_STAT(name, purpose)  STR(STATS_MODULE) ":" STR(name),
   const char *CONC(_stats_names_, STATS_MODULE)[] = {
      STATS_COUNTERS
      NULL,
   };
   #undef DEFN_STAT
   unsigned int CONC(_stats_, STATS_MODULE)[STATNAME(Last)];

   /*
    * Stats_Print --
    *
    *      Inline function to dump all the stats for a given module.  It's
    *      inline because the STATS_MODULE and such are embedded in the code
    *      (and it's just easier to write it this way and allow modules to
    *      decide how and when to print their stats.
    *
    *  Results:
    *      void.
    */

   static inline void
   Stats_Print(void)
   {
      unsigned int ii;

      PRINT(("Stats for module %s\n", STR(STATS_MODULE)));
      for (ii = 0; ii < STATNAME(Last); ii++) {
         assert(CONC(_stats_names_, STATS_MODULE)[ii] != NULL);
         if (CONC(_stats_, STATS_MODULE)[ii] > 0) {
            PRINT(("   %-30s\t%12d\n",
                   CONC(_stats_names_, STATS_MODULE)[ii],
                   CONC(_stats_, STATS_MODULE)[ii]));
            CONC(_stats_, STATS_MODULE)[ii] = 0;
         }
      }
   }
#endif
#else
#define STATS_ONLY(block)
#define STAT_GET(name)
#define STAT_SET(name, n)
#define STAT_CLEAR(name)
#define STAT_INC(name)
#define STAT_INC_BY(name, n)
#ifdef STATS_DEFINE_COUNTERS
   static inline void Stats_Print(void) {}
#endif
#endif


#ifdef __cplusplus
}
#endif
#endif
