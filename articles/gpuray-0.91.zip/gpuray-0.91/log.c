/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * log.c --
 *
 *      Simple log module.
 */

#include <stdarg.h>
#include <stdio.h>
#include <assert.h>
#include <errno.h>
#include <string.h>

#include "log.h"

FILE *_logFD;
int _quiet;


/*
 * Log_Open --
 *
 *      Opens the specified file to be the log and turns on logging.
 *
 * Returns:
 *      void.
 */

void
Log_Open(const char *fileName)
{
   if (_logFD != NULL) {
      fprintf(stderr, "LOG: Already logging, switching log to %s\n", fileName);

      fclose(_logFD);
      _logFD = NULL;
   }

   if ((_logFD = fopen(fileName, "wb")) == NULL) {
      fprintf(stderr, "LOG: Unable to open %s: %s!\n",
              fileName, strerror(errno));
   }
   PRINT(("Logging to %s.\n", fileName));
}


/*
 * Log_Close --
 *
 *      Closes the log and stops logging.
 *
 * Returns:
 *      void.
 */

void
Log_Close(void)
{
   fclose(_logFD);
   _logFD = NULL;
}


/*
 * Log --
 *
 *      Writes the specified contents to the log.
 *
 * Returns:
 *      void.
 */

void
Log(const char *fmt, ...)
{
   va_list args;
   assert(_logFD != NULL);

   va_start(args, fmt);
   vfprintf(_logFD, fmt, args);
   va_end(args);

   fflush(_logFD);
}
