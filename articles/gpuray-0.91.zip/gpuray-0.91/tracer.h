/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * tracer.h --
 *
 *      Class to wrap up all the details of the actual ray tracing.
 */

#ifndef __TRACER_H__
#define __TRACER_H__

#include "main.h"

class CameraManager;
class Scene;
class IRenderContext;
class IRayGenerator;

class ToggleOption
{
public:
   ToggleOption( bool inInitialValue, const char* inDescription = "" )
      : _value(inInitialValue), _description(inDescription)
   {
   }

   bool isEnabled() { return _value; }
   const char* getDescription() { return _description; }

   void toggle() { _value = !_value; }

private:
   bool _value;
   const char* _description;
};

class ITracer {
public:
   // handle a change in the requested render size
   virtual void Resize( int inWidth, int inHeight ) = 0;

   // perform ray tracing in response to a change
   // in scene or camera parameters
   // and return the approximate frames per second
   virtual void TraceRays() = 0;

   // do whatever is neccesary to display the last
   // result traced to the user (the implementation
   // will depend on the tracing algorithm).
   virtual void Display() = 0;
};

class DefaultTracer : public ITracer {
public:
   DefaultTracer( IRayGenerator* inRayGenerator )
      : _rayGenerator( inRayGenerator ) {}

   void Resize( int inWidth, int inHeight )
   { _width = inWidth; _height = inHeight; }

   void TraceRays();

   void Display() {}

private:
   IRayGenerator* _rayGenerator;

   int _width, _height;
};

class TracerFixedSize : public ITracer {
public:
   TracerFixedSize( ITracer* inInner, int inWidth, int inHeight );
   void Resize( int inWidth, int inHeight );
   void TraceRays();
   void Display();

private:
   ITracer* _inner;
};

class IRayGenerator
{
public:
   virtual void Generate( int inWidth, int inHeight ) = 0;
};

ITracer* CreateTracer(
   const Opts& inOptions,
   Scene* inScene,
   CameraManager* inCameraManager,
   IRenderContext* inRenderContext );

void
RenderOffline(const Opts& inOptions);

#endif
