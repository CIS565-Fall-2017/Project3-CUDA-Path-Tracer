/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * tracer.cpp --
 *
 *      Class to wrap up all the details of the actual ray tracing.
 */

#include <assert.h>

#include "tracer.h"
#include "log.h"
#include "timer.h"
#include "cpu/cpuTracer.h"
#include "cpu/cpuDisplay.h"
#include "cpu/shader.h"

#ifdef USE_CTM
  #include "ctm/ctmTracer.h"
  #include "ctm/ctmDisplay.h"
  #include "ctm/shader.h"
#endif

#if defined (USE_BROOK)
//defined(USE_CTM)||defined(USE_CTM_BROOK)
  #include "ctm/ctmTracer.h"
  #include "ctm/ctmTypes.h"
  #include "ctm/brookshader.h"
  #include "ctm/ctmDisplay.h"
#endif
#ifdef USE_BROOK
  #include "brook/brookTracer.h"
  #include "brook/brookDisplay.h"
  #include "brook/brookInterop.h"
#endif

#include "raster.h"
#include "fileIO/ppmImage.h"

#ifdef WINDOWS
  #include "renderContextGDI.h"
  #include "renderContextDX.h"
  #if defined(USE_CTM) || defined(USE_BROOK)
    #include "ctm/ctmDisplayGL.h"
    #include "ctm/ctmDisplayGDI.h"
    #ifdef USE_BROOK
      #include "ctm/ctmDisplayDX.h"
    #endif
  #endif
#endif

#ifndef BATCH_ONLY
  #include "renderContextGL.h"
  #include "cpu/cpuDisplayGL.h"
#endif

//////////////////////////////////////////////////////////////////////////
// The stuff in here belongs in other files eventually,
// but I'll group it for now

void DefaultTracer::TraceRays()
{
   _rayGenerator->Generate( _width, _height );
}


TracerFixedSize::TracerFixedSize( ITracer* inInner, int inWidth, int inHeight )
{
   _inner = inInner;
   _inner->Resize( inWidth, inHeight );
}

void TracerFixedSize::Resize( int inWidth, int inHeight )
{
   // ignore the resize request
}

void TracerFixedSize::TraceRays()
{
   _inner->TraceRays();
}

void TracerFixedSize::Display()
{
   _inner->Display();
}


#ifdef USE_BROOK
/*
 * CreateTracerBrook --
 *
 *      Creates an ITracer instance that uses the brook
 *      system to shade, and either brook or the CPU to
 *      generate and trace rays.
 *      The caller must supply scene data, along with
 *      an IPixelDisplayerBrook "callback" to handle
 *      the generated pixel data.
 *
 * Returns:
 *      The created tracer.
 */

static ITracer* CreateTracerBrook(
   const Opts& inOptions,
   Scene* inScene,
   CameraManager* inCameraManager,
   BrookContext* inBrookContext,
   IPixelDisplayerBrook* inPixelDisplayer )
{
   VertexDataBrook* vertexData = new VertexDataBrook( inScene );

   IRayGenerator* rayGenerator;

   if( inOptions.brookShade ) {
      PRINT(("CPU tracing with Brook shading is deprecated!\n"));
      throw -1;
   } else {
      IBaseRayIntersectorBrook* baseRayIntersector =
         new DefaultBaseRayIntersectorBrook( inOptions, inScene, vertexData );
      IHitShaderBrook* hitShader =
         new DefaultHitShaderBrook( inOptions, inScene, vertexData,
               inCameraManager, baseRayIntersector, inPixelDisplayer );
      IBoundRayIntersectorBrook* boundRayIntersector =
         new BoundRayIntersectorBrook( baseRayIntersector, hitShader );

      rayGenerator = new RayGeneratorBrook( inCameraManager,
                                            inScene, boundRayIntersector );
   }

   ITracer* innerTracer = new DefaultTracer( rayGenerator );
   return new TracerFixedSize( innerTracer, inOptions.width, inOptions.height );
}
#endif


/*
 * CreateTracerCPU --
 *
 *      Creates an ITracer that ONLY uses the CPU (both tracing and
 *      shading).  CreateTracerBrook() can create a tracer that mixes Brook
 *      and CPU image generation.
 *
 * Returns:
 *      The created tracer.
 */

static ITracer* CreateTracerCPU(
   const Opts& inOptions,
   Scene* inScene,
   CameraManager* inCameraManager,
   IPixelDisplayerCPU* inPixelDisplayer )
{
   ToggleOption* usePacketsOption =
      new ToggleOption( inOptions.packets, "Packet tracing" );

   // register this option to respond to keyboard 'p'
   // XXX: this is disabled as there is no easily-available clean
   // option for registering this option
   //         _toggleOptions['p'] = usePacketsOption;


   IBaseRayIntersectorCPU* baseRayIntersector =
      new DefaultBaseRayIntersectorCPU( inOptions, inScene, usePacketsOption );

   // XXX: we construct the tracer here, but it is
   // not complete until we plug in a shader. Unfortunately,
   // a shader that wishes to trace secondary rays must
   // have access to a tracer in order to do so. We break
   // the circularity by constructing the object before
   // initializing it
   DefaultTracerCPU* tracer = new DefaultTracerCPU (baseRayIntersector );

   IStandardShaderCPU* hitShader = NULL;
   if( inOptions.shaderName == NULL || strcmp(inOptions.shaderName, "false") == 0 ) {
      hitShader = new DefaultHitShaderCPU();
   } else if( strcmp(inOptions.shaderName, "simple") == 0 ) {
      hitShader = new SimpleShaderCPU( inScene, inCameraManager );
   } else if( strcmp(inOptions.shaderName, "shadow") == 0 ) {
      hitShader = new ShadowShaderCPU( inScene, inCameraManager, baseRayIntersector );
   } else if( strcmp(inOptions.shaderName, "whitted") == 0 ) {
      hitShader = new SumShaderCPU(
            new SimpleShaderCPU( inScene, inCameraManager ),
            new WhittedShaderCPU( inScene, inCameraManager, 0, tracer ) );
   } else if( strcmp(inOptions.shaderName, "diffuse") == 0 ) {
      hitShader = new SumShaderCPU(
            new SimpleShaderCPU( inScene, inCameraManager ),
            new WhittedShaderCPU( inScene, inCameraManager, 1, tracer ) );
   } else {
      PRINT(("Unknown CPU shader %s\n", inOptions.shaderName));
      hitShader = NULL;
      throw -1;
   }

   hitShader = new IgnoreMissesShaderCPU( hitShader, new MissShaderCPU() );

   tracer->setShader( hitShader );

   IPrimaryRayCallbackCPU* primaryRayCallback =
      new PrimaryRayCallbackCPU( tracer, inPixelDisplayer );

   if( inOptions.dumpRaysFile != NULL )
   {
      primaryRayCallback = new DumpPrimaryRaysCPU( primaryRayCallback, inOptions.dumpRaysFile );
   }
   IRayGenerator* rayGenerator =
      new RayGeneratorCPU( inCameraManager, primaryRayCallback );

   ITracer* innerTracer = new DefaultTracer( rayGenerator );
   return new TracerFixedSize( innerTracer, inOptions.width, inOptions.height );
}


extern int main2(int count,const F3*v0,const F3*v1,const F3*v2,F3 offset, bool init_display, IRenderContext*ctx);
#if defined(USE_CTM)||defined(USE_BROOK)
static ITracer* CreateTracerCTM(
   const Opts& inOptions,
   Scene* inScene,
   CameraManager* inCameraManager,
   IPixelDisplayerCTM* inPixelDisplayer,
   IRenderContext * ctx)
{
    bool usebrook=(inOptions.accelName&&0==strcmp("kdtree-brook",inOptions.accelName))?true:false;
    GPUDevice *device = usebrook?NULL:
#ifdef USE_CTM
createGPUDevice(GetKeyValueInt("xfire",inOptions.accelOpts,GetKeyValueInt("xfire",inOptions.shadeOpts,1)));
#else
    (GPUDevice*)NULL;
#endif
   BoundingBoxCTM *bbox = new BoundingBoxCTM;
   ToggleOption* usePacketsOption =
      new ToggleOption( inOptions.packets, "Packet tracing" );

   IBaseRayIntersectorCTM* baseRayIntersector =
      new DefaultBaseRayIntersectorCTM( inOptions, inScene, usePacketsOption, device, bbox );
   if (GetKeyValueInt("useRaster",inOptions.accelOpts,true)) {
       main2(inScene->nTris(),inScene->vertices(0),inScene->vertices(1),inScene->vertices(2),bbox->rayOffset,(inOptions.gdi)||(inOptions.d3d),ctx);
   }
   DefaultTracerCTM* tracer = new DefaultTracerCTM (baseRayIntersector );

   IStandardShaderCTM* hitShader = NULL;
   if( inOptions.shaderName == NULL || strcmp(inOptions.shaderName, "false") == 0 ) {
       hitShader = 
#ifdef USE_BROOK
	   usebrook?static_cast<IStandardShaderCTM*>(new DefaultHitShaderNewBrook(inScene,inCameraManager,tracer,inOptions)):
#endif
#ifdef USE_CTM
	   new DefaultHitShaderCTM( device, inScene, inCameraManager, tracer,inOptions );
#else
       NULL;
#endif
   } else {
      PRINT(("Unknown CTM shader %s\n", inOptions.shaderName));
      hitShader = NULL;
      throw -1;
   }

   tracer->setShader( hitShader );

   IPrimaryRayCallbackCTM* primaryRayCallback =
      new PrimaryRayCallbackCTM( tracer, inPixelDisplayer );

   IRayGenerator* rayGenerator =
       usebrook?static_cast<IRayGenerator*>(new RayGeneratorNewBrook(inCameraManager,primaryRayCallback,bbox)):
#ifdef USE_CTM
       new RayGeneratorCTM( inCameraManager, primaryRayCallback, device, bbox );
#else
   NULL;
#endif

   ITracer* innerTracer = new DefaultTracer( rayGenerator );
   return new TracerFixedSize( innerTracer, inOptions.width, inOptions.height );
}

#endif


#ifndef BATCH_ONLY
/*
 * CreateTracer --
 *
 *      Central entry point for creating various tracers.  Sorts through the
 *      specified options and creates a corresponding tracer.
 *
 * Returns:
 *      The created tracer.
 */

ITracer* CreateTracer(
   const Opts& inOptions,
   Scene* inScene,
   CameraManager* inCameraManager,
   IRenderContext* inRenderContext )
{
   if( inOptions.rasterize ) {
#ifdef _WIN32
      const char *renderer =
         inRenderContext->getRenderSystem()->getRenderSystemID();

      if( strcmp( renderer, "ogl" ) != 0 ) {
         PRINT(("Rasterization currently requires OpenGL!\n"));
         throw -1;
      }

      return new TracerRaster( inOptions, inScene, inCameraManager,
                               (RenderContextOGL *) inRenderContext );
#else
      PRINT(("Rasterization currently requires Windows!\n"));
      assert(false);
      return NULL;
#endif
   } else if( inOptions.brook || inOptions.brookShade) {
#ifdef USE_BROOK
      BrookContext* brookContext = new BrookContext( inRenderContext );
      IPixelDisplayerBrook* pixelDisplayer =
         CreatePixelDisplayerBrook( inRenderContext, brookContext );
      CachedPixelDisplayerBrook* cachedPixelDisplayer =
         new CachedPixelDisplayerBrook( pixelDisplayer );

      // we wrap the auto-created tracer in one that caches the brook stream,
      // so that we can re-use previously generated data when redrawing without
      // having to recalculate fully
      ITracer* innerTracer = CreateTracerBrook( inOptions, inScene,
         inCameraManager, brookContext, cachedPixelDisplayer );
      return new TracerBrook( innerTracer, cachedPixelDisplayer );
#else
      assert(false);
      return NULL;
#endif
   } else if( inOptions.ctm) {
#if defined(USE_CTM)||defined(USE_BROOK)
      const char *renderer =
         inRenderContext->getRenderSystem()->getRenderSystemID();

      IPixelDisplayerCTM* pixelDisplayer = 0;
      const char *accel = inOptions.accelName ? inOptions.accelName : "kdtree";
      bool dx9special=false;
#ifdef USE_BROOK
      BrookContext * brookContext = NULL;
      const char * whichRuntime=GetKeyValueString("runtime",inOptions.accelOpts,"dx9");

      if (strcmp(accel,"kdtree-brook")==0) {
	  if(strcmp(whichRuntime,renderer)==0)
	      brookContext=new BrookContext(inRenderContext);
	  else
	      brook::initialize(whichRuntime);//forego a brookContext
      }
      if (strcmp(renderer,"dx9")==0) {
	  pixelDisplayer = new PixelDisplayerCtmDX ( (RenderContextDX9*) inRenderContext,brookContext );
	  dx9special=true;
      } else 
#endif

	  if( strcmp( renderer, "ogl" ) == 0 ) {
		  printf ("openGL displayer\n");
         pixelDisplayer = new PixelDisplayerCtmOgl( (RenderContextOGL*) inRenderContext );
      } else {
         pixelDisplayer = new PixelDisplayerCtmGdi( (RenderContextGDI*) inRenderContext );
      }

      if( !pixelDisplayer ) {
         PRINT(("CTM render currently requires either GDI or OpenGL for Display!\n"));
         throw -1;
      }

      return CreateTracerCTM( inOptions, inScene, inCameraManager, pixelDisplayer , 1?inRenderContext:NULL);
#else
      assert(false);
      return NULL;
#endif
   } else {
      const char *renderer =
         inRenderContext->getRenderSystem()->getRenderSystemID();

      if( strcmp( renderer, "ogl" ) != 0 ) {
         PRINT(("CPU render currently requires OpenGL!\n"));
         throw -1;
      }

      IPixelDisplayerCPU* pixelDisplayer =
         new PixelDisplayerCpuOgl( (RenderContextOGL*) inRenderContext );
      return CreateTracerCPU( inOptions, inScene, inCameraManager, pixelDisplayer );
   }
}
#endif


/*
 * CreateOfflineTracer --
 *
 *      Entry point for applications that only intend to render an image and
 *      write it out.  For the Brook case, it needs to initialize enough of
 *      GL or D3D to run the brook kernels even though the rest of the
 *      application isn't going to need them.
 *
 * Returns:
 *      The created tracer.
 */

ITracer* CreateOfflineTracer(
   const Opts& inOptions,
   Scene* inScene,
   CameraManager* inCameraManager,
   ppmImage* inOutputImage )
{
   if( inOptions.rasterize ) {
      PRINT(("Rasterization currently requires interactive mode!\n"));
      throw -1;
   } else if( inOptions.brook || inOptions.brookShade) {
#ifdef USE_BROOK
      IRenderSystem* renderSystem;

      if( inOptions.d3d ) {
	  renderSystem = new RenderSystemDX9(0,0);//not fullscreen
      } else {
         renderSystem = new RenderSystemOGL();
      }

      // we are going to wrap things in brook to render...
      BrookContext* brookContext = new BrookContext( renderSystem );
      IPixelDisplayerBrook* pixelDisplayer =
         new WriteImagePixelDisplayerBrook( inOutputImage );

      return CreateTracerBrook( inOptions, inScene,
            inCameraManager, brookContext, pixelDisplayer );
#else
      assert( false );
      return NULL;
#endif
   } else if (inOptions.ctm) {
#if defined(USE_CTM)||defined(USE_BROOK)
      IPixelDisplayerCTM* displayer =
         new WriteImagePixelDisplayerCTM( inOutputImage );
      return CreateTracerCTM( inOptions, inScene, inCameraManager, displayer,NULL );

#else
      assert( false );
      return NULL;
#endif
   }else {
      IPixelDisplayerCPU* displayer =
         new WriteImagePixelDisplayerCPU( inOutputImage );
      return CreateTracerCPU( inOptions, inScene, inCameraManager, displayer );
   }
}

/*
 * RenderOffline --
 *
 *      Traces the image and writes it to disk without creating any windows
 *      or other interactive state.
 *
 * Returns:
 *      void
 */

void
RenderOffline(const Opts& inOptions)
{
   int width = inOptions.width;
   int height = inOptions.height;

   Scene scene(inOptions);
   CameraManager cameraManager( &scene, width, height );
   ppmImage image( width, height);
   ITracer* tracer =
      ::CreateOfflineTracer( inOptions, &scene, &cameraManager, &image );

   Timer_Reset();
   tracer->TraceRays();
   float t = Timer_GetMS();
   PRINT(("TraceRays took %3.2f seconds total.\n", t / 1000.0f));

   PRINT(("Writing image to %s.\n", inOptions.imageFile));
   image.Write(inOptions.imageFile);

   delete tracer;
}


//for simple keyboard control---
//we should fix this sometime and provide a real interface
bool morebounces=false;
bool toggleshadow=false;
bool lessbounces=false;
bool yesrasterize=false;
bool norasterize=false;
bool yespacketize=false;
bool nopacketize=false;
bool morespec=false;
bool lessspec=false;
bool morecutoff=false;
bool lesscutoff=false;
