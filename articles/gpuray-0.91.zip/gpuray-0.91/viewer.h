/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * viewer.h --
 *
 *      Simple viewer to create a window and display the generated images.
 */

#ifndef __VIEWER_H__
#define __VIEWER_H__

#ifdef _WIN32
#include <windows.h>
#else
#include <X11/Xlib.h>
#endif
#include <map>

#include "main.h"

class CameraManager;
class ITracer;
class Scene;
class IRenderSystem;
class IRenderContext;
class ToggleOption;
class FrameRateRecorder;

class Viewer {
public:
   Viewer(void) {
      _created = _visible = false;
      _rebuild = true;
   }
   virtual ~Viewer(void) { Destroy(); }

   bool Create(const Opts& opts);
   void Destroy(void);
   void MakeVisible(bool show);

   int PumpMsgs(bool block);

   bool IsCreated(void) const { return _created; }
   bool IsVisible(void) const { return IsCreated() && _visible; }

#ifdef _WIN32
   /*
    * Must either be public or have the Window class fn as a friend
    */
   LRESULT HandleMsg(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
#endif

protected:
   IRenderSystem* getRenderSystem() { return _renderSystem; }
   IRenderContext* getRenderContext() { return _renderContext; }

   void ForceRedraw(void) {
      _rebuild = true;
#ifdef _WIN32
      InvalidateRect(_win, NULL, false);
#else
      DrawDisplay();
#endif
   }

#ifndef _WIN32
   bool HandleEvent(XEvent *event);
#endif

   bool InitializeWindowSystem(const Opts& options);
   void InitializeTracer(const Opts& inOptions,
                         Scene* inScene, CameraManager* inCameraManager);
   float RebuildImage(void);
   void DrawDisplay(void);
   void Resize(int width, int height);
   bool HandleKeyPress(char c);
   void WriteImage(char *fileName);
   void Animate(void);

   IRenderSystem* _renderSystem;
   IRenderContext* _renderContext;

   bool _created, _visible, _rebuild, _rotate;
   int _width, _height;

   CameraManager *_cameraManager;
   ITracer *_tracer;

   typedef std::map<char, ToggleOption*> ToggleOptionMap;
   ToggleOptionMap _toggleOptions;

#ifdef _WIN32
   HWND _win;
#else
   Display *_dpy;
   Window   _win;
#endif
};

#endif
