/* *************************************************************************
 * Copyright (C) 2004 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * timer.c --
 *
 *      High resolution timing.  I lifted this from gpubench, which likely
 *      stole it from the Brook timing app.
 */
#include "timer.h"

#include <assert.h>
#include <stdlib.h>

#include "common/integerTypes.h"

#ifdef WINDOWS
#include <windows.h>

static LARGE_INTEGER start;
static float         freq;
#else
#include <sys/time.h>

static uint64        start;
#endif



/*
 * Timer_Reset --
 *
 *      Resets the logical timer to zero.  Also takes care of any
 *      one time intialization the first time it's invoked.
 *
 * Returns:
 *      void.
 */

void
Timer_Reset(void)
{
#ifdef WINDOWS
   static int knowFreq;

   if (!knowFreq) {
      LARGE_INTEGER freqInt;

      if (!QueryPerformanceFrequency(&freqInt)) {
         assert(0);
      }
      freq = (float) freqInt.QuadPart;
      knowFreq = 1;
   }

   if (!QueryPerformanceCounter(&start)) {
      assert(0);
   }
#else
   struct timeval tv;
   gettimeofday(&tv, NULL);
   start = tv.tv_usec + tv.tv_sec * ((uint64) 1000000);
#endif
}

/*
 * Timer_GetMS --
 *
 *      Returns the elapsed number of msecs since the most recent call to
 *      Timer_Reset().
 *
 * Returns:
 *      See above.
 */

float
Timer_GetMS(void)
{
#ifdef WINDOWS
   LARGE_INTEGER now;

   if (!QueryPerformanceCounter(&now)) {
      assert(0);
   }
   return ((float)(now.QuadPart - start.QuadPart)) / freq * 1000;
#else
   struct timeval tv;
   gettimeofday(&tv, NULL);
   uint64 now = tv.tv_usec + tv.tv_sec * ((uint64) 1000000);
   return (float) ((now - start) * 0.001);
#endif
}
