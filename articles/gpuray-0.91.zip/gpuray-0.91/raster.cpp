/* *************************************************************************
 * Copyright (C) 2006 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * raster.h --
 *
 *      Class for rasterizing primary hits
 */
#include "raster.h"

#include <assert.h>
#include <windows.h>
#include <string.h>
#include <GL/gl.h>
#include <GL/glu.h>

#include "nv-glext.h"
#include "timer.h"
#include "log.h"
#include "cameraManager.h"
#include "renderContextGL.h"

#define CHECK_GL()      (CheckGL(__FILE__, __LINE__))

#define GETPROCADDR(type, name) do { \
         if ((name = (type) wglGetProcAddress(#name)) == NULL) { \
            fprintf(stderr, "Unable to find symbol %s\n", name); \
         } } while(0)


static PFNGLBINDBUFFERARBPROC    glBindBufferARB;
static PFNGLBUFFERDATAARBPROC    glBufferDataARB;
static PFNGLMAPBUFFERARBPROC     glMapBufferARB;
static PFNGLUNMAPBUFFERARBPROC   glUnmapBufferARB;
static PFNGLDELETEBUFFERSARBPROC glDeleteBuffersARB;


static PFNGLENABLEVERTEXATTRIBARRAYARBPROC  glEnableVertexAttribArrayARB;
static PFNGLDISABLEVERTEXATTRIBARRAYARBPROC glDisableVertexAttribArrayARB;
static PFNGLVERTEXATTRIBPOINTERARBPROC      glVertexAttribPointerARB;


/*
 * CheckGL --
 *
 *      Checks for and reports and GL errors that have occurred.
 *
 * Results:
 *      void
 */

static void
CheckGL(const char *fileName, unsigned int line)
{
   static char error_msg[][32] = {
     "GL_INVALID_ENUM",
     "GL_INVALID_VALUE",
     "GL_INVALID_OPERATION",
     "GL_STACK_OVERFLOW",
     "GL_STACK_UNDERFLOW",
     "GL_OUT_OF_MEMORY"
   };
   static unsigned int numMsgs = sizeof error_msg / sizeof error_msg[0];
   GLenum err;

   if ((err = glGetError()) == GL_NO_ERROR) {
      return;
   }

   if ((unsigned) (err - GL_INVALID_ENUM) < numMsgs) {
      fprintf(stderr, "GLError: %s:%d: %s\n",
              fileName, line, error_msg[err - GL_INVALID_ENUM]);
   } else {
      static char unknown_msg[] = "Unknown GL error 01234567";

      sprintf(unknown_msg, "Unknown GL error %d\n", err);
      fprintf(stderr, "GLError: %s:%d: %s\n", fileName, line, unknown_msg);
   }
   assert(false);
   return;
}


/*
 * Raster::Raster --
 *
 *      Constructor.  Repacks all the geometry into a GL-friendly format.
 *
 * Results:
 *      Construction
 */

Raster::Raster(const Opts& opts, const Scene& scene,
               RenderContextOGL* renderContext)
{
   unsigned int vboSize, ii;
   const F3 *buf0, *buf1, *buf2;
   float *vbo;

   _renderContext = renderContext;

   GETPROCADDR(PFNGLBINDBUFFERARBPROC, glBindBufferARB);
   GETPROCADDR(PFNGLBUFFERDATAARBPROC, glBufferDataARB);
   GETPROCADDR(PFNGLMAPBUFFERARBPROC, glMapBufferARB);
   GETPROCADDR(PFNGLUNMAPBUFFERARBPROC, glUnmapBufferARB);
   GETPROCADDR(PFNGLDELETEBUFFERSARBPROC, glDeleteBuffersARB);
   GETPROCADDR(PFNGLENABLEVERTEXATTRIBARRAYARBPROC,
               glEnableVertexAttribArrayARB);
   GETPROCADDR(PFNGLDISABLEVERTEXATTRIBARRAYARBPROC,
               glDisableVertexAttribArrayARB);
   GETPROCADDR(PFNGLVERTEXATTRIBPOINTERARBPROC, glVertexAttribPointerARB);

   vboSize = scene.nTris() * 3 * 3 * sizeof(float);

   glBindBufferARB(GL_ARRAY_BUFFER_ARB, 1);
   glBufferDataARB(GL_ARRAY_BUFFER_ARB, vboSize, NULL, GL_STATIC_DRAW_ARB);
   vbo = (float *) glMapBufferARB(GL_ARRAY_BUFFER_ARB, GL_WRITE_ONLY_ARB);
   buf0 = scene.vertices(0);
   buf1 = scene.vertices(1);
   buf2 = scene.vertices(2);
   for (ii = 0; ii < scene.nTris(); ii++) {
      vbo[9 * ii + 0] = buf0[ii].v[0];
      vbo[9 * ii + 1] = buf0[ii].v[1];
      vbo[9 * ii + 2] = buf0[ii].v[2];

      vbo[9 * ii + 3] = buf1[ii].v[0];
      vbo[9 * ii + 4] = buf1[ii].v[1];
      vbo[9 * ii + 5] = buf1[ii].v[2];

      vbo[9 * ii + 6] = buf2[ii].v[0];
      vbo[9 * ii + 7] = buf2[ii].v[1];
      vbo[9 * ii + 8] = buf2[ii].v[2];
   }
   glUnmapBufferARB(GL_ARRAY_BUFFER_ARB);

   glBindBufferARB(GL_ARRAY_BUFFER_ARB, 2);
   glBufferDataARB(GL_ARRAY_BUFFER_ARB, vboSize, NULL, GL_STATIC_DRAW_ARB);
   vbo = (float *) glMapBufferARB(GL_ARRAY_BUFFER_ARB, GL_WRITE_ONLY_ARB);
   buf0 = scene.normals(0);
   buf1 = scene.normals(1);
   buf2 = scene.normals(2);
   for (ii = 0; ii < scene.nTris(); ii++) {
      vbo[9 * ii + 0] = buf0[ii].v[0];
      vbo[9 * ii + 1] = buf0[ii].v[1];
      vbo[9 * ii + 2] = buf0[ii].v[2];

      vbo[9 * ii + 3] = buf1[ii].v[0];
      vbo[9 * ii + 4] = buf1[ii].v[1];
      vbo[9 * ii + 5] = buf1[ii].v[2];

      vbo[9 * ii + 6] = buf2[ii].v[0];
      vbo[9 * ii + 7] = buf2[ii].v[1];
      vbo[9 * ii + 8] = buf2[ii].v[2];
   }
   glUnmapBufferARB(GL_ARRAY_BUFFER_ARB);

   glBindBufferARB(GL_ARRAY_BUFFER_ARB, 3);
   glBufferDataARB(GL_ARRAY_BUFFER_ARB, vboSize, NULL, GL_STATIC_DRAW_ARB);
   vbo = (float *) glMapBufferARB(GL_ARRAY_BUFFER_ARB, GL_WRITE_ONLY_ARB);
   buf0 = scene.colours(0);
   buf1 = scene.colours(1);
   buf2 = scene.colours(2);
   for (ii = 0; ii < scene.nTris(); ii++) {
      vbo[9 * ii + 0] = buf0[ii].v[0];
      vbo[9 * ii + 1] = buf0[ii].v[1];
      vbo[9 * ii + 2] = buf0[ii].v[2];

      vbo[9 * ii + 3] = buf1[ii].v[0];
      vbo[9 * ii + 4] = buf1[ii].v[1];
      vbo[9 * ii + 5] = buf1[ii].v[2];

      vbo[9 * ii + 6] = buf2[ii].v[0];
      vbo[9 * ii + 7] = buf2[ii].v[1];
      vbo[9 * ii + 8] = buf2[ii].v[2];
   }
   glUnmapBufferARB(GL_ARRAY_BUFFER_ARB);
   CHECK_GL();
}


/*
 * Raster::~Raster --
 *
 *      Destructor.  Frees a bunch of things.
 *
 * Results:
 *      void.
 */

Raster::~Raster(void)
{
   const GLuint vbos[] = { 1, 2, 3 };

   glDeleteBuffersARB(3, vbos);
   CHECK_GL();
}


/*
 * Raster::Rasterize --
 *
 *      Draws the whole scene-- intersections and shading in one tidy
 *      package.
 *
 * Results:
 *      Frames per second
 */

float
Raster::Rasterize(const Scene& scene, const int width, const int height,
                  const SceneTransformation& sceneTransform,
                  const CameraFrame& sceneSpaceCamera)
{
   float aspect, distance;
   float t;

   t = Timer_GetMS();

   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   aspect = (float) width / height;

   // XXX Really need to use transformed bboxMax.  This is wrong sometimes.
   distance = sceneSpaceCamera.direction.z > 0 ?
              scene.bboxMax().z - sceneSpaceCamera.position.z :
              scene.bboxMin().z -sceneSpaceCamera.position.z;
   gluPerspective(scene.fov(), aspect, 0.1f, distance * 1.1f);

   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
   gluLookAt(sceneSpaceCamera.position.x,
             sceneSpaceCamera.position.y,
             sceneSpaceCamera.position.z,

             sceneSpaceCamera.position.x +
             sceneSpaceCamera.direction.x,
             sceneSpaceCamera.position.y +
             sceneSpaceCamera.direction.y,
             sceneSpaceCamera.position.z +
             sceneSpaceCamera.direction.z,

             sceneSpaceCamera.up.x,
             sceneSpaceCamera.up.y,
             sceneSpaceCamera.up.z);

   glDrawBuffer(GL_BACK);
   glEnable(GL_DEPTH_TEST);
   glDepthFunc(GL_LESS);
   glClearColor(0.75f, 0.0f, 0.15f, 1.0f);
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

   glEnable(GL_LIGHTING);
   glShadeModel(GL_SMOOTH);
   GLfloat disabled[] = { 0.0f, 0.0f, 0.0f, 1.0f };
   glLightModelfv(GL_LIGHT_MODEL_AMBIENT, disabled);
   for (unsigned int ii = 0; ii < scene.numLights(); ii++) {
      const LightInfo *light;
      Vec3f lightPos;
      GLfloat glLightPos[4], diffuse[4];

      light = &scene.pointLight(ii);
      lightPos = sceneTransform.transformPoint(light->position);
      glLightPos[0] = lightPos.x;
      glLightPos[1] = lightPos.y;
      glLightPos[2] = lightPos.z;
      glLightPos[3] = 1.0f;

      diffuse[0] = light->diffIntensity.x;
      diffuse[1] = light->diffIntensity.y;
      diffuse[2] = light->diffIntensity.z;

      glEnable(GL_LIGHT0 + ii);
      glLightfv(GL_LIGHT0 + ii, GL_POSITION, glLightPos);
      glLightfv(GL_LIGHT0 + ii, GL_DIFFUSE, diffuse);
   }

   glEnable(GL_COLOR_MATERIAL);
   glColorMaterial(GL_FRONT, GL_DIFFUSE);
   glEnableClientState(GL_VERTEX_ARRAY);
   glEnableClientState(GL_NORMAL_ARRAY);
   glEnableClientState(GL_COLOR_ARRAY);

   glBindBufferARB(GL_ARRAY_BUFFER_ARB, 1);
   glVertexPointer(3, GL_FLOAT, 0, (float *) NULL);
   glBindBufferARB(GL_ARRAY_BUFFER_ARB, 2);
   glNormalPointer(GL_FLOAT, 0, (float *) NULL);
   glBindBufferARB(GL_ARRAY_BUFFER_ARB, 3);
   glColorPointer(3, GL_FLOAT, 0, (float *) NULL);

   glDrawArrays(GL_TRIANGLES, 0, scene.nTris() * 3);

   glDisableClientState(GL_COLOR_ARRAY);
   glDisableClientState(GL_NORMAL_ARRAY);
   glDisableClientState(GL_VERTEX_ARRAY);
   glDisable(GL_DEPTH_TEST);
   glDisable(GL_LIGHTING);
   glDisable(GL_COLOR_MATERIAL);
   CHECK_GL();

   glFinish();
   t = Timer_GetMS() - t;
   _renderContext->swap();
   PRINT(("Raster: Time is %f, FPS is %6.2f.\n", t, 1000.0f / t));

   return 1000.0f / t;
}

/*
 * TracerRaster::TracerRaster --
 *
 *      Constructor. Initializes a Raster object
 *      with the provided options.
 *
 * Results:
 *      None.
 */

TracerRaster::TracerRaster(
   const Opts& inOptions, Scene* inScene,
   CameraManager* inCameraManager,
   RenderContextOGL* inRenderContext )
{
   _scene = inScene;
   _cameraManager = inCameraManager;

   _width = _height = 0;

   // XXX: this shouldn't dereferencing the Scene pointer...
   // we should really merge the TracerRaster and
   // Raster classes, since this is the only client that
   // Raster has
   _raster = new Raster( inOptions, *inScene, inRenderContext);
}

/*
 * TracerRaster::TraceRays --
 *
 *      A no-op. Since rasterization happens on display,
 *      rather than as a preprocess, we do all our work
 *      in Display.
 *
 * Results:
 *      None.
 */

void TracerRaster::TraceRays()
{
}

/*
 * TracerRaster::Display --
 *
 *      Draws the whole scene-- intersections and shading in one tidy
 *      package.
 *
 * Results:
 *      None.
 */

void TracerRaster::Display()
{
   _raster->Rasterize( *_scene, _width, _height,
      _cameraManager->getSceneTransformation(), _cameraManager->getSceneSpaceCameraFrame() );
}
