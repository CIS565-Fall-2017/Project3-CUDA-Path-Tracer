/*
* quaternion.h --
*
*
*/

#ifndef __QUATERNION_H__
#define __QUATERNION_H__

#include "common/commonTypes.h"

class quaternion
{
public:
   quaternion();
   quaternion( float inX, float inY, float inZ, float inW );

   static quaternion identity();

   static quaternion fromAxisAngle( const Vec3f& inAxis, float inAngle );

   quaternion& operator*=( const quaternion& right );

   Vec3f transformVector( const Vec3f& v ) const;

   float x, y, z, w;
};

float magnitude( const quaternion& q );
float magnitudeSquared( const quaternion& q );
quaternion normalize( const quaternion& q );
quaternion conjugate( const quaternion& q );
quaternion inverse( const quaternion& q );

quaternion operator*( float left, const quaternion& right );
quaternion operator*( const quaternion& left, float right );
quaternion operator/( const quaternion& left, float right );
quaternion operator*( const quaternion& left, const quaternion& right );

#endif
