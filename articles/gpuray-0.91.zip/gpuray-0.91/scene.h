/* *************************************************************************
 * Copyright (C) 2006 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * scene.h --
 *
 *      Class that wraps all of the scene data and parsing.
 */

#ifndef __SCENE_H__
#define __SCENE_H__

#include "f3.h"
#include "main.h"
#include "fileformat.h"
#include "fileIO/fileIO.h"              /* For Grid */


class Scene {
public:
   Scene(const Opts& opts);
   ~Scene(void);

   const char* sceneName(void) const { return _sceneName; }
   
   const unsigned int nTris(void) const { return _grid.nTris; }
   const Vec3f& bboxMin(void) const { return _grid.min; }
   const Vec3f& bboxMax(void) const { return _grid.max; }

   const Vec3f& lookFrom(void) const { return _params.lookFrom; }
   const Vec3f& lookAt(void) const { return _params.lookAt; }
   const Vec3f& up(void) const { return _params.up; }
   const Vec3f& center(void) const { return _params.center; }

   const float& fov(void) const { return _params.fov; }
   const float& movementScale(void) const { return _params.movementScale; }
   const float& lightMovementScale(void) const { return _params.lightMovementScale; }

   const unsigned int numLights(void) const { return _params.pointLights.size(); }
   const LightInfo& pointLight(int lightNum) const {
      return _params.pointLights[lightNum];
   }

   const F3 *vertices(int n) const { return _v[n]; }
   const F3 *colours(int n) const { return _c[n]; }
   const F3 *normals(int n) const { return _n[n]; }
   const F3 *specColours(void) const { return _specular; }
   const float *specExps(void) const { return _specularExp; }

   /*
    * XXX Ideally this entry point should go away and the voxelgrid code
    * should do its own work.  Or else we should just be able to assert fail
    * / return NULL if there's no prebuilt-grid.
    */
   const Grid& getGrid(void) const { return _grid; }

protected:
   bool InitializeSceneData(const Opts& opts);

   void InitializeTriangleDataSimple(const Opts& opts);
   void WriteTriangleDataSimple(const char *sceneName) const;

   void PrintSceneGeometry(bool verbose) const;

   const char* _sceneName;
   SceneParams _params;
   NewScene _simpleScene;

   /*
    * Generated/read from the scene file.
    */

   Grid _grid;
#if 0
   F3 *_v0, *_v1, *_v2;    /* Triangle Vertices */
   F3 *_n0, *_n1, *_n2;    /* Triangle Normals */
   F3 *_c0, *_c1, *_c2;    /* Triangle Colours */
#endif
   F3 *_v[3], *_n[3], *_c[3];
   F3 *_specular;
   float *_specularExp;
};

#endif
