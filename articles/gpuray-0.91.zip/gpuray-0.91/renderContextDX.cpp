/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * renderContextDX.cpp --
 *
 *      DirectX implementation of the IRenderSystem interface.
 */


#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include <iostream>

#include "renderContextDX.h"


const char* RenderSystemDX9::getRenderSystemID()
{
   return "dx9";
}

IRenderContext* RenderSystemDX9::createRenderContext( HWND inWindowHandle )
{
   return new RenderContextDX9( this, inWindowHandle );
}

RenderContextDX9::RenderContextDX9( RenderSystemDX9* inRenderSystem, HWND inWindowHandle )
{
   _renderSystem = inRenderSystem;

   _direct3d = Direct3DCreate9( D3D_SDK_VERSION );
   if( _direct3d == NULL )
   {
      DX9Warn("Could not create Direct3D interface.");
      throw -1;
   }

   D3DPRESENT_PARAMETERS deviceDesc;
   ZeroMemory( &deviceDesc, sizeof(deviceDesc) );

   deviceDesc.Windowed = inRenderSystem->width()&&inRenderSystem->height()?FALSE:TRUE;
   deviceDesc.BackBufferWidth=inRenderSystem->width();
   deviceDesc.BackBufferHeight=inRenderSystem->height();
   deviceDesc.SwapEffect = D3DSWAPEFFECT_DISCARD;
   deviceDesc.BackBufferFormat = D3DFMT_X8R8G8B8;
   deviceDesc.EnableAutoDepthStencil = FALSE;
   deviceDesc.AutoDepthStencilFormat = D3DFMT_D24S8;

   HRESULT result = _direct3d->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, inWindowHandle,
      D3DCREATE_HARDWARE_VERTEXPROCESSING , &deviceDesc, &_device );
   if( FAILED(result) )
   {
       fprintf(stderr,"Could not fullscreen %d %d\n",deviceDesc.BackBufferWidth,deviceDesc.BackBufferHeight);
       fflush(stderr);
      DX9Warn("Could not create Direct3D device.");
      throw -1;
   }
/*
   result=_direct3d->SetCooperativeLevel(inWindowHandle,DDSCL_EXCLUSIVE|DDSCL_FULLSCREEN);
   if( FAILED(result) )
   {
      DX9Warn("Could not create Direct3D device.");
      throw -1;
   }
   result=_direct3d->SetDisplayMode(inRenderSystem->width(),inRenderSystem->height(),32);
   if( FAILED(result) )
   {
      DX9Warn("Could not create Direct3D device.");
      throw -1;
      }*/


   // TIM: set up initial state
   result = _device->SetRenderState( D3DRS_ZENABLE, D3DZB_FALSE );
   DX9AssertResult( result, "SetRenderState failed" );

   result = _device->GetRenderTarget( 0, &_defaultRenderTarget );
   if( FAILED(result) ) throw -1;
}

IRenderSystem* RenderContextDX9::getRenderSystem()
{
   return _renderSystem;
}

void* RenderContextDX9::getContextHandle()
{
   return (void*) _device;
}

void RenderContextDX9::resize( int inWidth, int inHeight )
{
   // TIM: TODO: implement
}

IDirect3DDevice9* RenderContextDX9::getDevice()
{
   return _device;
}

IDirect3DSurface9* RenderContextDX9::getDefaultRenderTarget()
{
   return _defaultRenderTarget;
}
