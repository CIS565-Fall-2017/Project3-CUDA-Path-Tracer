/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * cpuTracer.h --
 *
 *      Helper classes for ray-tracing with the CPU
 */

#ifndef __CPU_CPUTRACER_H__
#define __CPU_CPUTRACER_H__

#include "../main.h"
#include "../cameraManager.h"
#include "../scene.h"
#include "../cpu/acceleratorCPU.h"
#include "../tracer.h"

class IPixelDisplayerCPU;
class IStandardShaderCPU;

struct PixelCPU
{
   float r, g, b, a;
};

struct SampleCPU
{
   uint32 pixelIndex[BUNDLE_SIZE];
   uint32 recursionDepth[BUNDLE_SIZE];
   PixelCPU weight[BUNDLE_SIZE];
};

/*
 * ReallocateAligned --
 *
 *      Resizes an AllocateAligned() chunk of memory.
 *
 * Returns:
 *     A pointer to the allocated block.
 */

void* ReallocateAligned( void* ptr, size_t oldsize, size_t size, size_t alignment );

/*
 * AllocateAligned --
 *
 *     Allocates a block of 'size' bytes, aligned
 *     to an 'alignment'-byte boundary.
 *
 * Returns:
 *     A pointer to the allocated block.
 */

void* AllocateAligned( size_t size, size_t alignment );

/*
 * FreeAligned --
 *
 *     Frees a block of memory previously allocated
 *     with AllocateAligned.
 *
 * Returns:
 *     None.
 */

void FreeAligned( void* buffer );

/*
 * IHitCallbackCPU --
 *
 *     Interface for any computation that can
 *     take rays and associated hits as input
 *     and "process" them.
 */

class IHitCallbackCPU
{
public:
   virtual void Call(
      uint32 inCount,
      const RayCPU* inRays,
      const HitCPU* inHits ) = 0;
};

class ITracerCPU
{
public:
   virtual void Trace(
      uint32 inCount,
      const SampleCPU* inSamples,
      const RayCPU* inRays,
      PixelCPU* ioPixels ) = 0;

   virtual uint32 GetBatchGranularity() = 0;
};

class IPrimaryTracerCPU
{
public:
   virtual void Trace(
      uint32 inWidth, uint32 inHeight,
      const RayCPU* inRays ) = 0;
};

class IIntersectorCPU
{
public:
   virtual void Intersect(
      uint32 inCount,
      const RayCPU* inRays,
      IHitCallbackCPU* inContinuation ) = 0;
   virtual void IntersectP(
      uint32 inCount,
      const RayCPU* inRays,
      IHitCallbackCPU* inContinuation ) = 0;
};

class IBaseRayIntersectorCPU
{
public:
   virtual void Intersect(
      uint32 inCount,
      const RayCPU* inRays,
      IHitCallbackCPU* inContinuation ) = 0;
   virtual void IntersectP(
      uint32 inCount,
      const RayCPU* inRays,
      IHitCallbackCPU* inContinuation ) = 0;
   virtual uint32 GetBatchGranularity() = 0;
};

class IPrimaryRayCallbackCPU
{
public:
   virtual void Call(
      uint32 inWidth, uint32 inHeight,
      const RayCPU* inRays ) = 0;
};

class DefaultTracerCPU : public ITracerCPU
{
public:
   DefaultTracerCPU(
      IBaseRayIntersectorCPU* inIntersector )
   {
      _intersector = inIntersector;
      _shader = NULL;
   }

   void setShader( IStandardShaderCPU* inShader )
   {
      _shader = inShader;
   }

   virtual void Trace(
      uint32 inCount,
      const SampleCPU* inSamples,
      const RayCPU* inRays,
      PixelCPU* ioPixels );

   virtual uint32 GetBatchGranularity() {
      return _intersector->GetBatchGranularity();
   }

private:
   IBaseRayIntersectorCPU* _intersector;
   IStandardShaderCPU* _shader;
};

class DefaultBaseRayIntersectorCPU : public IBaseRayIntersectorCPU
{
public:
   DefaultBaseRayIntersectorCPU(
      const Opts& inOptions, Scene* inScene, ToggleOption* inUsePacketsOptions );

   void Intersect(
      uint32 inCount,
      const RayCPU* inRays,
      IHitCallbackCPU* inContinuation );
   void IntersectP(
      uint32 inCount,
      const RayCPU* inRays,
      IHitCallbackCPU* inContinuation );

   virtual uint32 GetBatchGranularity() {
      return _accelCPU->getBatchGranularity();
   }

private:
   Scene *_scene;
   ToggleOption *_usePacketsOption;

   AcceleratorCPU *_accelCPU;
};

class PrimaryRayCallbackCPU : public IPrimaryRayCallbackCPU
{
public:
   PrimaryRayCallbackCPU(
      ITracerCPU* inTracer,
      IPixelDisplayerCPU* inPixelDisplayer )
   {
      _tracer = inTracer;
      _pixelDisplayer = inPixelDisplayer;
   }

   virtual void Call(
      uint32 inWidth, uint32 inHeight,
      const RayCPU* inRays );

private:
   ITracerCPU* _tracer;
   IPixelDisplayerCPU* _pixelDisplayer;
};

/*
 * DumpPrimaryRaysCPU --
 *
 *     An IPrimaryRayCallbackCPU that wraps another, inner
 *     callback. When told to intersect rays this class
 *     dumps them to a file before handing them off to the
 *     inner object.
 *
 */

class DumpPrimaryRaysCPU : public IPrimaryRayCallbackCPU
{
public:
   DumpPrimaryRaysCPU(
      IPrimaryRayCallbackCPU* inInner,
      const char* inFileName );

   void Call(
      uint32 inWidth, uint32 inHeight,
      const RayCPU* inRays );

private:
   IPrimaryRayCallbackCPU* _inner;
   const char* _fileName;
};

class RayGeneratorCPU : public IRayGenerator
{
public:
   RayGeneratorCPU(
      CameraManager* inCameraManager,
      IPrimaryRayCallbackCPU* inContinuation );

   void Generate( int inWidth, int inHeight );

private:
   CameraManager* _cameraManager;
   IPrimaryRayCallbackCPU* _continuation;
};

#endif
