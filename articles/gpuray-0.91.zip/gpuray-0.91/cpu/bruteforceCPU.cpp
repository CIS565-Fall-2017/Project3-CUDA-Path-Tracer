/*
 * bruteforce.cpp --
 *
 *      Non-accelerator.  Just test every ray against every triangle.
 */

#include <math.h>
#include <float.h>

#include "bruteforceCPU.h"
#include "../log.h"

#define STATS_MODULE bruteforceCPU
#define STATS_COUNTERS \
   DEFN_STAT(TriMissTHit, "Ray hits triangle's plane with tHit > tMax") \
   DEFN_STAT(TriMissBary, "Ray hits triangle's plane, but not the triangle") \
   DEFN_STAT(TriHit, "Ray hits triangle.  Paper covers rock.") \

#define STATS_DEFINE_COUNTERS
#include "../stats.h"


/*
 * BruteForceCPU::IntersectRay --
 *
 *      Does intersection testing for a single ray.  In this case, just
 *      tests it against every triangle.
 *
 * Returns:
 *      void, fills in the hit information.
 */

void
BruteForceCPU::IntersectRay(const RayCPU &ray,
                            HitCPU *hit) const
{
   int jj;

   for (jj = 0; jj < BUNDLE_SIZE; jj++) {
      float tBest, uBest, vBest;
      int triBest;
      F3 o, d;
      int ii;

      tBest = FLT_MAX;
      triBest = -1;
      uBest = vBest = 0;
      d.x = ray.d.v[jj];
      d.y = ray.d.v[BUNDLE_SIZE + jj];
      d.z = ray.d.v[2*BUNDLE_SIZE + jj];
      o.x = ray.o.v[jj];
      o.y = ray.o.v[BUNDLE_SIZE + jj];
      o.z = ray.o.v[2*BUNDLE_SIZE + jj];
      for (ii = 0; ii < _numTris; ii++) {
         F3 edge1, edge2;
         F3 pvec, qvec, tvec;
         float invDet, time, uu, vv;

         F3_SUB(edge1, _v1[ii], _v0[ii]);
         F3_SUB(edge2, _v2[ii], _v0[ii]);
         F3_CROSS(pvec, d, edge2);
         invDet = 1.0f / F3_DOT(edge1, pvec);
         F3_SUB(tvec, o, _v0[ii]);
         F3_CROSS(qvec, tvec, edge1);

         /*
          * Test if the time the ray hits the plane of the triangle falls
          * within the ray's current interval
          */

         time = F3_DOT(edge2, qvec) * invDet;
         if (time > tBest || time < 0) {
            STAT_INC_BY(TriMissTHit, time > tBest);
            continue;
         }

         /*
          * Make sure the ray hits the triangle (and not just the triangle's
          * plane)
          */

         uu = F3_DOT(tvec, pvec) * invDet;
         vv = F3_DOT(d, qvec) * invDet;
         if (uu < 0 || vv < 0 || uu + vv > 1.0f) {
            STAT_INC(TriMissBary);
            continue;
         }
         tBest = time;
         uBest = uu;
         vBest = vv;
         triBest = ii;
         STAT_INC(TriHit);
      }

      hit->tHit[jj] = tBest;
      hit->uu[jj] = uBest;
      hit->vv[jj] = vBest;
      hit->triNum[jj] = triBest;
   }
}


/*
 * BruteForceCPU::intersect --
 *
 *      Loops through each ray and each triangle and tests for intersection.
 *
 * Returns:
 *      Fills in the corresponding hit for each ray
 */

void
BruteForceCPU::intersect(const RayCPU rays[],
                         uint32 numRays, HitCPU hits[])
{
   uint32 numPackets, percent;
   uint32 ii;

   PRINT(("   %6d Rays left", numRays));
   percent = numRays / 100;
   if (percent == 0) percent = 1;

   for(ii = 0, numPackets = numRays / BUNDLE_SIZE; ii < numPackets; ii++) {
      IntersectRay(rays[ii], &hits[ii]);

#ifndef SILENT
      if (ii % percent == 0) {
         printf("\r   %6d Rays left", numRays - ii * BUNDLE_SIZE);
         LOG(("\n   %6d Rays left", numRays - ii * BUNDLE_SIZE));
      }
#endif
   }
   PRINT(("\r   %6d Rays left\n", numRays - ii * BUNDLE_SIZE));
   Stats_Print();
}


/*
 * BruteForceCPU::intersectP --
 *
 *      specialized intersector for shadow rays.  I could implement this, but
 *      there's not a lot of point, so just fail for now.
 *
 * Returns:
 *      Not implemented.
 */

void
BruteForceCPU::intersectP(const RayCPU rays[],
                          uint32 numRays, HitCPU hits[])
{
   PRINT(("Bruteforce does not support intersection for shadow rays!\n"));
   assert(false);
   return;
}


/*
 * BruteForceCPU::intersectPacket --
 *
 *      Packet intersector for brute force.  I could implement this, but
 *      there's not a lot of point, so just fail for now.
 *
 * Returns:
 *      Not implemented.
 */

void
BruteForceCPU::intersectPacket(const RayCPU rays[],
                               uint32 numRays, HitCPU hits[])
{
   PRINT(("Bruteforce does not support packet intersection!\n"));
   assert(false);
   return;
}


/*
 * BruteForceCPU::intersectPacketP --
 *
 *      Packet intersector for shadow rays.  I could implement this, but
 *      there's not a lot of point, so just fail for now.
 *
 * Returns:
 *      Not implemented.
 */

void
BruteForceCPU::intersectPacketP(const RayCPU rays[],
                                uint32 numRays, HitCPU hits[])
{
   PRINT(("Bruteforce does not support packet intersection for shadow rays!\n"));
   assert(false);
   return;
}
