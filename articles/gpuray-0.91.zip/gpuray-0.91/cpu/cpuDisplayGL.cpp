/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * cpuDisplayGL.cpp --
 *
 *      Pixel displayer that expects the input image in memory on the CPU
 *      and uses GL to display it.
 */

#include "cpuDisplayGL.h"

#ifdef _WIN32
#include <windows.h>
#endif
#include <GL/gl.h>
#include <stdio.h>
#include <assert.h>

#include "../nv-glext.h"
#include "../renderContextGL.h"

#define CHECK_GL()      (CheckGL(__FILE__, __LINE__))


/*
 * CheckGL --
 *
 *      Checks for and reports and GL errors that have occurred.
 *
 * Results:
 *      void
 */

static void
CheckGL( const char *fileName, unsigned int line )
{
   static char error_msg[][32] = {
     "GL_INVALID_ENUM",
     "GL_INVALID_VALUE",
     "GL_INVALID_OPERATION",
     "GL_STACK_OVERFLOW",
     "GL_STACK_UNDERFLOW",
     "GL_OUT_OF_MEMORY"
   };
   static unsigned int numMsgs = sizeof error_msg / sizeof error_msg[0];
   GLenum err;

   if ( (err = glGetError() ) == GL_NO_ERROR) {
      return;
   }

   if ((unsigned) (err - GL_INVALID_ENUM) < numMsgs) {
      fprintf(stderr, "GLError: %s:%d: %s\n",
              fileName, line, error_msg[err - GL_INVALID_ENUM]);
   } else {
      static char unknown_msg[] = "Unknown GL error 01234567";

      sprintf(unknown_msg, "Unknown GL error %d\n", err);
      fprintf(stderr, "GLError: %s:%d: %s\n", fileName, line, unknown_msg);
   }
   assert(false);
   return;
}


PixelDisplayerCpuOgl::PixelDisplayerCpuOgl( RenderContextOGL* inRenderContext )
{
   _renderContext = inRenderContext;

   _renderContext->bind();

   glGenTextures(1, &_textureID);
   glBindTexture (GL_TEXTURE_2D, _textureID);
   CHECK_GL();
   glPixelStorei(GL_UNPACK_ALIGNMENT,1);
   glPixelStorei(GL_PACK_ALIGNMENT,1);

   glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
   glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
   glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
   glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
   CHECK_GL();

}

void
PixelDisplayerCpuOgl::Display( int inWidth, int inHeight,
                               const PixelCPU* inPixels )
{
   glBindTexture (GL_TEXTURE_2D, _textureID);
   glTexImage2D (GL_TEXTURE_2D, 0,
      GL_RGB,
      inWidth, inHeight, 0,
      GL_RGBA,
      GL_FLOAT, (const void*) inPixels);
   CHECK_GL();

   _renderContext->bind();

   glDrawBuffer(GL_BACK);
   glBindTexture(GL_TEXTURE_2D, _textureID);
   glEnable(GL_TEXTURE_2D);

   glColor3f(1, 1, 1);
   glClearColor( 1.0, 1.0, 0.0, 0.0 );
   glClear(GL_COLOR_BUFFER_BIT);
   CHECK_GL();

   glBegin(GL_QUADS);
   glTexCoord2d(0, 1);
   glVertex2f(-1.0f, -1.0f);

   glTexCoord2d(1, 1);
   glVertex2f(1.0f, -1.0f);

   glTexCoord2d(1, 0);
   glVertex2f(1.0f, 1.0f);

   glTexCoord2d(0, 0);
   glVertex2f(-1.0f, 1.0f);
   glEnd();

   _renderContext->swap();
}
