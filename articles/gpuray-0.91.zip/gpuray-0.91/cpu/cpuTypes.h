/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * cpuTypes.h --
 *
 *      The structs / typedefs used by the CPU version of the raytracer
 *
 */

#ifndef __CPUTYPES_H__
#define __CPUTYPES_H__

#include "../f3.h"
#include "../common/commonTypes.h"

typedef struct RayCPU {
   F3Packet o;
   F3Packet d;
} RayCPU;

typedef struct RayIntervalCPU {
   F3Packet o;
   float tmin[BUNDLE_SIZE];
   F3Packet d;
   float tmax[BUNDLE_SIZE];
} RayIntervalCPU;

typedef struct HitCPU {
   float tHit[BUNDLE_SIZE];
   float uu[BUNDLE_SIZE];
   float vv[BUNDLE_SIZE];
   int triNum[BUNDLE_SIZE];
} HitCPU;

#endif
