/*
 * cpuAccelerator.h --
 *
 *      Abstract class for wrapping CPU-hosted acceleration structures.
 */

#ifndef __CPU_ACCELERATOR_H__
#define __CPU_ACCELERATOR_H__

#include "cpuTypes.h"

class AcceleratorCPU
{
public:
   virtual void intersect(const RayCPU rays[],
                          uint32 numRays, HitCPU hits[]) = 0;
   virtual void intersectP(const RayCPU rays[],
                           uint32 numRays, HitCPU hits[]) = 0;
   virtual void intersectPacket(const RayCPU rays[],
                                uint32 numRays, HitCPU hits[]) = 0;
   virtual void intersectPacketP(const RayCPU rays[],
                                 uint32 numRays, HitCPU hits[]) = 0;

   virtual uint32 getBatchGranularity() = 0;
};

#endif
