/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * cpuTracer.cpp --
 *
 *      Helper classes for ray-tracing with the CPU
 */
#include "cpuTracer.h"


#include <assert.h>
#ifdef _WIN32
#include <winsock2.h>
#pragma comment(lib, "ws2_32")
#else
#include <arpa/inet.h>
#endif

#include "bruteforceCPU.h"
#include "kdtreeCPU.h"
#include "../log.h"
#include "../timer.h"
#include "../sampler.h"
#include "shader.h"
#include "cpuDisplay.h"
#include "../f3.h"

#if defined(SUPPORTS_CELL)
#include "../cell/kdtreeSPU.h"
#endif
#include "../ctm/kdtreeCTM_CPU.h"
/*
 * ReallocateAligned --
 *
 *      Extends an aligned allocation to a new size.
 *
 * Returns:
 *     A pointer to the allocated block.
 */

void*
ReallocateAligned( void* ptr, size_t oldsize, size_t size, size_t alignment )
{
#ifdef WINDOWS
  return _aligned_realloc( ptr, size, alignment );
#else
  void *result = 0;
  int error;

  error = posix_memalign( &result, alignment, size );
  assert( !error );
  memcpy( result, ptr, oldsize );
#ifdef SUPPORTS_CELL
  if( size > oldsize )
    memset( ((uint8*) result) + oldsize, 0, size - oldsize );
#endif
  FreeAligned( ptr );
  return result;
#endif
}

/*
 * AllocateAligned --
 *
 *     Allocates a block of 'size' bytes, aligned
 *     to an 'alignment'-byte boundary.
 *
 * Returns:
 *     A pointer to the allocated block.
 */

void*
AllocateAligned( size_t size, size_t alignment )
{
#ifdef WINDOWS
  return _aligned_malloc( size, alignment );
#else
  void* result = 0;
  int error;

  error = posix_memalign( &result, alignment, size );
  assert( !error );
#ifdef SUPPORTS_CELL
  memset( result, 0, size );
#endif
  return result;
#endif
}

/*
 * FreeAligned --
 *
 *     Frees a block of memory previously allocated
 *     with AllocateAligned.
 *
 * Returns:
 *     None.
 */

void
FreeAligned( void* buffer )
{
#ifdef WINDOWS
  _aligned_free( buffer );
#else
  free( buffer );
#endif
}

/*
 * DefaultTracerCPU::Trace --
 *
 *     Intersect rays, shade the hits,
 *     and composite the results into
 *     the image data provided.
 *
 * Returns:
 *     None.
 */

void DefaultTracerCPU::Trace(
   uint32 inCount,
   const SampleCPU* inSamples,
   const RayCPU* inRays,
   PixelCPU* ioPixels )
{
   class Callback : public IHitCallbackCPU
   {
   public:
      virtual void Call(
         uint32 inCount,
         const RayCPU* inRays,
         const HitCPU* inHits )
      {
         shader->Shade( inCount,
                        samples,
                        inRays,
                        inHits,
                        pixels,
                        true );
      }
      
      IStandardShaderCPU* shader;
      const SampleCPU* samples;
      PixelCPU* pixels;
   };

   Callback callback;
   callback.shader = _shader;
   callback.samples = inSamples;
   callback.pixels = ioPixels;
  
   _intersector->Intersect( inCount, inRays, &callback );
}

DefaultBaseRayIntersectorCPU::DefaultBaseRayIntersectorCPU(
   const Opts& inOptions,
   Scene* inScene,
   ToggleOption* inUsePacketsOptions )
{
   const char *accel = inOptions.accelName ? inOptions.accelName : "kdtree";
   float t;

   _scene = inScene;
   _usePacketsOption = inUsePacketsOptions;

   t = Timer_GetMS();
   if (strcmp(accel, "kdtree") == 0) {
      _accelCPU = new KDTreeAccelCPU(*_scene, inOptions);
   } else if (strcmp(accel, "bruteforce") == 0) {
      _accelCPU = new BruteForceCPU(*_scene);
#if defined(SUPPORTS_CELL)
   } else if (strcmp(accel, "kdtree-spu") == 0) {
     _accelCPU = new KDTreeSPU(*_scene, inOptions);
#endif
#ifdef USE_CTM
   } else if (strcmp(accel, "kdtree-ctm") == 0) {
     _accelCPU = new KDTreeCTMCPU(*_scene, inOptions);
#endif
   } else {
      fprintf(stderr, "Unknown CPU based accelerator: %s\n", accel);
      Usage(inOptions.progName);
   }
   t = Timer_GetMS() - t;

   PRINTTIME(("Constructing %s took %5.2f msecs.\n", accel, t));
   if (inOptions.buildOnly) {
      exit(0);
   }
}

void
DefaultBaseRayIntersectorCPU::Intersect(
   uint32 inCount,
   const RayCPU* inRays,
   IHitCallbackCPU* inContinuation )
{
   int numRays = inCount;
   HitCPU *hits;
   const RayCPU* rays;
   float t;

   rays = inRays;
   hits = (HitCPU *) AllocateAligned(numRays / BUNDLE_SIZE * sizeof(HitCPU), 16);


   if (_usePacketsOption->isEnabled()) {
      LOG(("Casting the rays (packets)...\n"));
      t = Timer_GetMS();
      _accelCPU->intersectPacket(rays, numRays, hits);
      t = Timer_GetMS() - t;

   } else {
      LOG(("Casting the rays (cpu)...\n"));
      t = Timer_GetMS();
      _accelCPU->intersect(rays, numRays, hits);
      t = Timer_GetMS() - t;
   }

   PRINTTIME(("Raycasting took %5.2f msecs (%5.2f MRays/s)\n",
              t, numRays / t/ 1000.0f));
   LOG(("   %5.2f MRays per second (%.2f usecs per ray).\n",
        numRays / t / 1000.0f, t * 1000.0 / numRays));

   LOG_ONLY({
      for (int ii = 0; ii < numRays / BUNDLE_SIZE; ii++) {
         for (int jj = 0; jj < BUNDLE_SIZE; jj++) {
            if (hits[ii].triNum[jj] >= 0) {
               LOG(("Ray[%d] hit triangle %d at time %f\n",
                  ii * BUNDLE_SIZE + jj,
                  hits[ii].triNum[jj], hits[ii].tHit[jj]));
            }
         }
      }
   });

   t = Timer_GetMS();
   inContinuation->Call( inCount, inRays, hits );
   t = Timer_GetMS() - t;
   PRINTTIME(("Shading took %5.2f msecs (%5.2f MPix/s)\n",
              t, inCount / t / 1000.0f));
}

void
DefaultBaseRayIntersectorCPU::IntersectP(
   uint32 inCount,
   const RayCPU* inRays,
   IHitCallbackCPU* inContinuation )
{
   int numRays = inCount;
   const RayCPU *rays;
   HitCPU *hits;
   float t;

   rays = inRays;
   hits = (HitCPU *) AllocateAligned(numRays / BUNDLE_SIZE * sizeof(HitCPU), 16);


   if (_usePacketsOption->isEnabled()) {
      PRINT(("Casting the shadow rays (packets)...\n"));
      t = Timer_GetMS();
      _accelCPU->intersectPacketP(rays, numRays, hits);
      t = Timer_GetMS() - t;

   } else {
      PRINT(("Casting the rays (cpu)...\n"));
      t = Timer_GetMS();
      _accelCPU->intersectP(rays, numRays, hits);
      t = Timer_GetMS() - t;
   }

   PRINTTIME(("Raycasting took %5.2f msecs (%5.2f fps) for %d rays and %d triangles.\n",
      t, 1000.0f / t, numRays, _scene->nTris()));
   PRINTTIME(("\t%5.2f MRays per second (%.2f usecs per ray).\n",
      numRays / t / 1000.0f, t * 1000.0 / numRays));

   LOG_ONLY({
      for (int ii = 0; ii < numRays / BUNDLE_SIZE; ii++) {
         for (int jj = 0; jj < BUNDLE_SIZE; jj++) {
            if (hits[ii].triNum[jj] >= 0) {
               LOG(("Ray[%d] hit triangle %d at time %f\n",
                  ii * BUNDLE_SIZE + jj,
                  hits[ii].triNum[jj], hits[ii].tHit[jj]));
            }
         }
      }
   });

   t = Timer_GetMS();
   inContinuation->Call( inCount, inRays, hits );
   t = Timer_GetMS() - t;
   PRINTTIME(("Shading took %5.2f msecs (%5.2f MPix/s)\n",
              t, inCount / t / 1000.0f));
}

/*
 * DumpBoundRayIntersectorCPU::DumpBoundRayIntersectorCPU --
 *
 *     Initializes a DumpBoundRayIntersectorCPU that will
 *     dump rays to the specified file name before passing
 *     them on to the "inner" intersector.
 *
 * Returns:
 *     None.
 */

void
PrimaryRayCallbackCPU::Call(
   uint32 inWidth, uint32 inHeight,
   const RayCPU* inRays )
{
   uint32 count = inWidth * inHeight;

   assert( count % BUNDLE_SIZE == 0 );

   uint32 bundleCount = count / BUNDLE_SIZE;

   SampleCPU* samples = (SampleCPU*) AllocateAligned(
      bundleCount*sizeof(SampleCPU), 16 );
   
   PixelCPU* pixels = new PixelCPU[ count ];

   memset( pixels, 0, count * sizeof(PixelCPU) );

   for( uint32 ii = 0; ii < bundleCount; ii++ )
   {
      for( uint32 jj = 0; jj < BUNDLE_SIZE; jj++ )
      {
         uint32 rayIndex = ii*BUNDLE_SIZE + jj;

         uint32 x, y;
         Sampler_IndexTo2D(rayIndex, inWidth, &x, &y);
         uint32 pixelIndex = x + y*inWidth;

         samples[ii].pixelIndex[jj] = pixelIndex;
         samples[ii].recursionDepth[jj] = 0;
      
         samples[ii].weight[jj].r = 1.0f;
         samples[ii].weight[jj].g = 1.0f;
         samples[ii].weight[jj].b = 1.0f;
         samples[ii].weight[jj].a = 1.0f;
      }
   }

   LOG(("rayType:primary %d\n", count));
   _tracer->Trace( count, samples, inRays, pixels );

   _pixelDisplayer->Display( inWidth, inHeight, pixels );

   delete[] pixels;
}

/*
 * DumpPrimaryRaysCPU::DumpPrimaryRaysCPU --
 *
 *     Initializes a DumpBoundRayIntersectorCPU that will
 *     dump rays to the specified file name before passing
 *     them on to the "inner" intersector.
 *
 * Returns:
 *     None.
 */

DumpPrimaryRaysCPU::DumpPrimaryRaysCPU(
   IPrimaryRayCallbackCPU* inInner,
   const char* inFileName )
{
   _inner = inInner;
   _fileName = inFileName;
}

/*
 * DumpBoundRayIntersectorCPU::Intersect --
 *
 *     Dump rays to a file and then pass them
 *     on to the inner intersector.
 *
 * Returns:
 *     None.
 */

void
DumpPrimaryRaysCPU::Call(
   uint32 inWidth, uint32 inHeight,
   const RayCPU* inRays )
{
   PRINT(("Dumping rays to file...\n"));
   float t = Timer_GetMS();

   uint32 width = inWidth;
   uint32 height = inHeight;
   uint32 rayCount = inWidth*inHeight;
   float* outputBuffer = new float[ 6*rayCount ];

   for( uint32 ii = 0; ii < rayCount; ii++ ) {
      uint32 packNum, packOff;
      uint32 x, y;
      
      Sampler_IndexTo2D(ii, inWidth, &x, &y);
      float* outputRay = outputBuffer + 6*(x + inWidth * y);

      packNum = ii / BUNDLE_SIZE; packOff = ii % BUNDLE_SIZE;

      outputRay[0] = inRays[packNum].o.v[packOff];
      outputRay[1] = inRays[packNum].o.v[packOff + BUNDLE_SIZE];
      outputRay[2] = inRays[packNum].o.v[packOff + 2*BUNDLE_SIZE];
      outputRay[3] = inRays[packNum].d.v[packOff];
      outputRay[4] = inRays[packNum].d.v[packOff + BUNDLE_SIZE];
      outputRay[5] = inRays[packNum].d.v[packOff + 2*BUNDLE_SIZE];
   }

   FILE* dumpFile = fopen( _fileName, "wb" );

   uint32 swappedWidth = htonl( width );
   fwrite( &swappedWidth, sizeof(swappedWidth), 1, dumpFile );

   uint32 swappedHeight = htonl( height );
   fwrite( &swappedHeight, sizeof(swappedHeight), 1, dumpFile );

   for( uint32 ii = 0; ii < rayCount; ii++ )
   {
      for( uint32 jj = 0; jj < 6; jj++ )
      {
         uint32 swapped = htonl( *((uint32*) outputBuffer + 6*ii + jj) );
         fwrite( &swapped, sizeof(swapped), 1, dumpFile );
      }
   }

   delete[] outputBuffer;

   fflush( dumpFile );
   fclose( dumpFile );

   t = Timer_GetMS() - t;
   PRINT(("Dumping rays took %5.2f msecs %d rays.\n", t, rayCount));

   _inner->Call( inWidth, inHeight, inRays );
}

RayGeneratorCPU::RayGeneratorCPU(
   CameraManager* inCameraManager,
   IPrimaryRayCallbackCPU* inContinuation )
{
   _cameraManager = inCameraManager;
   _continuation = inContinuation;
}


void
RayGeneratorCPU::Generate( int inWidth, int inHeight )
{
   int numRays = inWidth * inHeight;
   RayCPU *rays;

#if defined(_SSE2_) || defined(_WIN32)
   //PRINT(("SSE Control Register is 0x%x\n", _mm_getcsr()));
#endif
   
   rays = (RayCPU *) AllocateAligned(numRays * sizeof(RayCPU), 16);

   __m128 camTx, camTy, camU[3], camV[3], camW[3];
   __m128 invW, invH, one;
   float t;

   CameraInfo cam = _cameraManager->getSceneSpaceCameraInfo();
   int ii;

   t = Timer_GetMS();
   camTx = _mm_set1_ps(cam.tx);
   camTy = _mm_set1_ps(cam.ty);
   camU[0] = _mm_set1_ps(cam.u.x);
   camU[1] = _mm_set1_ps(cam.u.y);
   camU[2] = _mm_set1_ps(cam.u.z);
   camV[0] = _mm_set1_ps(cam.v.x);
   camV[1] = _mm_set1_ps(cam.v.y);
   camV[2] = _mm_set1_ps(cam.v.z);
   camW[0] = _mm_set1_ps(cam.w.x);
   camW[1] = _mm_set1_ps(cam.w.y);
   camW[2] = _mm_set1_ps(cam.w.z);

   invW = _mm_rcp_ps(_mm_set1_ps((float) inWidth));
   invH = _mm_rcp_ps(_mm_set1_ps((float) inHeight));
   one = _mm_set1_ps(1.0f);


   /*
    * Generate eye rays... (in the same order as krnGenEyeRays())
    */

   for (ii = 0; ii < inHeight * inWidth; ii += BUNDLE_SIZE) {
      __m128 filmX, filmY;
      __m128 rayD[3], norm;
      uint32 x[BUNDLE_SIZE], y[BUNDLE_SIZE], pos;

      pos = ii / BUNDLE_SIZE;

      /*
       * All rays have the same origin: the camera location.
       */

      rays[pos].o.x0 =
         rays[pos].o.x1 = rays[pos].o.x2 = rays[pos].o.x3 = cam.from.x;
      rays[pos].o.y0 =
         rays[pos].o.y1 = rays[pos].o.y2 = rays[pos].o.y3 = cam.from.y;
      rays[pos].o.z0 =
         rays[pos].o.z1 = rays[pos].o.z2 = rays[pos].o.z3 = cam.from.z;


      /*
       * Now determine the direction by sampling the film plane and
       * computing the ray corresponding to the chosen (x, y) location.
       *
       * Since we're generating four packed rays at a time, we actually
       * compute four samples.
       *
       * The scaled film position for (x, y) is (1 - 2x/width, 1 - 2y/height)
       */

      Sampler_IndexTo2D(ii, inWidth, &x[0], &y[0]);
      Sampler_IndexTo2D(ii + 1, inWidth, &x[1], &y[1]);
      Sampler_IndexTo2D(ii + 2, inWidth, &x[2], &y[2]);
      Sampler_IndexTo2D(ii + 3, inWidth, &x[3], &y[3]);

      filmX = _mm_set_ps(x[3] * 2.0f, x[2] * 2.0f, x[1] * 2.0f, x[0] * 2.0f);
      filmY = _mm_set_ps(y[3] * 2.0f, y[2] * 2.0f, y[1] * 2.0f, y[0] * 2.0f);

      filmX = _mm_sub_ps(one, _mm_mul_ps(filmX, invW));
      filmY = _mm_sub_ps(one, _mm_mul_ps(filmY, invH));
      filmX = _mm_mul_ps(camTy, filmX);
      filmY = _mm_mul_ps(camTy, filmY);

      rayD[0] = _mm_add_ps(camW[0], _mm_add_ps(_mm_mul_ps(filmX, camU[0]),
         _mm_mul_ps(filmY, camV[0])));
      rayD[1] = _mm_add_ps(camW[1], _mm_add_ps(_mm_mul_ps(filmX, camU[1]),
         _mm_mul_ps(filmY, camV[1])));
      rayD[2] = _mm_add_ps(camW[2], _mm_add_ps(_mm_mul_ps(filmX, camU[2]),
         _mm_mul_ps(filmY, camV[2])));

      norm = _mm_add_ps(_mm_add_ps(_mm_mul_ps(rayD[0], rayD[0]),
         _mm_mul_ps(rayD[1], rayD[1])),
         _mm_mul_ps(rayD[2], rayD[2]));
      norm = _mm_rsqrt_ps(norm);
      rayD[0] = _mm_mul_ps(rayD[0], norm);
      rayD[1] = _mm_mul_ps(rayD[1], norm);
      rayD[2] = _mm_mul_ps(rayD[2], norm);

      _mm_store_ps(&rays[pos].d.x0, rayD[0]);
      _mm_store_ps(&rays[pos].d.y0, rayD[1]);
      _mm_store_ps(&rays[pos].d.z0, rayD[2]);
      LOG_ONLY({
         for (int kk = 0; kk < BUNDLE_SIZE; kk++) {
            LOG(("SSE[%d]: o(%5.2f, %5.2f, %5.2f)  d(%5.2f, %5.2f, %5.2f)\n",
               pos * BUNDLE_SIZE + kk,
               rays[pos].o.v[kk], rays[pos].o.v[4+kk], rays[pos].o.v[8+kk],
               rays[pos].d.v[kk], rays[pos].d.v[4+kk], rays[pos].d.v[8+kk]));
         }
      });
   }
   t = Timer_GetMS() -t;
   PRINT(("SSE Eye Ray Generation took %5.2f msecs\n", t));

   _continuation->Call( inWidth, inHeight, rays );
}

