/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * cpuDisplayGL.h --
 *
 *      XXX
 */

#ifndef __CPU_CPUDISPLAYGL_H__
#define __CPU_CPUDISPLAYGL_H__

#ifdef _WIN32
#include <windows.h>
#endif
#include <GL/gl.h>

#include "cpuDisplay.h"
#include "../renderContextGL.h"
#include "../nv-glext.h"

class PixelDisplayerCpuOgl : public IPixelDisplayerCPU
{
public:
   PixelDisplayerCpuOgl( RenderContextOGL* inRenderContext );

   void Display( int inWidth, int inHeight, const PixelCPU* inPixels );

private:
   RenderContextOGL* _renderContext;

   unsigned int _fpID;
   unsigned int _textureID;
};

#endif
