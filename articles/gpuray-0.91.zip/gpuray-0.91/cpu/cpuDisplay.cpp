/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * cpuDisplay.cpp --
 *
 *      Helper classes for displaying pixels traced on the CPU.
 */
#include "cpuDisplay.h"

#include <assert.h>
#include <memory.h>
#include "../fileIO/ppmImage.h"

WriteImagePixelDisplayerCPU::WriteImagePixelDisplayerCPU(
   ppmImage* inOutputImage )
{
   _outputImage = inOutputImage;
}

void WriteImagePixelDisplayerCPU::Display(
   int inWidth, int inHeight,
   const PixelCPU* inPixels )
{
   assert( _outputImage->Width() == inWidth );
   assert( _outputImage->Height() == inHeight );

   memcpy( _outputImage->Data(), inPixels,
           inWidth*inHeight*sizeof(PixelCPU) );
}
