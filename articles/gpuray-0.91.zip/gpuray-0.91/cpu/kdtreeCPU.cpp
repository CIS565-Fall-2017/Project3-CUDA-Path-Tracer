/*
 * kdtreeCPU.cpp --
 *
 *      k-D tree spatial subdivision accelerator.
 */
#include "kdtreeCPU.h"

#include <math.h>

#include "simdIntrinsics.h"

#include "cpuTracer.h"
#include "../log.h"
#include "../builder/kdtree.h"

#define STATS_MODULE kdtreeCPU
#define STATS_COUNTERS \
   DEFN_STAT(Rays, "Number of rays cast") \
   DEFN_STAT(PacketSize, "Number of rays per packet") \
   DEFN_STAT(Traversals, "Number of cell traversals") \
   DEFN_STAT(MaxTraversals, "Most cells any ray traversed") \
   DEFN_STAT(TraverseLazy, "Number of lazy cells traversed") \
   DEFN_STAT(TraverseLeaves, "Number of leaf cells traversed") \
   DEFN_STAT(TraverseEmptyLeaves, "Number of empty leaf cells traversed") \
   DEFN_STAT(Intersections, "Number of triangles intersections tested") \
   DEFN_STAT(Push, "Number of kdtree node pushes") \
   DEFN_STAT(Pop, "Number of kdtree node pops") \
   DEFN_STAT(MaxIntersections, "Most triangles any ray tested") \
   DEFN_STAT(MailboxRaySize, "Size of the per-ray mailbox array") \
   DEFN_STAT(MailboxHits, "Number of intersections skipped by the mailbox") \
   DEFN_STAT(MaxStackDepth, "The deepest the stack ever gets") \
   DEFN_STAT(BadPackets, "Rays packets whose directions are incoherent") \
   DEFN_STAT(MissScene, "Rays that miss the scene bounding box") \
   DEFN_STAT(MissGeometry, "Rays that hit the scene, but not triangles") \
   DEFN_STAT(HitEmptyStack, "Rays that finish traversing with a hit > tMax") \
   DEFN_STAT(TriMissInactive, "Packet hits leaf with entire bundle inactive") \
   DEFN_STAT(TriMissTHit, "Ray hits triangle's plane with tHit > tMax") \
   DEFN_STAT(TriMissBary, "Ray hits triangle's plane, but not the triangle") \
   DEFN_STAT(TriHit, "Ray hits triangle.  Paper covers rock.") \

//#define WORKINGSET
#define STATS_DEFINE_COUNTERS
#include "../stats.h"

#define MAX(x, y)       ((x) > (y) ? (x) : (y))
#define MIN(x, y)       ((x) < (y) ? (x) : (y))

#define BUNDLES_PER_PACKET     4
#define PACKET_SIZE            (BUNDLES_PER_PACKET * BUNDLE_SIZE)

#define GET_ACCEL(t, n) ((TriAccel *) (((uint8 *) (t)) + (n)))

#define RAY_EPSILON 1.0e-2f

/*
 * I chose this value near-arbitrarily.  The deepest stack I've seen with
 * the current scenes and trees is only 13.
 */
#define STACK_SIZE      32


struct StackNode {
   float tMax;
   uint32 node;
};

struct StackSSENode {
   __m128 tMax[BUNDLES_PER_PACKET];
   __m128 tMin[BUNDLES_PER_PACKET];
   uint32 node;
};

struct RaySSE {
   __m128 o[3];
   __m128 d[3];
};

struct HitSSE {
   __m128 tHit;
   __m128 uu;
   __m128 vv;
   __m128i triNum;
};


/*
 * XXX These were members of the KDTreeAccelCPU class, but the VC++ kept screwing
 * up their alignment within the struct and causing weird exceptions.  The
 * __m128 type is supposed to force 16 byte alignment (and explicitly adding
 * a declspec didn't help), but the compiler just ignored it.  However, it
 * then generated aligned moves for the _mm_set* intrinsics which would
 * unpredictably fault.  This avoids that problem.
 */

static __m128 _bboxMinSSE[3];
static __m128 _bboxMaxSSE[3];

static const uint32 modulo3[] = { 0, 1, 2, 0, 1 };


/*
 * KDTreeAccelCPU::UpdateCachedTree --
 *
 *      We cache a handful of pointers based on the KDTree instead of
 *      repeatedly calling methods on the tree.  However, periodically we
 *      can refine the tree and all the pointers can change.
 *
 *      Additionally, as new triangle indices are added, we need to grow the
 *      _triIndexAccel list too.
 *
 * Returns:
 *      void, but a bunch of internal state is recomputed.
 */

void inline
KDTreeAccelCPU::UpdateCachedTree(void)
{
   const int *builtIndices;
   uint32 newNumIndices;

   _nodes = _tree->getNodes();

   /*
    * Smear out the precomputed intersection data to save an indirection at
    * intersection time.
    */

   newNumIndices = _tree->getPrimitiveIndexCount();
   if (newNumIndices > _numIndices) {
      uint32 ii;

      if (newNumIndices > _numAllocatedIndices) {
         uint32 numAllocated = _numAllocatedIndices * 2;

         numAllocated = MAX(newNumIndices, numAllocated);
         _triIndexAccel =
            (TriAccel *) ReallocateAligned(_triIndexAccel,
                                           _numAllocatedIndices * sizeof(TriAccel),
                                           numAllocated * sizeof(TriAccel), 16);

         _numAllocatedIndices = numAllocated;
      }

      builtIndices = _tree->getPrimitiveIndices();
      for (ii = _numIndices; ii < newNumIndices; ii++ ) {
         uint32 triNum = builtIndices[ii];

         _triIndexAccel[ii] = _triAccel[triNum];
      }
      _numIndices = newNumIndices;
   }
}


/*
 * KDTreeAccelCPU::KDTreeAccelCPU --
 *
 *      Constructor.  Stashes away the scene geometry, jobs out tree
 *      construction, and then repacks the tree for future use.
 *
 * Returns:
 *      Construction.
 */

KDTreeAccelCPU::KDTreeAccelCPU(const Scene& scene, const Opts& opts)
{
   KDTreeBuildOptions buildOptions;
   const F3 *v0 = scene.vertices(0);
   const F3 *v1 = scene.vertices(1);
   const F3 *v2 = scene.vertices(2);
   uint32 ii;

   _numTris = scene.nTris();
   F3_FROM_FLOAT3(_bboxMin, scene.bboxMin());
   F3_FROM_FLOAT3(_bboxMax, scene.bboxMax());
   for (ii = 0; ii < 3; ii++) {
      assert(((uint32) &_bboxMinSSE[ii]) % 16 == 0);
      _bboxMinSSE[ii] = _mm_set1_ps(_bboxMin.v[ii]);
      assert(((uint32) &_bboxMaxSSE[ii]) % 16 == 0);
      _bboxMaxSSE[ii] = _mm_set1_ps(_bboxMax.v[ii]);
   }

   /*
    * Precompute intemediate results to help with triangle intersection.
    */

   _triAccel = (TriAccel *) AllocateAligned(_numTris * sizeof(TriAccel), 16);
   for (ii = 0; ii < _numTris; ii++ ) {
      ComputeTriAccel(ii, v0[ii], v1[ii], v2[ii], &_triAccel[ii]);
   }

   _numAllocatedIndices = _numIndices = 0;
   _triIndexAccel = NULL;

   PRINT(("Building kd-tree from %d triangles...\n", _numTris));
   buildOptions.triIndexSize = sizeof(TriAccel);
   
   buildOptions.refineDepth =
      GetKeyValueInt("refineDepth", opts.buildOpts, buildOptions.refineDepth);
   buildOptions.isectCost= GetKeyValueFloat("isectCost", opts.buildOpts, buildOptions.isectCost);
   buildOptions.minNodeExtentRatio= GetKeyValueFloat("minNodeExtentRatio", opts.buildOpts, buildOptions.minNodeExtentRatio);
   _tree = KDTree_Create(opts, scene, buildOptions);
   UpdateCachedTree();
   PRINTTIME(("   Built kdtree with %d nodes and %d triangleIndices (%d triangles).\n",
              _tree->getNodeCount(), _numIndices, _numTris));

#ifdef USE_MAILBOX_TRI
   _mbox = new uint32[_numTris];
#endif
}


/*
 * KDTreeAccelCPU::~KDTreeAccelCPU --
 *
 *      Destructor.  Cleans up all the allocated memory.
 *
 * Returns:
 *      Death and destruction.  Or at least destruction.
 */

KDTreeAccelCPU::~KDTreeAccelCPU(void)
{
   delete _tree;
   delete [] _nodes;
#ifdef USE_MAILBOX_TRI
   delete [] _mbox;
#endif
   FreeAligned(_triAccel);
   FreeAligned(_triIndexAccel);
}


/*
 * KDTreeAccelCPU::getBatchGranularity --
 *
 *      Inform the caller of the size they should round
 *      up their buffers to (in number of bundles), so
 *      that we can trace without edge cases.
 *
 * Returns:
 *      the appropriate granularity
 */

uint32
KDTreeAccelCPU::getBatchGranularity()
{
   return BUNDLES_PER_PACKET;
}


/*
 * KDTreeAccelCPU::ComputeTriAccel --
 *
 *      Precalculates the information about the triangle used by the
 *      intersection routine.  Currently we precompute in which axis the
 *      face normal has greatest extent, the plane equation of the face, and
 *      the line equations of e1 and e2.  The three equations are all scaled
 *      such that one of the coefficients is 1 and doesn't need to be
 *      stored.
 *
 * Returns:
 *      void, fills in *triAccel
 */

void
KDTreeAccelCPU::ComputeTriAccel(uint32 triNum, const F3& v0,
                                const F3& v1, const F3& v2, TriAccel *accel)
{
   F3 e1, e2, e1xe2;
   float invDet;
   int axis, u, v;

   F3_SUB(e1, v2, v0);
   F3_SUB(e2, v1, v0);
   F3_CROSS(e1xe2, e1, e2);

   axis = 2;
   if (fabs(e1xe2.x) > fabs(e1xe2.y)) {
      if (fabs(e1xe2.x) > fabs(e1xe2.z)) axis = 0;
   } else {
      if (fabs(e1xe2.y) > fabs(e1xe2.z)) axis = 1;
   }
   u = modulo3[axis + 1];
   v = modulo3[axis + 2];

   accel->n_u = e1xe2.v[u] / e1xe2.v[axis];
   accel->n_v = e1xe2.v[v] / e1xe2.v[axis];
   accel->n_d = F3_DOT(v0, e1xe2) / e1xe2.v[axis];
   accel->axis = axis;

   invDet =  1.0f / (e1.v[u] * e2.v[v] - e1.v[v] * e2.v[u]);
   accel->e1_nu =  e1.v[u] * invDet;
   accel->e1_nv = -e1.v[v] * invDet;
   accel->v0_u = v0.v[u];

   accel->e2_nu =  e2.v[v] * invDet;
   accel->e2_nv = -e2.v[u] * invDet;
   accel->v0_v = v0.v[v];

   accel->triNum = triNum;
}


#if 0
/*
 * KDTreeAccelCPU::IntersectLeaf --
 *
 *      Routine to test a given ray against all the primitives in a leaf
 *      node and determine which one, if any, it hits first.
 *
 * Returns:
 *      void, updates *hitBest
 */

void
KDTreeAccelCPU::IntersectLeaf(const F3& rayO, const F3& rayD, uint32 triIdx,
                              uint32 numTris, uint32 packOff, HitCPU *hitBest) const
{
   uint32 ii;
   float tBest = hitBest->tHit[packOff], uBest = hitBest->uu[packOff];
   float vBest = hitBest->vv[packOff];
   int triBest = hitBest->triNum[packOff];

   STAT_INC_BY(TraverseEmptyLeaves, numTris == 0);
   for (ii = 0; ii < numTris; ii++) {
      float tHit;
      F3 v0, e1, e2, e2xe1;
      F3 txrayD, tvec;
      float invDet, uu, vv;
      uint32 triNum;

      triNum = _triNums[triIdx + ii];
#ifdef USE_MAILBOX_TRI
      if (_mbox[triNum] == _id) {
         STAT_INC(MailboxHits);
         continue;
      }
      _mbox[triNum] = _id;
#endif
      STAT_INC(Intersections);

      v0.x = _triPackets[triIdx + ii].x0;
      v0.y = _triPackets[triIdx + ii].y0;
      v0.z = _triPackets[triIdx + ii].z0;
      e1.x = _triPackets[triIdx + ii].x1;
      e1.y = _triPackets[triIdx + ii].y1;
      e1.z = _triPackets[triIdx + ii].z1;
      e2.x = _triPackets[triIdx + ii].x2;
      e2.y = _triPackets[triIdx + ii].y2;
      e2.z = _triPackets[triIdx + ii].z2;
      e2xe1.x = _triPackets[triIdx + ii].x3;
      e2xe1.y = _triPackets[triIdx + ii].y3;
      e2xe1.z = _triPackets[triIdx + ii].z3;

      /*
       * Test if the time the ray hits the plane of the triangle falls within
       * the ray's current interval
       */

      invDet = 1.0f / F3_DOT(rayD, e2xe1);
      F3_SUB(tvec, v0, rayO);
      tHit = F3_DOT(tvec, e2xe1) * invDet;
      if (tHit > tBest || tHit < RAY_EPSILON) {
         LOG(("Missed plane %d\n", triNum));
         STAT_INC(TriMissTHit);
         continue;
      }

      /*
       * Make sure it hit the triangle (and not just the triangle's plane)
       */

      F3_CROSS(txrayD, tvec, rayD);
      uu = -F3_DOT(txrayD, e2) * invDet;
      vv = F3_DOT(txrayD, e1) * invDet;
      if (uu < 0 || vv < 0 || uu + vv > 1.0f) {
         LOG(("Missed triangle %d\n", triNum));
         STAT_INC(TriMissBary);
         continue;
      }

      LOG(("Hit triangle %d at tHit %5.2f (best was %5.2f)\n",
           triNum, tHit, tBest));
      tBest = tHit;
      uBest = uu;
      vBest = vv;
      triBest = triNum;
      STAT_INC(TriHit);
   }
   hitBest->tHit[packOff] = tBest;
   hitBest->uu[packOff] = uBest;
   hitBest->vv[packOff] = vBest;
   hitBest->triNum[packOff] = triBest;
}
#endif


/*
 * KDTreeAccelCPU::IntersectLeafFast --
 *
 *      Routine to test a given ray against all the primitives in a leaf
 *      node and determine which one, if any, it hits first.
 *
 *      This version uses the alternate intersection routine suggested in
 *      the Intel paper at:
 *
 *   http://www.intel.com/cd/ids/developer/asmo-na/eng/dc/threading/245711.htm
 *
 * Returns:
 *      void, updates *hitBest
 */

void
KDTreeAccelCPU::IntersectLeafFast(const F3& rayO, const F3& rayD, uint32 triIdx,
                                  uint32 numTris, uint32 packOff, HitCPU *hitBest) const
{
   uint32 ii;
   float tBest = hitBest->tHit[packOff], uBest = hitBest->uu[packOff];
   float vBest = hitBest->vv[packOff];
   int triBest = hitBest->triNum[packOff];
   TriAccel *accel = GET_ACCEL(_triIndexAccel, triIdx);

   STAT_INC_BY(TraverseEmptyLeaves, numTris == 0);
   for (ii = 0; ii < numTris; ii++, accel++) {
      const uint32 triNum = accel->triNum;
#ifdef WORKINGSET
      accel->pad = 1;
#endif
#ifdef USE_MAILBOX_TRI
      if (_mbox[triNum] == _id) {
         STAT_INC(MailboxHits);
         continue;
      }
      _mbox[triNum] = _id;
#endif
#ifdef USE_MAILBOX_RAY
      if (triNum == _lastTri[triNum & MAILBOX_RAY_MASK]) {
         STAT_INC(MailboxHits);
         continue;
      }
      _lastTri[triNum & MAILBOX_RAY_MASK] = triNum;
#endif
      STAT_INC(Intersections);

      const uint32 axis = accel->axis;
      const uint32 u = modulo3[axis + 1];
      const uint32 v = modulo3[axis + 2];
      const float d = 1.0f / (rayD.v[axis] + accel->n_u * rayD.v[u] + accel->n_v * rayD.v[v]);
      const float tHit = (accel->n_d - rayO.v[axis] - accel->n_u * rayO.v[u] - accel->n_v * rayO.v[v]) * d;

      if (tHit > tBest || tHit < RAY_EPSILON) {
         LOG(("Missed plane %d\n", triNum));
         STAT_INC(TriMissTHit);
         continue;
      }

      const float hu = rayO.v[u] + tHit * rayD.v[u] - accel->v0_u;
      const float hv = rayO.v[v] + tHit * rayD.v[v] - accel->v0_v;
      const float uu = hv * accel->e1_nu + hu * accel->e1_nv;
      const float vv = hu * accel->e2_nu + hv * accel->e2_nv;

      if (uu < 0 || vv < 0 || uu + vv > 1.0f) {
         LOG(("Missed triangle %d\n", triNum));
         STAT_INC(TriMissBary);
         continue;
      }

      LOG(("Hit triangle %d at tHit %5.2f (best was %5.2f)\n",
           triNum, tHit, tBest));
      tBest = tHit;
      uBest = uu;
      vBest = vv;
      triBest = triNum;
      STAT_INC(TriHit);
   }
   hitBest->tHit[packOff] = tBest;
   hitBest->uu[packOff] = uBest;
   hitBest->vv[packOff] = vBest;
   hitBest->triNum[packOff] = triBest;
}


/*
 * KDTreeAccelCPU::IntersectLeafFastP --
 *
 *      Routine to test a given ray against all the primitives in a leaf
 *      node and determine which one, if any, it hits first.
 *
 *      This version uses the alternate intersection routine suggested in
 *      the Intel paper at:
 *
 *   http://www.intel.com/cd/ids/developer/asmo-na/eng/dc/threading/245711.htm
 *
 * Returns:
 *      void, updates *hitBest
 */

void
KDTreeAccelCPU::IntersectLeafFastP(const F3& rayO, const F3& rayD, uint32 triIdx,
                                   uint32 numTris, uint32 packOff, HitCPU *hit) const
{
   uint32 ii;
   float tBest = hit->tHit[packOff];
   TriAccel *accel = GET_ACCEL(_triIndexAccel, triIdx);

   STAT_INC_BY(TraverseEmptyLeaves, numTris == 0);
   for (ii = 0; ii < numTris; ii++, accel++) {
      const uint32 triNum = accel->triNum;
#ifdef WORKINGSET
      accel->pad = 1;
#endif
#ifdef USE_MAILBOX_TRI
      if (_mbox[triNum] == _id) {
         STAT_INC(MailboxHits);
         continue;
      }
      _mbox[triNum] = _id;
#endif
#ifdef USE_MAILBOX_RAY
      if (triNum == _lastTri[triNum & MAILBOX_RAY_MASK]) {
         STAT_INC(MailboxHits);
         continue;
      }
      _lastTri[triNum & MAILBOX_RAY_MASK] = triNum;
#endif
      STAT_INC(Intersections);

      const uint32 axis = accel->axis;
      const uint32 u = modulo3[axis + 1];
      const uint32 v = modulo3[axis + 2];
      const float d = 1.0f / (rayD.v[axis] + accel->n_u * rayD.v[u] + accel->n_v * rayD.v[v]);
      const float tHit = (accel->n_d - rayO.v[axis] - accel->n_u * rayO.v[u] - accel->n_v * rayO.v[v]) * d;

      if (tHit > tBest || tHit < RAY_EPSILON) {
         LOG(("Missed plane %d\n", triNum));
         STAT_INC(TriMissTHit);
         continue;
      }

      const float hu = rayO.v[u] + tHit * rayD.v[u] - accel->v0_u;
      const float hv = rayO.v[v] + tHit * rayD.v[v] - accel->v0_v;
      const float uu = hv * accel->e1_nu + hu * accel->e1_nv;
      const float vv = hu * accel->e2_nu + hv * accel->e2_nv;

      if (uu < 0 || vv < 0 || uu + vv > 1.0f) {
         LOG(("Missed triangle %d\n", triNum));
         STAT_INC(TriMissBary);
         continue;
      }

      LOG(("Hit triangle %d at tHit %5.2f\n",
           triNum, tHit));
      STAT_INC(TriHit);
      hit->tHit[packOff] = tHit;
      hit->triNum[packOff] = triNum;
      break;
   }
}


/*
 * KDTreeAccelCPU::IntersectRay --
 *
 *      Does intersection testing for a single ray.  Specifically, each ray
 *      walks through the kdtree until it a leaf.  It tests itself against
 *      the triangles in the leaf and each terminates of unwinds its stack
 *      and keeps trying.
 *
 * Returns:
 *      void, fills in the hit information.
 */

void
KDTreeAccelCPU::IntersectRay(const F3Packet& rayOs,
                             const F3Packet& rayDs, HitCPU *hit)
{
   for (uint32 ii = 0; ii < BUNDLE_SIZE; ii++, _id++) {
      static StackNode stack[STACK_SIZE];          /* Keep it off the stack */
      F3 rayD, rayO, invD, bboxNear, bboxFar, tNear, tFar;
      float tMin, tMax;
      uint32 node;
      uint32 stackTop = (uint32) -1;
      uint8 rightward[4];  /* The last one is just a pad */
#ifdef STATS
      uint32 nodesVisited = 0;
      uint32 trisTested = 0;
#endif

      STAT_INC(Rays);
#ifdef USE_MAILBOX_RAY
      memset(_lastTri, -1, MAILBOX_RAY_SIZE * sizeof _lastTri[0]);
#endif

      /* Compute once and save */
      rayD.x = rayDs.v[ii];
      rayD.y = rayDs.v[BUNDLE_SIZE + ii];
      rayD.z = rayDs.v[2*BUNDLE_SIZE + ii];
      rayO.x = rayOs.v[ii];
      rayO.y = rayOs.v[BUNDLE_SIZE + ii];
      rayO.z = rayOs.v[2*BUNDLE_SIZE + ii];
      F3_INV(invD, rayD);
      rightward[0] = NODE_SIZE * (invD.v[0] < 0);
      rightward[1] = NODE_SIZE * (invD.v[1] < 0);
      rightward[2] = NODE_SIZE * (invD.v[2] < 0);

      /*
       * Clip the ray against the scene bounding box to produce initial values
       * for tMin and tMax
       */

      if (!rightward[0]) {
         bboxNear.v[0] = _bboxMin.v[0]; bboxFar.v[0] = _bboxMax.v[0];
      } else {
         bboxNear.v[0] = _bboxMax.v[0]; bboxFar.v[0] = _bboxMin.v[0];
      }
      if (!rightward[1]) {
         bboxNear.v[1] = _bboxMin.v[1]; bboxFar.v[1] = _bboxMax.v[1];
      } else {
         bboxNear.v[1] = _bboxMax.v[1]; bboxFar.v[1] = _bboxMin.v[1];
      }
      if (!rightward[2]) {
         bboxNear.v[2] = _bboxMin.v[2]; bboxFar.v[2] = _bboxMax.v[2];
      } else {
         bboxNear.v[2] = _bboxMax.v[2]; bboxFar.v[2] = _bboxMin.v[2];
      }
      F3_SUB(tNear, bboxNear, rayO);
      F3_MUL(tNear, tNear, invD);
      tMin = MAX(MAX(MAX(tNear.v[0], tNear.v[1]), tNear.v[2]), 0);

      F3_SUB(tFar, bboxFar, rayO);
      F3_MUL(tFar, tFar, invD);
      tMax = MIN(MIN(tFar.v[0], tFar.v[1]), tFar.v[2]);

      /*
       * Allow a little slop when clipping to the bounding box.  Other than the
       * multiplication, this isn't a performance hit (walking off the last
       * cell of the kd-tree is equally expensive no matter by how far you go
       * after leaving).
       *
       * It really helps with scenes like the Cornell Box where there are
       * primitives on the walls of the scene bounding box.
       */

      tMax *= 1.01f;

      /*
       * Now walk the tree down to relevant leaves and test their primitives
       * for intersection.
       */

      LOG(("\nRay[%d] Tracing new ray, tMin: %5.2f, tMax: %5.2f\n",
           _id, tMin, tMax));
      hit->tHit[ii] = FLT_MAX; hit->triNum[ii] = -1;
      if (tMax < tMin) {
         STAT_INC(MissScene);
         continue;
      }

      node = 0;
      while (true) {
         float plane;
         uint32 near;

         while (true) {
            uint32 far, splitAxis;
            float tSplit;

            STAT_INC(Traversals);
            STATS_ONLY({
               nodesVisited++;
               if (nodesVisited > *STAT_GET(MaxTraversals)) {
                  STAT_SET(MaxTraversals, nodesVisited);
               }
            });
            near = GET_NODE(_nodes, node)->split.leftChild;
            plane = GET_NODE(_nodes, node)->split.splitValue;
            splitAxis = near & 0x3;
            near = near & (~0x3);
#ifdef WORKINGSET
            near = near & (~0x80000000);
            GET_NODE(_nodes, node)->split.leftChild |= 0x80000000;
#endif
            if (splitAxis == KD_LEAF) { break; }

            tSplit = (plane - rayO.v[splitAxis]) * invD.v[splitAxis];

            /*
             * NOTE:  Relies upon left + 1 being the index of the right child!
             */

            far = near + NODE_SIZE - rightward[splitAxis];
            near += rightward[splitAxis];
            assert(far - near == NODE_SIZE || near - far == NODE_SIZE);

            if (tSplit < tMin) {
               LOG(("Ray[%d] Going far only: %d (tSplit: %5.2f)\n",
                    _id, far, tSplit));
               node = far;
               continue;
            }
            if (tSplit > tMax) {
               LOG(("Ray[%d] Going near only: %d (tSplit: %5.2f)\n",
                    _id, near, tSplit));
               node = near;
               continue;
            }

            LOG(("Ray[%d] Going near: %d, pushing far: %d (tSplit: %5.2f)\n",
                 _id, near, far, tSplit));
            stackTop++;
            STAT_INC(Push);
            STATS_ONLY({
               if (stackTop + 1 > *STAT_GET(MaxStackDepth)) {
                  *STAT_GET(MaxStackDepth) = stackTop + 1;
               }
            });
            assert(stackTop < STACK_SIZE);
            stack[stackTop].tMax = tMax;
            stack[stackTop].node = far;

            tMax = tSplit;
            node = near;
         }

         STAT_INC(TraverseLeaves);
         LOG(("Ray[%d] Intersecting leaf\n", _id));
         if (*((int *) &plane) > 0) {
            if (((int) near) < 0) {
               /*
                * A negative primitive index signals a lazy node.
                */

               STAT_INC(TraverseLazy);
               _tree->refineLazy(node);
               UpdateCachedTree();
               continue;
            } else {
               IntersectLeafFast(rayO, rayD, near, *((int *) &plane), ii, hit);
            }
         }
         STATS_ONLY({
            trisTested += *(int *) &plane;
            if (trisTested > *STAT_GET(MaxIntersections)) {
               STAT_SET(MaxIntersections, trisTested);
            }
         });

         if (hit->tHit[ii] <= tMax) {
            assert(hit->triNum[ii] >= 0);
            break;    /* You sunk my battleship! */
         }

         if ((int) stackTop < 0) {
            assert(hit->triNum[ii] == -1);
            STAT_INC(MissGeometry);
            break;
         }

         STAT_INC(Pop);
         tMin = tMax;
         tMax = stack[stackTop].tMax;
         node = stack[stackTop].node;
         stackTop--;
         LOG(("Ray[%d] Popping Node %d: %5.2f, %5.2f\n", _id, node, tMin, tMax));
      }
   }
}


/*
 * KDTreeAccelCPU::IntersectRayP --
 *
 *      Does intersection testing for a single ray.  Specifically, each ray
 *      walks through the kdtree until it a leaf.  It tests itself against
 *      the triangles in the leaf and each terminates of unwinds its stack
 *      and keeps trying.
 *
 * Returns:
 *      void, fills in the hit information.
 */

void
KDTreeAccelCPU::IntersectRayP(const F3Packet& rayOs,
                             const F3Packet& rayDs, HitCPU *hit)
{
   for (uint32 ii = 0; ii < BUNDLE_SIZE; ii++, _id++) {
      static StackNode stack[STACK_SIZE];          /* Keep it off the stack */
      F3 rayD, rayO, invD, bboxNear, bboxFar, tNear, tFar;
      float tMin, tMax;
      uint32 node;
      uint32 stackTop = (uint32) -1;
      uint8 rightward[4];  /* The last one is just a pad */
#ifdef STATS
      uint32 nodesVisited = 0;
      uint32 trisTested = 0;
#endif

      STAT_INC(Rays);
#ifdef USE_MAILBOX_RAY
      memset(_lastTri, -1, MAILBOX_RAY_SIZE * sizeof _lastTri[0]);
#endif

      /* Compute once and save */
      rayD.x = rayDs.v[ii];
      rayD.y = rayDs.v[BUNDLE_SIZE + ii];
      rayD.z = rayDs.v[2*BUNDLE_SIZE + ii];
      rayO.x = rayOs.v[ii];
      rayO.y = rayOs.v[BUNDLE_SIZE + ii];
      rayO.z = rayOs.v[2*BUNDLE_SIZE + ii];
      F3_INV(invD, rayD);
      rightward[0] = NODE_SIZE * (invD.v[0] < 0);
      rightward[1] = NODE_SIZE * (invD.v[1] < 0);
      rightward[2] = NODE_SIZE * (invD.v[2] < 0);

      /*
       * Clip the ray against the scene bounding box to produce initial values
       * for tMin and tMax
       */

      if (!rightward[0]) {
         bboxNear.v[0] = _bboxMin.v[0]; bboxFar.v[0] = _bboxMax.v[0];
      } else {
         bboxNear.v[0] = _bboxMax.v[0]; bboxFar.v[0] = _bboxMin.v[0];
      }
      if (!rightward[1]) {
         bboxNear.v[1] = _bboxMin.v[1]; bboxFar.v[1] = _bboxMax.v[1];
      } else {
         bboxNear.v[1] = _bboxMax.v[1]; bboxFar.v[1] = _bboxMin.v[1];
      }
      if (!rightward[2]) {
         bboxNear.v[2] = _bboxMin.v[2]; bboxFar.v[2] = _bboxMax.v[2];
      } else {
         bboxNear.v[2] = _bboxMax.v[2]; bboxFar.v[2] = _bboxMin.v[2];
      }
      F3_SUB(tNear, bboxNear, rayO);
      F3_MUL(tNear, tNear, invD);
      tMin = MAX(MAX(MAX(tNear.v[0], tNear.v[1]), tNear.v[2]), 0);

      F3_SUB(tFar, bboxFar, rayO);
      F3_MUL(tFar, tFar, invD);
      tMax = MIN(MIN(tFar.v[0], tFar.v[1]), tFar.v[2]);

      /*
       * Allow a little slop when clipping to the bounding box.  Other than the
       * multiplication, this isn't a performance hit (walking off the last
       * cell of the kd-tree is equally expensive no matter by how far you go
       * after leaving).
       *
       * It really helps with scenes like the Cornell Box where there are
       * primitives on the walls of the scene bounding box.
       */

      tMax *= 1.01f;

      /*
       * Now walk the tree down to relevant leaves and test their primitives
       * for intersection.
       */

      LOG(("\nRay[%d] Tracing new ray, tMin: %5.2f, tMax: %5.2f\n",
           _id, tMin, tMax));
      hit->tHit[ii] = FLT_MAX; hit->triNum[ii] = -1;
      if (tMax < tMin) {
         STAT_INC(MissScene);
         continue;
      }

      node = 0;
      while (true) {
         float plane;
         uint32 near;

         while (true) {
            uint32 far, splitAxis;
            float tSplit;

            STAT_INC(Traversals);
            STATS_ONLY({
               nodesVisited++;
               if (nodesVisited > *STAT_GET(MaxTraversals)) {
                  STAT_SET(MaxTraversals, nodesVisited);
               }
            });
            near = GET_NODE(_nodes, node)->split.leftChild;
            plane = GET_NODE(_nodes, node)->split.splitValue;
            splitAxis = near & 0x3;
            near = near & (~0x3);
#ifdef WORKINGSET
            near = near & (~0x80000000);
            GET_NODE(_nodes, node)->split.leftChild |= 0x80000000;
#endif
            if (splitAxis == KD_LEAF) { break; }

            tSplit = (plane - rayO.v[splitAxis]) * invD.v[splitAxis];

            /*
             * NOTE:  Relies upon left + 1 being the index of the right child!
             */

            far = near + NODE_SIZE - rightward[splitAxis];
            near += rightward[splitAxis];
            assert(far - near == NODE_SIZE || near - far == NODE_SIZE);

            if (tSplit < tMin) {
               LOG(("Ray[%d] Going far only: %d (tSplit: %5.2f)\n",
                    _id, far, tSplit));
               node = far;
               continue;
            }
            if (tSplit > tMax) {
               LOG(("Ray[%d] Going near only: %d (tSplit: %5.2f)\n",
                    _id, near, tSplit));
               node = near;
               continue;
            }

            LOG(("Ray[%d] Going near: %d, pushing far: %d (tSplit: %5.2f)\n",
                 _id, near, far, tSplit));
            stackTop++;
            STAT_INC(Push);
            STATS_ONLY({
               if (stackTop + 1 > *STAT_GET(MaxStackDepth)) {
                  *STAT_GET(MaxStackDepth) = stackTop + 1;
               }
            });
            assert(stackTop < STACK_SIZE);
            stack[stackTop].tMax = tMax;
            stack[stackTop].node = far;

            tMax = tSplit;
            node = near;
         }

         STAT_INC(TraverseLeaves);
         LOG(("Ray[%d] Intersecting leaf\n", _id));
         if (*((int *) &plane) > 0) {
            if (((int) near) < 0) {
               /*
                * A negative primitive index signals a lazy node.
                */

               _tree->refineLazy(node);
               UpdateCachedTree();
               continue;
            } else {
               IntersectLeafFastP(rayO, rayD, near, *((int *) &plane), ii, hit);
            }
         }
         STATS_ONLY({
            trisTested += *(int *) &plane;
            if (trisTested > *STAT_GET(MaxIntersections)) {
               STAT_SET(MaxIntersections, trisTested);
            }
         });
#if 1
         if (hit->tHit[ii] <= tMax) {
           //assert(hit->triNum[ii] >= 0);
            break;    /* You sunk my battleship! */
         }

         if ((int) stackTop < 0) {
           //assert(hit->triNum[ii] == -1);
            STAT_INC(MissGeometry);
            break;
         }
#endif
         STAT_INC(Pop);
         tMin = tMax;
         tMax = stack[stackTop].tMax;
         node = stack[stackTop].node;
         stackTop--;
         LOG(("Ray[%d] Popping Node %d: %5.2f, %5.2f\n", _id, node, tMin, tMax));
      }
   }
}


#if 0
/*
 * KDTreeAccelCPU::IntersectLeafSSE --
 *
 *      SIMD SSE version of IntersectLeaf().  Intersects a packet of rays
 *      with the triangles in a given cell.
 *
 * Returns:
 *      void, updates *hitBest
 */

void
KDTreeAccelCPU::IntersectLeafSSE(const __m128 rayO[3], const __m128 rayD[3],
                                 uint32 triIdx, uint32 numTris,
                                 HitSSE *hitBest) const
{
   uint32 ii;
   __m128 tBest = hitBest->tHit, uBest = hitBest->uu, vBest = hitBest->vv;
   __m128 one = _mm_set1_ps(1.0f), zero = _mm_setzero_ps();
   __m128i triBest = hitBest->triNum;

   STAT_INC_BY(TraverseEmptyLeaves, BUNDLE_SIZE*(numTris == 0));
   for (ii = 0; ii < numTris; ii++) {
      __m128 tHit, bestMask, hitMask;
      __m128 v0[3], e1[3], e2[3], e2xe1[3];
      __m128 txrayD[3], tvec[3];
      __m128 invDet, uu, vv;
      uint32 triNum;

      triNum = _triNums[triIdx + ii];
#ifdef USE_MAILBOX_TRI
      if (_mbox[triNum] == _id) {
         STAT_INC_BY(MailboxHits, BUNDLE_SIZE);
         continue;
      }
      _mbox[triNum] = _id;
#endif
      STAT_INC_BY(Intersections, BUNDLE_SIZE);

      __m128 tmp0, tmp1, tmp2;
      tmp0 = _mm_load_ps(&_triPackets[triIdx + ii].v[0]);
      tmp1 = _mm_load_ps(&_triPackets[triIdx + ii].v[4]);
      tmp2 = _mm_load_ps(&_triPackets[triIdx + ii].v[8]);

      v0[0] = _mm_shuffle_ps(tmp0, tmp0, _MM_SHUFFLE(0, 0, 0, 0));
      v0[1] = _mm_shuffle_ps(tmp1, tmp1, _MM_SHUFFLE(0, 0, 0, 0));
      v0[2] = _mm_shuffle_ps(tmp2, tmp2, _MM_SHUFFLE(0, 0, 0, 0));

      e1[0] = _mm_shuffle_ps(tmp0, tmp0, _MM_SHUFFLE(1, 1, 1, 1));
      e1[1] = _mm_shuffle_ps(tmp1, tmp1, _MM_SHUFFLE(1, 1, 1, 1));
      e1[2] = _mm_shuffle_ps(tmp2, tmp2, _MM_SHUFFLE(1, 1, 1, 1));

      e2[0] = _mm_shuffle_ps(tmp0, tmp0, _MM_SHUFFLE(2, 2, 2, 2));
      e2[1] = _mm_shuffle_ps(tmp1, tmp1, _MM_SHUFFLE(2, 2, 2, 2));
      e2[2] = _mm_shuffle_ps(tmp2, tmp2, _MM_SHUFFLE(2, 2, 2, 2));

      e2xe1[0] = _mm_shuffle_ps(tmp0, tmp0, _MM_SHUFFLE(3, 3, 3, 3));
      e2xe1[1] = _mm_shuffle_ps(tmp1, tmp1, _MM_SHUFFLE(3, 3, 3, 3));
      e2xe1[2] = _mm_shuffle_ps(tmp2, tmp2, _MM_SHUFFLE(3, 3, 3, 3));

      /*
       * Test if the time the ray hits the plane of the triangle falls within
       * the ray's current interval
       */

      invDet = _mm_rcp_ps(_MM_DOT_PS(rayD, e2xe1));
      tvec[0] = _mm_sub_ps(v0[0], rayO[0]);
      tvec[1] = _mm_sub_ps(v0[1], rayO[1]);
      tvec[2] = _mm_sub_ps(v0[2], rayO[2]);
      tHit = _mm_mul_ps(_MM_DOT_PS(tvec, e2xe1), invDet);

      bestMask = _mm_and_ps(_mm_cmpge_ps(tHit, zero),
                            _mm_cmplt_ps(tHit, tBest));
      if (_mm_movemask_ps(bestMask) == 0) {
         LOG(("Missed plane %d\n", triNum));
         STAT_INC_BY(TriMissTHit, BUNDLE_SIZE);
         continue;
      }

      /*
       * Make sure it hit the triangle (and not just the triangle's plane)
       */

      txrayD[0] = _mm_sub_ps(_mm_mul_ps(tvec[1], rayD[2]),
                             _mm_mul_ps(tvec[2], rayD[1]));
      txrayD[1] = _mm_sub_ps(_mm_mul_ps(tvec[2], rayD[0]),
                             _mm_mul_ps(tvec[0], rayD[2]));
      txrayD[2] = _mm_sub_ps(_mm_mul_ps(tvec[0], rayD[1]),
                             _mm_mul_ps(tvec[1], rayD[0]));

      uu = _mm_sub_ps(zero, _MM_DOT_PS(txrayD, e2));
      vv = _MM_DOT_PS(txrayD, e1);
      uu = _mm_mul_ps(uu, invDet);
      vv = _mm_mul_ps(vv, invDet);
      hitMask = _mm_and_ps(_mm_cmpge_ps(uu, zero),
                           _mm_and_ps(_mm_cmpge_ps(vv, zero),
                                      _mm_cmple_ps(_mm_add_ps(uu,
                                                   _mm_sub_ps(vv, one)), zero)));
      hitMask = _mm_and_ps(hitMask, bestMask);
      if (_mm_movemask_ps(hitMask) == 0) {
         LOG(("Missed triangle %d\n", triNum));
         STAT_INC_BY(TriMissBary, BUNDLE_SIZE);
         continue;
      }

      /*
       * This is the best hit for at least one, but not necessarily all,
       * rays so we use the mask computed above to update tBest, triBest,
       * etc.
       */

      LOG(("Hit triangle %d with mask 0x%x\n",
           triNum, _mm_movemask_ps(hitMask)));

#define _MM_CMOV_PS(dst, src, mask) \
      _mm_or_ps(_mm_andnot_ps(mask, dst), _mm_and_ps(mask, src))
#define _MM_CMOV_SI128(dst, src, mask) \
      _mm_or_si128(_mm_andnot_si128(mask, dst), _mm_and_si128(mask, src))

      tBest = _MM_CMOV_PS(tBest, tHit, hitMask);
      uBest = _MM_CMOV_PS(uBest, uu, hitMask);
      vBest = _MM_CMOV_PS(vBest, vv, hitMask);

      __m128i triHit = _mm_set1_epi32(triNum);
      triBest = _MM_CMOV_SI128(triBest, triHit, *(__m128i *) &hitMask);
      STAT_INC_BY(TriHit, BUNDLE_SIZE);   /* XXX This isn't quite accurate */

   }
   hitBest->tHit = tBest;
   hitBest->uu = uBest;
   hitBest->vv = vBest;
   hitBest->triNum = triBest;
}
#endif


/*
 * KDTreeAccelCPU::IntersectLeafSSEFast --
 *
 *      Routine to test a given ray against all the primitives in a leaf
 *      node and determine which one, if any, it hits first.
 *
 *      This version uses the alternate intersection routine suggested in
 *      the Intel paper at:
 *
 *   http://www.intel.com/cd/ids/developer/asmo-na/eng/dc/threading/245711.htm
 *
 * Returns:
 *      void, updates *hitBest
 */

void
KDTreeAccelCPU::IntersectLeafSSEFast(const RaySSE rays[BUNDLES_PER_PACKET],
                                     const __m128 activeMask[BUNDLES_PER_PACKET],
                                     uint32 triIdx, uint32 numTris,
                                     HitSSE hitBest[BUNDLES_PER_PACKET]) const
{
   uint32 ii, jj;
   __m128 one = _mm_set1_ps(1.0f), zero = _mm_setzero_ps();
   TriAccel *accel = GET_ACCEL(_triIndexAccel, triIdx);

   STAT_INC_BY(TraverseEmptyLeaves, PACKET_SIZE * (numTris == 0));
   for (ii = 0; ii < numTris; ii++, accel++) {
      const uint32 triNum = accel->triNum;
#ifdef WORKINGSET
      accel->pad = 1;
#endif
#ifdef USE_MAILBOX_TRI
      if (_mbox[triNum] == _id) {
         STAT_INC(MailboxHits);
         continue;
      }
      _mbox[triNum] = _id;
#endif
#ifdef USE_MAILBOX_RAY
      if (triNum == _lastTri[triNum & MAILBOX_RAY_MASK]) {
         STAT_INC(MailboxHits);
         continue;
      }
      _lastTri[triNum & MAILBOX_RAY_MASK] = triNum;
#endif

      const uint32 axis = accel->axis;
      const uint32 u = modulo3[axis + 1];
      const uint32 v = modulo3[axis + 2];

      const __m128 tmp0 = _mm_load_ps((float *) &accel->axis);
      const __m128 nu = _mm_shuffle_ps(tmp0, tmp0, _MM_SHUFFLE(1, 1, 1, 1));
      const __m128 nv = _mm_shuffle_ps(tmp0, tmp0, _MM_SHUFFLE(2, 2, 2, 2));
      const __m128 nd = _mm_shuffle_ps(tmp0, tmp0, _MM_SHUFFLE(3, 3, 3, 3));

      const __m128 tmp1 = _mm_load_ps(&accel->v0_u);
      const __m128 tmp2 = _mm_load_ps(&accel->e2_nu);
      const __m128 v0_u = _mm_shuffle_ps(tmp1, tmp1, _MM_SHUFFLE(0, 0, 0, 0));
      const __m128 v0_v = _mm_shuffle_ps(tmp1, tmp1, _MM_SHUFFLE(1, 1, 1, 1));
      const __m128 e1_nu = _mm_shuffle_ps(tmp1, tmp1, _MM_SHUFFLE(2, 2, 2, 2));
      const __m128 e1_nv = _mm_shuffle_ps(tmp1, tmp1, _MM_SHUFFLE(3, 3, 3, 3));
      const __m128 e2_nu = _mm_shuffle_ps(tmp2, tmp2, _MM_SHUFFLE(0, 0, 0, 0));
      const __m128 e2_nv = _mm_shuffle_ps(tmp2, tmp2, _MM_SHUFFLE(1, 1, 1, 1));

      for (jj = 0; jj < BUNDLES_PER_PACKET; jj++) {
         if (_mm_movemask_ps(activeMask[jj]) == 0) {
            STAT_INC_BY(TriMissInactive, BUNDLE_SIZE);
            continue;
         }
         STAT_INC_BY(Intersections, BUNDLE_SIZE);

         const __m128 d = _mm_rcp_ps(_mm_add_ps(rays[jj].d[axis],
                                     _mm_add_ps(_mm_mul_ps(nu, rays[jj].d[u]),
                                                _mm_mul_ps(nv, rays[jj].d[v]))));
         const __m128 tHit = _mm_mul_ps(_mm_sub_ps(nd,
                                        _mm_add_ps(rays[jj].o[axis],
                                        _mm_add_ps(_mm_mul_ps(nu, rays[jj].o[u]),
                                                   _mm_mul_ps(nv, rays[jj].o[v])))), d);

         const __m128 bestMask = _mm_and_ps(_mm_cmpge_ps(tHit, zero),
                                            _mm_cmplt_ps(tHit, hitBest[jj].tHit));
         if (_mm_movemask_ps(bestMask) == 0) {
            LOG(("Missed plane %d\n", triNum));
            STAT_INC_BY(TriMissTHit, BUNDLE_SIZE);
            continue;
         }

         const __m128 hu = _mm_add_ps(rays[jj].o[u],
                           _mm_sub_ps(_mm_mul_ps(tHit, rays[jj].d[u]), v0_u));
         const __m128 hv = _mm_add_ps(rays[jj].o[v],
                           _mm_sub_ps(_mm_mul_ps(tHit, rays[jj].d[v]), v0_v));
         const __m128 uu = _mm_add_ps(_mm_mul_ps(hv, e1_nu),
                                      _mm_mul_ps(hu, e1_nv));
         const __m128 vv = _mm_add_ps(_mm_mul_ps(hu, e2_nu),
                                      _mm_mul_ps(hv, e2_nv));

         const __m128 hitMask = _mm_and_ps(bestMask,
                                _mm_and_ps(_mm_cmpge_ps(uu, zero),
                                _mm_and_ps(_mm_cmpge_ps(vv, zero),
                                           _mm_cmple_ps(_mm_add_ps(uu, vv), one))));
         if (_mm_movemask_ps(hitMask) == 0) {
            LOG(("Missed triangle %d\n", triNum));
            STAT_INC_BY(TriMissBary, BUNDLE_SIZE);
            continue;
         }

         LOG(("Hit triangle %d with mask 0x%x\n",
              triNum, _mm_movemask_ps(hitMask)));

#define _MM_CMOV_PS(dst, src, mask) \
         _mm_or_ps(_mm_andnot_ps(mask, dst), _mm_and_ps(mask, src))
#define _MM_CMOV_SI128(dst, src, mask) \
         _mm_or_si128(_mm_andnot_si128(mask, dst), _mm_and_si128(mask, src))

         hitBest[jj].tHit = _MM_CMOV_PS(hitBest[jj].tHit, tHit, hitMask);
         hitBest[jj].uu = _MM_CMOV_PS(hitBest[jj].uu, uu, hitMask);
         hitBest[jj].vv = _MM_CMOV_PS(hitBest[jj].vv, vv, hitMask);

         const __m128i triHit = _mm_set1_epi32(triNum);
         hitBest[jj].triNum = _MM_CMOV_SI128(hitBest[jj].triNum,
                                             triHit, *(__m128i *) &hitMask);
         STAT_INC_BY(TriHit, BUNDLE_SIZE);
      }
   }
}


/*
 * KDTreeAccelCPU::IntersectLeafSSEFastP --
 *
 *      Routine to test a given ray against all the primitives in a leaf
 *      node and determine which one, if any, it hits first.
 *
 *      This version uses the alternate intersection routine suggested in
 *      the Intel paper at:
 *
 *   http://www.intel.com/cd/ids/developer/asmo-na/eng/dc/threading/245711.htm
 *
 * Returns:
 *      void as soon as it finds any intersection, updates hits[].tHit
 */

void
KDTreeAccelCPU::IntersectLeafSSEFastP(const RaySSE rays[BUNDLES_PER_PACKET],
                                      const __m128 activeMask[BUNDLES_PER_PACKET],
                                      uint32 triIdx, uint32 numTris,
                                      HitSSE hits[BUNDLES_PER_PACKET]) const
{
   uint32 ii, jj;
   __m128 one = _mm_set1_ps(1.0f), zero = _mm_setzero_ps();
   TriAccel *accel = GET_ACCEL(_triIndexAccel, triIdx);
   int hitFlag[BUNDLES_PER_PACKET];

   STAT_INC_BY(TraverseEmptyLeaves, PACKET_SIZE * (numTris == 0));
   for (ii = 0; ii < numTris; ii++, accel++) {
      const uint32 triNum = accel->triNum;
#ifdef WORKINGSET
      accel->pad = 1;
#endif
#ifdef USE_MAILBOX_TRI
      if (_mbox[triNum] == _id) {
         STAT_INC(MailboxHits);
         continue;
      }
      _mbox[triNum] = _id;
#endif
#ifdef USE_MAILBOX_RAY
      if (triNum == _lastTri[triNum & MAILBOX_RAY_MASK]) {
         STAT_INC(MailboxHits);
         continue;
      }
      _lastTri[triNum & MAILBOX_RAY_MASK] = triNum;
#endif

      const uint32 axis = accel->axis;
      const uint32 u = modulo3[axis + 1];
      const uint32 v = modulo3[axis + 2];

      const __m128 tmp0 = _mm_load_ps((float *) &accel->axis);
      const __m128 nu = _mm_shuffle_ps(tmp0, tmp0, _MM_SHUFFLE(1, 1, 1, 1));
      const __m128 nv = _mm_shuffle_ps(tmp0, tmp0, _MM_SHUFFLE(2, 2, 2, 2));
      const __m128 nd = _mm_shuffle_ps(tmp0, tmp0, _MM_SHUFFLE(3, 3, 3, 3));

      const __m128 tmp1 = _mm_load_ps(&accel->v0_u);
      const __m128 tmp2 = _mm_load_ps(&accel->e2_nu);
      const __m128 v0_u = _mm_shuffle_ps(tmp1, tmp1, _MM_SHUFFLE(0, 0, 0, 0));
      const __m128 v0_v = _mm_shuffle_ps(tmp1, tmp1, _MM_SHUFFLE(1, 1, 1, 1));
      const __m128 e1_nu = _mm_shuffle_ps(tmp1, tmp1, _MM_SHUFFLE(2, 2, 2, 2));
      const __m128 e1_nv = _mm_shuffle_ps(tmp1, tmp1, _MM_SHUFFLE(3, 3, 3, 3));
      const __m128 e2_nu = _mm_shuffle_ps(tmp2, tmp2, _MM_SHUFFLE(0, 0, 0, 0));
      const __m128 e2_nv = _mm_shuffle_ps(tmp2, tmp2, _MM_SHUFFLE(1, 1, 1, 1));

      for (jj = 0; jj < BUNDLES_PER_PACKET; jj++) {
         if (hitFlag[jj] == 0xf) {
            // All rays in the bundle have already found any intersection.
            continue;
         }

         if (_mm_movemask_ps(activeMask[jj]) == 0) {
            STAT_INC_BY(TriMissInactive, BUNDLE_SIZE);
            continue;
         }
         STAT_INC_BY(Intersections, BUNDLE_SIZE);

         const __m128 d = _mm_rcp_ps(_mm_add_ps(rays[jj].d[axis],
                                     _mm_add_ps(_mm_mul_ps(nu, rays[jj].d[u]),
                                                _mm_mul_ps(nv, rays[jj].d[v]))));
         const __m128 tHit = _mm_mul_ps(_mm_sub_ps(nd,
                                        _mm_add_ps(rays[jj].o[axis],
                                        _mm_add_ps(_mm_mul_ps(nu, rays[jj].o[u]),
                                                   _mm_mul_ps(nv, rays[jj].o[v])))), d);

         const __m128 bestMask = _mm_and_ps(_mm_cmpge_ps(tHit, zero),
                                            _mm_cmplt_ps(tHit, hits[jj].tHit));
         if (_mm_movemask_ps(bestMask) == 0) {
            LOG(("Missed plane %d\n", triNum));
            STAT_INC_BY(TriMissTHit, BUNDLE_SIZE);
            continue;
         }

         const __m128 hu = _mm_add_ps(rays[jj].o[u],
                           _mm_sub_ps(_mm_mul_ps(tHit, rays[jj].d[u]), v0_u));
         const __m128 hv = _mm_add_ps(rays[jj].o[v],
                           _mm_sub_ps(_mm_mul_ps(tHit, rays[jj].d[v]), v0_v));
         const __m128 uu = _mm_add_ps(_mm_mul_ps(hv, e1_nu),
                                      _mm_mul_ps(hu, e1_nv));
         const __m128 vv = _mm_add_ps(_mm_mul_ps(hu, e2_nu),
                                      _mm_mul_ps(hv, e2_nv));

         const __m128 hitMask = _mm_and_ps(bestMask,
                                _mm_and_ps(_mm_cmpge_ps(uu, zero),
                                _mm_and_ps(_mm_cmpge_ps(vv, zero),
                                           _mm_cmple_ps(_mm_add_ps(uu, vv), one))));
         if ((hitFlag[jj] = _mm_movemask_ps(hitMask)) == 0) {
            LOG(("Missed triangle %d\n", triNum));
            STAT_INC_BY(TriMissBary, BUNDLE_SIZE);
            continue;
         }

         LOG(("Hit triangle %d with mask 0x%x\n",
              triNum, hitFlag[jj]));

#define _MM_CMOV_PS(dst, src, mask) \
         _mm_or_ps(_mm_andnot_ps(mask, dst), _mm_and_ps(mask, src))
#define _MM_CMOV_SI128(dst, src, mask) \
         _mm_or_si128(_mm_andnot_si128(mask, dst), _mm_and_si128(mask, src))

         hits[jj].tHit = _MM_CMOV_PS(hits[jj].tHit, tHit, hitMask);
 
         __m128i triHit = _mm_set1_epi32(triNum);
         hits[jj].triNum = _MM_CMOV_SI128(hits[jj].triNum,
                                             triHit, *(__m128i *) &hitMask);
         STAT_INC_BY(TriHit, BUNDLE_SIZE);
      }
   }
}


/*
 * KDTreeAccelCPU::IntersectSSE --
 *
 *      SIMD/SSE packet tracing.  Runs four rays at a time through the
 *      kdtree in tandem.
 *
 * Returns:
 *      Fills in the corresponding hit for each ray
 */

void
KDTreeAccelCPU::IntersectSSE(const RayCPU inRays[], HitCPU outHits[])
{
   ALIGN16(static StackSSENode stack[STACK_SIZE]);
   ALIGN16(static float fltMax[4]) = { FLT_MAX, FLT_MAX, FLT_MAX, FLT_MAX };
   ALIGN16(static int minusOne[4]) = { -1, -1, -1, -1 };

   HitSSE hits[BUNDLES_PER_PACKET];
   __m128 rayO[3 * BUNDLES_PER_PACKET],
          rayD[3 * BUNDLES_PER_PACKET], invD[3 * BUNDLES_PER_PACKET];
   __m128 tMin[BUNDLES_PER_PACKET], tMax[BUNDLES_PER_PACKET],
          activeMask[BUNDLES_PER_PACKET], liveMask[BUNDLES_PER_PACKET];
   __m128 zero = _mm_setzero_ps();
   uint32 node, ii, jj;
   uint32 stackTop = (uint32) -1;
   uint8 rightward[4];  /* The last one is just a pad */
   int anyLive, anyActive;
#ifdef STATS
   uint32 nodesVisited = 0;
   uint32 trisTested = 0;
#endif

#ifdef USE_MAILBOX_RAY
   memset(_lastTri, -1, MAILBOX_RAY_SIZE * sizeof _lastTri[0]);
#endif
   for (ii = 0; ii < BUNDLES_PER_PACKET; ii++) {
      rayO[ii * 3 + 0] = _mm_load_ps(&inRays[ii].o.v[0]);
      rayO[ii * 3 + 1] = _mm_load_ps(&inRays[ii].o.v[4]);
      rayO[ii * 3 + 2] = _mm_load_ps(&inRays[ii].o.v[8]);
      rayD[ii * 3 + 0] = _mm_load_ps(&inRays[ii].d.v[0]);
      invD[ii * 3 + 0] = _mm_rcp_ps(rayD[ii * 3 + 0]);
      rayD[ii * 3 + 1] = _mm_load_ps(&inRays[ii].d.v[4]);
      invD[ii * 3 + 1] = _mm_rcp_ps(rayD[ii * 3 + 1]);
      rayD[ii * 3 + 2] = _mm_load_ps(&inRays[ii].d.v[8]);
      invD[ii * 3 + 2] = _mm_rcp_ps(rayD[ii * 3 + 2]);
   }

   /*
    * Defend against ill-formed rays here for now.  Arguably these should
    * be assertions and the callers should be smarter.
    *
    * Note: The vastly common case is that the packet is good.  As such, in
    * the vastly common case, all of the comparisons will be done and no
    * if()'s will be taken.  As such, I've used bitwise operations instead
    * of logical ones since short-circuiting is extremely unlikely and
    * merged the check into one final if().
    *
    * Note2: I've sneaked the precomputation of rightward[] into this code
    * since it reuses one of the conditions (signMask != 0) and any remotely
    * sane compiler will save some work.
    */

   int bad;
   rightward[0] = _mm_movemask_ps(_mm_cmplt_ps(invD[0], zero));
   bad = (rightward[0] != 0) & (rightward[0] != 0xf);
   rightward[1] = _mm_movemask_ps(_mm_cmplt_ps(invD[1], zero));
   bad = bad | ((rightward[1] != 0) & (rightward[1] != 0xf));
   rightward[2] = _mm_movemask_ps(_mm_cmplt_ps(invD[2], zero));
   bad = bad | ((rightward[2] != 0) & (rightward[2] != 0xf));

   for (ii = 1; ii < BUNDLES_PER_PACKET; ii++) {
      int signMask;

      signMask = _mm_movemask_ps(_mm_cmplt_ps(invD[3*ii + 0], zero));
      bad = (signMask != rightward[0]) | bad;
      signMask = _mm_movemask_ps(_mm_cmplt_ps(invD[3*ii + 1], zero));
      bad = (signMask != rightward[1]) | bad;
      signMask = _mm_movemask_ps(_mm_cmplt_ps(invD[3*ii + 2], zero));
      bad = (signMask != rightward[2]) | bad;
   }
   rightward[0] = NODE_SIZE * (rightward[0] != 0);
   rightward[1] = NODE_SIZE * (rightward[1] != 0);
   rightward[2] = NODE_SIZE * (rightward[2] != 0);

   if (bad) {
      STAT_INC(BadPackets);
      for (ii = 0; ii < BUNDLES_PER_PACKET; ii++) {
         IntersectRay(inRays[ii].o, inRays[ii].d, &outHits[ii]);
      }
      return;
   }


   /*
    * At this point, we're committed, so increment the stats.
    */

   STAT_INC_BY(Rays, PACKET_SIZE);

   /*
    * Clip the ray against the scene bounding box to produce initial values
    * for tMin and tMax.
    */

   for (anyLive = false, ii = 0; ii < BUNDLES_PER_PACKET; ii++) {
      hits[ii].tHit = _mm_load_ps(fltMax);
      hits[ii].triNum = _mm_load_si128((__m128i *) minusOne);

      __m128 tNear[3], tFar[3];
      for (jj = 0; jj < 3; jj++) {
         __m128 tmp1, tmp2;

         tmp1 = _mm_mul_ps(_mm_sub_ps(_bboxMinSSE[jj], rayO[3*ii + jj]),
                           invD[3*ii + jj]);
         tmp2 = _mm_mul_ps(_mm_sub_ps(_bboxMaxSSE[jj], rayO[3*ii + jj]),
                           invD[3*ii + jj]);
         tNear[jj] = _mm_min_ps(tmp1, tmp2);
         tFar[jj] = _mm_max_ps(tmp1, tmp2);
      }
      tMin[ii] = _mm_setzero_ps();
      tMin[ii] = _mm_max_ps(_mm_max_ps(tNear[0], tNear[1]),
                        _mm_max_ps(tNear[2], tMin[ii]));
      tMax[ii] = _mm_min_ps(_mm_min_ps(tFar[0], tFar[1]), tFar[2]);

      /*
       * Fudge tMax because of instances where primitives lie on the
       * bounding box of the scene.
       */
      tMax[ii] = _mm_mul_ps(tMax[ii], _mm_set1_ps(1.01f));
      LOG_ONLY({
         ALIGN16(float rb[8]);
         _mm_store_ps(&rb[0], tMin[ii]);
         _mm_store_ps(&rb[4], tMax[ii]);
         LOG(("\nSSE[%d] tMin[0]: %5.2f, tMin[1]: %5.2f tMin[2]: %5.2f, tMin[3]: %5.2f\n",
                _id, rb[0], rb[1], rb[2], rb[3]));
         LOG(("SSE[%d] tMax[0]: %5.2f, tMax[1]: %5.2f tMax[2]: %5.2f, tMax[3]: %5.2f\n",
                _id, rb[4], rb[5], rb[6], rb[7]));
      });

      liveMask[ii] = activeMask[ii] = _mm_cmple_ps(tMin[ii], tMax[ii]);
      anyLive = _mm_movemask_ps(liveMask[ii]) | anyLive;
   }

   /*
    * Only rays for which tMin <= tMax even need to begin traversal.  If no
    * rays are live, then short-circuit here.
    */
   
   if (anyLive == false) {
      STAT_INC_BY(MissScene, PACKET_SIZE);
      for (ii = 0; ii < BUNDLES_PER_PACKET; ii++) {
         _mm_store_si128((__m128i *) &outHits[ii].triNum, hits[ii].triNum);
      }
      return;
   }


   /*
    * Now walk the tree down to relevant leaves and test their primitives
    * for intersection.
    */

   node = 0;
   while (true) {
      uint32 near;

      while (true) {
         uint32 far, splitAxis;
         __m128 tSplits[BUNDLES_PER_PACKET], plane;
         __m128 wantNear, wantFar;

         STAT_INC_BY(Traversals, PACKET_SIZE);
         STATS_ONLY({
            nodesVisited += PACKET_SIZE;
            if (nodesVisited > *STAT_GET(MaxTraversals)) {
               STAT_SET(MaxTraversals, nodesVisited);
            }
         });
         near = GET_NODE(_nodes, node)->split.leftChild;
         plane = _mm_set1_ps(GET_NODE(_nodes, node)->split.splitValue);
         splitAxis = near & 0x3;
         near = near & (~0x3);
#ifdef WORKINGSET
            near = near & (~0x80000000);
            GET_NODE(_nodes, node)->split.leftChild |= 0x80000000;
#endif
         if (splitAxis == KD_LEAF) { break; }


         tSplits[0] = _mm_mul_ps(_mm_sub_ps(plane, rayO[splitAxis]), invD[splitAxis]);
         wantFar  = _mm_and_ps(_mm_cmple_ps(tSplits[0], tMax[0]), activeMask[0]);
         wantNear = _mm_and_ps(_mm_cmpge_ps(tSplits[0], tMin[0]), activeMask[0]);
         for (ii = 1; ii < BUNDLES_PER_PACKET; ii++) {
            tSplits[ii] = _mm_mul_ps(_mm_sub_ps(plane, rayO[ii*3 + splitAxis]),
                                     invD[ii*3 + splitAxis]);
            wantFar  = _mm_or_ps(wantFar,
                  _mm_and_ps(_mm_cmple_ps(tSplits[ii], tMax[ii]), activeMask[ii]));
            wantNear = _mm_or_ps(wantNear,
                  _mm_and_ps(_mm_cmpge_ps(tSplits[ii], tMin[ii]), activeMask[ii]));
         }

         far = near + NODE_SIZE - rightward[splitAxis];
         near += rightward[splitAxis];
         assert(far - near == NODE_SIZE || near - far == NODE_SIZE);

         if (_mm_movemask_ps(wantNear) == 0) {
            LOG(("SSE[%d] Going far only: %d (masks: 0x%x / 0x%x)\n",
                  _id, far,
                  _mm_movemask_ps(wantNear), _mm_movemask_ps(wantNear)));
            node = far;
            continue;
         }
         if (_mm_movemask_ps(wantFar) == 0) {
            LOG(("SSE[%d] Going near only: %d (masks: 0x%x / 0x%x)\n",
                 _id, near,
                 _mm_movemask_ps(wantNear), _mm_movemask_ps(wantNear)));
            node = near;
            continue;
         }

         LOG(("SSE[%d] Going near: %d, pushing far: %d (masks: 0x%x / 0x%x)\n",
              _id, near, far,
              _mm_movemask_ps(wantNear), _mm_movemask_ps(wantNear)));
         stackTop++;
         STAT_INC_BY(Push, PACKET_SIZE);
         STATS_ONLY({
            if (stackTop + 1 > *STAT_GET(MaxStackDepth)) {
               *STAT_GET(MaxStackDepth) = stackTop + 1;
            }
         });
         assert(stackTop < STACK_SIZE);
         stack[stackTop].node = far;


         for (ii = 0; ii < BUNDLES_PER_PACKET; ii++) {
            _mm_store_ps((float *) &stack[stackTop].tMin[ii],
                         _mm_max_ps(tSplits[ii], tMin[ii]));
            _mm_store_ps((float *) &stack[stackTop].tMax[ii], tMax[ii]);

            tMax[ii] = _mm_min_ps(tSplits[ii], tMax[ii]);
            activeMask[ii] = _mm_cmple_ps(tMin[ii], tMax[ii]);
         }
         node = near;
      }


      uint32 numTris = GET_NODE(_nodes, node)->leaf.numPrimitives;
      LOG(("SSE[%d] Intersecting leaf\n", _id));
      STAT_INC_BY(TraverseLeaves, PACKET_SIZE);
      //assert(_mm_movemask_ps(_mm_and_ps(liveMask, activeMask)) != 0);

      if (numTris > 0) {
         /*
          * A negative primitive index signals a lazy node.
          */

         if (((int) near) < 0) {
            _tree->refineLazy(node);
            UpdateCachedTree();
            continue;
         } else {
            IntersectLeafSSEFast((const RaySSE *) inRays,
                                 activeMask,
                                 near,
                                 numTris,
                                 hits);
         }
      }

      for (anyLive = false, ii = 0; ii < BUNDLES_PER_PACKET; ii++) {
         liveMask[ii] = _mm_cmpgt_ps(hits[ii].tHit, _mm_max_ps(tMax[ii], tMin[ii]));
         anyLive = _mm_movemask_ps(liveMask[ii]) | anyLive;
      }

      STATS_ONLY({
         trisTested += (* (int *) &numTris);
         if (trisTested > *STAT_GET(MaxIntersections)) {
            STAT_SET(MaxIntersections, trisTested);
         }
      });

      if (anyLive == false) {
         for (ii = 0; ii < BUNDLES_PER_PACKET; ii++) {
            _mm_store_ps(outHits[ii].tHit, hits[ii].tHit);
            _mm_store_ps(outHits[ii].uu, hits[ii].uu);
            _mm_store_ps(outHits[ii].vv, hits[ii].vv);
            _mm_store_si128((__m128i *) outHits[ii].triNum, hits[ii].triNum);
#if 0
            for (jj = 0; jj < BUNDLE_SIZE; jj++) {
               if (outHits[ii].triNum[jj] > (int) _numTris) {
                  PRINT(("Found a bogus triangle: %d (tHit: %5.2f)\n",
                         outHits[ii].triNum[jj], outHits[ii].tHit[jj]));
               }
            }
#endif
         }
         return;
      }

      /*
       * Sometimes only a few rays in a packet require a node be pushed
       * and those rays then hit geometry before it's popped.  If other
       * rays are still traversing and we pop such a node (as defined as
       * a node where all live rays would be inactive) then immediately
       * discard it and move on to the next.
       */
      do {
         if ((int) stackTop < 0) {
            for (ii = 0; ii < BUNDLES_PER_PACKET; ii++) {
               _mm_store_ps(outHits[ii].tHit, hits[ii].tHit);
               _mm_store_ps(outHits[ii].uu, hits[ii].uu);
               _mm_store_ps(outHits[ii].vv, hits[ii].vv);
               _mm_store_si128((__m128i *) outHits[ii].triNum, hits[ii].triNum);
            }
            STATS_ONLY({
               for (ii = 0; ii < BUNDLES_PER_PACKET; ii++) {
                  for (jj = 0; jj < 4; jj++) {
                     if (outHits[ii].triNum[jj] != -1) {
                        STAT_INC(HitEmptyStack);
                     } else {
                        STAT_INC(MissGeometry);
                     }
                  }
               }
            });
            return;
         }

         STAT_INC_BY(Pop, PACKET_SIZE);
         node = stack[stackTop].node;
         for (anyActive = false, ii = 0; ii < BUNDLES_PER_PACKET; ii++) {
            tMin[ii] = _mm_load_ps((float *) &stack[stackTop].tMin[ii]);
            tMax[ii] = _mm_load_ps((float *) &stack[stackTop].tMax[ii]);
            tMax[ii] = _mm_and_ps(tMax[ii], liveMask[ii]);
            activeMask[ii] = _mm_cmple_ps(tMin[ii], tMax[ii]);
            anyActive = _mm_movemask_ps(activeMask[ii]) | anyActive;
         }
         stackTop--;
         LOG(("SSE[%d] Popping Node %d\n", _id, node));
      } while (anyActive == false);
   }
}


/*
 * KDTreeAccelCPU::IntersectSSEP --
 *
 *      SIMD/SSE packet tracing.  Runs four rays at a time through the
 *      kdtree in tandem.
 *
 * Returns:
 *      TRUE as soon as it finds any intersection
 *      without worrying about finding the closest one.
 */

void
KDTreeAccelCPU::IntersectSSEP(const RayCPU inRays[], HitCPU outHits[])
{
   ALIGN16(static StackSSENode stack[STACK_SIZE]);
   ALIGN16(static float fltMax[4]) = { FLT_MAX, FLT_MAX, FLT_MAX, FLT_MAX };
   ALIGN16(static int minusOne[4]) = { -1, -1, -1, -1 };

   HitSSE hits[BUNDLES_PER_PACKET];
   __m128 rayO[3 * BUNDLES_PER_PACKET],
          rayD[3 * BUNDLES_PER_PACKET], invD[3 * BUNDLES_PER_PACKET];
   __m128 tMin[BUNDLES_PER_PACKET], tMax[BUNDLES_PER_PACKET],
          activeMask[BUNDLES_PER_PACKET], liveMask[BUNDLES_PER_PACKET];
   __m128 zero = _mm_setzero_ps();
   uint32 node, ii, jj;
   uint32 stackTop = (uint32) -1;
   uint8 rightward[4];  /* The last one is just a pad */
   int anyLive, anyActive;
#ifdef STATS
   uint32 nodesVisited = 0;
   uint32 trisTested = 0;
#endif

#ifdef USE_MAILBOX_RAY
   memset(_lastTri, -1, MAILBOX_RAY_SIZE * sizeof _lastTri[0]);
#endif
   for (ii = 0; ii < BUNDLES_PER_PACKET; ii++) {
      rayO[ii * 3 + 0] = _mm_load_ps(&inRays[ii].o.v[0]);
      rayO[ii * 3 + 1] = _mm_load_ps(&inRays[ii].o.v[4]);
      rayO[ii * 3 + 2] = _mm_load_ps(&inRays[ii].o.v[8]);
      rayD[ii * 3 + 0] = _mm_load_ps(&inRays[ii].d.v[0]);
      invD[ii * 3 + 0] = _mm_rcp_ps(rayD[ii * 3 + 0]);
      rayD[ii * 3 + 1] = _mm_load_ps(&inRays[ii].d.v[4]);
      invD[ii * 3 + 1] = _mm_rcp_ps(rayD[ii * 3 + 1]);
      rayD[ii * 3 + 2] = _mm_load_ps(&inRays[ii].d.v[8]);
      invD[ii * 3 + 2] = _mm_rcp_ps(rayD[ii * 3 + 2]);
   }

   /*
    * Defend against ill-formed rays here for now.  Arguably these should
    * be assertions and the callers should be smarter.
    *
    * Note: The vastly common case is that the packet is good.  As such, in
    * the vastly common case, all of the comparisons will be done and no
    * if()'s will be taken.  As such, I've used bitwise operations instead
    * of logical ones since short-circuiting is extremely unlikely and
    * merged the check into one final if().
    *
    * Note2: I've sneaked the precomputation of rightward[] into this code
    * since it reuses one of the conditions (signMask != 0) and any remotely
    * sane compiler will save some work.
    */

   int bad;
   rightward[0] = _mm_movemask_ps(_mm_cmplt_ps(invD[0], zero));
   bad = (rightward[0] != 0) & (rightward[0] != 0xf);
   rightward[1] = _mm_movemask_ps(_mm_cmplt_ps(invD[1], zero));
   bad = bad | ((rightward[1] != 0) & (rightward[1] != 0xf));
   rightward[2] = _mm_movemask_ps(_mm_cmplt_ps(invD[2], zero));
   bad = bad | ((rightward[2] != 0) & (rightward[2] != 0xf));

   for (ii = 1; ii < BUNDLES_PER_PACKET; ii++) {
      int signMask;

      signMask = _mm_movemask_ps(_mm_cmplt_ps(invD[3*ii + 0], zero));
      bad = (signMask != rightward[0]) | bad;
      signMask = _mm_movemask_ps(_mm_cmplt_ps(invD[3*ii + 1], zero));
      bad = (signMask != rightward[1]) | bad;
      signMask = _mm_movemask_ps(_mm_cmplt_ps(invD[3*ii + 2], zero));
      bad = (signMask != rightward[2]) | bad;
   }
   rightward[0] = NODE_SIZE * (rightward[0] != 0);
   rightward[1] = NODE_SIZE * (rightward[1] != 0);
   rightward[2] = NODE_SIZE * (rightward[2] != 0);

   if (bad) {
     // Under Construction
      STAT_INC(BadPackets);
      for (ii = 0; ii < BUNDLES_PER_PACKET; ii++) {
         IntersectRayP(inRays[ii].o, inRays[ii].d, &outHits[ii]);
      }
      return;
   }


   /*
    * At this point, we're committed, so increment the stats.
    */

   STAT_INC_BY(Rays, PACKET_SIZE);

   /*
    * Clip the ray against the scene bounding box to produce initial values
    * for tMin and tMax.
    */

   for (anyLive = false, ii = 0; ii < BUNDLES_PER_PACKET; ii++) {
      hits[ii].tHit = _mm_load_ps(fltMax);
      hits[ii].triNum = _mm_load_si128((__m128i *) minusOne);

      __m128 tNear[3], tFar[3];
      for (jj = 0; jj < 3; jj++) {
         __m128 tmp1, tmp2;

         tmp1 = _mm_mul_ps(_mm_sub_ps(_bboxMinSSE[jj], rayO[3*ii + jj]),
                           invD[3*ii + jj]);
         tmp2 = _mm_mul_ps(_mm_sub_ps(_bboxMaxSSE[jj], rayO[3*ii + jj]),
                           invD[3*ii + jj]);
         tNear[jj] = _mm_min_ps(tmp1, tmp2);
         tFar[jj] = _mm_max_ps(tmp1, tmp2);
      }
      tMin[ii] = _mm_setzero_ps();
      tMin[ii] = _mm_max_ps(_mm_max_ps(tNear[0], tNear[1]),
                        _mm_max_ps(tNear[2], tMin[ii]));
      tMax[ii] = _mm_min_ps(_mm_min_ps(tFar[0], tFar[1]), tFar[2]);

      /*
       * Fudge tMax because of instances where primitives lie on the
       * bounding box of the scene.
       */
      tMax[ii] = _mm_mul_ps(tMax[ii], _mm_set1_ps(1.01f));
      LOG_ONLY({
         ALIGN16(float rb[8]);
         _mm_store_ps(&rb[0], tMin[ii]);
         _mm_store_ps(&rb[4], tMax[ii]);
         LOG(("\nSSE[%d] tMin[0]: %5.2f, tMin[1]: %5.2f tMin[2]: %5.2f, tMin[3]: %5.2f\n",
                _id, rb[0], rb[1], rb[2], rb[3]));
         LOG(("SSE[%d] tMax[0]: %5.2f, tMax[1]: %5.2f tMax[2]: %5.2f, tMax[3]: %5.2f\n",
                _id, rb[4], rb[5], rb[6], rb[7]));
      });

      liveMask[ii] = activeMask[ii] = _mm_cmple_ps(tMin[ii], tMax[ii]);
      anyLive = _mm_movemask_ps(liveMask[ii]) | anyLive;
   }

   /*
    * Only rays for which tMin <= tMax even need to begin traversal.  If no
    * rays are live, then short-circuit here.
    */
   
   if (anyLive == false) {
      STAT_INC_BY(MissScene, PACKET_SIZE);
      for (ii = 0; ii < BUNDLES_PER_PACKET; ii++) {
         _mm_store_si128((__m128i *) &outHits[ii].triNum, hits[ii].triNum);
      }
      return;
   }


   /*
    * Now walk the tree down to relevant leaves and test their primitives
    * for intersection.
    */

   node = 0;
   while (true) {
      uint32 near;

      while (true) {
         uint32 far, splitAxis;
         __m128 tSplits[BUNDLES_PER_PACKET], plane;
         __m128 wantNear, wantFar;

         STAT_INC_BY(Traversals, PACKET_SIZE);
         STATS_ONLY({
            nodesVisited += PACKET_SIZE;
            if (nodesVisited > *STAT_GET(MaxTraversals)) {
               STAT_SET(MaxTraversals, nodesVisited);
            }
         });
         near = GET_NODE(_nodes, node)->split.leftChild;
         plane = _mm_set1_ps(GET_NODE(_nodes, node)->split.splitValue);
         splitAxis = near & 0x3;
         near = near & (~0x3);
#ifdef WORKINGSET
            near = near & (~0x80000000);
            GET_NODE(_nodes, node)->split.leftChild |= 0x80000000;
#endif
         if (splitAxis == KD_LEAF) { break; }


         tSplits[0] = _mm_mul_ps(_mm_sub_ps(plane, rayO[splitAxis]), invD[splitAxis]);
         wantFar  = _mm_and_ps(_mm_cmple_ps(tSplits[0], tMax[0]), activeMask[0]);
         wantNear = _mm_and_ps(_mm_cmpge_ps(tSplits[0], tMin[0]), activeMask[0]);
         for (ii = 1; ii < BUNDLES_PER_PACKET; ii++) {
            tSplits[ii] = _mm_mul_ps(_mm_sub_ps(plane, rayO[ii*3 + splitAxis]),
                                     invD[ii*3 + splitAxis]);
            wantFar  = _mm_or_ps(wantFar,
                  _mm_and_ps(_mm_cmple_ps(tSplits[ii], tMax[ii]), activeMask[ii]));
            wantNear = _mm_or_ps(wantNear,
                  _mm_and_ps(_mm_cmpge_ps(tSplits[ii], tMin[ii]), activeMask[ii]));
         }

         far = near + NODE_SIZE - rightward[splitAxis];
         near += rightward[splitAxis];
         assert(far - near == NODE_SIZE || near - far == NODE_SIZE);

         if (_mm_movemask_ps(wantNear) == 0) {
            LOG(("SSE[%d] Going far only: %d (masks: 0x%x / 0x%x)\n",
                  _id, far,
                  _mm_movemask_ps(wantNear), _mm_movemask_ps(wantNear)));
            node = far;
            continue;
         }
         if (_mm_movemask_ps(wantFar) == 0) {
            LOG(("SSE[%d] Going near only: %d (masks: 0x%x / 0x%x)\n",
                 _id, near,
                 _mm_movemask_ps(wantNear), _mm_movemask_ps(wantNear)));
            node = near;
            continue;
         }

         LOG(("SSE[%d] Going near: %d, pushing far: %d (masks: 0x%x / 0x%x)\n",
              _id, near, far,
              _mm_movemask_ps(wantNear), _mm_movemask_ps(wantNear)));
         stackTop++;
         STAT_INC_BY(Push, PACKET_SIZE);
         STATS_ONLY({
            if (stackTop + 1 > *STAT_GET(MaxStackDepth)) {
               *STAT_GET(MaxStackDepth) = stackTop + 1;
            }
         });
         assert(stackTop < STACK_SIZE);
         stack[stackTop].node = far;


         for (ii = 0; ii < BUNDLES_PER_PACKET; ii++) {
            _mm_store_ps((float *) &stack[stackTop].tMin[ii],
                         _mm_max_ps(tSplits[ii], tMin[ii]));
            _mm_store_ps((float *) &stack[stackTop].tMax[ii], tMax[ii]);

            tMax[ii] = _mm_min_ps(tSplits[ii], tMax[ii]);
            activeMask[ii] = _mm_cmple_ps(tMin[ii], tMax[ii]);
         }
         node = near;
      }


      uint32 numTris = GET_NODE(_nodes, node)->leaf.numPrimitives;
      LOG(("SSE[%d] Intersecting leaf\n", _id));
      STAT_INC_BY(TraverseLeaves, PACKET_SIZE);
      //assert(_mm_movemask_ps(_mm_and_ps(liveMask, activeMask)) != 0);

      if (numTris > 0) {
         /*
          * A negative primitive index signals a lazy node.
          */

         if (((int) near) < 0) {
            STAT_INC(TraverseLazy);
            _tree->refineLazy(node);
            UpdateCachedTree();
            continue;
         } else {
            IntersectLeafSSEFastP((const RaySSE *) inRays,
                                  activeMask,
                                  near,
                                  numTris,
                                  hits);
         }
      }

      for (anyLive = false, ii = 0; ii < BUNDLES_PER_PACKET; ii++) {
         liveMask[ii] = _mm_cmpgt_ps(hits[ii].tHit, _mm_max_ps(tMax[ii], tMin[ii]));
         anyLive = _mm_movemask_ps(liveMask[ii]) | anyLive;
      }

      STATS_ONLY({
         trisTested += (* (int *) &numTris);
         if (trisTested > *STAT_GET(MaxIntersections)) {
            STAT_SET(MaxIntersections, trisTested);
         }
      });

      if (anyLive == false) {
         for (ii = 0; ii < BUNDLES_PER_PACKET; ii++) {
            _mm_store_ps(outHits[ii].tHit, hits[ii].tHit);
            _mm_store_ps(outHits[ii].uu, hits[ii].uu);
            _mm_store_ps(outHits[ii].vv, hits[ii].vv);
            _mm_store_si128((__m128i *) outHits[ii].triNum, hits[ii].triNum);
         }
         return;
      }

      /*
       * Sometimes only a few rays in a packet require a node be pushed
       * and those rays then hit geometry before it's popped.  If other
       * rays are still traversing and we pop such a node (as defined as
       * a node where all live rays would be inactive) then immediately
       * discard it and move on to the next.
       */
      do {
         if ((int) stackTop < 0) {
            for (ii = 0; ii < BUNDLES_PER_PACKET; ii++) {
               _mm_store_ps(outHits[ii].tHit, hits[ii].tHit);
               _mm_store_ps(outHits[ii].uu, hits[ii].uu);
               _mm_store_ps(outHits[ii].vv, hits[ii].vv);
               _mm_store_si128((__m128i *) outHits[ii].triNum, hits[ii].triNum);
            }
            STATS_ONLY({
               for (ii = 0; ii < BUNDLES_PER_PACKET; ii++) {
                  for (jj = 0; jj < 4; jj++) {
                     if (outHits[ii].triNum[jj] != -1) {
                        STAT_INC(HitEmptyStack);
                     } else {
                        STAT_INC(MissGeometry);
                     }
                  }
               }
            });
            return;
         }

         STAT_INC_BY(Pop, PACKET_SIZE);
         node = stack[stackTop].node;
         for (anyActive = false, ii = 0; ii < BUNDLES_PER_PACKET; ii++) {
            tMin[ii] = _mm_load_ps((float *) &stack[stackTop].tMin[ii]);
            tMax[ii] = _mm_load_ps((float *) &stack[stackTop].tMax[ii]);
            tMax[ii] = _mm_and_ps(tMax[ii], liveMask[ii]);
            activeMask[ii] = _mm_cmple_ps(tMin[ii], tMax[ii]);
            anyActive = _mm_movemask_ps(activeMask[ii]) | anyActive;
         }
         stackTop--;
         LOG(("SSE[%d] Popping Node %d\n", _id, node));
      } while (anyActive == false);
   }
}


/*
 * KDTreeAccelCPU::intersect --
 *
 *      Loops through each ray traversing through the kdtree looking for
 *      intersections.
 *
 * Returns:
 *      Fills in the corresponding hit for each ray
 */

void
KDTreeAccelCPU::intersect(const RayCPU rays[],
                          uint32 numRays, HitCPU hits[])
{
   uint32 numPackets = numRays / BUNDLE_SIZE, percent;
   uint32 ii;

   assert(numRays % BUNDLE_SIZE == 0);  /* Simplify boundary conditions */

#ifdef USE_MAILBOX_TRI
   memset(_mbox, 0, sizeof(uint32) * _numTris);
#endif
#ifdef USE_MAILBOX_RAY
   STAT_SET(MailboxRaySize, MAILBOX_RAY_SIZE);
#endif

   PRINT(("   %7d Rays left", numRays));
   percent = numPackets / 10;
   if (percent == 0) percent = 1;

   STAT_SET(PacketSize, 1);
   for (ii = 0; ii < numPackets; ii++) {
      _id = ii * BUNDLE_SIZE;
      IntersectRay(rays[ii].o, rays[ii].d, &hits[ii]);

#ifndef NDEBUG
      if (ii % percent == 0) {
         if (!_quiet) printf("\r   %7d Rays left", numRays - ii * BUNDLE_SIZE);
         LOG(("\n   %7d Rays left", numRays - ii * BUNDLE_SIZE));
      }
#endif
   }
   PRINT(("\r   %7d Rays left\n", numRays - ii * BUNDLE_SIZE));
   Stats_Print();
   _tree->printStats();
#ifdef WORKINGSET
   uint32 refnodes = 0, reftris = 0;
   KDTreeNode *nodep = GET_NODE(_nodes, 0);
   for(ii = 0; ii < (uint32)_tree->getNodeCount(); ii++, nodep++)
   {
     if(nodep->split.leftChild & 0x80000000)
     {
       nodep->split.leftChild &= (~0x80000000);
       refnodes++;
     }
   }
   PRINT(("WORKINGSET  %d Nodes / %d Nodes referenced\n", refnodes, _tree->getNodeCount()));
   TriAccel *accelp = GET_ACCEL(_triIndexAccel, 0);
   for(ii = 0; ii < (uint32)_numTris; ii++, accelp++)
   {
     if(accelp->pad == 1)
     {
       accelp->pad = 0;
       reftris++;
     }
   }
   PRINT(("WORKINGSET  %d Triangles / %d Triangles referenced\n", reftris, _numTris));
#endif
}


/*
 * KDTreeAccelCPU::intersectP --
 *
 *      Loops through each ray traversing through the kdtree looking for
 *      intersections.
 *
 * Returns:
 *      Fills in the corresponding hit for each ray
 */

void
KDTreeAccelCPU::intersectP(const RayCPU rays[],
                           uint32 numRays, HitCPU hits[])
{
   uint32 numPackets = numRays / BUNDLE_SIZE, percent;
   uint32 ii;

   assert(numRays % BUNDLE_SIZE == 0);  /* Simplify boundary conditions */

#ifdef USE_MAILBOX_TRI
   memset(_mbox, 0, sizeof(uint32) * _numTris);
#endif
#ifdef USE_MAILBOX_RAY
   STAT_SET(MailboxRaySize, MAILBOX_RAY_SIZE);
#endif

   PRINT(("   %7d Rays left", numRays));
   percent = numPackets / 10;
   if (percent == 0) percent = 1;

   STAT_SET(PacketSize, 1);
   for (ii = 0; ii < numPackets; ii++) {
      _id = ii * BUNDLE_SIZE;
      IntersectRayP(rays[ii].o, rays[ii].d, &hits[ii]);

#ifndef NDEBUG
      if (ii % percent == 0) {
         if (!_quiet) printf("\r   %7d Rays left", numRays - ii * BUNDLE_SIZE);
         LOG(("\n   %7d Rays left", numRays - ii * BUNDLE_SIZE));
      }
#endif
   }
   PRINT(("\r   %7d Rays left\n", numRays - ii * BUNDLE_SIZE));
   Stats_Print();
   _tree->printStats();
#ifdef WORKINGSET
   uint32 refnodes = 0, reftris = 0;
   KDTreeNode *nodep = GET_NODE(_nodes, 0);
   for(ii = 0; ii < (uint32)_tree->getNodeCount(); ii++, nodep++)
   {
     if(nodep->split.leftChild & 0x80000000)
     {
       nodep->split.leftChild &= (~0x80000000);
       refnodes++;
     }
   }
   PRINT(("WORKINGSET  %d Nodes / %d Nodes referenced\n", refnodes, _tree->getNodeCount()));
   TriAccel *accelp = GET_ACCEL(_triIndexAccel, 0);
   for(ii = 0; ii < (uint32)_numTris; ii++, accelp++)
   {
     if(accelp->pad == 1)
     {
       accelp->pad = 0;
       reftris++;
     }
   }
   PRINT(("WORKINGSET  %d Triangles / %d Triangles referenced\n", reftris, _numTris));
#endif
}


/*
 * KDTreeAccelCPU::intersectPacket --
 *
 *      Packet-at-a-time kd-tree traversal and triangle intersection.
 *
 * Returns:
 *      Fills in the corresponding hit for each ray
 */

void
KDTreeAccelCPU::intersectPacket(const RayCPU rays[],
                                uint32 numRays, HitCPU hits[])
{
   uint32 numBundles = numRays / BUNDLE_SIZE;
   uint32 percent, ii;

   assert(BUNDLE_SIZE == 4);    /* Required to use IntersectSSE()! */
   assert(numRays % (PACKET_SIZE) == 0);  /* Simplify boundaries */

#ifdef USE_MAILBOX_TRI
   memset(_mbox, 0, sizeof(uint32) * _numTris);
#endif
#ifdef USE_MAILBOX_RAY
   STAT_SET(MailboxRaySize, MAILBOX_RAY_SIZE);
#endif

   PRINT(("   %7d Rays left", numRays));
   percent = numBundles / 10;
   if (percent == 0) percent = 1;

   /*
    * An actual 'packet' consists of some number of bundled 2x2 groups of
    * rays.
    */

   STAT_SET(PacketSize, PACKET_SIZE);
   for (ii = 0; ii < numBundles; ii += BUNDLES_PER_PACKET) {
      _id = ii * BUNDLE_SIZE;
      IntersectSSE(&rays[ii], &hits[ii]);

#ifndef NDEBUG
      if (ii % percent == 0) {
         if (!_quiet) printf("\r   %7d Rays left", numRays - ii * BUNDLE_SIZE);
         LOG(("\n   %7d Rays left", numRays - ii * BUNDLE_SIZE));
      }
#endif
   }
   PRINT(("\r   %7d Rays left\n", numRays - ii * BUNDLE_SIZE));
   Stats_Print();
   _tree->printStats();


#ifdef WORKINGSET
   uint32 refnodes = 0, reftris = 0;
   KDTreeNode *nodep = GET_NODE(_nodes, 0);
   for(ii = 0; ii < (uint32)_tree->getNodeCount(); ii++, nodep++)
   {
     if(nodep->split.leftChild & 0x80000000)
     {
       nodep->split.leftChild &= (~0x80000000);
       refnodes++;
     }
   }
   PRINT(("WORKINGSET  %d Nodes / %d Nodes referenced\n", refnodes, _tree->getNodeCount()));
   TriAccel *accelp = GET_ACCEL(_triIndexAccel, 0);
   for(ii = 0; ii < (uint32)_numTris; ii++, accelp++)
   {
     if(accelp->pad == 1)
     {
       accelp->pad = 0;
       reftris++;
     }
   }
   PRINT(("WORKINGSET  %d Triangles / %d Triangles referenced\n", reftris, _numTris));
#endif
}


/*
 * KDTreeAccelCPU::intersectPacketP --
 *
 *      Packet-at-a-time kd-tree traversal and triangle intersection.
 *
 * Returns:
 *      TRUE as soon as it finds any intersection 
 *      without worring about finding the closest one
 */

void
KDTreeAccelCPU::intersectPacketP(const RayCPU rays[],
                                 uint32 numRays, HitCPU hits[])
{
   uint32 numBundles = numRays / BUNDLE_SIZE;
   uint32 percent, ii;

   assert(BUNDLE_SIZE == 4);    /* Required to use IntersectSSE()! */
   assert(numRays % (PACKET_SIZE) == 0);  /* Simplify boundaries */

#ifdef USE_MAILBOX_TRI
   memset(_mbox, 0, sizeof(uint32) * _numTris);
#endif
#ifdef USE_MAILBOX_RAY
   STAT_SET(MailboxRaySize, MAILBOX_RAY_SIZE);
#endif

   PRINT(("   %7d Rays left", numRays));
   percent = numBundles / 10;
   if (percent == 0) percent = 1;

   /*
    * An actual 'packet' consists of some number of bundled 2x2 groups of
    * rays.
    */

   STAT_SET(PacketSize, PACKET_SIZE);
   for (ii = 0; ii < numBundles; ii += BUNDLES_PER_PACKET) {
      _id = ii * BUNDLE_SIZE;
      IntersectSSEP(&rays[ii], &hits[ii]);

#ifndef NDEBUG
      if (ii % percent == 0) {
         if (!_quiet) printf("\r   %7d Rays left", numRays - ii * BUNDLE_SIZE);
         LOG(("\n   %7d Rays left", numRays - ii * BUNDLE_SIZE));
      }
#endif
   }
   PRINT(("\r   %7d Rays left\n", numRays - ii * BUNDLE_SIZE));
   Stats_Print();
   _tree->printStats();
#ifdef WORKINGSET
   uint32 refnodes = 0, reftris = 0;
   KDTreeNode *nodep = GET_NODE(_nodes, 0);
   for(ii = 0; ii < (uint32)_tree->getNodeCount(); ii++, nodep++)
   {
     if(nodep->split.leftChild & 0x80000000)
     {
       nodep->split.leftChild &= (~0x80000000);
       refnodes++;
     }
   }
   PRINT(("WORKINGSET  %d Nodes / %d Nodes referenced\n", refnodes, _tree->getNodeCount()));
   TriAccel *accelp = GET_ACCEL(_triIndexAccel, 0);
   for(ii = 0; ii < (uint32)_numTris; ii++, accelp++)
   {
     if(accelp->pad == 1)
     {
       accelp->pad = 0;
       reftris++;
     }
   }
   PRINT(("WORKINGSET  %d Triangles / %d Triangles referenced\n", reftris, _numTris));
#endif
}
