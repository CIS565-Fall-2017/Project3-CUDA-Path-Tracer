/*
 * shader.cpp --
 *
 *      CPU Shader implementation
 */

#include <math.h>
#include <stdlib.h>
#include <assert.h>
#include "simdIntrinsics.h"

#include "shader.h"
#include "kdtreeCPU.h"
#include "cpuDisplay.h"
#include "../sampler.h"
#include "../log.h"

#ifdef WIN32
extern double drand48();
#endif

/*
* AllocateAlignedClear --
*
*      Allocate a memory block with alignment, and zero it out.
*
* Results:
*      The allocated block, or NULL on failure.
*
*/
static void*
AllocateAlignedClear( size_t inSize, size_t inAlignment )
{
   void* result = AllocateAligned( inSize, inAlignment );
   if( result == NULL ) return NULL;
   memset( result, 0, inSize );
   return result;
}


/*
 * InterpolateBary --
 *
 *      Takes 3 values and computes their weighted average according to the
 *      specified barycentric weights.
 *
 * Results:
 *      See above (weighted average of v0, v1, v2)
 *
 */

static inline __m128
InterpolateBary(const __m128& v0, const __m128& v1, const __m128& v2, const
      __m128&u, const __m128& v, const __m128& w)
{
   const __m128 c0 = _mm_mul_ps(v0, u);
   const __m128 c1 = _mm_mul_ps(v1, v);
   const __m128 c2 = _mm_mul_ps(v2, w);
   return _mm_add_ps(_mm_add_ps(c0, c1), c2);
}


/*
 * CalcTangent --
 *
 *      Calculate tangent vector from normal vector.
 *
 * Results:
 *      void, but tangent is written.
 *
 */

static inline void
CalcTangent(const __m128 *normal, __m128 *tangent)
{
  int i, j;

  ALIGN16(F3Packet nv);
  ALIGN16(F3Packet tv);
  _mm_store_ps(&nv.x0, normal[0]);
  _mm_store_ps(&nv.y0, normal[1]);
  _mm_store_ps(&nv.z0, normal[2]);

  /* Find the minor axis of the vector */
  for(j = 0; j < BUNDLE_SIZE; j++)
  {
    int index = -1;
    float min = FLT_MAX;
    for(i = 0; i < 3; i++)
    {
      float val = fabs(nv.v[i * BUNDLE_SIZE + j]);
      if(val < min)
      {
        min = val;
        index = i;
      }
    }
    assert( index < 3 );
    if(index == 0)
    {
      tv.v[0 * BUNDLE_SIZE + j] =  0.0f;
      tv.v[1 * BUNDLE_SIZE + j] = -nv.v[2 * BUNDLE_SIZE + j];
      tv.v[2 * BUNDLE_SIZE + j] =  nv.v[1 * BUNDLE_SIZE + j];
    }
    else if(index == 1)
    {
      tv.v[0 * BUNDLE_SIZE + j] = -nv.v[2 * BUNDLE_SIZE + j];
      tv.v[1 * BUNDLE_SIZE + j] =  0.0f;
      tv.v[2 * BUNDLE_SIZE + j] =  nv.v[0 * BUNDLE_SIZE + j];
    }
    else if(index == 2)
    {
      tv.v[0 * BUNDLE_SIZE + j] = -nv.v[1 * BUNDLE_SIZE + j];
      tv.v[1 * BUNDLE_SIZE + j] =  nv.v[0 * BUNDLE_SIZE + j];
      tv.v[2 * BUNDLE_SIZE + j] =  0.0f;
    }
  }
  tangent[0] = _mm_load_ps(&tv.x0);
  tangent[1] = _mm_load_ps(&tv.y0);
  tangent[2] = _mm_load_ps(&tv.z0);

  /* Normalize tangent vector */
  __m128 invLength = _mm_rsqrt_ps(_MM_DOT_PS(tangent, tangent));
  tangent[0] = _mm_mul_ps(tangent[0], invLength);
  tangent[1] = _mm_mul_ps(tangent[1], invLength);
  tangent[2] = _mm_mul_ps(tangent[2], invLength);
}


/*
 * ShadeLocalLight --
 *
 *      Helper routine that computes the contribution of the given point
 *      light to given hit.  Currently it only does simple diffuse shading.
 *
 * Results:
 *      void, but *rgb[] is filled in.
 */

static inline void
ShadeLocalLight(const __m128 pHit[3], const __m128 N[3],
                const __m128 diffuse[3], const LightInfo& light,
                const CameraManager *cam, __m128 rgb[3])
{
   /*
    * XXX This should all be cached in the lights and updated per frame,
    * not computed repeatedly here and in the Brook shading code.
    */
   Vec3f lightPosV =
      cam->getSceneTransformation().transformPoint(light.position);
   const __m128 lightPos[3] = {
      _mm_set1_ps(lightPosV.x), _mm_set1_ps(lightPosV.y), _mm_set1_ps(lightPosV.z),
   };
   const __m128 lightAtten = _mm_set1_ps(light.distAtten);
   const __m128 attenFactor = _mm_rcp_ps(_mm_mul_ps(lightAtten, lightAtten));
   const __m128 lightDiffuse[3] = {
      _mm_set1_ps(light.diffIntensity.x),
      _mm_set1_ps(light.diffIntensity.y),
      _mm_set1_ps(light.diffIntensity.z),
   };

   /*
    * Below here is the code that's actually dependent on the hit.
    */

   __m128 lightD[3] = {
      _mm_sub_ps(lightPos[0], pHit[0]),
      _mm_sub_ps(lightPos[1], pHit[1]),
      _mm_sub_ps(lightPos[2], pHit[2]),
   };
   const __m128 lightDist = _MM_DOT_PS(lightD, lightD);

   const __m128 attenuation = _mm_max_ps(_mm_setzero_ps(),
         _mm_sub_ps(_mm_set1_ps(1.0f), _mm_mul_ps(lightDist, attenFactor)));

   const __m128 invLength = _mm_rsqrt_ps(lightDist);
   lightD[0] = _mm_mul_ps(lightD[0], invLength);
   lightD[1] = _mm_mul_ps(lightD[1], invLength);
   lightD[2] = _mm_mul_ps(lightD[2], invLength);

   __m128 NdotL = _MM_DOT_PS(N, lightD);
   NdotL = _mm_max_ps(_mm_setzero_ps(), NdotL);
   NdotL = _mm_mul_ps(NdotL, attenuation);

   for (uint32 ii = 0; ii < 3; ii++) {
      rgb[ii] = _mm_add_ps(rgb[ii],
            _mm_mul_ps(_mm_mul_ps(diffuse[ii], lightDiffuse[ii]), NdotL));
   }
}

static inline uint32 roundUp( uint32 n, uint32 d )
{
   return d * ( (n + d-1) / d );
}

static inline void
CompositePixel( PixelCPU* ioDstPixel,
                const PixelCPU& inSrcPixel,
                const PixelCPU& inWeight )
{
#ifndef NDEBUG
  const float* components = (const float*) &inSrcPixel;

  for( int ii = 0; ii < 4; ii++) {
    assert( !isnan(components[ii]) && !isinf(components[ii]) );
    assert( components[ii] >= 0.0f );
  }
#endif

  ioDstPixel->r += inSrcPixel.r * inWeight.r;
  ioDstPixel->g += inSrcPixel.g * inWeight.g;
  ioDstPixel->b += inSrcPixel.b * inWeight.b;
  ioDstPixel->a += inSrcPixel.a * inWeight.a;
}

static inline void
CompositeMiss( PixelCPU* ioDstPixel, const PixelCPU& inWeight )
{
  static const PixelCPU kMissPixel = {0.75f, 0, 0.15f, 1.0f};
  CompositePixel( ioDstPixel, kMissPixel, inWeight );
}

void
MissShaderCPU::Shade(
   uint32 inCount,
   const SampleCPU* inSamples,
   const RayCPU* inRays,
   const HitCPU* inHits,
   PixelCPU* ioPixels,
   bool inShouldRelease )
{
  if( inShouldRelease )
  {
    FreeAligned( (void*) inSamples );
    FreeAligned( (void*) inRays );
    FreeAligned( (void*) inHits );
  }
}

void
DefaultHitShaderCPU::Shade(
   uint32 inCount,
   const SampleCPU* inSamples,
   const RayCPU* inRays,
   const HitCPU* inHits,
   PixelCPU* ioPixels,
   bool inShouldRelease )
{
   uint32 rayCount = inCount;

   assert( rayCount % BUNDLE_SIZE == 0 );

   uint32 bundleCount = rayCount / BUNDLE_SIZE;

   for( uint32 ii = 0; ii < bundleCount; ii++ )
   {
      const SampleCPU &sample = inSamples[ii];
      const HitCPU &hit = inHits[ii];

      PixelCPU pixel = { 0, 0, 0, 0 };

      for( uint32 jj = 0; jj < BUNDLE_SIZE; jj++ )
      {
         float u = hit.uu[jj];
         float v = hit.vv[jj];
         float w = 1.0f - (u + v);
         int triangleIndex = hit.triNum[jj];

         if( triangleIndex >= 0 )
         {
            pixel.r = u;
            pixel.g = v;
            pixel.b = w;
            pixel.a = 1.0f;
         
            assert( sample.pixelIndex[jj] != (uint32) -1 );
            CompositePixel( &ioPixels[sample.pixelIndex[jj]],
                           pixel,
                           sample.weight[jj] );

         }
      }
   }

   if( inShouldRelease )
   {
      FreeAligned( (void*) inSamples );
      FreeAligned( (void*) inRays );
      FreeAligned( (void*) inHits );
   }
}

/*
 * IgnoreMissesShaderCPU::IgnoreMissesShaderCPU --
 *
 *      Create a "shader" that partitions rays
 *      between hits and misses, and then passes
 *      each partition on to an appropriate
 *      shader.
 *
 * Results:
 * 	none.
 */

IgnoreMissesShaderCPU::IgnoreMissesShaderCPU(
   IStandardShaderCPU* inHitShader,
   IStandardShaderCPU* inMissShader )
{
   _hitShader = inHitShader;
   _missShader = inMissShader;
}

/*
 * IgnoreMissesShaderCPU::Shade --
 *
 *      Partition rays into hits and misses,
 *      and then shade each accordingly...
 *
 * Results:
 *      void, but 'displays' the results.
 */

void IgnoreMissesShaderCPU::Shade(
   uint32 inCount,
   const SampleCPU* inSamples,
   const RayCPU* inRays,
   const HitCPU* inHits,
   PixelCPU* ioPixels,
   bool inShouldRelease )
{
   uint32 hitCount = 0;
   uint32 missCount = 0;

   assert( inCount % BUNDLE_SIZE == 0 );
   
   uint32 bundleCount = inCount / BUNDLE_SIZE;

   // we scan once to count up hits/misses
   for( uint32 ii = 0; ii < bundleCount; ii++ )
   {
      for( uint32 jj = 0; jj < BUNDLE_SIZE; jj++ )
      {
         if( inHits[ii].triNum[jj] >= 0 )
            hitCount++;
         else
            missCount++;
      }
   }
   assert( (hitCount + missCount) == inCount );

   if( missCount == 0 )
   {
      _hitShader->Shade( inCount,
         inSamples, inRays, inHits,
         ioPixels, inShouldRelease );
      return;
   }
   else if( hitCount == 0 )
   {
      _missShader->Shade( inCount,
         inSamples, inRays, inHits,
         ioPixels, inShouldRelease );
      return;
   }
  
   uint32 hitBatchGranularity = _hitShader->GetBatchGranularity();
   uint32 missBatchGranularity = _missShader->GetBatchGranularity();
   
   uint32 hitBundleCount =
      roundUp( hitCount, hitBatchGranularity*BUNDLE_SIZE ) / BUNDLE_SIZE;
   uint32 missBundleCount =
      roundUp( missCount, missBatchGranularity*BUNDLE_SIZE ) / BUNDLE_SIZE;

   uint32 alignment = 16;
   SampleCPU* hitSamples = (SampleCPU*) AllocateAligned( hitBundleCount*sizeof(SampleCPU), alignment );
   memset( hitSamples, 0xFF, hitBundleCount*sizeof(SampleCPU) );
   SampleCPU* missSamples = (SampleCPU*) AllocateAligned( missBundleCount*sizeof(SampleCPU), alignment );
   memset( missSamples, 0xFF, missBundleCount*sizeof(SampleCPU) );
   
   RayCPU* hitRays = (RayCPU*) AllocateAlignedClear( hitBundleCount*sizeof(RayCPU), alignment );
   RayCPU* missRays = (RayCPU*) AllocateAlignedClear( missBundleCount*sizeof(RayCPU), alignment );
   
   HitCPU* hitHits = (HitCPU*) AllocateAligned( hitBundleCount*sizeof(HitCPU), alignment );
   memset( hitHits, 0xFF, hitBundleCount*sizeof(HitCPU) );
   HitCPU* missHits = (HitCPU*) AllocateAligned( missBundleCount*sizeof(HitCPU), alignment );
   memset( missHits, 0xFF, missBundleCount*sizeof(HitCPU) );
   
   // and scan again to collect results
   hitCount = missCount = 0;
   for( uint32 ii = 0; ii < bundleCount; ii++ )
   {
      for( uint32 jj = 0; jj < BUNDLE_SIZE; jj++ )
      {
         bool wasHit = inHits[ii].triNum[jj] >= 0;
         uint32& count = wasHit ? hitCount : missCount;
         SampleCPU*& samples = wasHit ? hitSamples : missSamples;
         RayCPU*& rays = wasHit ? hitRays : missRays;
         HitCPU*& hits = wasHit ? hitHits : missHits;

         uint32 b = count / BUNDLE_SIZE;
         uint32 r = count % BUNDLE_SIZE;

         samples[b].pixelIndex[r] = inSamples[ii].pixelIndex[jj];
         samples[b].recursionDepth[r] = inSamples[ii].recursionDepth[jj];
         samples[b].weight[r] = inSamples[ii].weight[jj];

         for( uint32 kk = 0; kk < 3; kk++ )
         {
            rays[b].o.v[BUNDLE_SIZE*kk + r] = inRays[ii].o.v[BUNDLE_SIZE*kk + jj];
            rays[b].d.v[BUNDLE_SIZE*kk + r] = inRays[ii].d.v[BUNDLE_SIZE*kk + jj];
         }

         hits[b].tHit[r] = inHits[ii].tHit[jj];
         hits[b].uu[r] = inHits[ii].uu[jj];
         hits[b].vv[r] = inHits[ii].vv[jj];
         hits[b].triNum[r] = inHits[ii].triNum[jj];

         count++;
      }
   }
   assert( (hitCount + missCount) == inCount );

   if( inShouldRelease )
   {
      FreeAligned( (void*) inSamples );
      FreeAligned( (void*) inRays );
      FreeAligned( (void*) inHits );
   }

   _hitShader->Shade( hitBundleCount*BUNDLE_SIZE,
                      hitSamples, hitRays, hitHits,
                      ioPixels, true );
   _missShader->Shade( missBundleCount*BUNDLE_SIZE,
                       missSamples, missRays, missHits,
                       ioPixels, true );
}

/*
 * SimpleShaderCPU::Shade --
 *
 *      Basic material shader.
 *
 * Results:
 *      void, but 'displays' the results.
 */

void
SimpleShaderCPU::Shade(
   uint32 inCount,
   const SampleCPU* inSamples,
   const RayCPU* inRays,
   const HitCPU* inHits,
   PixelCPU* ioPixels,
   bool inShouldRelease )
{
   int rayCount = inCount;
   const RayCPU* rays = inRays;
   const HitCPU* hits = inHits;

   assert(rayCount % BUNDLE_SIZE == 0);
   for (int ii = 0; ii < rayCount; ii += BUNDLE_SIZE) {
      __m128 diffuse[3], normal[3], pHit[3], rgb[3];
      int packNum = ii / BUNDLE_SIZE;
      int triNum[BUNDLE_SIZE];
      uint32 jj;
      bool anyLive;

      /*
       * XXX Could do this with SSE Integer intrinsics.
       * Claim any rays that missed hit triangle 0 so we can unconditionally
       * SIMD shade without worrying about looking up data for bogus triangles.
       */
      for (anyLive = false, jj = 0; jj < BUNDLE_SIZE; jj++) {
         triNum[jj] = hits[packNum].triNum[jj] >= 0 ? hits[packNum].triNum[jj] : 0;
         anyLive = anyLive | (hits[packNum].triNum[jj] >= 0);

#if 0
         if (triNum[jj] > (int) _scene->nTris()) {
            PRINT(("Found a bogus triangle: %d\n", triNum[jj]));
         }
#endif
      }

      if (!anyLive) {
         continue;
      }

      const __m128 rayOx = _mm_load_ps(&rays[packNum].o.x0);
      const __m128 rayOy = _mm_load_ps(&rays[packNum].o.y0);
      const __m128 rayOz = _mm_load_ps(&rays[packNum].o.z0);
      const __m128 rayDx = _mm_load_ps(&rays[packNum].d.x0);
      const __m128 rayDy = _mm_load_ps(&rays[packNum].d.y0);
      const __m128 rayDz = _mm_load_ps(&rays[packNum].d.z0);

      const __m128 uu = _mm_load_ps(hits[packNum].uu);
      const __m128 vv = _mm_load_ps(hits[packNum].vv);
      const __m128 one = _mm_set1_ps(1.0f);
      const __m128 tHit = _mm_load_ps(hits[packNum].tHit);
      const __m128 ww = _mm_sub_ps(one, _mm_add_ps(uu, vv));

      /*
       * Compute the hitpoint.  Could also interpolate the vertices
       * using the barycentric coordinates, but that's more work.
       */

      pHit[0] = _mm_add_ps(rayOx, _mm_mul_ps(rayDx, tHit));
      pHit[1] = _mm_add_ps(rayOy, _mm_mul_ps(rayDy, tHit));
      pHit[2] = _mm_add_ps(rayOz, _mm_mul_ps(rayDz, tHit));

      /*
       * Interpolate the diffuse colour
       */

      for (jj = 0; jj < 3; jj++) {
         const __m128 c0 = _mm_set_ps(_scene->colours(0)[triNum[3]].v[jj],
                                      _scene->colours(0)[triNum[2]].v[jj],
                                      _scene->colours(0)[triNum[1]].v[jj],
                                      _scene->colours(0)[triNum[0]].v[jj]);
         const __m128 c1 = _mm_set_ps(_scene->colours(1)[triNum[3]].v[jj],
                                      _scene->colours(1)[triNum[2]].v[jj],
                                      _scene->colours(1)[triNum[1]].v[jj],
                                      _scene->colours(1)[triNum[0]].v[jj]);
         const __m128 c2 = _mm_set_ps(_scene->colours(2)[triNum[3]].v[jj],
                                      _scene->colours(2)[triNum[2]].v[jj],
                                      _scene->colours(2)[triNum[1]].v[jj],
                                      _scene->colours(2)[triNum[0]].v[jj]);

         diffuse[jj] = InterpolateBary(c0, c1, c2, ww, uu, vv);
      }

      /*
       * Interpolate the normal and then renormalize
       */

      for (jj = 0; jj < 3; jj++) {
         const __m128 n0 = _mm_set_ps(_scene->normals(0)[triNum[3]].v[jj],
                                      _scene->normals(0)[triNum[2]].v[jj],
                                      _scene->normals(0)[triNum[1]].v[jj],
                                      _scene->normals(0)[triNum[0]].v[jj]);
         const __m128 n1 = _mm_set_ps(_scene->normals(1)[triNum[3]].v[jj],
                                      _scene->normals(1)[triNum[2]].v[jj],
                                      _scene->normals(1)[triNum[1]].v[jj],
                                      _scene->normals(1)[triNum[0]].v[jj]);
         const __m128 n2 = _mm_set_ps(_scene->normals(2)[triNum[3]].v[jj],
                                      _scene->normals(2)[triNum[2]].v[jj],
                                      _scene->normals(2)[triNum[1]].v[jj],
                                      _scene->normals(2)[triNum[0]].v[jj]);

         normal[jj] = InterpolateBary(n0, n1, n2, ww, uu, vv);
      }
      const __m128 invLength = _mm_rsqrt_ps(_MM_DOT_PS(normal, normal));
      normal[0] = _mm_mul_ps(normal[0], invLength);
      normal[1] = _mm_mul_ps(normal[1], invLength);
      normal[2] = _mm_mul_ps(normal[2], invLength);


      rgb[0] = rgb[1] = rgb[2] = _mm_setzero_ps();
      for (jj = 0; jj < _scene->numLights(); jj++) {
         ShadeLocalLight(pHit, normal, diffuse, _scene->pointLight(jj), _cam, rgb);
      }


      ALIGN16(float rArray[4]); ALIGN16(float gArray[4]); ALIGN16(float bArray[4]);
      _mm_store_ps(rArray, rgb[0]);
      _mm_store_ps(gArray, rgb[1]);
      _mm_store_ps(bArray, rgb[2]);

      PixelCPU pixel = {0.75f, 0, 0.15f, 1.0f};
      for (jj = 0; jj < BUNDLE_SIZE; jj++) {
         if (hits[packNum].triNum[jj] >= 0) {
            pixel.r = rArray[jj];
            pixel.g = gArray[jj];
            pixel.b = bArray[jj];

            assert( inSamples[packNum].pixelIndex[jj] != (uint32) -1 );
            CompositePixel( &ioPixels[ inSamples[packNum].pixelIndex[jj] ],
                            pixel,
                            inSamples[packNum].weight[jj]);
         }
      }
   }
   if( inShouldRelease )
   {
      FreeAligned( (void*) inSamples );
      FreeAligned( (void*) inRays );
      FreeAligned( (void*) inHits );
   }
}


/*
 * ShadowShaderCallback --
 *
 *      A wrapper object to allow the callback-oriented
 *      style of tracing to work with the shadow shader.
 *
 */

class ShadowShaderCallbackCPU : public IHitCallbackCPU
{
public:
  const Scene *scene;
  const RayCPU *eyeRays;
  const HitCPU *eyeHits;
  const SampleCPU *eyeSamples;
  LightInfo light;
  const __m128 *lightDist;
  const uint32 *mapShadowBundleToEyeBundle;
  PixelCPU* pixelData;

  /*
   * Call --
   *
   *      Helper routine that computes the contribution of the given point
   *      light to given hit.  Currently it only does simple diffuse and
   *      shadow shading.
   *
   * Results:
   *      void, but *pixelData[] is filled in.
   */
  void Call( uint32 inCount,
             const RayCPU* inRays,
             const HitCPU* inHits)
  {
    const __m128 lightAtten = _mm_set1_ps(light.distAtten);
    const __m128 attenFactor = _mm_rcp_ps(_mm_mul_ps(lightAtten, lightAtten));
    const __m128 lightDiffuse[3] = {
      _mm_set1_ps(light.diffIntensity.x),
      _mm_set1_ps(light.diffIntensity.y),
      _mm_set1_ps(light.diffIntensity.z),
    };

    assert( inCount % BUNDLE_SIZE == 0 );
    uint32 numBundles = inCount / BUNDLE_SIZE;

   for (uint32 ii = 0; ii < numBundles; ii++)
   {
      __m128 diffuse[3], normal[3], rgb[3];
      int triNum[BUNDLE_SIZE];
      uint32 jj;
      bool anyLive;

      uint32 eyeBundle = mapShadowBundleToEyeBundle[ii];
      if( eyeBundle == (uint32)-1 )
         continue;

      /*
       * XXX Could do this with SSE Integer intrinsics.
       * Claim any rays that missed hit triangle 0 so we can unconditionally
       * SIMD shade without worrying about looking up data for bogus triangles.
       */
      for (anyLive = false, jj = 0; jj < BUNDLE_SIZE; jj++) {
         triNum[jj] = eyeHits[eyeBundle].triNum[jj];
         anyLive = anyLive | (triNum[jj] >= 0);
         if( triNum[jj] < 0 )
            triNum[jj] = 0;
      }

      if (!anyLive) {
         continue;
      }

      const __m128 uu = _mm_load_ps(eyeHits[eyeBundle].uu);
      const __m128 vv = _mm_load_ps(eyeHits[eyeBundle].vv);
      const __m128 one = _mm_set1_ps(1.0f);
      const __m128 ww = _mm_sub_ps(one, _mm_add_ps(uu, vv));

      /*
       * Interpolate the diffuse colour
       */

      for (jj = 0; jj < 3; jj++) {
         const __m128 c0 = _mm_set_ps(scene->colours(0)[triNum[3]].v[jj],
                                      scene->colours(0)[triNum[2]].v[jj],
                                      scene->colours(0)[triNum[1]].v[jj],
                                      scene->colours(0)[triNum[0]].v[jj]);
         const __m128 c1 = _mm_set_ps(scene->colours(1)[triNum[3]].v[jj],
                                      scene->colours(1)[triNum[2]].v[jj],
                                      scene->colours(1)[triNum[1]].v[jj],
                                      scene->colours(1)[triNum[0]].v[jj]);
         const __m128 c2 = _mm_set_ps(scene->colours(2)[triNum[3]].v[jj],
                                      scene->colours(2)[triNum[2]].v[jj],
                                      scene->colours(2)[triNum[1]].v[jj],
                                      scene->colours(2)[triNum[0]].v[jj]);

         diffuse[jj] = InterpolateBary(c0, c1, c2, ww, uu, vv);
      }

      /*
       * Interpolate the normal and then renormalize
       */

      for (jj = 0; jj < 3; jj++) {
         const __m128 n0 = _mm_set_ps(scene->normals(0)[triNum[3]].v[jj],
                                      scene->normals(0)[triNum[2]].v[jj],
                                      scene->normals(0)[triNum[1]].v[jj],
                                      scene->normals(0)[triNum[0]].v[jj]);
         const __m128 n1 = _mm_set_ps(scene->normals(1)[triNum[3]].v[jj],
                                      scene->normals(1)[triNum[2]].v[jj],
                                      scene->normals(1)[triNum[1]].v[jj],
                                      scene->normals(1)[triNum[0]].v[jj]);
         const __m128 n2 = _mm_set_ps(scene->normals(2)[triNum[3]].v[jj],
                                      scene->normals(2)[triNum[2]].v[jj],
                                      scene->normals(2)[triNum[1]].v[jj],
                                      scene->normals(2)[triNum[0]].v[jj]);

         normal[jj] = InterpolateBary(n0, n1, n2, ww, uu, vv);
      }
      const __m128 invLength = _mm_rsqrt_ps(_MM_DOT_PS(normal, normal));
      normal[0] = _mm_mul_ps(normal[0], invLength);
      normal[1] = _mm_mul_ps(normal[1], invLength);
      normal[2] = _mm_mul_ps(normal[2], invLength);

      // Compute N dot L
      const __m128 attenuation = _mm_max_ps(_mm_setzero_ps(),
                                            _mm_sub_ps(_mm_set1_ps(1.0f),
                                                       _mm_mul_ps(lightDist[ii], attenFactor)));
      __m128 shadowD[3] = {
        _mm_load_ps(&inRays[ii].d.x0),
        _mm_load_ps(&inRays[ii].d.y0),
        _mm_load_ps(&inRays[ii].d.z0),
      };

      __m128 NdotL = _MM_DOT_PS(normal, shadowD);  // shadowD == LightD
      NdotL = _mm_max_ps(_mm_setzero_ps(), NdotL);
      NdotL = _mm_mul_ps(NdotL, attenuation);

      // Compute shadow factor
      const __m128 tHitShadow = _mm_load_ps(inHits[ii].tHit); 
      const __m128 shadowVec[3] = {
        _mm_mul_ps(shadowD[0], tHitShadow), 
        _mm_mul_ps(shadowD[1], tHitShadow), 
        _mm_mul_ps(shadowD[2], tHitShadow),
      };
      const __m128 cmpDir = _mm_cmplt_ps(tHitShadow, _mm_set1_ps(0.0f));
      const __m128 shadowDist = _MM_DOT_PS(shadowVec, shadowVec);
      const __m128 cmpDist = _mm_cmplt_ps(lightDist[ii], shadowDist);
      const __m128 shadowFactor = _mm_or_ps(cmpDir, cmpDist);

      // Computer color
      rgb[0] = rgb[1] = rgb[2] = _mm_setzero_ps();

      for (jj = 0; jj < 3; jj++) {
        rgb[jj] = _mm_mul_ps(_mm_mul_ps(diffuse[jj], lightDiffuse[jj]),
                             _mm_and_ps(shadowFactor, NdotL));
      }

      ALIGN16(float rArray[4]); ALIGN16(float gArray[4]); ALIGN16(float bArray[4]);
      _mm_store_ps(rArray, rgb[0]);
      _mm_store_ps(gArray, rgb[1]);
      _mm_store_ps(bArray, rgb[2]);

      PixelCPU pixel = {0.75f, 0, 0.15f, 1.0f};
      for (jj = 0; jj < BUNDLE_SIZE; jj++) {
         if (eyeHits[eyeBundle].triNum[jj] >= 0) {
            pixel.r = rArray[jj];
            pixel.g = gArray[jj];
            pixel.b = bArray[jj];

            assert( eyeSamples[eyeBundle].pixelIndex[jj] != (uint32) -1 );
            CompositePixel( &pixelData[ eyeSamples[eyeBundle].pixelIndex[jj] ],
                            pixel, eyeSamples[eyeBundle].weight[jj] );
         }
      }
    }
  }
};


/*
 * ShadowShaderCPU::Shade --
 *
 *      Shadow shader.
 *
 * Results:
 *      void, but 'displays' the results.
 */

void
ShadowShaderCPU::Shade(
   uint32 inCount,
   const SampleCPU* inSamples,
   const RayCPU* inRays,
   const HitCPU* inHits,
   PixelCPU* ioPixels,
   bool inShouldRelease )
{
  int numRays = inCount;
  const RayCPU* rays = inRays;
  const HitCPU* hits = inHits;
  
  assert(numRays % BUNDLE_SIZE == 0);
  int numBundles = numRays / BUNDLE_SIZE;
  //  PixelCPU* pixelData = new PixelCPU[ numRays ];
  PixelCPU* pixelData = ioPixels;

  // create an object for the shadow ray case to use when "shading"
  // its hits.
  ShadowShaderCallbackCPU callback;
  callback.scene = _scene;
  callback.eyeSamples = inSamples;
  callback.eyeRays = rays;
  callback.eyeHits = hits;
  callback.pixelData = pixelData;

  /* 16 byte aligned for SSE instructions */
  uint32 batchGranularity = _intersector->GetBatchGranularity();
  uint32 maxShadowBundles = roundUp( numBundles, batchGranularity );
  
  /*
   * Generate Shadow Rays
   */
  for (uint32 ll = 0; ll < _scene->numLights(); ll++)
  {
    LightInfo light = _scene->pointLight(ll);
    callback.light = light;

    // 16 byte aligned for SSE instructions
    uint32 *mapShadowBundleToEyeBundle = (uint32 *) AllocateAligned(
      maxShadowBundles * sizeof(uint32), 16);
    memset( mapShadowBundleToEyeBundle, 0xFF,
            maxShadowBundles * sizeof(uint32) );
    callback.mapShadowBundleToEyeBundle = mapShadowBundleToEyeBundle;

    RayCPU *shadowRays =
       (RayCPU *) AllocateAlignedClear(maxShadowBundles * sizeof(RayCPU), 16);
    uint32 shadowBundleCount = 0;

    // To reuse shadowDist as lightDist
    __m128 *shadowDist = (__m128 *) AllocateAligned(
      sizeof(__m128) * maxShadowBundles, 16);
    callback.lightDist = shadowDist;

    /*
     * XXX This should all be cached in the lights and updated per frame,
     * not computed repeatedly here and in the Brook shading code.
     */
    Vec3f lightPosV =
      _cam->getSceneTransformation().transformPoint(light.position);
    const __m128 lightPos[3] = {
      _mm_set1_ps(lightPosV.x), _mm_set1_ps(lightPosV.y), _mm_set1_ps(lightPosV.z),
    };

    /*
     * Below here is the code that's actually dependent on the hit.
     */
    for (int ii = 0; ii < numBundles; ii++)
    {
       bool anyLive;
       uint32 jj;
       for (anyLive = false, jj = 0; jj < BUNDLE_SIZE; jj++) {
          anyLive = anyLive | (inHits[ii].triNum[jj] >= 0);
       }
       
       if (!anyLive) {
          continue;
       }

      // Prepare for SSE instructions
      const __m128 rayOx = _mm_load_ps(&rays[ii].o.x0);
      const __m128 rayOy = _mm_load_ps(&rays[ii].o.y0);
      const __m128 rayOz = _mm_load_ps(&rays[ii].o.z0);
      const __m128 rayDx = _mm_load_ps(&rays[ii].d.x0);
      const __m128 rayDy = _mm_load_ps(&rays[ii].d.y0);
      const __m128 rayDz = _mm_load_ps(&rays[ii].d.z0);
      const __m128 tHit = _mm_load_ps(hits[ii].tHit);

      // Compute the hitpoint
      const __m128 pHit[3] = { 
        _mm_add_ps(rayOx, _mm_mul_ps(rayDx, tHit)),
        _mm_add_ps(rayOy, _mm_mul_ps(rayDy, tHit)),
        _mm_add_ps(rayOz, _mm_mul_ps(rayDz, tHit)),
      };

      // Compute the shadow ray direction vector
      __m128 shadowD[3] = {
        _mm_sub_ps(lightPos[0], pHit[0]),
        _mm_sub_ps(lightPos[1], pHit[1]),
        _mm_sub_ps(lightPos[2], pHit[2]),
      };

      // Normalize shadowRayD
      __m128 tempShadowDist = _MM_DOT_PS(shadowD, shadowD);
      const __m128 invLength = _mm_rsqrt_ps(tempShadowDist);
      shadowD[0] = _mm_mul_ps(shadowD[0], invLength);
      shadowD[1] = _mm_mul_ps(shadowD[1], invLength);
      shadowD[2] = _mm_mul_ps(shadowD[2], invLength);

      // Displace shadow ray origin to avoid false self-intersections
      static const float kRayEpsilon = 0.0f;
      const __m128 shadowO[3] = {
        _mm_add_ps(pHit[0], _mm_mul_ps(_mm_set1_ps(kRayEpsilon), shadowD[0])),
        _mm_add_ps(pHit[1], _mm_mul_ps(_mm_set1_ps(kRayEpsilon), shadowD[1])),
        _mm_add_ps(pHit[2], _mm_mul_ps(_mm_set1_ps(kRayEpsilon), shadowD[2])),
      };


      // only place those components that are needed...

      /* Put rays back into F3Packet array for Intersect routine */
      ALIGN16(F3Packet origin);
      ALIGN16(F3Packet direction);
      _mm_store_ps(&origin.x0, shadowO[0]);
      _mm_store_ps(&origin.y0, shadowO[1]);
      _mm_store_ps(&origin.z0, shadowO[2]);
      _mm_store_ps(&direction.x0, shadowD[0]);
      _mm_store_ps(&direction.y0, shadowD[1]);
      _mm_store_ps(&direction.z0, shadowD[2]);
    

      for( uint32 jj = 0; jj < BUNDLE_SIZE; jj++ )
      {
         if( inHits[ii].triNum[jj] < 0 )
         {
            for( uint32 kk = 0; kk < 3; kk++ )
            {
               origin.v[kk*BUNDLE_SIZE + jj] = FLT_MAX;
               direction.v[kk*BUNDLE_SIZE + jj] = 1.0f;
            }
         }
      }

      shadowRays[shadowBundleCount].o = origin;
      shadowRays[shadowBundleCount].d = direction;
      shadowDist[shadowBundleCount] = tempShadowDist;
      mapShadowBundleToEyeBundle[shadowBundleCount] = ii;
      shadowBundleCount++;
    }

    if( shadowBundleCount != 0 )
    {
       uint32 paddedShadowRayCount =
          roundUp( shadowBundleCount*BUNDLE_SIZE, batchGranularity );
       assert( paddedShadowRayCount <= maxShadowBundles*BUNDLE_SIZE );

       uint32 ii = shadowBundleCount*BUNDLE_SIZE;
       for(; ii < paddedShadowRayCount; ii++ )
       {
          uint32 b = ii / BUNDLE_SIZE;
          uint32 r = ii % BUNDLE_SIZE;
        
          for( uint32 kk = 0; kk < 3; kk++ )
          {
             shadowRays[b].o.v[kk*BUNDLE_SIZE + r] = FLT_MAX;
             shadowRays[b].d.v[kk*BUNDLE_SIZE + r] = 1.0f;
          }
       }
     
       PRINT(("rayType:shadow.%d %d\n", ll, shadowBundleCount*BUNDLE_SIZE));
       _intersector->IntersectP( paddedShadowRayCount, shadowRays, &callback );
    }

    FreeAligned( mapShadowBundleToEyeBundle );
    FreeAligned( shadowRays );
    FreeAligned( shadowDist );
  }

  if( inShouldRelease )
  {
    FreeAligned( (void*) inSamples );
    FreeAligned( (void*) inRays );
    FreeAligned( (void*) inHits );
  }
}

/*
 * WhittedShaderCPU::Shade --
 *
 *      Whitted shader.
 *
 * Results:
 *      void, but 'displays' the results.
 */

void
WhittedShaderCPU::Shade(
   uint32 inCount,
   const SampleCPU* inSamples,
   const RayCPU* inRays,
   const HitCPU* inHits,
   PixelCPU* ioPixels,
   bool inShouldRelease )
{
  int numRays = inCount;
  const RayCPU* rays = inRays;
  const HitCPU* hits = inHits;
  assert(numRays % BUNDLE_SIZE == 0);
  int numBundles = numRays / BUNDLE_SIZE;
  
  /*
   * Generate Secondary Rays
   */

  /* 16 byte aligned for SSE instructions */
  uint32 batchGranularity = _tracer->GetBatchGranularity();
  uint32 maxSecondaryBundles = roundUp( numBundles, batchGranularity );
  SampleCPU *secondaryRaySamples =
     (SampleCPU *) AllocateAligned(maxSecondaryBundles * sizeof(SampleCPU),
                                   16);
  // XXX: the scalar tracer apparently finds intersections for
  // rays that have 0 direction (probably because of infinties...),
  // so we set these to have maximal recursion depth, as a means
  // to prune them...
  memset( secondaryRaySamples, 0xFF, maxSecondaryBundles * sizeof(SampleCPU) );
  RayCPU *secondaryRays =
     (RayCPU *) AllocateAlignedClear(maxSecondaryBundles * sizeof(RayCPU), 16);
  uint32 secondaryRayCount = 0;
  
  /*
   * Below here is the code that's actually dependent on the hit.
   */
  for (int ii = 0; ii < numBundles; ii++)
  {
    int triNum[BUNDLE_SIZE];
    uint32 jj;
    bool anyLive;

    /*
     * XXX Could do this with SSE Integer intrinsics.
     * Claim any rays that missed hit triangle 0 so we can unconditionally
     * SIMD shade without worrying about looking up data for bogus triangles.
     */
    for (anyLive = false, jj = 0; jj < BUNDLE_SIZE; jj++) {
       triNum[jj] = inHits[ii].triNum[jj] >= 0 ? inHits[ii].triNum[jj] : 0;
       anyLive = anyLive | (inHits[ii].triNum[jj] >= 0);
    }

    if (!anyLive) {
       continue;
    }

    /* Prepare for SSE instructions */
    const __m128 rayO[3] = {
      _mm_load_ps(&rays[ii].o.x0),
      _mm_load_ps(&rays[ii].o.y0),
      _mm_load_ps(&rays[ii].o.z0),
    };
    const __m128 rayD[3] = {
      _mm_load_ps(&rays[ii].d.x0),
      _mm_load_ps(&rays[ii].d.y0),
      _mm_load_ps(&rays[ii].d.z0),
    };

    const __m128 uu = _mm_load_ps(hits[ii].uu);
    const __m128 vv = _mm_load_ps(hits[ii].vv);
    const __m128 one = _mm_set1_ps(1.0f);
    const __m128 ww = _mm_sub_ps(one, _mm_add_ps(uu, vv));
    const __m128 tHit = _mm_load_ps(hits[ii].tHit);

    /* Compute the hitpoint */
    const __m128 pHit[3] = { 
      _mm_add_ps(rayO[0], _mm_mul_ps(rayD[0], tHit)),
      _mm_add_ps(rayO[1], _mm_mul_ps(rayD[1], tHit)),
      _mm_add_ps(rayO[2], _mm_mul_ps(rayD[2], tHit)),
    };

    /*
     * Interpolate the normal and then renormalize
     */
    __m128 normal[3];
    for (jj = 0; jj < 3; jj++) {
      const __m128 n0 = _mm_set_ps(_scene->normals(0)[triNum[3]].v[jj],
                                   _scene->normals(0)[triNum[2]].v[jj],
                                   _scene->normals(0)[triNum[1]].v[jj],
                                   _scene->normals(0)[triNum[0]].v[jj]);
      const __m128 n1 = _mm_set_ps(_scene->normals(1)[triNum[3]].v[jj],
                                   _scene->normals(1)[triNum[2]].v[jj],
                                   _scene->normals(1)[triNum[1]].v[jj],
                                   _scene->normals(1)[triNum[0]].v[jj]);
      const __m128 n2 = _mm_set_ps(_scene->normals(2)[triNum[3]].v[jj],
                                   _scene->normals(2)[triNum[2]].v[jj],
                                   _scene->normals(2)[triNum[1]].v[jj],
                                   _scene->normals(2)[triNum[0]].v[jj]);

      normal[jj] = InterpolateBary(n0, n1, n2, ww, uu, vv);
    }
    __m128 invLength = _mm_rsqrt_ps(_MM_DOT_PS(normal, normal));
    normal[0] = _mm_mul_ps(normal[0], invLength);
    normal[1] = _mm_mul_ps(normal[1], invLength);
    normal[2] = _mm_mul_ps(normal[2], invLength);

    /* Compute the second ray direction vector */
    __m128 secondD[3];
    if(false && _diffuse == 1)
    {
#if 0
      /* Generate random spherical angles */
#if 1
      const float theta[4] = {
        acosf(sqrt((float)(1.0f - drand48()))),
        acosf(sqrt((float)(1.0f - drand48()))),
        acosf(sqrt((float)(1.0f - drand48()))),
        acosf(sqrt((float)(1.0f - drand48())))
      };
#else
      const float theta[4] = {
        (float)(M_PI * drand48()),
        (float)(M_PI * drand48()),
        (float)(M_PI * drand48()),
        (float)(M_PI * drand48())
      };
#endif
      const float phi[4]   = {
        (float)(2.0f * M_PI * drand48()),
        (float)(2.0f * M_PI * drand48()),
        (float)(2.0f * M_PI * drand48()),
        (float)(2.0f * M_PI * drand48())
      };
      /* Set normal vector up as the Z axis of spherical coordinates*/
      __m128 tangent[3], binormal[3];
      CalcTangent(normal, tangent);
      _MM_CROSS_PS(binormal, normal, tangent);
      const __m128 sinThetaCosPhi = _mm_set_ps(sinf(theta[0]) * cosf(phi[0]),
                                               sinf(theta[1]) * cosf(phi[1]),
                                               sinf(theta[2]) * cosf(phi[2]),
                                               sinf(theta[3]) * cosf(phi[3]));
      tangent[0] = _mm_mul_ps(tangent[0], sinThetaCosPhi);
      tangent[1] = _mm_mul_ps(tangent[1], sinThetaCosPhi);
      tangent[2] = _mm_mul_ps(tangent[2], sinThetaCosPhi);
      const __m128 sinThetaSinPhi = _mm_set_ps(sinf(theta[0]) * sinf(phi[0]),
                                               sinf(theta[1]) * sinf(phi[1]),
                                               sinf(theta[2]) * sinf(phi[2]),
                                               sinf(theta[3]) * sinf(phi[3]));
      binormal[0] = _mm_mul_ps(binormal[0], sinThetaSinPhi);
      binormal[1] = _mm_mul_ps(binormal[1], sinThetaSinPhi);
      binormal[2] = _mm_mul_ps(binormal[2], sinThetaSinPhi);
      const __m128 cosTheta = _mm_set_ps(cosf(theta[0]),
                                         cosf(theta[1]),
                                         cosf(theta[2]),
                                         cosf(theta[3]));
      normal[0] = _mm_mul_ps(normal[0], cosTheta);
      normal[1] = _mm_mul_ps(normal[1], cosTheta);
      normal[2] = _mm_mul_ps(normal[2], cosTheta);
      secondD[0] = _mm_add_ps(_mm_add_ps(tangent[0], binormal[0]), normal[0]);
      secondD[1] = _mm_add_ps(_mm_add_ps(tangent[1], binormal[1]), normal[1]);
      secondD[2] = _mm_add_ps(_mm_add_ps(tangent[2], binormal[2]), normal[2]);
#endif
    } else {
      __m128 IdotN = _MM_DOT_PS(rayD, normal);
      IdotN = _mm_mul_ps(_mm_set1_ps(2.0f), IdotN);
      secondD[0] = _mm_sub_ps(rayD[0], _mm_mul_ps(IdotN, normal[0]));
      secondD[1] = _mm_sub_ps(rayD[1], _mm_mul_ps(IdotN, normal[1]));
      secondD[2] = _mm_sub_ps(rayD[2], _mm_mul_ps(IdotN, normal[2]));
    }

    /* Normalize secondRayD */
    const __m128 secondDist = _MM_DOT_PS(secondD, secondD);
    invLength = _mm_rsqrt_ps(secondDist);
    secondD[0] = _mm_mul_ps(secondD[0], invLength);
    secondD[1] = _mm_mul_ps(secondD[1], invLength);
    secondD[2] = _mm_mul_ps(secondD[2], invLength);

    /* Displace second ray origin to avoid false self-intersections */
    static const float kRayEpsilon = 0.0f;
    const __m128 secondO[3] = {
      _mm_add_ps(pHit[0], _mm_mul_ps(_mm_set1_ps(kRayEpsilon), secondD[0])),
      _mm_add_ps(pHit[1], _mm_mul_ps(_mm_set1_ps(kRayEpsilon), secondD[1])),
      _mm_add_ps(pHit[2], _mm_mul_ps(_mm_set1_ps(kRayEpsilon), secondD[2])),
    };

    // put the good rays onto our output buffer for recursion
    
    /* Put rays back into F3Packet array for Intersect routine */
    ALIGN16(F3Packet origin);
    ALIGN16(F3Packet direction);
    _mm_store_ps(&origin.x0, secondO[0]);
    _mm_store_ps(&origin.y0, secondO[1]);
    _mm_store_ps(&origin.z0, secondO[2]);
    _mm_store_ps(&direction.x0, secondD[0]);
    _mm_store_ps(&direction.y0, secondD[1]);
    _mm_store_ps(&direction.z0, secondD[2]);
    
    for( jj = 0; jj < 4; jj++ )
    {
       if( inHits[ii].triNum[jj] < 0
          || inSamples[ii].recursionDepth[jj] >= _maximumDepth )
       {
          continue;
       }
       
       uint32 bundleIndex = secondaryRayCount / BUNDLE_SIZE;
       uint32 bundleOffset = secondaryRayCount % BUNDLE_SIZE;

       secondaryRaySamples[bundleIndex].pixelIndex[bundleOffset] =
          inSamples[ii].pixelIndex[jj];
       secondaryRaySamples[bundleIndex].recursionDepth[bundleOffset] =
          inSamples[ii].recursionDepth[jj] + 1;
       secondaryRaySamples[bundleIndex].weight[jj] =
          inSamples[ii].weight[jj];

       secondaryRaySamples[bundleIndex].weight[bundleOffset].r *= 0.5f;
       secondaryRaySamples[bundleIndex].weight[bundleOffset].g *= 0.5f;
       secondaryRaySamples[bundleIndex].weight[bundleOffset].b *= 0.5f;
       secondaryRaySamples[bundleIndex].weight[bundleOffset].a = 0.0f;
       
       for( uint32 kk = 0; kk < 3; kk++ )
       {
          secondaryRays[bundleIndex].o.v[kk*BUNDLE_SIZE + bundleOffset] =
             origin.v[kk*BUNDLE_SIZE + jj];
          secondaryRays[bundleIndex].d.v[kk*BUNDLE_SIZE + bundleOffset] =
             direction.v[kk*BUNDLE_SIZE + jj];
       }
       
       secondaryRayCount++;
    }
  }

  if( inShouldRelease )
  {
    FreeAligned( (void*) inSamples );
    FreeAligned( (void*) inRays );
    FreeAligned( (void*) inHits );
  }

  if( secondaryRayCount != 0 )
  {
     uint32 paddedSecondaryRayCount =
        roundUp( secondaryRayCount, batchGranularity );
     assert( paddedSecondaryRayCount/BUNDLE_SIZE <= maxSecondaryBundles );

     for( uint32 ii = secondaryRayCount; ii < paddedSecondaryRayCount; ii++ )
     {
       uint32 b = ii / BUNDLE_SIZE;
       uint32 r = ii % BUNDLE_SIZE;
        
       for( uint32 kk = 0; kk < 3; kk++ )
       {
          secondaryRays[b].o.v[kk*BUNDLE_SIZE + r] = FLT_MAX;
          secondaryRays[b].d.v[kk*BUNDLE_SIZE + r] = 1.0f;
       }
     }
     
     PRINT(("rayType:reflection %d\n", secondaryRayCount));
     _tracer->Trace( paddedSecondaryRayCount,
        secondaryRaySamples,
        secondaryRays,
        ioPixels );

  }
}

void
SumShaderCPU::Shade(
   uint32 inCount,
   const SampleCPU* inSamples,
   const RayCPU* inRays,
   const HitCPU* inHits,
   PixelCPU* ioPixels,
   bool inShouldRelease )
{
  _left->Shade( inCount, inSamples, inRays, inHits, ioPixels, false );
  _right->Shade( inCount, inSamples, inRays, inHits, ioPixels, inShouldRelease );
}

static uint32
gcd( uint32 x, uint32 y )
{
   uint32 a = x > y ? x : y;
   uint32 b = x < y ? x : y;

   while( true )
   {
      uint32 c = a % b;
      if( c == 0 ) break;
      a = b;
      b = c;
   }

   return b;
}

static uint32
lcm( uint32 x, uint32 y )
{
   return (x * y) / gcd( x, y );
}

uint32
SumShaderCPU::GetBatchGranularity()
{
   return lcm( _left->GetBatchGranularity(),
               _right->GetBatchGranularity() );
}

