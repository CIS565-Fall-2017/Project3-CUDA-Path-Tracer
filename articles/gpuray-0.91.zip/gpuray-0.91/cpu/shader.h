/*
 * shader.h --
 *
 *      CPU shader implementations
 */

#ifndef __CPU_SHADER_H__
#define __CPU_SHADER_H__

#include "cpuTracer.h"  /* For IHitShaderCPU */

struct PixelCPU;

typedef IPixelDisplayerCPU IPixelCallbackCPU;

class IStandardShaderCPU
{
public:
   virtual void Shade(
         uint32 inCount,
         const SampleCPU* inSamples,
         const RayCPU* inRays,
         const HitCPU* inHits,
         PixelCPU* ioPixels,
         bool inShouldRelease ) = 0;

   virtual uint32 GetBatchGranularity() = 0;
};

class MissShaderCPU : public IStandardShaderCPU
{
public:
   MissShaderCPU() {}

   virtual void Shade(
         uint32 inCount,
         const SampleCPU* inSamples,
         const RayCPU* inRays,
         const HitCPU* inHits,
         PixelCPU* ioPixels,
         bool inShouldRelease );

   virtual uint32 GetBatchGranularity() { return 1; }
};

class DefaultHitShaderCPU : public IStandardShaderCPU
{
public:
   DefaultHitShaderCPU() {}

   virtual void Shade(
         uint32 inCount,
         const SampleCPU* inSamples,
         const RayCPU* inRays,
         const HitCPU* inHits,
         PixelCPU* ioPixels,
         bool inShouldRelease );

   virtual uint32 GetBatchGranularity() { return 1; }
};

class IgnoreMissesShaderCPU : public IStandardShaderCPU
{
public:
   IgnoreMissesShaderCPU(
      IStandardShaderCPU* inHitShader,
      IStandardShaderCPU* inMissShader );

   virtual void Shade(
         uint32 inCount,
         const SampleCPU* inSamples,
         const RayCPU* inRays,
         const HitCPU* inHits,
         PixelCPU* ioPixels,
         bool inShouldRelease );

   virtual uint32 GetBatchGranularity() { return 1; }

private:
   IStandardShaderCPU* _hitShader;
   IStandardShaderCPU* _missShader;
};

class SimpleShaderCPU : public IStandardShaderCPU
{
public:
   SimpleShaderCPU(const Scene *scene, const CameraManager *cam ) {
      _scene = scene;
      _cam = cam;
   }

   virtual void Shade(
         uint32 inCount,
         const SampleCPU* inSamples,
         const RayCPU* inRays,
         const HitCPU* inHits,
         PixelCPU* ioPixels,
         bool inShouldRelease );

   virtual uint32 GetBatchGranularity() { return 1; }

private:
   const Scene *_scene;
   const CameraManager *_cam;
};

class ShadowShaderCPU : public IStandardShaderCPU
{
public:
   ShadowShaderCPU(const Scene *scene, const CameraManager *cam,
                   IBaseRayIntersectorCPU* inIntersector ) {
      _scene = scene;
      _cam = cam;
      _intersector = inIntersector;
   }

   virtual void Shade(
         uint32 inCount,
         const SampleCPU* inSamples,
         const RayCPU* inRays,
         const HitCPU* inHits,
         PixelCPU* ioPixels,
         bool inShouldRelease );

   virtual uint32 GetBatchGranularity() { return 1; }

private:
   const Scene *_scene;
   const CameraManager *_cam;
   IBaseRayIntersectorCPU* _intersector;
};

class WhittedShaderCPU : public IStandardShaderCPU
{
public:
   WhittedShaderCPU(
      const Scene *scene,
      const CameraManager *cam,
      const bool diffuse,
      ITracerCPU* inTracer )
   {
      _scene = scene;
      _cam = cam;
      _diffuse = diffuse;
      _tracer = inTracer;
      _maximumDepth = 2;
   }

   virtual void Shade(
         uint32 inCount,
         const SampleCPU* inSamples,
         const RayCPU* inRays,
         const HitCPU* inHits,
         PixelCPU* ioPixels,
         bool inShouldRelease );

   virtual uint32 GetBatchGranularity() { return 1; }

private:
   const Scene *_scene;
   const CameraManager *_cam;
   bool _diffuse;
   ITracerCPU* _tracer;
   uint32 _maximumDepth;
};

class SumShaderCPU : public IStandardShaderCPU
{
public:
   SumShaderCPU(
      IStandardShaderCPU* inLeft,
      IStandardShaderCPU* inRight )
   {
      _left = inLeft;
      _right = inRight;
   }

   virtual void Shade(
         uint32 inCount,
         const SampleCPU* inSamples,
         const RayCPU* inRays,
         const HitCPU* inHits,
         PixelCPU* ioPixels,
         bool inShouldRelease );

   virtual uint32 GetBatchGranularity();

private:
   IStandardShaderCPU* _left;
   IStandardShaderCPU* _right;
};

#endif
