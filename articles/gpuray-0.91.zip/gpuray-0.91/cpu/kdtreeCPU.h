/*
 * kdtreeCPU.h --
 *
 *      k-D tree / axis-aligned bounding box tree acceleration structure.
 */

#ifndef __KDTREECPU_H__
#define __KDTREECPU_H__

#include <math.h>
#include "simdIntrinsics.h"

#include "../scene.h"
#include "cpuTypes.h"
#include "acceleratorCPU.h"

//#define USE_MAILBOX_TRI
//#define USE_MAILBOX_RAY

#ifdef USE_MAILBOX_RAY
#define MAILBOX_RAY_BITS        2
#define MAILBOX_RAY_SIZE        (1<<MAILBOX_RAY_BITS)
#define MAILBOX_RAY_MASK        (MAILBOX_RAY_SIZE - 1)
#endif

class KDTree;
union KDTreeNode;
struct RaySSE;
struct HitSSE;

struct TriAccel {
   uint32 axis;
   float n_u, n_v, n_d;         // Plane equation constants

   float v0_u, v0_v;            // Projected v0 coordinates
   float e1_nu, e1_nv;          // e1 line equation constants

   float e2_nu, e2_nv;          // e2 line equation constants
   uint32 triNum;
   int pad;
};


class KDTreeAccelCPU : public AcceleratorCPU
{
public:
   KDTreeAccelCPU(const Scene& scene, const Opts& opts);
   virtual ~KDTreeAccelCPU(void);

   void intersect(const RayCPU rays[],
                  uint32 numRays, HitCPU hits[]);
   void intersectP(const RayCPU rays[],
                   uint32 numRays, HitCPU hits[]);
   void intersectPacket(const RayCPU rays[],
                        uint32 numRays, HitCPU hits[]);
   void intersectPacketP(const RayCPU rays[],
                         uint32 numRays, HitCPU hits[]);

   uint32 getBatchGranularity();

   /* XXX: This isn't really a k-d tree specific operation,
    * and should be moved into a more appropriate location
    * eventually. For now it is public so that the SPU
    * accelerator can access it
    */
   static void ComputeTriAccel(uint32 triNum, const F3& v0,
                        const F3& v1, const F3& v2, TriAccel *accel);

protected:
   /*
    * Intersection / Traversal Methods
    */

   void IntersectLeaf(const F3& rayO, const F3& rayD, uint32 triIdx,
                      uint32 numTris, uint32 packOff, HitCPU *hitBest) const;
   void IntersectLeafFast(const F3& rayO, const F3& rayD, uint32 triIdx,
                          uint32 numTris, uint32 packOff,
                          HitCPU *hitBest) const;
   void IntersectLeafFastP(const F3& rayO, const F3& rayD, uint32 triIdx,
                           uint32 numTris, uint32 packOff,
                           HitCPU *hit) const;
   void IntersectLeafSSE(const RaySSE *rays,
                         uint32 triIdx, uint32 numTris, HitSSE *hitBest) const;
   void IntersectLeafSSEFast(const RaySSE *rays,
                             const __m128 activeMask[],
                             uint32 triIdx, uint32 numTris,
                             HitSSE hitBest[]) const;
   void IntersectLeafSSEFastP(const RaySSE *rays,
                              const __m128 activeMask[],
                              uint32 triIdx, uint32 numTris,
                              HitSSE hits[]) const;

   void IntersectRay(const F3Packet& rayOs,
                     const F3Packet& rayDs, HitCPU hits[]);
   void IntersectRayP(const F3Packet& rayOs,
                      const F3Packet& rayDs, HitCPU hits[]);
   void IntersectSSE(const RayCPU inRays[], HitCPU outHits[]);
   void IntersectSSEP(const RayCPU inRays[], HitCPU outHits[]);

   void UpdateCachedTree(void);

   /*
    * Tree State
    */

   KDTree *_tree;
   const KDTreeNode *_nodes;
   TriAccel *_triIndexAccel, *_triAccel;
   uint32 _numTris, _numIndices, _numAllocatedIndices;
   F3 _bboxMin, _bboxMax;

   mutable uint32 _id;
#ifdef USE_MAILBOX_TRI
   mutable uint32 *_mbox;
#endif
#ifdef USE_MAILBOX_RAY
   mutable uint32 _lastTri[MAILBOX_RAY_SIZE];
#endif
};

#endif
