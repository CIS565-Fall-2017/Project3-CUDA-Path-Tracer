/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * cpuDisplay.h --
 *
 *      Helper classes for displaying pixels traced on the CPU.
 */

#ifndef __CPU_CPUDISPLAY_H__
#define __CPU_CPUDISPLAY_H__

#include "../common/commonTypes.h"
#include "cpuTracer.h"

class ppmImage;

/*
 * IPixelDisplayerCPU --
 *
 *      Interface for components that can take an array
 *      of pixels and display it to the user (or otherwise
 *      consume the pixel data).
 *
 */

class IPixelDisplayerCPU
{
public:
   virtual void Display( int inWidth, int inHeight, const PixelCPU* inPixels ) = 0;
};

/*
 * WriteImagePixelDisplayerCPU --
 *
 *      An implementation of IPixelDisplayerCPU that
 *      writes the result pixels out to a memory-resident
 *      image.
 *
 */

class WriteImagePixelDisplayerCPU : public IPixelDisplayerCPU
{
public:
   WriteImagePixelDisplayerCPU(
      ppmImage* inOutputImage );

   void Display( int inWidth, int inHeight, const PixelCPU* inPixels );

private:
   ppmImage* _outputImage;
};
#endif
