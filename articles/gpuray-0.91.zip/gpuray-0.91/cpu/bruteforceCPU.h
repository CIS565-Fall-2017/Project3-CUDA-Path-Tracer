/*
 * bruteforceCPU.h --
 *
 *      The simplest 'acceleration' structure: none.  The bruteforce
 *      approach just intersects every ray with every triangle and finds the
 *      first hit.
 */

#ifndef __BRUTEFORCECPU_H__
#define __BRUTEFORCECPU_H__

#include "../scene.h"
#include "cpuTypes.h"
#include "acceleratorCPU.h"

class BruteForceCPU : public AcceleratorCPU
{
public:
   BruteForceCPU(const Scene& scene) {
      _numTris = scene.nTris();
      _v0 = scene.vertices(0);
      _v1 = scene.vertices(1);
      _v2 = scene.vertices(2);
   }
   virtual ~BruteForceCPU(void) {
      _numTris = 0;
      _v0 = _v1 = _v2 = NULL;
   }

   void intersect(const RayCPU rays[],
                  uint32 numRays, HitCPU hits[]);
   void intersectP(const RayCPU rays[],
                   uint32 numRays, HitCPU hits[]);
   void intersectPacket(const RayCPU rays[],
                        uint32 numRays, HitCPU hits[]);
   void intersectPacketP(const RayCPU rays[],
                        uint32 numRays, HitCPU hits[]);

   uint32 getBatchGranularity() { return BUNDLE_SIZE; }

private:
   void IntersectRay(const RayCPU &ray,
                     HitCPU *hit) const;

   int _numTris;
   const F3 *_v0;
   const F3 *_v1;
   const F3 *_v2;
};

#endif
