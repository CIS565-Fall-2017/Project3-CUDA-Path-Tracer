/*
 * kdtreeSPU.h --
 *
 *      k-D tree / axis-aligned bounding box tree acceleration structure.
 */

#ifndef __CELL_KDTREESPU_H__
#define __CELL_KDTREESPU_H__

#include <math.h>
extern "C" {
#include <libspe.h>
}

#include "../scene.h"
#include "../cpu/cpuTypes.h"
#include "../cpu/acceleratorCPU.h"

union SpuKdTreeNode
{
  struct
  {
    int primitiveCount_tag;
    int firstPrimitiveIndex;
  } leaf;
  struct
  {
     int leftChildIndex_splitAxis;
     float splitValue;
  } split;
};

struct SpuKdTreeTriangle
{
   float v[12];
   float pad[4];
};

class KDTreeSPU : public AcceleratorCPU
{
public:
  KDTreeSPU(const Scene& scene, const Opts& options);
  virtual ~KDTreeSPU(void);

  void intersect(const RayCPU rays[],
                 uint32 numRays, HitCPU hits[]);
  void intersectPacket(const RayCPU rays[],
                       uint32 numRays, HitCPU hits[]);

  void intersectP(const RayCPU rays[],
                  uint32 numRays, HitCPU hits[]);
  void intersectPacketP(const RayCPU rays[],
                        uint32 numRays, HitCPU hits[]);

  uint32 getBatchGranularity();

protected:
  void initializeThreads();
  void finalizeThreads();

  enum { kMaximumThreadCount = 16 };
  enum { kAlignment = 128 };

  // number of SPE threads to launch
  // can range from 1-16 for our dual-processor
  // blades, but will scale best in the 1-8 range
  uint32 _threadCount;
  speid_t _speThreadIDs[kMaximumThreadCount];

  // control for how many times to re-submit the same frame
  // (when testing throughput rather than end-to-end latency)
  uint32 _repeatFrameSubmitCount;

  F3 _bboxMin;
  F3 _bboxMax;
  
  uint32 _nodeCount;
  SpuKdTreeNode* _nodes;

  uint32 _triangleCount;
  uint32* _triangleIDs;
  SpuKdTreeTriangle* _triangleData;
};

#endif
