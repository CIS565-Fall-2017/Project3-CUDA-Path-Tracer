// Copyright (C) 2006 Tim Foley


/*
 * simdIntrinsics.h --
 *
 *      Implementations of various "primitive" operations not included
 *      in the standard SPU instrinsics.
 */

#ifndef __SPU_SIMDINTRINSICS_H__
#define __SPU_SIMDINTRINSICS_H__

/*
 * spu_cmov --
 *
 *      Conditionally return left or right,
 *      based on the bitmask in mask.
 *
 * Returns:
 *      for each component i:
 *         left[i] if mask[i] == 0
 *         right[i] if mask[i] = 0xFFFFFFFF
 *         undefined otherwise
 */

static inline qword
spu_cmov( qword left, qword right,
          vector unsigned int mask )
{
  return (qword) spu_sel( (vector unsigned int) left,
                          (vector unsigned int) right,
                          mask );
}

/*
 * spu_min --
 *
 *      Compute component-wise floating-point minimum.
 *
 * Returns:
 *      for each component i, min(left[i],right[i])
 */

static inline vector float
spu_min( vector float left, vector float right )
{
  return (vector float) spu_cmov( (qword) right,
                                  (qword) left,
                                  spu_cmpgt( right, left ) ); 
}

/*
 * spu_max --
 *
 *      Compute component-wise floating-point maximum.
 *
 * Returns:
 *      for each component i, max(left[i],right[i])
 */

static inline vector float
spu_max( vector float left, vector float right )
{
  return (vector float) spu_cmov( (qword) left,
                                  (qword) right,
                                  spu_cmpgt( right, left ) ); 
}

/*
 * spu_not --
 *
 *      Compute the coponent-wise inverse
 *      of a boolean condition.
 *
 * Returns:
 *      for each component i, x[i] == 0
 */

static inline vector unsigned int
spu_not( vector unsigned int x )
{
  return spu_cmpeq( x, spu_splats( (unsigned int) 0 ) );
}

/*
 * spu_cmpge --
 *
 *      Compare greater-than or equal
 *
 * Returns:
 *      for each component i:
 *         left[i] >= right[i] ? 0xFFFFFFFF : 0
 */

static inline vector unsigned int
spu_cmpge( vector float left, vector float right )
{
  return spu_not( spu_cmpgt( right, left ) );
}

#endif
