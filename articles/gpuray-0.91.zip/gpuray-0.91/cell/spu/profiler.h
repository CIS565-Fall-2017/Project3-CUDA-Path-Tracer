// Copyright (C) 2006 Tim Foley

/*
 * profiler.h
 *      Macros for simple profiling.
 */

#ifndef __SPU_PROFILER_H__
#define __SPU_PROFILER_H__

#if !defined(ENABLE_PROFILER)

#define PROFILE_DEFINE(_name) /* empty */

#define PROFILE_INITIALIZE() /* empty */
#define PROFILE_BEGIN(_name) /* empty */
#define PROFILE_END(_name) /* empty */

#else

#define PROFILE_DEFINE(_name) \
   unsigned long long _name = 0;

#define PROFILE_INITIALIZE() \
   spu_writech( SPU_WrDec, 0xFFFFFFFF );
#define PROFILE_BEGIN(_name) \
   unsigned int start_ ## _name = spu_readch( SPU_RdDec );
#define PROFILE_END(_name) \
   _name += (start_ ## _name) - spu_readch( SPU_RdDec );

#endif

#endif
