// Copyright (C) 2006 Tim Foley

/*
 * log.h --
 *      Logging and related functions..
 */

#ifndef __SPU_LOG_H__
#define __SPU_LOG_H__

#if !defined(ENABLE_LOG)

#define LOG(__args) do {} while(0)
#define LogIntVector( _n, _v ) do {} while(0)
#define LogUIntVector( _n, _v ) do {} while(0)
#define LogFloatVector( _n, _v ) do {} while(0)

#else

#define LOG(__args) printf __args

/*
 * LogIntVector --
 *      Print a 4-wide SIMD vector of integers.
 *
 * Returns:
 *      void.
 */

static inline void
LogIntVector( const char* inName, vector signed int inValue )
{
  LOG(( "%s: <%d %d %d %d>\n",
        inName,
        spu_extract( inValue, 0 ),
        spu_extract( inValue, 1 ),
        spu_extract( inValue, 2 ),
        spu_extract( inValue, 3 ) ));
}

/*
 * LogUIntVector --
 *      Print a 4-wide SIMD vector of unsigned integers.
 *
 * Returns:
 *      void.
 */

static inline void
LogUIntVector( const char* inName, vector unsigned int inValue )
{
  LOG(( "%s: <%d %d %d %d>\n",
        inName,
        spu_extract( inValue, 0 ),
        spu_extract( inValue, 1 ),
        spu_extract( inValue, 2 ),
        spu_extract( inValue, 3 ) ));
}

/*
 * LogFloatVector --
 *      Print a 4-wide SIMD vector of floats.
 *
 * Returns:
 *      void.
 */

static inline void
LogFloatVector( const char* inName, vector float inValue )
{
  LOG(( "%s: <%f %f %f %f>\n",
        inName,
        spu_extract( inValue, 0 ),
        spu_extract( inValue, 1 ),
        spu_extract( inValue, 2 ),
        spu_extract( inValue, 3 ) ));
}

#endif // !defined(ENABLE_LOG)

#endif
