#include <stdio.h>
#include <spu_intrinsics.h>
#include <cbe_mfc.h>
#include <limits.h>
#include <math.h>
#include <assert.h>

#include "../request.h"
#include "simdIntrinsics.h"

#define __builtin_expect(_a,_b) (_a)

//#define DEBUG_TRACE_DMAS
//#define ENABLE_PROFILER
//#define ENABLE_LOG
//#define ENABLE_STATS

#include "profiler.h"
#include "log.h"
#include "stats.h"
#include "dma.h"

//#define ENABLE_NODE_PREFETCH
#define MAXIMUM_PREFETCH_NODE_PAIRS 256
//#define ENABLE_TRIANGLE_PREFETCH
#define MAXIMUM_PREFETCH_TRIANGLES 256

#define CACHE_LINE_QWORD_COUNT 16
#define CACHE_LINE_SIZE (CACHE_LINE_QWORD_COUNT * sizeof(qword))
#define CACHE_ASSOCIATIVITY 4

#ifdef ENABLE_STATS
#define COLLECT_CACHE_STATS
#endif

#define ENABLE_NODE_CACHE
#define NODE_CACHE_SET_COUNT (2048 / CACHE_LINE_QWORD_COUNT)
#define NODE_CACHE_LINE_COUNT (NODE_CACHE_SET_COUNT * CACHE_ASSOCIATIVITY)

#define ENABLE_TRIANGLE_CACHE
#define TRIANGLE_CACHE_SET_COUNT (512 / CACHE_LINE_QWORD_COUNT)
#define TRIANGLE_CACHE_LINE_COUNT (TRIANGLE_CACHE_SET_COUNT * CACHE_ASSOCIATIVITY)

#define RAY_EPSILON 1.0e-2f

#define TAG_GROUP_MEGA_PACKET 4
#define TAG_GROUP_NODE_CACHE 3
#define TAG_GROUP_CACHE 3

STATS_DEFINE( gDivergentPacketCount )
STATS_DEFINE( gExpandedPacketCount )
STATS_DEFINE( gPacketNodeCount )
STATS_DEFINE( gPacketMaxNodeCount )
STATS_DEFINE( gPacketTriangleCount )
STATS_DEFINE( gPacketMaxTriangleCount )
STATS_DEFINE( gBundleTriangleCount )
STATS_DEFINE( gBadPacketCount )
STATS_DEFINE( gMissSceneCount )
STATS_DEFINE( gStackEmptyCount )
STATS_DEFINE( gNormalCount )

PROFILE_DEFINE( gTotalTime )
PROFILE_DEFINE( gTotalTraverseTime )
PROFILE_DEFINE( gTraverseSplitTime )
PROFILE_DEFINE( gSplitGetNodeTime )
PROFILE_DEFINE( gTotalIntersectTime )

volatile RequestContext request __attribute__((aligned(128)));

static inline unsigned int
ReadMessage()
{
  return spu_readch( SPU_RdInMbox );
}

static inline unsigned int
GetMessageTag( unsigned int inMessage )
{
  return inMessage & MESSAGE_TAG_MASK;
}

static inline unsigned int
GetMessagePointer( unsigned int inMessage )
{
  return inMessage & ~MESSAGE_TAG_MASK;
}

static inline unsigned int
GetMessageInt( unsigned int inMessage )
{
  return inMessage >> 4;
}

#if defined(ENABLE_NODE_CACHE) || defined(ENABLE_TRIANGLE_CACHE)

static void
InitializeCache( unsigned int inLineSize,
                 unsigned int inSetCount,
                 const void* inDataArray,
                 vector unsigned int* ioTagArray )
{
  vector unsigned int offsets = (vector unsigned int)(
    0,
    inLineSize,
    2*inLineSize,
    3*inLineSize);
  offsets = spu_add( offsets, spu_splats( (unsigned int) inDataArray ) );

  int i;
  for( i = 0; i < inSetCount; i++ )
  {
    ioTagArray[2*i] = spu_splats( 0xFFFFFFFF );
    ioTagArray[2*i+1] = offsets;

    offsets = spu_add( offsets, (vector unsigned int)spu_splats( inLineSize*4 ) );
  }
}


static inline const void*
LookupCache( unsigned int inOffset,
             unsigned int inCacheSetMask,
             vector unsigned int* inCacheTags,
             unsigned long long inGlobalAddress
#ifdef COLLECT_CACHE_STATS
             ,
             unsigned long* getCount,
             unsigned long* missCount
#endif
             )
{
#ifdef COLLECT_CACHE_STATS
   (*getCount)++;
#endif

#define CACHE_LINE_OFFSET_MASK (CACHE_LINE_SIZE-1)
   unsigned int lineOffset = inOffset & CACHE_LINE_OFFSET_MASK;

#define CACHE_LINE_TAG_MASK (~CACHE_LINE_OFFSET_MASK)
   unsigned int lineBase = inOffset & CACHE_LINE_TAG_MASK;

#define CACHE_SET_FACTOR (CACHE_LINE_SIZE / (2*sizeof(qword)))
   unsigned int setOffset = (inOffset & inCacheSetMask) / CACHE_SET_FACTOR;

   vector unsigned int* tagEntry = (vector unsigned int*)
      (((unsigned int) inCacheTags) + setOffset);

   vector unsigned int tags = tagEntry[0];
   vector unsigned int dataPointers = tagEntry[1];

   vector unsigned int compareTags = spu_cmpeq( tags, spu_splats( lineBase ) );
   unsigned int anyHit = spu_extract( spu_orx( compareTags ), 0 );

   if( __builtin_expect(anyHit != 0, 1) )
   {
      unsigned int dataPointer = spu_extract( spu_orx( spu_and( dataPointers,
         compareTags ) ), 0 );

      return (void*) (dataPointer+lineOffset);
   }

#ifdef COLLECT_CACHE_STATS
   (*missCount)++;
#endif

   unsigned int globalPointer =
      inGlobalAddress+ lineBase;

   unsigned int localPointer = spu_extract( dataPointers, 0 );

   IssueDmaGetAsync( (void*) localPointer,
                     globalPointer,
                     CACHE_LINE_SIZE,
                     TAG_GROUP_CACHE );

   tags = spu_insert( lineBase, tags, 0 );

   // rotate the tag entry so that we replace
   // a different element next time
   tags = spu_rlqwbyte( tags, 4 );
   dataPointers = spu_rlqwbyte( dataPointers, 4 );

   tagEntry[0] = tags;
   tagEntry[1] = dataPointers;

   IssueDmaWait( TAG_GROUP_CACHE );

   return (void*) (localPointer + lineOffset);
}




#endif


#ifdef ENABLE_NODE_PREFETCH
static volatile qword gNodeData[MAXIMUM_PREFETCH_NODE_PAIRS] __attribute__((aligned(128)));

static void
PrefetchNodes()
{
  IssueDmaGetAndWait( (void*) gNodeData,
                       request.inputNodesBase,
                       request.inputNodeCount * sizeof(Node) );
}
#endif

#ifdef ENABLE_NODE_CACHE
qword gNodeCacheData[NODE_CACHE_LINE_COUNT*CACHE_LINE_QWORD_COUNT] __attribute__((aligned(128)));
vector unsigned int gNodeCacheTags[NODE_CACHE_SET_COUNT*2] __attribute((aligned(16)));

static inline void
InitializeNodeCache()
{
   InitializeCache( CACHE_LINE_SIZE,
                    NODE_CACHE_SET_COUNT,
                    gNodeCacheData,
                    gNodeCacheTags );
}

#ifdef COLLECT_CACHE_STATS
unsigned long gNodeCacheGetCount = 0;
unsigned long gNodeCacheMissCount = 0;
#endif
#endif

static inline qword
GetNodePairData( unsigned int inOffset )
{
#ifdef ENABLE_NODE_CACHE

#define NODE_SET_MASK ((NODE_CACHE_SET_COUNT-1) * CACHE_LINE_SIZE)
   const void* cacheData = LookupCache( inOffset,
                                        NODE_SET_MASK,
                                        gNodeCacheTags,
                                        request.inputNodesBase
#ifdef COLLECT_CACHE_STATS
                                        , &gNodeCacheGetCount,
                                        &gNodeCacheMissCount
#endif
                                        );
   return *((qword*) cacheData);

#elif defined( ENABLE_NODE_PREFETCH )

  return gNodeData[ inOffset / sizeof(qword) ];

  //  unsigned int localPointer = ((unsigned int) gNodeData) + inOffset;
  //  return *((qword*) localPointer);

#else

#ifdef DEBUG_TRACE_DMAS
  printf( "NodeDMA %d\n", inIndex );
#endif
  qword result;

  unsigned int nodePointer =
    request.inputNodesBase + (inOffset & ~0xF);

  IssueDmaGetAndWait( (void*) &result,
                      nodePointer,
                      2*sizeof(Node) );

  return result;
#endif
}

#ifdef ENABLE_TRIANGLE_PREFETCH
static volatile Triangle gTriangleData[MAXIMUM_PREFETCH_TRIANGLES] __attribute__((aligned(128)));

static void
PrefetchTriangles()
{
  IssueDmaGetAndWait( (void*) gTriangleData,
                       request.inputTrianglesBase,
                       request.inputTriangleCount * sizeof(Triangle) );
}
#endif

#ifdef ENABLE_TRIANGLE_CACHE
qword gTriangleCacheData[TRIANGLE_CACHE_LINE_COUNT*CACHE_LINE_QWORD_COUNT] __attribute__((aligned(128)));
vector unsigned int gTriangleCacheTags[TRIANGLE_CACHE_SET_COUNT*2] __attribute((aligned(16)));

static inline void
InitializeTriangleCache()
{
   InitializeCache( CACHE_LINE_SIZE,
                    TRIANGLE_CACHE_SET_COUNT,
                    gTriangleCacheData,
                    gTriangleCacheTags );
}

#ifdef COLLECT_CACHE_STATS
unsigned long gTriangleCacheGetCount = 0;
unsigned long gTriangleCacheMissCount = 0;
#endif
#endif

static inline Triangle
GetTriangleData( int inOffset )
{
#ifdef ENABLE_TRIANGLE_CACHE

#define TRIANGLE_SET_MASK ((TRIANGLE_CACHE_SET_COUNT-1) * CACHE_LINE_SIZE)
   const void* cacheData = LookupCache( inOffset,
                                        TRIANGLE_SET_MASK,
                                        gTriangleCacheTags,
                                        request.inputTrianglesBase
#ifdef COLLECT_CACHE_STATS
                                        , &gTriangleCacheGetCount,
                                        &gTriangleCacheMissCount
#endif
                                        );
   return *((Triangle*) cacheData);

#elif defined( ENABLE_TRIANGLE_PREFETCH )

  unsigned char* baseAddress = (unsigned char*) &gTriangleData[0];
  unsigned char* triangleAddress = baseAddress + inOffset;
  return *((Triangle*) triangleAddress);

#else

#ifdef DEBUG_TRACE_DMAS
  printf( "TriangleDMA %d\n", inIndex );
#endif
  Triangle triangle;

  unsigned int trianglePointer =
    request.inputTrianglesBase + inOffset;

  IssueDmaGetAndWait( (void*) &triangle,
                      trianglePointer,
                      sizeof(triangle) );

  return triangle;
#endif
}

static inline void
InitializeHit( HitBundle* ioHitPacket )
{
  int i;
  for( i = 0; i < BUNDLES_PER_PACKET; i++ )
  {
    ioHitPacket[i].triangleIndex = spu_splats( -1 );
    ioHitPacket[i].u = spu_splats( 0.0f );
    ioHitPacket[i].v = spu_splats( 0.0f );
    ioHitPacket[i].time = spu_splats( 10000.0f );
  }
}

static inline vector float
refineReciprocal( vector float input )
{
  vector float estimate = spu_re( input );
  
  estimate = spu_mul( estimate,
                      spu_sub( spu_splats( 2.0f ),
                               spu_mul( estimate, input ) ) );

  return estimate;
}

static void
IntersectTriangle( int inTriangleOffset,
                   vector unsigned int* activeMask,
                   RayBundle* __restrict inRayPacket,
                   HitBundle* __restrict ioHitPacket )
{
  STATS_INC( gPacketTriangleCount );

#ifdef DEBUG_TRACE_INTERSECTION
  printf( "IntersectTriangle(%d)\n", inTriangleIndex );
#endif

  vector float zero = spu_splats( 0.0f );
  vector float tMin = spu_splats( RAY_EPSILON );
  vector float one = spu_splats( 1.0f );

  Triangle triangle = GetTriangleData( inTriangleOffset );

#ifdef USE_TRI_ACCEL
   unsigned int jj;

   const signed int triNum = spu_extract(
      (vector signed int) (qword) triangle.c, 2 );

   static const unsigned int modulo3[] = {0, 1, 2, 0, 1};

   const unsigned int axis = spu_extract(
      (vector unsigned int) (qword) triangle.a, 0 );
   const unsigned int u = modulo3[axis + 1];
   const unsigned int v = modulo3[axis + 2];

   const vector float nu = spu_splats( spu_extract( triangle.a, 1 ) );
   const vector float nv = spu_splats( spu_extract( triangle.a, 2 ) );
   const vector float nd = spu_splats( spu_extract( triangle.a, 3 ) );

   const vector float v0_u = spu_splats( spu_extract( triangle.b, 0 ) );
   const vector float v0_v = spu_splats( spu_extract( triangle.b, 1 ) );
   const vector float e1_nu = spu_splats( spu_extract( triangle.b, 2 ) );
   const vector float e1_nv = spu_splats( spu_extract( triangle.b, 3 ) );

   const vector float e2_nu = spu_splats( spu_extract( triangle.c, 0 ) );
   const vector float e2_nv = spu_splats( spu_extract( triangle.c, 1 ) );

   for( jj = 0; jj < BUNDLES_PER_PACKET; jj++ )
   {
     // all rays in packet vector missed triangle plane
     if( spu_extract( spu_orx(activeMask[jj]), 0 ) == 0 )
     {
       //    printf( "all failed plane test\n" );
       continue;
     }

     STATS_INC( gBundleTriangleCount );

     vector float rayO[3];
     vector float rayD[3];
     vector signed int triIdxBest;
     vector float tBest;
     vector float uBest;
     vector float vBest;

     rayO[0] = inRayPacket[jj].origin.bundle[0];
     rayO[1] = inRayPacket[jj].origin.bundle[1];
     rayO[2] = inRayPacket[jj].origin.bundle[2];

     rayD[0] = inRayPacket[jj].direction.bundle[0];
     rayD[1] = inRayPacket[jj].direction.bundle[1];
     rayD[2] = inRayPacket[jj].direction.bundle[2];

     triIdxBest = ioHitPacket[jj].triangleIndex;
     tBest = ioHitPacket[jj].time;
     uBest = ioHitPacket[jj].u;
     vBest = ioHitPacket[jj].v;

     const vector float d =
       refineReciprocal(spu_add(rayD[axis],
                      spu_add(spu_mul(nu, rayD[u]),
                              spu_mul(nv, rayD[v]))));

     const vector float tHit =
       spu_mul(spu_sub(nd,
                       spu_add(rayO[axis],
                               spu_add(spu_mul(nu, rayO[u]),
                                       spu_mul(nv, rayO[v])))), d);


     const vector unsigned int bestMask =
       spu_and( spu_cmpge(tHit, tMin), spu_cmpgt(tBest, tHit) );

     if( spu_extract( spu_orx(bestMask), 0 ) == 0 )
       continue;

     const vector float hu =
       spu_add(rayO[u],
               spu_sub(spu_mul(tHit, rayD[u]), v0_u));
     const vector float hv =
       spu_add(rayO[v],
               spu_sub(spu_mul(tHit, rayD[v]), v0_v));
     const vector float uu =
       spu_add(spu_mul(hv, e1_nu),
               spu_mul(hu, e1_nv));
     const vector float vv =
       spu_add(spu_mul(hu, e2_nu),
               spu_mul(hv, e2_nv));

     const vector unsigned int hitMask =
       spu_and(bestMask,
               spu_and(spu_cmpge(uu, zero),
               spu_and(spu_cmpge(vv, zero),
                       spu_cmpge(one, spu_add(uu, vv)))));

     if( spu_extract( spu_orx(hitMask), 0 ) == 0 )
       continue;


     tBest = (vector float) spu_cmov( (qword) tBest, (qword) tHit, hitMask );
     uBest = (vector float) spu_cmov( (qword) uBest, (qword) uu, hitMask );
     vBest = (vector float) spu_cmov( (qword) vBest, (qword) vv, hitMask );

     vector signed int triHit = spu_splats( triNum );
     triIdxBest = (vector signed int) spu_cmov( (qword) triIdxBest,
                                                (qword) triHit,
                                                hitMask );

     ioHitPacket[jj].time = tBest;
     ioHitPacket[jj].u = uBest;
     ioHitPacket[jj].v = vBest;
     ioHitPacket[jj].triangleIndex = triIdxBest;
   }
#else
  vector float v0[3];
  vector float e1[3];
  vector float e2[3];
  vector float e2xe1[3];

  vector unsigned char splatWord0 =
    (vector unsigned char)(0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3);
  vector unsigned char splatWord1 =
    (vector unsigned char)(4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7);
  vector unsigned char splatWord2 =
    (vector unsigned char)(8, 9,10,11, 8, 9,10,11, 8, 9,10,11, 8, 9,10,10);
  vector unsigned char splatWord3 =
    (vector unsigned char)(12,13,14,15,12,13,14,15,12,13,14,15,12,13,14,15);

  vector float tmp0 = triangle.a;
  vector float tmp1 = triangle.b;
  vector float tmp2 = triangle.c;

  v0[0] = spu_shuffle( tmp0, tmp0, splatWord0 );
  v0[1] = spu_shuffle( tmp1, tmp1, splatWord0 );
  v0[2] = spu_shuffle( tmp2, tmp2, splatWord0 );

  e1[0] = spu_shuffle( tmp0, tmp0, splatWord1 );
  e1[1] = spu_shuffle( tmp1, tmp1, splatWord1 );
  e1[2] = spu_shuffle( tmp2, tmp2, splatWord1 );

  e2[0] = spu_shuffle( tmp0, tmp0, splatWord2 );
  e2[1] = spu_shuffle( tmp1, tmp1, splatWord2 );
  e2[2] = spu_shuffle( tmp2, tmp2, splatWord2 );

  e2xe1[0] = spu_shuffle( tmp0, tmp0, splatWord3 );
  e2xe1[1] = spu_shuffle( tmp1, tmp1, splatWord3 );
  e2xe1[2] = spu_shuffle( tmp2, tmp2, splatWord3 );

#define SPU_DOT(a, b) \
  spu_add( spu_add( spu_mul( a[0], b[0] ), spu_mul( a[1], b[1] )), \
           spu_mul( a[2], b[2] ) )

  int j;
  for( j = 0; j < BUNDLES_PER_PACKET; j++ )
  {
    // all rays in packet vector missed triangle plane
    if( spu_extract( spu_orx(activeMask[j]), 0 ) == 0 )
    {
      //    printf( "all failed plane test\n" );
      continue;
    }

    STATS_INC( gBundleTriangleCount );


    vector float rayO[3];
    vector float rayD[3];
    vector signed int triIdxBest;
    vector float tBest;
    vector float uBest;
    vector float vBest;

    vector unsigned int bestMask;
    vector unsigned int hitMask;

    vector float txrayD[3];
    vector float tvec[3];
    vector float invDet;
    vector float tHit;
    vector float uu;
    vector float vv;

    rayO[0] = inRayPacket[j].origin.bundle[0];
    rayO[1] = inRayPacket[j].origin.bundle[1];
    rayO[2] = inRayPacket[j].origin.bundle[2];

    rayD[0] = inRayPacket[j].direction.bundle[0];
    rayD[1] = inRayPacket[j].direction.bundle[1];
    rayD[2] = inRayPacket[j].direction.bundle[2];

    triIdxBest = ioHitPacket[j].triangleIndex;
    tBest = ioHitPacket[j].time;
    uBest = ioHitPacket[j].u;
    vBest = ioHitPacket[j].v;

    invDet = spu_re( SPU_DOT(rayD, e2xe1) );
    tvec[0] = spu_sub( v0[0], rayO[0] );
    tvec[1] = spu_sub( v0[1], rayO[1] );
    tvec[2] = spu_sub( v0[2], rayO[2] );
    tHit = spu_mul( SPU_DOT(tvec, e2xe1), invDet );

    bestMask = spu_andc( spu_cmpgt(tBest, tHit),
                         spu_cmpge(tMin, tHit) );

    // all rays in packet vector missed triangle plane
    if( spu_extract( spu_orx(bestMask), 0 ) == 0 )
    {
      //    printf( "all failed plane test\n" );
      continue;
    }

    txrayD[0] = spu_sub( spu_mul(tvec[1], rayD[2]),
                         spu_mul(tvec[2], rayD[1]));
    txrayD[1] = spu_sub( spu_mul(tvec[2], rayD[0]),
                         spu_mul(tvec[0], rayD[2]));
    txrayD[2] = spu_sub( spu_mul(tvec[0], rayD[1]),
                         spu_mul(tvec[1], rayD[0]));

    uu = spu_sub(zero, SPU_DOT(txrayD, e2));
    vv = SPU_DOT(txrayD, e1);
    uu = spu_mul(uu, invDet);
    vv = spu_mul(vv, invDet);

    hitMask = spu_nor(spu_or(spu_cmpgt(zero, uu),
                             spu_cmpgt(zero, vv)),
                      spu_cmpgt(spu_add(uu, vv), one));
    hitMask = spu_and(hitMask, bestMask);

    // all rays in packet vector missed triangle plane
    // or missed barycentric coordinate test
    if( spu_extract( spu_orx(hitMask), 0 ) == 0 )
    {
      //    printf( "all failed barycentric test\n" );
      continue;
    }

    //  printf( "somebody hit triangle %d\n", inTriangleIndex );

    tBest = (vector float) spu_cmov((qword) tBest, (qword) tHit, hitMask);
    uBest = (vector float) spu_cmov((qword) uBest, (qword) uu, hitMask);
    vBest = (vector float) spu_cmov((qword) vBest, (qword) vv, hitMask);
    triIdxBest = (vector signed int) spu_cmov( (qword) triIdxBest,
                                               (qword) spu_splats(inTriangleOffset / sizeof(Triangle)),
                                               hitMask);

    ioHitPacket[j].time = tBest;
    ioHitPacket[j].u = uBest;
    ioHitPacket[j].v = vBest;
    ioHitPacket[j].triangleIndex = triIdxBest;
  }

#endif
}

static inline void
IntersectLeaf( int inFirstTriangleOffset,
               int inPrimitiveCount,
               vector unsigned int* activeMask,
               RayBundle* __restrict inRayPacket,
               HitBundle* __restrict ioHitPacket )
{
  PROFILE_BEGIN( gTotalIntersectTime )

  int i;
  unsigned int triangleOffset = inFirstTriangleOffset;
  for( i = 0; i < inPrimitiveCount; i++ )
  {
    IntersectTriangle( triangleOffset,
                       activeMask,
                       inRayPacket,
                       ioHitPacket );
    triangleOffset += sizeof(Triangle);
  }
  PROFILE_END( gTotalIntersectTime )
}


/*
 * ProcessPacket --
 *
 *      Intersect a packet with the scene. The
 *      packet is assumed to be non-divergent
 *      (all ray directions in one octant), for
 *      the rays where liveMask is enabled.
 *
 * Returns:
 *      void.
 */

static void
ProcessPacket( RayBundle* __restrict inRayPacket,
                 vector float rayO[BUNDLES_PER_PACKET][3],
                 vector float rayD[BUNDLES_PER_PACKET][3],
                 vector float invD[BUNDLES_PER_PACKET][3],
                 vector float* __restrict tMin,
                 vector float* __restrict tMax,
                 vector unsigned int* __restrict liveMask,
                 vector unsigned int* __restrict activeMask,
                 HitBundle* __restrict ioHitPacket,
                 vector unsigned int rotateMaskForAxis )
{
  STATS_INC( gExpandedPacketCount )

  int j;

  vector unsigned int intZero = spu_splats( (unsigned int) 0 );

  int stackIndex = 0;
#define STACK_SIZE 32
  qword nodePairStack[STACK_SIZE];
  vector float tMinStack[BUNDLES_PER_PACKET][STACK_SIZE];
  vector float tMaxStack[BUNDLES_PER_PACKET][STACK_SIZE];

  vector float tSplit[BUNDLES_PER_PACKET];

  qword nodePair = GetNodePairData( 0 );

  STATS_ONLY(
    unsigned int packetNodeCount = 0;
    unsigned int packetTriangleCount = 0;
  )


  while( 1 )
  {
    PROFILE_BEGIN( gTraverseSplitTime )

    while( 1 )
    {
      //printf( "visiting node %d\n", nodeIndex );
      STATS_INC( gPacketNodeCount );
      STATS_ONLY(
         packetNodeCount++;
         if( packetNodeCount > gPacketMaxNodeCount )
           gPacketMaxNodeCount = packetNodeCount;

      )

      unsigned int leftIndex_splitAxis = spu_extract(
        (vector unsigned int) nodePair, 0 );

      unsigned int splitAxis = leftIndex_splitAxis & 0x3;

      if( __builtin_expect( splitAxis == 0x3, 0 ) )
        break;

      float splitValue = spu_extract(
        (vector float) nodePair, 1 );

      // process internal node

      // XXX: we ignore the trailing bits of the value
      // when converting it to a pointer, since
      // they will be ignored by all of our fetch logic...
      // This is risky business.
      unsigned int leftOffset = (unsigned int) leftIndex_splitAxis;
      // leftOffset &= ~0xF

      //LOG(( "split axis=%d left=%d value=%f\n",
      //    splitAxis, leftOffset, splitValue ));

      //      PROFILE_BEGIN( gSplitGetNodeTime )
      nodePair = GetNodePairData( leftOffset );
      //      PROFILE_END( gSplitGetNodeTime )

      unsigned int rotateAmount = spu_extract(
        spu_rlqwbyte( rotateMaskForAxis, splitAxis * 4 ), 0 );

      qword near = spu_rlqwbyte( nodePair, rotateAmount );
      qword far = spu_rlqwbyte( nodePair, rotateAmount ^ 8 );

      vector unsigned int anyNearVector = intZero;
      vector unsigned int anyFarVector = intZero;

      for( j = 0; j < BUNDLES_PER_PACKET; j++ )
      {
        vector unsigned int wantNear;
        vector unsigned int wantFar;

        tSplit[j] = spu_mul(spu_sub(spu_splats(splitValue),
                                    rayO[j][splitAxis]),
                            invD[j][splitAxis]);
        wantFar = spu_andc(activeMask[j],
                              spu_cmpgt(tSplit[j], tMax[j]));
        wantNear = spu_andc(activeMask[j],
                               spu_cmpgt(tMin[j], tSplit[j]));

        anyNearVector = spu_or( anyNearVector, wantNear );
        anyFarVector = spu_or( anyFarVector, wantFar );
      }

      unsigned int anyNear = spu_extract( spu_orx( anyNearVector ), 0 );
      unsigned int anyFar = spu_extract( spu_orx( anyFarVector ), 0 );
      //LOG(("anyNear=%d anyFar=%d\n", anyNear, anyFar));

      vector unsigned int mask = spu_splats( anyNear );
      nodePair = (qword) spu_sel( (vector unsigned int)far,
                                  (vector unsigned int)near,
                                  mask );

      if( __builtin_expect( anyNear & anyFar, 0 ) )
      {
        //LOG(("push\n"));

        // do that stack thing... :)
        for( j = 0; j < BUNDLES_PER_PACKET; j++ )
        {
          tMinStack[j][stackIndex] = spu_max(tSplit[j], tMin[j]);
          tMaxStack[j][stackIndex] = tMax[j];
          tMax[j] = spu_min(tSplit[j], tMax[j]);
          activeMask[j] = spu_and( liveMask[j], spu_cmpge(tMax[j], tMin[j]));
        }
        nodePairStack[stackIndex] = far;
        stackIndex++;
        nodePair = near;
      }
    }

    PROFILE_END( gTraverseSplitTime )

    // process leaf node
    //printf( "leaf\n" );
    unsigned int primitiveCount = spu_extract(
      (vector unsigned int) nodePair, 0 ) >> 2;
    unsigned int firstPrimitiveIndex = spu_extract(
      (vector unsigned int) nodePair, 1 );

    //LOG(( "leaf %d %d\n", firstPrimitiveIndex, primitiveCount ));
    STATS_ONLY(
       packetTriangleCount += primitiveCount;
       if( packetTriangleCount > gPacketMaxTriangleCount )
         gPacketMaxTriangleCount = packetTriangleCount;
    )

    IntersectLeaf( firstPrimitiveIndex, primitiveCount,
                   activeMask, inRayPacket, ioHitPacket );

    unsigned int normal = 0;

    for( j = 0; j < BUNDLES_PER_PACKET; j++ )
    {
      liveMask[j] = spu_and( liveMask[j],
                             spu_cmpgt( ioHitPacket[j].time,
                                        spu_max( tMax[j], tMin[j] ) ) );
      normal |= spu_extract( spu_orx( liveMask[j] ), 0 );
    }

    if( normal == 0 )
    {
      STATS_INC( gNormalCount );
      return;
    }

    int active = 0;

    do
    {
      if( stackIndex == 0 )
      {
        STATS_INC( gStackEmptyCount );
        return;
      }

      stackIndex--;
      nodePair = nodePairStack[stackIndex];

      for( j = 0; j < BUNDLES_PER_PACKET; j++ )
      {
        tMin[j] = tMinStack[j][stackIndex];
        tMax[j] = tMaxStack[j][stackIndex];
        tMax[j] = (vector float) spu_and( liveMask[j],
                                          (vector unsigned int) (qword) tMax[j] );
        activeMask[j] = spu_and( liveMask[j],
                                 spu_cmpge(tMax[j], tMin[j]) );
        active |= spu_extract( spu_orx( activeMask[j] ), 0 );
      }
      //printf( "popped %d\n", nodeIndex );

    } while( active == 0 );
  }
}

/*
 * ProcessDivergentPacket --
 *
 *      Intersect a packet with the scene.
 *      This function handles the case where
 *      the various rays may not reside in
 *      a single octant.
 *
 * Returns:
 *      void.
 */

static inline void
ProcessDivergentPacket( float* __restrict inBoundsMin,
                float* __restrict inBoundsMax,
                RayBundle* __restrict inRayPacket,
                HitBundle* __restrict ioHitPacket )
{
  STATS_INC( gDivergentPacketCount )

  int j, kk;

  vector float rayO[BUNDLES_PER_PACKET][3];
  vector float rayD[BUNDLES_PER_PACKET][3];
  vector float invD[BUNDLES_PER_PACKET][3];

  vector float zero = spu_splats( 0.0f );
  vector unsigned int intZero = spu_splats( (unsigned int) 0 );

  for( j = 0; j < BUNDLES_PER_PACKET; j++ )
  {
    rayO[j][0] = inRayPacket[j].origin.bundle[0];
    rayO[j][1] = inRayPacket[j].origin.bundle[1];
    rayO[j][2] = inRayPacket[j].origin.bundle[2];

    rayD[j][0] = inRayPacket[j].direction.bundle[0];
    rayD[j][1] = inRayPacket[j].direction.bundle[1];
    rayD[j][2] = inRayPacket[j].direction.bundle[2];

    invD[j][0] = spu_re( rayD[j][0] );
    invD[j][1] = spu_re( rayD[j][1] );
    invD[j][2] = spu_re( rayD[j][2] );
  }

  vector float tNear[BUNDLES_PER_PACKET][3];
  vector float tFar[BUNDLES_PER_PACKET][3];
  vector float tMin[BUNDLES_PER_PACKET];
  vector float tMax[BUNDLES_PER_PACKET];
  vector unsigned int liveMask[BUNDLES_PER_PACKET];
  vector unsigned int activeMask[BUNDLES_PER_PACKET];
  unsigned int hitScene = 0;

#define LOOP_UNROLLING

  for( j = 0; j < BUNDLES_PER_PACKET; j++ )
  {
#ifdef LOOP_UNROLLING
      vector float tmp1[3];
      vector float tmp2[3];

      tmp1[0] = spu_mul( spu_sub( spu_splats( inBoundsMin[0] ),
                                  rayO[j][0] ),
                         invD[j][0] );
      tmp1[1] = spu_mul( spu_sub( spu_splats( inBoundsMin[1] ),
                                  rayO[j][1] ),
                         invD[j][1] );
      tmp1[2] = spu_mul( spu_sub( spu_splats( inBoundsMin[2] ),
                                  rayO[j][2] ),
                         invD[j][2] );
      tmp2[0] = spu_mul( spu_sub( spu_splats( inBoundsMax[0] ),
                                  rayO[j][0] ),
                         invD[j][0] );
      tmp2[1] = spu_mul( spu_sub( spu_splats( inBoundsMax[1] ),
                                  rayO[j][1] ),
                         invD[j][1] );
      tmp2[2] = spu_mul( spu_sub( spu_splats( inBoundsMax[2] ),
                                  rayO[j][2] ),
                         invD[j][2] );

      tNear[j][0] = spu_min( tmp1[0], tmp2[0] );
      tNear[j][1] = spu_min( tmp1[1], tmp2[1] );
      tNear[j][2] = spu_min( tmp1[2], tmp2[2] );
      tFar[j][0] = spu_max( tmp1[0], tmp2[0] );
      tFar[j][1] = spu_max( tmp1[1], tmp2[1] );
      tFar[j][2] = spu_max( tmp1[2], tmp2[2] );
#else
    for( i = 0; i < 3; i++ )
    {
      vector float tmp1;
      vector float tmp2;

      tmp1 = spu_mul( spu_sub( spu_splats( inBoundsMin[i] ),
                               rayO[j][i] ),
                      invD[j][i] );
      tmp2 = spu_mul( spu_sub( spu_splats( inBoundsMax[i] ),
                               rayO[j][i] ),
                      invD[j][i] );

      tNear[j][i] = spu_min( tmp1, tmp2 );
      tFar[j][i] = spu_max( tmp1, tmp2 );

      //debugPrintFloatVector( "tNear", tNear[j][i] );
      //debugPrintFloatVector( "tFar", tFar[j][i] );
    }
#endif

    tMin[j] = spu_splats( 0.0f );
    tMin[j] = spu_max(spu_max( tNear[j][0], tNear[j][1]),
                      spu_max( tNear[j][2], tMin[j] ));
    tMax[j] = ioHitPacket[j].time;
    tMax[j] = spu_min(spu_min( tFar[j][0], tFar[j][1]),
                      spu_min( tFar[j][2], tMax[j] ));

    // fudge tmax, because Jeremy does too
    tMax[j] = spu_mul(tMax[j], spu_splats(1.5f));

    //debugPrintFloatVector( "tMin", tMin[j] );
    //debugPrintFloatVector( "tMax", tMax[j] );

    liveMask[j] = activeMask[j] = spu_cmpge( tMax[j], tMin[j] );
    hitScene |=  spu_extract( spu_orx( liveMask[j] ), 0 );
  }

  if( hitScene == 0 )
  {
    STATS_INC( gMissSceneCount );
    return;
  }


  // the 0..2 components of this vector are
  // supposed to be the appropriate byte amount to
  // rotate a node pair by to get it into (near,far)
  // order. If the ray is pointing 'left' along
  // the axis it will be 8, otherwise 0.
  vector unsigned int rotateMaskForAxis = intZero;

  vector unsigned int signMask;
  vector unsigned int bad = intZero;

  vector unsigned int leftMask[3];
  leftMask[0] = leftMask[1] = leftMask[2] = intZero;

  vector unsigned int rightMask[3];
  rightMask[0] = rightMask[1] = rightMask[2] = intZero;

  for( j = 0; j < BUNDLES_PER_PACKET; j++ )
  {
    for( kk = 0; kk < 3; kk++ )
    {
      signMask = spu_cmpgt( zero, invD[j][kk] );
      unsigned int anyLeftward = spu_extract( spu_orx( signMask ), 0 );

      rotateMaskForAxis = spu_or( rotateMaskForAxis,
        spu_insert( anyLeftward, rotateMaskForAxis, kk ) );

      leftMask[kk] = spu_or( leftMask[kk], signMask );
      rightMask[kk] = spu_orc( rightMask[kk], signMask );
    }
  }
  rotateMaskForAxis = spu_and( rotateMaskForAxis, spu_splats(8U) );

  for( j = 0; j < 3; j++ )
  {
    bad = spu_or( bad, spu_and( spu_orx( leftMask[j] ),
                                spu_orx( rightMask[j] ) ) );
  }

  if( __builtin_expect( spu_extract( bad, 0 ), 0xFFFFFF ) != 0 )
  {
    STATS_INC( gBadPacketCount )

    vector float fakeTMin[BUNDLES_PER_PACKET];
    vector float fakeTMax[BUNDLES_PER_PACKET];
    vector unsigned int fakeLiveMask[BUNDLES_PER_PACKET];

    unsigned int ii;
    for( ii = 0; ii < 8; ii++ )
    {
      vector unsigned int anyCorrect = spu_splats( 0U );

      for( j = 0; j < BUNDLES_PER_PACKET; j++ )
      {
        vector unsigned int correctOctant = spu_splats( 0xFFFFFFFF );

        for( kk = 0; kk < 3; kk++ )
        {
          vector unsigned int axisMask =
            spu_splats( ii & (1 << kk) ? 0xFFFFFFFFU : 0U );
          correctOctant =
            spu_and( correctOctant,
                     spu_xor( axisMask,
                              spu_cmpgt( zero, invD[j][kk] ) ) );
        }

        fakeLiveMask[j] = spu_and( liveMask[j], correctOctant );
        activeMask[j] = fakeLiveMask[j];
        fakeTMin[j] = tMin[j];
        fakeTMax[j] = tMax[j];

        anyCorrect = spu_or( anyCorrect, correctOctant );
      }

      if( spu_extract( spu_orx( anyCorrect ), 0 ) != 0 )
      {
        rotateMaskForAxis = (vector unsigned int)(
          (ii & 1) ? 0 : 8,
          (ii & 2) ? 0 : 8,
          (ii & 4) ? 0 : 8,
          0 );

        ProcessPacket( inRayPacket,
                       rayO, rayD, invD,
                       fakeTMin, fakeTMax,
                       fakeLiveMask, activeMask,
                       ioHitPacket,
                       rotateMaskForAxis );
      }
    }
  }
  else
  {
    ProcessPacket( inRayPacket,
                   rayO, rayD, invD,
                   tMin, tMax,
                   liveMask, activeMask,
                   ioHitPacket,
                   rotateMaskForAxis );
  }
}

/*
 * ProcessMegaPacket --
 *
 *      Process a buffer of rays
 *      to produce hits.
 *
 * Returns:
 *      void.
 */

static void
ProcessMegaPacket( RayBundle* __restrict inRays,
                   HitBundle* __restrict outHits,
                   unsigned int inRayBundleCount )
{
  RayBundle* rays = inRays;
  HitBundle* hits = outHits;

  assert( inRayBundleCount % BUNDLES_PER_PACKET == 0 );

  unsigned int packetsRemaining = inRayBundleCount / BUNDLES_PER_PACKET;
  while( packetsRemaining-- )
  {
    InitializeHit( hits );
    PROFILE_BEGIN( gTotalTraverseTime );
    ProcessDivergentPacket( (float* __restrict) request.bboxMin,
                            (float* __restrict) request.bboxMax,
                            rays,
                            hits );
    PROFILE_END( gTotalTraverseTime );

    rays += BUNDLES_PER_PACKET;
    hits += BUNDLES_PER_PACKET;
  }
}

/*
 * ProcessFrame --
 *
 *      Receive data for a single frame
 *      from the PPE until MESSAGE_END_FRAME
 *      is received.
 *      'inMessage' is the first message to
 *      be processed for this frame.
 *
 * Returns:
 *      void.
 */

static void
ProcessFrame( unsigned int inMessage )
{
  // allocate space for double-buffers
  // of messages, input ray packets,
  // and output hit packets
  unsigned int message[2];
  unsigned int messageIndex = 0;

  RayBundle rayBuffer[2][BUNDLES_PER_TRANSFER_BLOCK];
  HitBundle hitBuffer[2][BUNDLES_PER_TRANSFER_BLOCK];
  unsigned int bufferIndex = 0;

  // read our first message, and if its "end frame"
  // then do so
  message[messageIndex] = inMessage;
  if( GetMessageTag(message[messageIndex]) == MESSAGE_PPU_END_FRAME )
    return;

  unsigned int bufferDestinationOffset = 0;
  unsigned int ii = 0;


  // this is the first iteration of the loop
  // where we set things up for the steady-state
  // cast.

  unsigned int blockIndex = GetMessageInt( message[messageIndex] );
  unsigned int nextBufferIndex = bufferIndex;
  unsigned int nextBufferSourceOffset =
    blockIndex * RAY_MESSAGE_BLOCK_SIZE
    + ii * RAY_TRANSFER_BLOCK_SIZE;
  unsigned int nextBufferDestinationOffset =
    blockIndex * HIT_MESSAGE_BLOCK_SIZE
    + ii * HIT_TRANSFER_BLOCK_SIZE;

  IssueDmaGetAsync( (void*) rayBuffer[nextBufferIndex],
                    request.inputRayPacketsBase + nextBufferSourceOffset,
                    RAY_TRANSFER_BLOCK_SIZE,
                    TAG_GROUP_MEGA_PACKET + nextBufferIndex );

  bufferIndex = nextBufferIndex;
  bufferDestinationOffset = nextBufferDestinationOffset;
  ii++;

  // this is the steady-state loop
  // where we always a previous block
  // to wait for, a current one to
  // process, and a next one to start
  // pulling in...

  while( 1 )
  {
    for( ; ii < TRANSFER_BLOCKS_PER_MESSAGE_BLOCK; ii++ )
    {
      unsigned int blockIndex = GetMessageInt( message[messageIndex] );

      unsigned int nextBufferIndex = bufferIndex ^ 1;
      unsigned int nextBufferSourceOffset =
        blockIndex * RAY_MESSAGE_BLOCK_SIZE
        + ii * RAY_TRANSFER_BLOCK_SIZE;
      unsigned int nextBufferDestinationOffset =
        blockIndex * HIT_MESSAGE_BLOCK_SIZE
        + ii * HIT_TRANSFER_BLOCK_SIZE;

      IssueDmaGetAsync( (void*) rayBuffer[nextBufferIndex],
                        request.inputRayPacketsBase + nextBufferSourceOffset,
                        RAY_TRANSFER_BLOCK_SIZE,
                        TAG_GROUP_MEGA_PACKET + nextBufferIndex );

      IssueDmaWait( TAG_GROUP_MEGA_PACKET + bufferIndex );

      ProcessMegaPacket( rayBuffer[bufferIndex],
                         hitBuffer[bufferIndex],
                         BUNDLES_PER_TRANSFER_BLOCK );

      IssueDmaSetAsync( (void*) hitBuffer[bufferIndex],
                        request.outputHitPacketsBase
                          + bufferDestinationOffset,
                        HIT_TRANSFER_BLOCK_SIZE,
                        TAG_GROUP_MEGA_PACKET + bufferIndex );

      bufferIndex = nextBufferIndex;
      bufferDestinationOffset = nextBufferDestinationOffset;
    }

    unsigned int nextMessageIndex = messageIndex ^ 1;
    message[nextMessageIndex] = ReadMessage();
    if( GetMessageTag(message[nextMessageIndex]) == MESSAGE_PPU_END_FRAME )
      break;

    messageIndex = nextMessageIndex;
    ii = 0;
  }

  // finish any remaining transfer block
  IssueDmaWait( TAG_GROUP_MEGA_PACKET + bufferIndex );

  ProcessMegaPacket( rayBuffer[bufferIndex],
                     hitBuffer[bufferIndex],
                     BUNDLES_PER_TRANSFER_BLOCK );

  IssueDmaSetAndWait( (void*) hitBuffer[bufferIndex],
                      request.outputHitPacketsBase
                        + bufferDestinationOffset,
                      HIT_TRANSFER_BLOCK_SIZE );
}

/*
 * PrintCollectedResults --
 *
 *      Write all relevant data collected
 *      to standard output for the user.
 *
 * Returns:
 *      void.
 */

static void
PrintCollectedResults()
{
#ifdef ENABLE_NODE_CACHE
#ifdef COLLECT_CACHE_STATS
  printf( "node cache: fetch %ld hit %ld (%f%%) miss %ld (%f%%)\n",
          gNodeCacheGetCount,
          gNodeCacheGetCount - gNodeCacheMissCount,
          (float) (gNodeCacheGetCount - gNodeCacheMissCount)
             / (float) gNodeCacheGetCount,
          gNodeCacheMissCount,
          (float) gNodeCacheMissCount / (float) gNodeCacheGetCount );

  gNodeCacheGetCount = 0;
  gNodeCacheMissCount = 0;

#endif
#endif

#ifdef ENABLE_TRIANGLE_CACHE
#ifdef COLLECT_CACHE_STATS
  printf( "tri cache: fetch %ld hit %ld (%f%%) miss %ld (%f%%)\n",
          gTriangleCacheGetCount,
          gTriangleCacheGetCount - gTriangleCacheMissCount,
          (float) (gTriangleCacheGetCount - gTriangleCacheMissCount)
             / (float) gTriangleCacheGetCount,
          gTriangleCacheMissCount,
          (float) gTriangleCacheMissCount / (float) gTriangleCacheGetCount );

  gTriangleCacheGetCount = 0;
  gTriangleCacheMissCount = 0;

#endif
#endif

#ifdef ENABLE_PROFILER
  printf( "total: %lld DMAGet: %lld DMASet: %lld Isect: %lld Trav: %lld Split: %lld SplitNode: %lld\n",
          gTotalTime,
          gTotalDmaGetTime,
          gTotalDmaSetTime,
          gTotalIntersectTime,
          gTotalTraverseTime,
          gTraverseSplitTime,
          gSplitGetNodeTime );
#endif

  STATS_ONLY(
             printf( "STAT packet size %d, node cache %d bytes, tri cache %d bytes, line size %d bytes\n",
                     (int)( BUNDLE_SIZE*BUNDLES_PER_PACKET ),
                     (int)( NODE_CACHE_LINE_COUNT*CACHE_LINE_SIZE ),
                     (int)( TRIANGLE_CACHE_LINE_COUNT*CACHE_LINE_SIZE ),
                     (int)( CACHE_LINE_SIZE ) );
                     
  )

  STATS_PRINT( gDivergentPacketCount );
  STATS_PRINT( gExpandedPacketCount );
  STATS_PRINT( gPacketNodeCount );
  STATS_PRINT( gPacketMaxNodeCount );
  STATS_PRINT( gPacketTriangleCount );
  STATS_PRINT( gPacketMaxTriangleCount );
  STATS_PRINT( gBundleTriangleCount );
  STATS_PRINT( gBadPacketCount );
  STATS_PRINT( gMissSceneCount );
  STATS_PRINT( gStackEmptyCount );
  STATS_PRINT( gNormalCount );

  STATS_CLEAR( gDivergentPacketCount );
  STATS_CLEAR( gExpandedPacketCount );
  STATS_CLEAR( gPacketNodeCount );
  STATS_CLEAR( gPacketMaxNodeCount );
  STATS_CLEAR( gPacketTriangleCount );
  STATS_CLEAR( gPacketMaxTriangleCount );
  STATS_CLEAR( gBundleTriangleCount );
  STATS_CLEAR( gBadPacketCount );
  STATS_CLEAR( gMissSceneCount );
  STATS_CLEAR( gStackEmptyCount );
  STATS_CLEAR( gNormalCount );
}

/*
 * ProcessFrames --
 *
 *      Respond to frames sent from the PPE
 *      until MESSAGE_TERMINATE_THREAD is
 *      received.
 *
 * Returns:
 *      void.
 */
static void
ProcessFrames()
{
  // don't prefetch between frames,
  // since we are trying to measure
  // speed of light
#ifdef ENABLE_NODE_PREFETCH
  PrefetchNodes();
#endif
#ifdef ENABLE_TRIANGLE_PREFETCH
  PrefetchTriangles();
#endif

  while( 1 )
  {
    // re-initialize the node
    // and triangle caches between
    // frames to simulate a case
    // where scene data changes per-frame
#ifdef ENABLE_NODE_CACHE
    InitializeNodeCache();
#endif
#ifdef ENABLE_TRIANGLE_CACHE
    InitializeTriangleCache();
#endif

    // read the next request from the PPE
    // and terminate if it is the 'terminate thread'
    // request
    unsigned int message = ReadMessage();
    if( GetMessageTag(message) == MESSAGE_PPU_END_THREAD )
      break;

    // otherwise this is the first message for
    // a frame's worth of data, so process  the frame
    assert( GetMessageTag(message) == MESSAGE_PPU_BEGIN_FRAME );

    unsigned int requestPointer = GetMessagePointer(message);

    // read in context data... ugh...
    IssueDmaGetAndWait( (void*) &request,
                        requestPointer,
                        sizeof(request) );


    // read the first message of the new frame...
    message = ReadMessage();
    ProcessFrame( message );

    PrintCollectedResults();

    // inform the host that we are done
    spu_writech( SPU_WrOutMbox, MESSAGE_SPU_FRAME_DONE );
  }
}

int
main( unsigned long long inThreadID,
      unsigned long long inContextPointer )
{
  // initialize profiler
  PROFILE_INITIALIZE()

  // read in frame-independent data
  IssueDmaGetAndWait( (void*) &request,
                      inContextPointer,
                      sizeof(request) );

  // let the PPE know we are ready
  spu_writech( SPU_WrOutMbox, MESSAGE_SPU_READY );

  // main loop - process one or more frames
  PROFILE_BEGIN( gTotalTime )
  ProcessFrames();
  PROFILE_END( gTotalTime )

  return 0;
}
