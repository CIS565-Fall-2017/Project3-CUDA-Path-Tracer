// Copyright (C) 2006 Tim Foley

/*
 * stats.h --
 *      Macros for computing and printing stats.
 */

#ifndef __SPU_STATS_H__
#define __SPU_STATS_H__

#if !defined(ENABLE_STATS)

#define STATS_ONLY( _stuff ) /* empty */

#define STATS_DEFINE(_name) /* empty */
#define STATS_INC(_name) /* empty */
#define STATS_PRINT(_name) /* empty */
#define STATS_CLEAR(_name) /* empty */

#else

#define STATS_ONLY( _stuff ) _stuff

#define STATS_DEFINE( _name ) unsigned long long _name = 0;
#define STATS_INC( _name ) _name ++ ;
#define STATS_PRINT( _name ) printf( "STAT " #_name ": %lld\n", _name );
#define STATS_CLEAR( _name ) _name = 0;

#endif

#endif
