/* request.h */

#ifndef REQUEST_H
#define REQUEST_H

// to get the definition of BUNDLE_SIZE
#include "../f3.h"

#ifdef __cplusplus
extern "C" {
#endif

#define USE_TRI_ACCEL

// number of SIMD bundles in a packet
#define BUNDLES_PER_PACKET 8

// number of bundles per group
// we DMA in
#define BUNDLES_PER_TRANSFER_BLOCK 128
#define RAY_TRANSFER_BLOCK_SIZE \
  (BUNDLES_PER_TRANSFER_BLOCK * sizeof(RayBundle))
#define HIT_TRANSFER_BLOCK_SIZE \
  (BUNDLES_PER_TRANSFER_BLOCK * sizeof(HitBundle))

#define BUNDLES_PER_MESSAGE_BLOCK 1024
#define RAY_MESSAGE_BLOCK_SIZE \
  (BUNDLES_PER_MESSAGE_BLOCK * sizeof(RayBundle))
#define HIT_MESSAGE_BLOCK_SIZE \
  (BUNDLES_PER_MESSAGE_BLOCK * sizeof(HitBundle))
#define TRANSFER_BLOCKS_PER_MESSAGE_BLOCK \
  (BUNDLES_PER_MESSAGE_BLOCK / BUNDLES_PER_TRANSFER_BLOCK)

#define MESSAGE_TAG_MASK            0xF

// PPU->SPU messages
#define MESSAGE_PPU_BEGIN_FRAME     0x0
#define MESSAGE_PPU_END_FRAME       0x1
#define MESSAGE_PPU_END_THREAD      0x2
#define MESSAGE_PPU_PROCESS_BLOCK   0x3

// SPU->PPU messages
#define MESSAGE_SPU_READY           0x1
#define MESSAGE_SPU_FRAME_DONE      0x2

typedef struct RequestContext_t
{
  unsigned int inputRayPacketsBase;
  unsigned int inputNodesBase;
  unsigned int inputTrianglesBase;
  unsigned int outputHitPacketsBase;

  float bboxMin[3];
  float bboxMax[3];
  int inputRayPacketCount;
  int inputNodeCount;

  int inputTriangleCount;
  int padding[3];
} RequestContext;

typedef union Float3Bundle_t
{
  struct
  {
    vector float bundle[3];
  };
  struct
  {
    float array[3][4];
  };
} Float3Bundle;

typedef struct RayBundle_t
{
  Float3Bundle origin;
  Float3Bundle direction;
} RayBundle;

typedef union HitBundle_t
{
  struct
  {
    vector float time;
    vector float u;
    vector float v;
    vector signed int triangleIndex;
  };
  struct
  {
    float time[BUNDLE_SIZE];
    float u[BUNDLE_SIZE];
    float v[BUNDLE_SIZE];
    int triangleIndex[BUNDLE_SIZE];
  } array;
} HitBundle;

typedef union Node_t
{
  struct
  {
    unsigned int leftChildIndex;
    float splitValue;
  } split;
  
  struct
  {
    unsigned int primitiveCount;
    unsigned int firstPrimitiveIndex;
  } leaf;  
} Node;

typedef union Triangle_t
{
  // we pad it out to 3 float4s
  // so that it will be 16-byte
  // aligned

  struct
  {
    vector float a;
    vector float b;
    vector float c;
    vector float pad;
  };
  float array[4][4];
} Triangle;

#ifdef __cplusplus
}
#endif

#endif
