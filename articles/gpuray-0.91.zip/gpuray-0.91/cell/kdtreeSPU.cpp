/*
 * kdtreeSPU.cpp --
 *
 *      k-D tree spatial subdivision accelerator.
 */
#include "kdtreeSPU.h"

#include <errno.h>
extern "C" {
#include <libspe.h>
}

#include "../scenecache.h"
#include "../log.h"
#include "../timer.h"
#include "../cpu/cpuTracer.h"
#include "../cpu/kdtreeCPU.h"

#include "request.h"

extern spe_program_handle_t spuKdTreeKernel;


KDTreeSPU::KDTreeSPU(const Scene& scene, const Opts& options)
{
  _threadCount = GetKeyValueInt( "speCount", options.accelOpts, 8 );
  if( _threadCount < 1 || _threadCount > kMaximumThreadCount )
  {
    fprintf( stderr, "Invalid SPE thread count %d.\n", _threadCount );
    exit( 1 );
  }

  _repeatFrameSubmitCount = GetKeyValueInt(
    "frameCount", options.accelOpts, 1 );
  if( _repeatFrameSubmitCount < 1 )
  {
    fprintf( stderr, "Invalid frame count %d.\n", _repeatFrameSubmitCount );
    exit( 1 );
  }

  KDTreeBuildOptions buildOptions;

  KDTree* builtTree = BuildKDTreeCached( options, &scene, buildOptions );

  BoundingBox bounds = builtTree->getBounds();
  for( uint32 ii = 0; ii < 3; ii++ )
  {
    _bboxMin.v[ii] = bounds.minimum[ii];
    _bboxMax.v[ii] = bounds.maximum[ii];
  }

  _nodeCount = builtTree->getNodeCount();
  const KDTreeNode* builtNodes = builtTree->getNodes();

  _nodes = (SpuKdTreeNode*) AllocateAligned(
    _nodeCount * sizeof(SpuKdTreeNode), 128 );
  for( uint32 ii = 0; ii < _nodeCount; ii++ )
  {
      KDTreeNode builtNode = builtNodes[ii];
      SpuKdTreeNode& node = _nodes[ii];

      uint32 splitAxis = builtNode.split.leftChild & 0x3;

      if( splitAxis == 0x3 )
      {
         uint32 firstPrimitiveIndex, primitiveCount;

         primitiveCount = builtNode.leaf.numPrimitives;
         firstPrimitiveIndex = builtNode.leaf.firstPrimitive >> 2;

         node.leaf.primitiveCount_tag = (primitiveCount << 2) | 0x3;
         node.leaf.firstPrimitiveIndex =
           firstPrimitiveIndex * sizeof(SpuKdTreeTriangle);
      }
      else
      {
         float splitValue;
         uint32 leftChild;

         splitValue = builtNode.split.splitValue;
         leftChild = builtNode.split.leftChild >> 3;

         assert( leftChild % 1 == 0 );

         node.split.leftChildIndex_splitAxis = (leftChild << 3) | splitAxis;
         node.split.splitValue = splitValue;
      }
   }

   uint32 triangleIndexCount = builtTree->getPrimitiveIndexCount();
   const int* builtIndices = builtTree->getPrimitiveIndices();

   _triangleCount = triangleIndexCount;
   _triangleIDs = new uint32[ _triangleCount ];
   _triangleData = (SpuKdTreeTriangle *) AllocateAligned(
     _triangleCount * sizeof(SpuKdTreeTriangle), 128 );

   const F3* v0 = scene.vertices(0);
   const F3* v1 = scene.vertices(1);
   const F3* v2 = scene.vertices(2);

   for( uint32 ii = 0; ii < triangleIndexCount; ii++ )
   {
      uint32 triangleIndex = _triangleIDs[ii] = builtIndices[ii];

      SpuKdTreeTriangle packet;

#ifdef USE_TRI_ACCEL
      assert( sizeof(F3Packet) == sizeof(TriAccel) );
      KDTreeAccelCPU::ComputeTriAccel( triangleIndex,
                                       v0[triangleIndex],
                                       v1[triangleIndex],
                                       v2[triangleIndex],
                                       (TriAccel *) &packet );
      
#else
      F3 triV0, e1, e2, e2xe1;

      triV0 = v0[triangleIndex];
      F3_SUB(e1, v1[triangleIndex], v0[triangleIndex]);
      F3_SUB(e2, v2[triangleIndex], v0[triangleIndex]);
      F3_CROSS(e2xe1, e2, e1);

      packet.v[0] = triV0.v[0];
      packet.v[1] = e1.v[0];
      packet.v[2] = e2.v[0];
      packet.v[3] = e2xe1.v[0];

      packet.v[4] = triV0.v[1];
      packet.v[5] = e1.v[1];
      packet.v[6] = e2.v[1];
      packet.v[7] = e2xe1.v[1];

      packet.v[8] = triV0.v[2];
      packet.v[9] = e1.v[2];
      packet.v[10] = e2.v[2];
      packet.v[11] = e2xe1.v[2];
#endif

      _triangleData[ii] = packet;
   }

   delete builtTree;

   initializeThreads();
}

KDTreeSPU::~KDTreeSPU(void)
{
  finalizeThreads();
}

uint32
KDTreeSPU::getBatchGranularity()
{
  return BUNDLES_PER_MESSAGE_BLOCK*4;
}

void
KDTreeSPU::intersect(const RayCPU rays[],
                     uint32 numRays, HitCPU hits[])
{
  // we fill in the request structure again for this frame,
  // even though a lot of this data was specified at the
  // thread startup... this should get factored into two
  // pieces of data (per-scene and per-frame).
  RequestContext* request = (RequestContext*) AllocateAligned(
    sizeof(RequestContext), kAlignment );

  assert( numRays % BUNDLE_SIZE == 0 );

  uint32 rayBundleCount = numRays / BUNDLE_SIZE;
  RayBundle* rayBundles = (RayBundle*) rays;

  request->inputRayPacketsBase = (unsigned long) rayBundles;
  request->outputHitPacketsBase = (unsigned long) hits;
  request->inputRayPacketCount = 0; // XXX: unused
  request->inputNodesBase = (unsigned long) _nodes;
  request->inputTrianglesBase = (unsigned long) _triangleData;
  request->inputNodeCount = _nodeCount;
  request->inputTriangleCount = _triangleCount;
  
  for( int j = 0; j < 3; j++ )
  {
    request->bboxMin[j] = _bboxMin.v[j];
    request->bboxMax[j] = _bboxMax.v[j];
  }

  float startTime = Timer_GetMS();

  static unsigned int kMegaPacketSize = BUNDLES_PER_MESSAGE_BLOCK;


  // submit this one frame of data multiple times,
  // so that we can measure throughput rather than
  // the end-to-end time of a single frame...
  for( uint32 jj = 0; jj < _repeatFrameSubmitCount; jj++ )
  {
    // inform all the SPEs of start of frame
    for( uint32 i = 0; i < _threadCount; i++ )
    {
      // wait until an open slot is available in the mailbox
      while( spe_stat_in_mbox( _speThreadIDs[i] ) == 0 )
        ;
      unsigned int requestPointer = (unsigned int) request;
      spe_write_in_mbox( _speThreadIDs[i],
                         requestPointer | MESSAGE_PPU_BEGIN_FRAME );
    }

    int blockCount = rayBundleCount / kMegaPacketSize;
    int blockIndex = 0;

    while( true )
    {
      if( blockCount == 0 )
        break;

      for( uint32 i = 0; i < _threadCount; i++ )
      {
#if 0
        // check for debug messages from the SPU
        if( spe_stat_out_mbox( _speThreadIDs[i] ) != 0 )
        {
          unsigned int m = spe_read_out_mbox( _speThreadIDs[i] );
          PRINT(("SPE message %d %f\n", m, *((float*) &m)));
        }
#endif
        // check number of free slots in threads
        // input queue
        if( spe_stat_in_mbox( _speThreadIDs[i] ) != 0 )
        {
          // if there is an available slot,
          // fill it
          spe_write_in_mbox( _speThreadIDs[i], 
                             (blockIndex << 4) | MESSAGE_PPU_PROCESS_BLOCK );
          blockIndex++;
          blockCount--;
          if( blockCount == 0 )
            break;
        }
      }
    }
    
    // inform all the SPEs of end-of-frame
    // in case they want to invalidate cache or anything
    for( uint32 i = 0; i < _threadCount; i++ )
    {
      // wait until an open slot is available in the mailbox
      while( spe_stat_in_mbox( _speThreadIDs[i] ) == 0 )
        ;
      spe_write_in_mbox( _speThreadIDs[i], MESSAGE_PPU_END_FRAME );
    }

    // wait for the response from the SPEs
    uint32 doneThreadCount = 0;
    while( doneThreadCount < _threadCount )
    {
      for( uint32 i = 0; i < _threadCount; i++ )
      {
        if( spe_stat_out_mbox( _speThreadIDs[i] ) != 0 )
        {
          unsigned int message = spe_read_out_mbox( _speThreadIDs[i] );
          if( (message & MESSAGE_TAG_MASK) == MESSAGE_SPU_FRAME_DONE )
            doneThreadCount++;
        }
      }
    }
  }

  // we are now guaranteed to have all the frame's
  // hits back in PPE memory, so we can stop our timer

  float stopTime = Timer_GetMS();

  FreeAligned( request );

#ifndef USE_TRI_ACCEL
  // we must "mangle" all the hits to have correct triangle IDs
  // (rather than indices into the expanded triangle list)
  for( uint32 ii = 0; ii < rayBundleCount; ii++ )
  {
    for( uint32 jj = 0; jj < 4; jj++ )
    {
      int triangleIndex = hits[ii].triNum[jj];
      int triangleID;
      if( triangleIndex >= 0 )
      {
        assert( triangleIndex < (int) _triangleCount );
        triangleID = _triangleIDs[ triangleIndex ];
      }
      else
        triangleID = -1;
      hits[ii].triNum[jj] = triangleID;
    }
  }
#endif

  float elapsedSeconds = (stopTime - startTime) * 0.001f;
  float elapsedMicroseconds = (stopTime - startTime) * 1000.0f;

  long totalRayCount = rayBundleCount * BUNDLE_SIZE * _repeatFrameSubmitCount;

  float megaRays = (float) totalRayCount / (float) elapsedMicroseconds;
  float megaRaysPerSpe = megaRays / _threadCount;

  PRINT(( "CELL: %fs for %ld rays (%fMrays/s) (%fMRays/s/SPE)\n",
          elapsedSeconds,
          totalRayCount,
          megaRays,
          megaRaysPerSpe ));
}

void
KDTreeSPU::intersectPacket(const RayCPU rays[],
                           uint32 numRays, HitCPU hits[])
{
  intersect( rays, numRays, hits );
}

void
KDTreeSPU::intersectP(const RayCPU rays[],
                      uint32 numRays, HitCPU hits[])
{
  intersect( rays, numRays, hits );
}

void
KDTreeSPU::intersectPacketP(const RayCPU rays[],
                            uint32 numRays, HitCPU hits[])
{
  intersect( rays, numRays, hits );
}

void
KDTreeSPU::initializeThreads()
{
  spe_program_handle_t* programHandle = &spuKdTreeKernel;

  // allocate a buffer to hold static information
  // for the various processing threads...
  // XXX: we allocate kThreadCount of these,
  // although they currently all contain identical data
  RequestContext* request = (RequestContext*) AllocateAligned(
    sizeof(RequestContext), kAlignment );

  request->inputRayPacketsBase = (unsigned long) NULL;
  request->outputHitPacketsBase = (unsigned long) NULL;
  request->inputRayPacketCount = 0; // XXX: unused
  request->inputNodesBase = (unsigned long) _nodes;
  request->inputTrianglesBase = (unsigned long) _triangleData;
  request->inputNodeCount = _nodeCount;
  request->inputTriangleCount = _triangleCount;
  
  for( uint32 j = 0; j < 3; j++ )
  {
    request->bboxMin[j] = _bboxMin.v[j];
    request->bboxMax[j] = _bboxMax.v[j];
  }

  for( uint32 i = 0; i < _threadCount; i++ )
  {
    _speThreadIDs[i] = spe_create_thread( 0,
                                          programHandle,
                                          (void*) request,
                                          NULL,
                                          (unsigned long) -1,
                                          0 );
    
    if( _speThreadIDs[i] == 0 )
    {
      fprintf( stderr, "Failed to create SPE thread %d (errno %d)\n", i, errno);

      fprintf( stderr, "ENOMEM %d EINVAL %d EPERM %d ESRCH %d\n",
               ENOMEM, EINVAL, EPERM, ESRCH );

      exit(1);
    }
  }

  // wait for the threads to signal that they have started
  for( uint32 i = 0; i < _threadCount; i++ )
  {
    while( spe_stat_out_mbox( _speThreadIDs[i] ) == 0 )
      ;
    unsigned int message = spe_read_out_mbox( _speThreadIDs[i] );
    assert( (message & MESSAGE_TAG_MASK) == MESSAGE_SPU_READY );
  }

  // we can now free the request structure
  FreeAligned( request );

  // the threads are started and ready to serve
  // as ray-tracing "servers". We start timing
  // now, as we launch the job

}

void
KDTreeSPU::finalizeThreads()
{
  // we must now inform each thread that we are shutting down
  for( uint32 i = 0; i < _threadCount; i++ )
  {
    // wait until an open slot is available in the mailbox
    while( spe_stat_in_mbox( _speThreadIDs[i] ) == 0 )
      ;
    spe_write_in_mbox( _speThreadIDs[i], MESSAGE_PPU_END_THREAD );
  }

  // wait for the threads to terminate
  for( uint32 i = 0; i < _threadCount; i++ )
  {
    int status;
    spe_wait( _speThreadIDs[i], &status, 0 );
  }
}
