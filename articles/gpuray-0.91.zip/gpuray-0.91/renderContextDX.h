/* *************************************************************************
 * Copyright (C) 2005 Jeremy Sugerman
 * All Rights Reserved
 * *************************************************************************/

/*
 * renderContextDX.h --
 *
 *      DirectX implementation of the IRenderSystem interface.
 */

#ifndef __RENDERCONTEXTDX_H__
#define __RENDERCONTEXTDX_H__

#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "renderContext.h"

struct DXVertex
{
   float x, y, z, w;
   float tx, ty, tz, tw;
};

class RenderSystemDX9 : public IRenderSystem
{
    int _width;
    int _height;
public:
    int width(){return _width;}
    int height(){return _height;}
    RenderSystemDX9(int width, int height){_width=width;_height=height;}
   const char* getRenderSystemID();
   IRenderContext* createRenderContext( HWND inWindowHandle );
};

class RenderContextDX9 : public IRenderContext
{
public:
   RenderContextDX9( RenderSystemDX9* inRenderSystem, HWND inWindowHandle );

   IRenderSystem* getRenderSystem();
   void* getContextHandle();

   void resize( int inWidth, int inHeight );

   IDirect3DDevice9* getDevice();
   IDirect3DSurface9* getDefaultRenderTarget();

private:
   RenderSystemDX9* _renderSystem;

   IDirect3D9* _direct3d;
   IDirect3DDevice9* _device;
   IDirect3DSurface9* _defaultRenderTarget;
};


static inline void
DX9Warn( const char* inFormat, ... ) {
}

static inline void
DX9AssertResult( HRESULT inResult, const char* inMessage )
{
   if( !FAILED(inResult) ) return;
   std::cerr << inMessage << std::endl;
   abort();
}


#endif
