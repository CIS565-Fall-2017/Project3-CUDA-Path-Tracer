#pragma once

// If MEASURE_EXECUTION_TIMES is defined, the execution time of all kernels will be measured
#define MEASURE_EXECUTION_TIMES

// What kind of data structure to use for the BVH tree? SOA or AOS
#define SOA
