var searchData=
[
  ['offset',['Offset',['../structcub_1_1_item_offset_pair.html#ac541377b1ef1b842825716a85acd5009',1,'cub::ItemOffsetPair']]]
];
