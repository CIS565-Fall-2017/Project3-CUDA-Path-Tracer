var searchData=
[
  ['warp_2dwide_20_28collective_29',['Warp-wide (collective)',['../group___warp_module.html',1,'']]]
];
