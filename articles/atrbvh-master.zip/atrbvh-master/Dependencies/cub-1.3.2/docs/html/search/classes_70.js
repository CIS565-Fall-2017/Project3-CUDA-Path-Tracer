var searchData=
[
  ['poweroftwo',['PowerOfTwo',['../structcub_1_1_power_of_two.html',1,'cub']]]
];
