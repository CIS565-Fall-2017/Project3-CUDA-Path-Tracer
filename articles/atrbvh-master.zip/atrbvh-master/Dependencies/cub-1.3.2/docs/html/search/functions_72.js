var searchData=
[
  ['reduce',['Reduce',['../classcub_1_1_block_reduce.html#a089953b3bdfe7c48208632d0cc2ac1fb',1,'cub::BlockReduce::Reduce(T input, ReductionOp reduction_op)'],['../classcub_1_1_block_reduce.html#a81878a614ef3b39de654918fc1f6144d',1,'cub::BlockReduce::Reduce(T(&amp;inputs)[ITEMS_PER_THREAD], ReductionOp reduction_op)'],['../classcub_1_1_block_reduce.html#a0e947f6a1d812d21839632b87aaf32e5',1,'cub::BlockReduce::Reduce(T input, ReductionOp reduction_op, int num_valid)'],['../structcub_1_1_device_reduce.html#a834eccddb91e7b5f03e219ab5e7d2c0f',1,'cub::DeviceReduce::Reduce()'],['../classcub_1_1_warp_reduce.html#a0dd72fc4cf7e1ecf59e8b15bd6819185',1,'cub::WarpReduce::Reduce(T input, ReductionOp reduction_op)'],['../classcub_1_1_warp_reduce.html#ad1ecfeddf0e7fb3f359cf61b60f4745a',1,'cub::WarpReduce::Reduce(T input, ReductionOp reduction_op, int valid_items)']]],
  ['reducebykey',['ReduceByKey',['../structcub_1_1_device_reduce.html#a4822e04d8701b10ac3f2d28effb454d3',1,'cub::DeviceReduce']]],
  ['rowmajortid',['RowMajorTid',['../group___util_ptx.html#gaa3f839b109cc6dc9d9ece4f1acf7d2ce',1,'cub']]],
  ['runlengthencode',['RunLengthEncode',['../structcub_1_1_device_reduce.html#abd3971072f62f2874bf7ea956ec9817f',1,'cub::DeviceReduce']]]
];
