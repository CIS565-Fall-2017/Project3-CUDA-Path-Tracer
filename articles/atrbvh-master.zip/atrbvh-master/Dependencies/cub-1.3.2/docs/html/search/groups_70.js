var searchData=
[
  ['primitives',['Primitives',['../group___primitive_module.html',1,'']]],
  ['ptx_20intrinsics',['PTX intrinsics',['../group___util_ptx.html',1,'']]]
];
