var searchData=
[
  ['block_2dwide_20_28collective_29',['Block-wide (collective)',['../group___block_module.html',1,'']]]
];
