var searchData=
[
  ['prmt',['PRMT',['../group___util_ptx.html#ga7b6445f3d02d31c17d9d33c67fcffcb1',1,'cub']]],
  ['ptxversion',['PtxVersion',['../group___util_mgmt.html#ga274acbdeef0a8f56373501323ef51d05',1,'cub']]]
];
