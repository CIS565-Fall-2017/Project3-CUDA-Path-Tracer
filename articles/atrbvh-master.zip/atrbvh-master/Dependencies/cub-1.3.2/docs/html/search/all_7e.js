var searchData=
[
  ['_7ecachingdeviceallocator',['~CachingDeviceAllocator',['../structcub_1_1_caching_device_allocator.html#a2a521f7464d3eee98486b4d321fc8cc7',1,'cub::CachingDeviceAllocator']]]
];
