var searchData=
[
  ['flagged',['Flagged',['../structcub_1_1_device_partition.html#a84ca1ba3be36800927d8220a05a75e08',1,'cub::DevicePartition::Flagged()'],['../structcub_1_1_device_select.html#a4bdafa080cce999f8694c820fd567c83',1,'cub::DeviceSelect::Flagged()']]],
  ['flagheads',['FlagHeads',['../classcub_1_1_block_discontinuity.html#ab219179e48df220e7fde27c86e28dca1',1,'cub::BlockDiscontinuity::FlagHeads(FlagT(&amp;head_flags)[ITEMS_PER_THREAD], T(&amp;input)[ITEMS_PER_THREAD], FlagOp flag_op)'],['../classcub_1_1_block_discontinuity.html#ae00129d2763e49959d3a29f51cfe8755',1,'cub::BlockDiscontinuity::FlagHeads(FlagT(&amp;head_flags)[ITEMS_PER_THREAD], T(&amp;input)[ITEMS_PER_THREAD], FlagOp flag_op, T tile_predecessor_item)']]],
  ['flagtails',['FlagTails',['../classcub_1_1_block_discontinuity.html#a47f3d8cd0955d59bd86a6f4772a37f27',1,'cub::BlockDiscontinuity::FlagTails(FlagT(&amp;tail_flags)[ITEMS_PER_THREAD], T(&amp;input)[ITEMS_PER_THREAD], FlagOp flag_op)'],['../classcub_1_1_block_discontinuity.html#a8e3ac8c56afab6e1e4f2e66b8b5160d3',1,'cub::BlockDiscontinuity::FlagTails(FlagT(&amp;tail_flags)[ITEMS_PER_THREAD], T(&amp;input)[ITEMS_PER_THREAD], FlagOp flag_op, T tile_successor_item)']]],
  ['freeallcached',['FreeAllCached',['../structcub_1_1_caching_device_allocator.html#afbe43fd3a59ba6f4b974a4a66315c86e',1,'cub::CachingDeviceAllocator']]]
];
