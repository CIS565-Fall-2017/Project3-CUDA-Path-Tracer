var searchData=
[
  ['debug',['Debug',['../group___util_mgmt.html#ga5a175d2a88f63f7f1ab30e8b4f2cfa95',1,'cub']]],
  ['deviceallocate',['DeviceAllocate',['../structcub_1_1_caching_device_allocator.html#a4a6fd29b17ff15c6a2ee01a25c5e45fb',1,'cub::CachingDeviceAllocator::DeviceAllocate(void **d_ptr, size_t bytes, int device)'],['../structcub_1_1_caching_device_allocator.html#a7d8a199c902d88ed14f0433bdf94318c',1,'cub::CachingDeviceAllocator::DeviceAllocate(void **d_ptr, size_t bytes)']]],
  ['devicefree',['DeviceFree',['../structcub_1_1_caching_device_allocator.html#aafd80ae2cdadb883fe1da0c8a549228c',1,'cub::CachingDeviceAllocator::DeviceFree(void *d_ptr, int device)'],['../structcub_1_1_caching_device_allocator.html#adbf65c59172b140420636e150325deeb',1,'cub::CachingDeviceAllocator::DeviceFree(void *d_ptr)']]],
  ['doublebuffer',['DoubleBuffer',['../structcub_1_1_double_buffer.html#a8d51dcd30484a1f186e056eb7ab09979',1,'cub::DoubleBuffer::DoubleBuffer()'],['../structcub_1_1_double_buffer.html#a100c51f0e1aefdff4cdfe6480c89f59e',1,'cub::DoubleBuffer::DoubleBuffer(T *d_current, T *d_alternate)']]]
];
