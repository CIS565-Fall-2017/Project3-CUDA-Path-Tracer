var searchData=
[
  ['log2',['Log2',['../structcub_1_1_log2.html',1,'cub']]]
];
