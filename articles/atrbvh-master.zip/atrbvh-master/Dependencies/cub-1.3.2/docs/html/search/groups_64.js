var searchData=
[
  ['device_2dwide',['Device-wide',['../group___device_module.html',1,'']]],
  ['device_2c_20kernel_2c_20and_20storage_20management',['Device, kernel, and storage management',['../group___util_mgmt.html',1,'']]]
];
